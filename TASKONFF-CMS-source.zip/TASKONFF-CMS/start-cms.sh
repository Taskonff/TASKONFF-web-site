#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
node scripts/check-node.mjs
if [ ! -d node_modules ]; then
  npm ci
fi
npm run admin:setup
npm run build
exec npm start
