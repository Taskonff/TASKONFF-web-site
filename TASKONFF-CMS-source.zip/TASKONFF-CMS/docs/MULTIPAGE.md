# Multipage implementation

Built on the published homepage snapshot. No environment publication or repository push was performed.

## Routes

For both `/ru` and `/en`:

- `/`: existing homepage, retained animated digital engine and interactive scenarios.
- `/about`: company approach, principles and capability navigation.
- `/services`: searchable, filterable service catalog.
- `/services/[service]`: ten distinct service descriptions, scope, deliverables, workflow, decision criteria and FAQ.
- `/industries`: six explicitly proposed application scenarios with selectable workflow steps.
- `/portfolio`: designed publication state without fabricated case studies.
- `/technologies`: interactive architecture-layer explorer and technology choices.
- `/process`: interactive project phases, deliverables and FAQ.
- `/contact`: brief form, preparation guidance and FAQ.
- `/privacy`, `/terms`: clearly marked draft legal information, noindex/nofollow pending legal approval.

Forty localized HTML routes total. Service slugs and titles are centralized in `src/content/services.ts`; company/trust content lives in separate typed modules. Future CMS providers can replace content access without moving route or presentation ownership.

## Shared shell and motion

The locale layout owns a single Header, Footer and scroll progress indicator. Next Link navigates real pages; current section is marked, language switching preserves the page/service route, and the mobile menu supports Escape. All site sections appear in the footer. Localized 404 content is provided.

The locale template wraps content in a route-entry animation that also responds to deeper pathname changes. Shared `InternalHero` and `PageCTA` define visual hierarchy; each content family owns scoped CSS and its own interaction components. Motion respects reduced motion. The existing hero pauses offscreen/when hidden and includes manual pause controls.

## Server-generated brief

`POST /api/brief` validates the actual submitted payload using Zod and returns a UTF-8 downloadable brief in the selected language. The browser shows loading/failure/success states. The application neither persists the message nor sends the inquiry to the team. This changes the earlier local-only workflow: personal data is now transiently processed by the site server, which is reflected in the interface and draft privacy text.

Protections: same-origin checks, JSON content type, bounded streaming body, honeypot, and bounded per-process rate windows. Next.js can construct request URLs from its bind hostname; origin checks use the browser Host unless an official SITE_URL is configured. Forwarded IP headers are never trusted by default. The optional TRUSTED_CLIENT_IP_HEADER requires an ingress that strips untrusted client copies. The shared fallback limit is 60 requests/minute per API scope; a trusted client key uses 10/minute. Use a shared durable limiter before scaling across instances.

`POST /api/contact` is a disabled-by-default delivery boundary. It requires validated data and explicit consent; without CONTACT_FORM_ENABLED=true and a confirmed HTTPS CONTACT_WEBHOOK_URL it returns 503, never a success message. It supports an optional HMAC signature via CONTACT_WEBHOOK_SECRET, an 8-second timeout and no redirects. Provider calls were not made in this task. The current UI generates briefs rather than pretending to send messages. Direct delivery remains pending an approved destination and legal configuration.

## SEO and outstanding facts

Every page has distinct metadata and localized alternates when SITE_URL is set. Sitemap includes homepage, public section pages and ten service routes in each language. Draft legal pages are omitted. Preview indexing stays disabled without an official origin. Open Graph images inherit the localized segment's image route; Next reports a missing metadataBase warning until the official origin is provided.

Original logo file, approved project materials, legal entity/contact details and delivery destination remain outside the available source material. No substitute company history, headcount, metrics, contacts, clients or testimonials were created. Payload/PostgreSQL and analytics are not active integrations.

## Validation in this instance

- Production build generated all routes successfully.
- ESLint and TypeScript passed.
- Five unit/security tests passed.
- Seventeen repository Playwright tests passed, covering the existing homepage, all internal routes in both languages, all service detail routes, mobile/desktop layout, translated-route navigation, distinct metadata, legal noindex, server validation, cross-origin rejection, disabled delivery, and canvas animation/pause/offscreen behavior.
- A rendered-link crawler visited 20 main routes and checked 40 unique internal destinations; all returned 200.
- Additional focused QA checked architecture/process tabs and industry/catalog interactions with keyboard navigation, valid ARIA targets and no overflow/page errors.

Screenshots in the current workspace: `/workspace/taskonff-validation/multipage-{services,industries,about,technologies,process,contact,portfolio,privacy}-{1440,390}.png`.
