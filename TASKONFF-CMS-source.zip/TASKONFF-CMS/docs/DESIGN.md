# Homepage — technology-led redesign

A replacement composition rather than another theme overlay. The previous orbital/panel demo and its CSS have been removed.

## Visual system

- Navy / electric blue / cyan drawn from the supplied TASKONFF logo reference.
- Local variable Manrope including Cyrillic, installed from the fontsource package. No font CDN at runtime.
- Oversized editorial hero typography, subtle grid, white original-logo surfaces, alternating light editorial sections and dark interactive sections, electric-blue project brief.
- Two-column illustrated service bento, cursor-position light response and service-to-brief selection.

## Functional interactions

- `digital-engine.tsx`: perspective-projected toroidal wireframe/particle flow, pointer camera, three topology modes, pause/resume. No stock video, live telemetry or invented company metrics.
- `solution-explorer.tsx`: three clearly labeled proposed solution scenarios with keyboard-accessible tabs and selectable workflow nodes. They are not presented as delivered case studies.
- `service-grid.tsx`: choosing a service populates the brief's area field through a scoped custom event.
- `experience.tsx`: spring scroll progress and animated capability ribbon with a pause control.
- `project-brief.tsx`: local Zod validation and downloadable text. No message delivery is claimed.

## Motion and performance

Canvas DPR is capped, lines are batched, animation pauses offscreen and when the tab is hidden. Reduced motion starts with a static visualization and a Play control. Content remains usable with motion disabled. The canvas never intercepts touch scrolling. Native controls support keyboard use.

## Original logo status

The chat reference is visible to the model but its original binary has not been exposed to the execution environment. File discovery has been repeated independently. No tracing, generated imitation or invented logo is used. `BrandLogo` will render the unchanged original from `public/brand/taskonff-logo.svg`, `.png` or `.webp` after the asset is available and the static pages are rebuilt. Current fallback is the plain company name. This is an unresolved asset dependency, not a completed logo replacement.
