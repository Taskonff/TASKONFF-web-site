# TASKONFF: current CMS architecture

## Application

Next.js16 App Router + React19 + TypeScript. Public routes under `[locale]` cover RU/EN homepage, nine sections and ten service detail pages. Route transitions, the canvas engine, catalog filters, architecture/industry explorers and FAQs remain interactive. Local Manrope supports Cyrillic without a font CDN.

The public locale layout is dynamic and owns Header/Footer plus a serializable `SiteContentProvider`. `getSiteData()` caches `readSiteData()` per request; it composes only published CMS records over typed defaults. Client components use that same snapshot, preventing stale imported dictionaries after editing. Server metadata reads the published content. Static `SITE_URL` configuration determines canonical origins and indexing.

## Content model

Payload3.93.0 uses a SQLite adapter and checked-in initial migration. Collections:

- `users`: authenticated administrators; password and session management use Payload.
- `pages`:21 fixed document keys, bilingual structured content, optional page image, drafts and versions.
- `media`: public raster images with authenticated writes, MIME/signature/decode validation,8MB and32MP bounds.
- `case-studies`: user-supplied localized title, summary, body and image; only published entries render.

The `site-settings` global supplies logo, home image, social-sharing image, page-image slots, brand name and optional real contact details. Page image takes priority over a general image slot. No original company logo or case material is fabricated; users upload/publish their own assets.

`src/cms/defaults.ts` composes page definitions from serializable `src/content/*` dictionaries and validates fixed structure. The custom Payload JSON field renders normal labeled text controls, search, collapsible groups and RU/EN tabs. System route values, icon IDs, keys and list shape remain fixed. Defaults seed only missing documents and never overwrite editors' content.

## Security and storage

No public account creation or default credentials. The local `admin:setup` CLI creates the first account, with hidden password entry or securely supplied environment variables. User hooks block Payload's special first-register bypass. Login lockout, HTTP-only sessions, logout and reset use Payload; CLI password recovery revokes previous sessions. Unconfigured email recovery is blocked before token email generation.

CMS REST mutations require a matching Origin independently of the configured domain. JSON streams are bounded before Payload parsing; media writes reject unauthenticated callers before Sharp decoding. Public queries cannot read draft pages, draft cases or private version history. SVG uploads are not accepted. React renders content as text, without executable rich HTML.

SQLite, media and the private signing key persist in `CMS_DATA_DIR` (default `data/`, outside `public/`). Private files are excluded from build tracing and delivery archives. Back up the whole directory with the server stopped. Deploy on a single persistent Node instance; multi-instance PostgreSQL/object-storage deployment needs its own adapter/migration configuration.

## Forms and export

`/api/brief` validates/generates a document without saving its contents or delivering an inquiry. The optional contact webhook boundary stays disabled until a real destination and policies are configured.

`export:html` reads a published-only snapshot, copies referenced public media and builds an isolated static application without admin/API routes. It converts the brief to browser-only generation and adjusts the explanatory copy. Static files preserve animations and interactions but do not provide CMS functionality. Database files, accounts, sessions and signing secrets are never included.

For first launch and editor instructions see `CMS-README-RU.md`.
