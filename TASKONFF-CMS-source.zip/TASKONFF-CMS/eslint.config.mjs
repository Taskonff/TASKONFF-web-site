import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";
export default defineConfig([
  ...nextVitals,
  ...nextTs,
  globalIgnores([
    ".next/**",
    "next-env.d.ts",
    "exports/**",
    "data/**",
    "cms-data/**",
    "src/cms/payload-types.ts",
    "src/app/(payload)/admin/importMap.ts",
  ]),
]);
