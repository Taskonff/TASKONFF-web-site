import nextEnv from "@next/env";
import { createInterface } from "node:readline/promises";
import { stdin, stdout } from "node:process";
import type { Payload } from "payload";

nextEnv.loadEnvConfig(process.cwd());

async function question(label: string) {
  if (!stdin.isTTY)
    throw new Error(
      "For non-interactive setup, provide ADMIN_EMAIL and ADMIN_PASSWORD as environment variables.",
    );
  const reader = createInterface({ input: stdin, output: stdout });
  try {
    return (await reader.question(label)).trim();
  } finally {
    reader.close();
  }
}

async function passwordQuestion(label: string): Promise<string> {
  if (!stdin.isTTY || !stdin.setRawMode) {
    throw new Error(
      "For non-interactive setup, provide ADMIN_EMAIL and ADMIN_PASSWORD as environment variables.",
    );
  }
  stdout.write(label);
  return new Promise((resolve, reject) => {
    let value = "";
    const wasRaw = stdin.isRaw;
    stdin.setRawMode(true);
    stdin.resume();
    const cleanup = () => {
      stdin.removeListener("data", onData);
      stdin.setRawMode(wasRaw);
      stdin.pause();
      stdout.write("\n");
    };
    const onData = (chunk: Buffer) => {
      for (const character of chunk.toString("utf8")) {
        if (character === "\u0003") {
          cleanup();
          reject(new Error("Setup cancelled."));
          return;
        }
        if (character === "\r" || character === "\n") {
          cleanup();
          resolve(value);
          return;
        }
        if (character === "\u007f" || character === "\b")
          value = Array.from(value).slice(0, -1).join("");
        else if (character >= " " && character !== "\u001b") value += character;
      }
    };
    stdin.on("data", onData);
  });
}

async function credentials() {
  const email = (
    process.env.ADMIN_EMAIL ||
    (await question("Administrator email / Email администратора: "))
  )
    .trim()
    .toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    throw new Error("Provide a valid administrator email address.");
  }
  const password =
    process.env.ADMIN_PASSWORD ||
    (await passwordQuestion(
      "Password (12+ characters, hidden) / Пароль (не отображается): ",
    ));
  if (password.length < 12 || password.length > 200)
    throw new Error("Use a password containing 12 to 200 characters.");
  if (
    !process.env.ADMIN_PASSWORD &&
    password !==
      (await passwordQuestion("Confirm password / Повторите пароль: "))
  ) {
    throw new Error("The passwords do not match.");
  }
  return { email, password };
}

async function main() {
  let payload: Payload | undefined;
  try {
    const reset = process.argv.includes("--reset-password");
    const unknownArgs = process.argv
      .slice(2)
      .filter((argument) => argument !== "--reset-password");
    if (unknownArgs.length)
      throw new Error("Usage: npm run admin:setup [-- --reset-password]");
    const { getCms, seedSiteDefaults } =
      await import("../src/cms/server/payload");
    payload = await getCms();
    const accounts = await payload.count({
      collection: "users",
      overrideAccess: true,
    });

    if (reset) {
      if (!accounts.totalDocs)
        throw new Error(
          "No administrator exists. Run npm run admin:setup without --reset-password.",
        );
      const { email, password } = await credentials();
      const target = await payload.find({
        collection: "users",
        where: { email: { equals: email } },
        limit: 1,
        overrideAccess: true,
      });
      if (!target.docs[0])
        throw new Error("No administrator with that email address exists.");
      await payload.update({
        collection: "users",
        id: target.docs[0].id,
        data: { password, loginAttempts: 0, lockUntil: null, sessions: [] },
        overrideAccess: true,
        context: { cliRecovery: true },
      });
      stdout.write(
        "Administrator password updated. / Пароль администратора обновлён.\n",
      );
    } else if (!accounts.totalDocs) {
      const { email, password } = await credentials();
      await payload.create({
        collection: "users",
        data: {
          email,
          password,
          ...(process.env.ADMIN_NAME ? { name: process.env.ADMIN_NAME } : {}),
        },
        overrideAccess: true,
        context: { bootstrap: true },
      });
      stdout.write("Administrator created. / Администратор создан.\n");
    } else {
      stdout.write(
        "An administrator already exists; credentials were preserved. / Данные существующего администратора сохранены.\n",
      );
    }

    const count = await seedSiteDefaults(payload);
    stdout.write(
      `Added ${count} missing website pages. Existing content was preserved.\n`,
    );
    stdout.write("Open /admin and sign in. / Откройте /admin и войдите.\n");
  } catch (error) {
    // Never serialize Payload request objects, passwords, cookies or signing secrets.
    const message =
      error instanceof Error ? error.message : "CMS setup failed.";
    process.stderr.write(`${message}\n`);
    process.exitCode = 1;
  } finally {
    await payload?.destroy();
  }
}

void main();
