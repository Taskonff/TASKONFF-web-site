const major = Number(process.versions.node.split(".")[0]);
if (major < 24) {
  console.error(
    "TASKONFF CMS requires Node.js 24 or newer. / Установите Node.js 24 или новее.",
  );
  process.exit(1);
}
console.log("Node.js version is supported. / Версия Node.js подходит.");
