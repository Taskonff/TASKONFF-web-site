import { spawn } from "node:child_process";
import { randomBytes } from "node:crypto";
import {
  chmod,
  cp,
  lstat,
  mkdir,
  mkdtemp,
  readFile,
  rename,
  rm,
  symlink,
  writeFile,
} from "node:fs/promises";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import type { CmsSiteData } from "../src/cms/defaults";

const project = fileURLToPath(new URL("../", import.meta.url));
const output = path.join(project, "exports", "TASKONFF-HTML");
const require = createRequire(import.meta.url);

async function exists(file: string) {
  try {
    await lstat(file);
    return true;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
    throw error;
  }
}

async function edit(file: string, change: (source: string) => string) {
  const before = await readFile(file, "utf8");
  const after = change(before);
  if (after === before)
    throw new Error(
      `Static-export adapter no longer matches ${path.basename(file)}.`,
    );
  await writeFile(file, after);
}

function localBriefCopy(data: CmsSiteData) {
  data.site.ru.formNote =
    "В HTML-версии данные проверяются только в браузере. Бриф скачивается на ваше устройство и не отправляется команде автоматически.";
  data.site.en.formNote =
    "In this HTML version, data is validated only in your browser. The brief downloads to your device and is not sent to the team automatically.";
  data.site.ru.formError =
    "Проверьте имя, email и описание задачи (от 20 символов), затем повторите попытку.";
  data.site.en.formError =
    "Check your name, email and project description (at least 20 characters), then try again.";
  data.trust.ru.contact.modeText =
    "HTML-версия проверяет данные в браузере и создаёт текстовый файл на вашем устройстве. Форма не передаёт данные серверу или команде TASKONFF.";
  data.trust.en.contact.modeText =
    "The HTML version validates data in your browser and creates a text file on your device. This form does not transmit data to a server or the TASKONFF team.";
  data.trust.ru.contact.faq[1][1] =
    "Данные проверяются в браузере и используются для создания скачиваемого файла. Эта HTML-форма не отправляет их на сервер и не сохраняет в базе данных.";
  data.trust.en.contact.faq[1][1] =
    "Your browser validates the data and creates a downloadable file. This HTML form does not transmit it to a server or store it in a database.";
  const ru = data.trust.ru.legal;
  const en = data.trust.en.legal;
  ru.privacy.sections[1][1] =
    "Форма запрашивает имя, рабочий email, направление интереса и описание проекта. В HTML-версии эти сведения обрабатываются только в браузере для создания текстового файла. Скачивание не означает доставку заявки команде TASKONFF.";
  en.privacy.sections[1][1] =
    "The form asks for your name, work email, area of interest and project description. In this HTML version, your browser processes these details only to create a text file. Downloading it does not deliver an inquiry to TASKONFF.";
  ru.privacy.sections[2][1] =
    "HTML-форма не отправляет содержание брифа на сервер, в базу данных или внешнему получателю. Файл создаётся и скачивается в браузере. Хранение и последующая передача файла зависят от ваших действий и настроек устройства.";
  en.privacy.sections[2][1] =
    "The HTML form does not send brief contents to a server, database or external recipient. Your browser creates and downloads the file. Its storage and any subsequent sharing depend on your actions and device settings.";
  ru.privacy.sections[3][1] =
    "При размещении HTML-версии хостинг может обрабатывать технические журналы запросов страниц и ресурсов. Данные формы этим способом не отправляются. Состав журналов, сроки хранения и условия обработки необходимо уточнить у выбранного хостинга перед запуском.";
  en.privacy.sections[3][1] =
    "When the HTML version is hosted, the provider may process technical logs for page and asset requests. Form data is not transmitted by this form. Confirm log contents, retention and processing terms with your hosting provider before launch.";
  ru.terms.sections[2][1] =
    "Форма HTML-версии создаёт скачиваемый файл после проверки в браузере. Она не заключает договор и не отправляет сообщение команде. Наличие email в брифе само по себе не означает, что компания получила обращение или обязалась ответить.";
  en.terms.sections[2][1] =
    "The HTML form creates a downloadable file after browser validation. It does not create a contract or send the team a message. Providing an email address in the brief does not mean the company received an inquiry or agreed to respond.";
}

async function copyPublishedMedia(
  data: CmsSiteData,
  mediaDirectory: string,
  stage: string,
) {
  const copied = new Set<string>();
  async function copyUrl(value: string | undefined) {
    if (!value) return value;
    const url = new URL(value, "https://snapshot.invalid");
    if (!url.pathname.startsWith("/api/media/file/")) return value;
    const encoded = url.pathname.slice("/api/media/file/".length);
    const filename = decodeURIComponent(encoded);
    if (
      !filename ||
      filename === "." ||
      filename === ".." ||
      filename !== path.basename(filename) ||
      /[\\/\u0000-\u001f\u007f]/u.test(filename)
    )
      throw new Error("A published media URL contains an invalid filename.");
    if (!copied.has(filename)) {
      const source = path.join(mediaDirectory, filename);
      const entry = await lstat(source);
      if (!entry.isFile() || entry.isSymbolicLink())
        throw new Error(`Published media must be a regular file: ${filename}`);
      await mkdir(path.join(stage, "public", "media"), { recursive: true });
      await cp(source, path.join(stage, "public", "media", filename));
      copied.add(filename);
    }
    return `/media/${encodeURIComponent(filename)}`;
  }
  for (const field of ["logoUrl", "heroImageUrl", "ogImageUrl"] as const)
    data.settings[field] = await copyUrl(data.settings[field]);
  for (const asset of Object.values(data.pageMedia))
    asset.url = (await copyUrl(asset.url))!;
  for (const item of data.cases)
    if (item.image) item.image.url = (await copyUrl(item.image.url))!;
  return copied.size;
}

async function adaptSource(stage: string) {
  await rm(path.join(stage, "src", "app", "(payload)"), {
    recursive: true,
    force: true,
  });
  await rm(path.join(stage, "src", "app", "api"), {
    recursive: true,
    force: true,
  });
  await writeFile(
    path.join(stage, "next.config.ts"),
    `import type { NextConfig } from "next";
const config: NextConfig = {
  output: "export",
  trailingSlash: true,
  images: { unoptimized: true },
  poweredByHeader: false,
  serverExternalPackages: ["payload", "@payloadcms/db-sqlite", "sharp"],
};
export default config;
`,
  );
  for (const metadataFile of ["src/app/robots.ts", "src/app/sitemap.ts"]) {
    await edit(
      path.join(stage, metadataFile),
      (source) => 'export const dynamic = "force-static";\n' + source,
    );
  }
  await edit(path.join(stage, "src/app/[locale]/layout.tsx"), (source) =>
    source.replace(
      'export const dynamic = "force-dynamic";',
      'export const dynamic = "force-static";\nexport const dynamicParams = false;',
    ),
  );
  await edit(
    path.join(stage, "src/app/[locale]/services/[service]/page.tsx"),
    (source) => `export const dynamicParams = false;\n${source}`,
  );
  await edit(
    path.join(stage, "src/app/[locale]/opengraph-image.tsx"),
    (source) =>
      source
        .replace('import { getCMSPaths } from "@/cms/server/storage";\n', "")
        .replace(
          'export const dynamic = "force-dynamic";',
          'export const dynamic = "force-static";\nexport function generateStaticParams() { return [{ locale: "ru" }, { locale: "en" }]; }',
        )
        .replace(
          'url.pathname.startsWith("/api/media/file/")',
          'url.pathname.startsWith("/media/")',
        )
        .replace(
          "path.join(getCMSPaths().mediaDir, name)",
          'path.join(process.cwd(), "public", "media", name)',
        ),
  );
  await edit(
    path.join(stage, "src/components/home/project-brief-form.tsx"),
    (source) => {
      const start = source.indexOf(
        '      const response = await fetch("/api/brief", {',
      );
      const finish = source.indexOf(
        '      const link = document.createElement("a");',
        start,
      );
      if (start < 0 || finish < 0)
        throw new Error(
          "The brief form changed; update the static-export adapter.",
        );
      return (
        source.slice(0, start) +
        '      const url = URL.createObjectURL(new Blob([createBrief(data)], { type: "text/plain;charset=utf-8" }));\n' +
        source.slice(finish)
      ).replace(
        'import { briefSchema } from "@/lib/brief";',
        'import { briefSchema, createBrief } from "@/lib/brief";',
      );
    },
  );
}

const preview = `#!/usr/bin/env python3
"""Local HTTP preview for the TASKONFF HTML snapshot. Requires Python 3."""
import argparse
import functools
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import threading
import webbrowser

class Handler(SimpleHTTPRequestHandler):
    def guess_type(self, filename):
        name = Path(filename).name
        if name == "index.txt" or (name.startswith("__next.") and name.endswith(".txt")):
            return "text/x-component"
        return super().guess_type(filename)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--port", type=int, default=4173)
parser.add_argument("--no-browser", action="store_true")
args = parser.parse_args()
root = Path(__file__).resolve().parent
handler = functools.partial(Handler, directory=str(root))
try:
    server = ThreadingHTTPServer(("127.0.0.1", args.port), handler)
except OSError as error:
    raise SystemExit(f"Cannot start preview: {error}. Try --port 4174.")
url = f"http://127.0.0.1:{server.server_port}/ru/"
print(f"TASKONFF preview: {url} (Ctrl+C to stop)", flush=True)
if not args.no_browser:
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
`;

const shellLauncher = `#!/bin/sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  exec python3 preview.py "$@"
fi
printf '%s\\n' 'Install Python 3 from https://www.python.org/ and run python3 preview.py.'
exit 1
`;

async function addDeliveryFiles(directory: string, mediaCount: number) {
  await cp(
    path.join(project, "THIRD_PARTY_NOTICES"),
    path.join(directory, "THIRD_PARTY_NOTICES"),
    { recursive: true },
  );
  await writeFile(path.join(directory, ".nojekyll"), "");
  await writeFile(path.join(directory, "preview.py"), preview);
  for (const file of ["preview.sh", "START-MAC.command"]) {
    await writeFile(path.join(directory, file), shellLauncher);
    await chmod(path.join(directory, file), 0o755);
  }
  await writeFile(
    path.join(directory, "START-WINDOWS.cmd"),
    '@echo off\r\ncd /d "%~dp0"\r\nwhere py >nul 2>nul\r\nif not errorlevel 1 (\r\n  py -3 preview.py %*\r\n) else (\r\n  python preview.py %*\r\n)\r\nif errorlevel 1 pause\r\n',
  );
  await writeFile(
    path.join(directory, "index.html"),
    `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TASKONFF</title><meta name="robots" content="noindex"><style>body{margin:0;padding:10vh 8vw;background:#020e1b;color:#fff;font:18px/1.6 system-ui}a{color:#00cbd5}code{color:#00cbd5}</style></head><body><h1>TASKONFF</h1><p id="help">Для просмотра запустите START-WINDOWS.cmd, START-MAC.command или <code>python3 preview.py</code>. Сайт открывается через HTTP; открытие HTML двойным щелчком не поддерживается.</p><p><a href="./ru/">Русская версия</a> · <a href="./en/">English version</a></p><script>if(location.protocol!=="file:"){document.getElementById("help").textContent="Открываем сайт…";location.replace("./ru/"+location.search+location.hash)}</script></body></html>\n`,
  );
  await writeFile(
    path.join(directory, "README-RU.txt"),
    `TASKONFF — HTML-версия сайта\n\n` +
      `Снимок опубликованного контента CMS от ${new Date().toISOString()}.\n` +
      `Скопировано опубликованных медиафайлов: ${mediaCount}.\n\n` +
      `БЫСТРЫЙ ПРОСМОТР\n` +
      `1. Распакуйте всю папку, сохраняя структуру файлов.\n` +
      `2. Установите Python 3, если его нет: https://www.python.org/\n` +
      `3. Windows: START-WINDOWS.cmd. macOS: START-MAC.command.\n` +
      `   Linux/macOS: sh preview.sh; либо python3 preview.py.\n` +
      `4. Откройте http://127.0.0.1:4173/ru/ (или /en/).\n` +
      `Если порт занят: python3 preview.py --port 4174. Остановка: Ctrl+C.\n\n` +
      `Это статическая HTML/CSS/JS-версия без административной панели, базы данных и серверного API.\n` +
      `Анимации, мобильное меню, переключение языка, фильтры и интерактивные блоки сохранены.\n` +
      `Форма проверяет данные локально в браузере и скачивает текстовый бриф.\n` +
      `Она не отправляет заявки команде и не поддерживает серверную валидацию.\n` +
      `Для редактирования через /admin используйте отдельный архив исходного проекта с CMS.\n` +
      `После публикации изменений в CMS снова выполните npm run export:html.\n\n` +
      `РАЗМЕЩЕНИЕ\n` +
      `Открывайте сайт через HTTP/HTTPS, а не через file://.\n` +
      `Загрузите содержимое этой папки в корень домена на статический хостинг.\n` +
      `Ссылки на ресурсы начинаются с /; размещение в подпапке без пересборки не поддерживается.\n` +
      `Сервер должен отдавать index.html для каталогов и сохранять все файлы _next,\n` +
      `локализованные каталоги ru/en, файлы .txt для навигации, изображения и .nojekyll.\n` +
      `Не редактируйте скомпилированные чанки и не удаляйте их. Node.js на хостинге не нужен.\n` +
      `Файлы preview.py и START-* нужны только для локального просмотра.\n\n` +
      `SEO: для публичного индексирования задайте корректный SITE_URL в исходном проекте\n` +
      `перед экспортом. Без SITE_URL сохраняется запрет индексации черновика.\n` +
      `Юридические тексты остаются проектами документов до согласования владельцем сайта.\n`,
  );
}

async function build(stage: string, snapshotFile: string) {
  await new Promise<void>((resolve, reject) => {
    const child = spawn(
      process.execPath,
      [require.resolve("next/dist/bin/next"), "build", "--webpack"],
      {
        cwd: stage,
        stdio: "inherit",
        env: {
          ...process.env,
          NODE_ENV: "production",
          NEXT_TELEMETRY_DISABLED: "1",
          CMS_STATIC_EXPORT: "1",
          CMS_SNAPSHOT_FILE: snapshotFile,
          CMS_DATA_DIR: path.join(stage, ".cms-build-only"),
          PAYLOAD_SECRET: randomBytes(48).toString("hex"),
        },
      },
    );
    child.on("error", reject);
    child.on("exit", (code, signal) => {
      if (code === 0) resolve();
      else reject(new Error(`HTML export build failed (${signal || code}).`));
    });
  });
}

async function installOutput(prepared: string) {
  await mkdir(path.dirname(output), { recursive: true });
  // Stage on the same filesystem before swapping so a failed build keeps the previous export.
  const incoming = await mkdtemp(
    path.join(path.dirname(output), ".html-incoming-"),
  );
  const backup = `${incoming}-previous`;
  let movedPrevious = false;
  try {
    await cp(prepared, incoming, { recursive: true });
    if (await exists(output)) {
      const entry = await lstat(output);
      if (!entry.isDirectory() || entry.isSymbolicLink())
        throw new Error(
          "Refusing to replace a non-directory HTML export path.",
        );
      await rename(output, backup);
      movedPrevious = true;
    }
    try {
      await rename(incoming, output);
    } catch (error) {
      if (movedPrevious) await rename(backup, output);
      movedPrevious = false;
      throw error;
    }
    if (movedPrevious) await rm(backup, { recursive: true, force: true });
  } finally {
    await rm(incoming, { recursive: true, force: true });
  }
}

async function main() {
  process.chdir(project);
  // Load the same local configuration as Next without ever copying .env files into the archive.
  require("@next/env").loadEnvConfig(project);
  if (process.env.CMS_STATIC_EXPORT === "1")
    throw new Error(
      "Run export:html against the CMS, without CMS_STATIC_EXPORT set.",
    );
  const stage = await mkdtemp(path.join(tmpdir(), "taskonff-html-"));
  try {
    const [{ readSiteData }, { getCms }, { getCMSPaths }] = await Promise.all([
      import("../src/cms/read-site-data"),
      import("../src/cms/server/payload"),
      import("../src/cms/server/storage"),
    ]);
    const payload = await getCms();
    let snapshot: CmsSiteData;
    try {
      snapshot = await readSiteData();
    } finally {
      await payload.destroy();
    }
    for (const entry of [
      "src",
      "public",
      "package.json",
      "package-lock.json",
      "tsconfig.json",
      "next-env.d.ts",
      "postcss.config.mjs",
    ]) {
      const source = path.join(project, entry);
      if (await exists(source))
        await cp(source, path.join(stage, entry), { recursive: true });
    }
    await symlink(
      path.join(project, "node_modules"),
      path.join(stage, "node_modules"),
      process.platform === "win32" ? "junction" : "dir",
    );
    const mediaCount = await copyPublishedMedia(
      snapshot,
      getCMSPaths().mediaDir,
      stage,
    );
    localBriefCopy(snapshot);
    const snapshotFile = path.join(stage, "cms-snapshot.json");
    await writeFile(snapshotFile, JSON.stringify(snapshot));
    await adaptSource(stage);
    console.info(
      "Building the published CMS snapshot in an isolated temporary directory…",
    );
    await build(stage, snapshotFile);
    const prepared = path.join(stage, "out");
    await addDeliveryFiles(prepared, mediaCount);
    await installOutput(prepared);
    console.info(`HTML export ready: ${output}`);
    console.info(
      "The CMS/database remain in the source project; this export contains public content only.",
    );
  } finally {
    await rm(stage, { recursive: true, force: true });
  }
}

// Payload/native SQLite can retain background handles after destroy().
// main() awaits database shutdown, output installation and temporary cleanup first.
main()
  .then(() => process.exit(0))
  .catch((error: unknown) => {
    console.error(
      error instanceof Error ? error.message : "HTML export failed.",
    );
    process.exit(1);
  });
