const industryItems = {
  ru: [
    {
      name: "Ритейл и e-commerce",
      iconId: "ShoppingBag",
      title: "Единый путь от каталога до исполнения.",
      text: "Возможный сценарий: связать витрину, остатки, заказы и работу с покупателями. Детали зависят от модели продаж и существующих систем.",
      steps: [
        ["Каталог", "Согласованные карточки, цены и правила публикации."],
        ["Заказ", "Понятный путь покупки и состояния заказа."],
        ["Исполнение", "Передача в учёт, уведомления и обработка исключений."],
      ],
      guard:
        "Предусмотреть ошибки оплаты, рассинхронизацию остатков и защиту персональных данных.",
    },
    {
      name: "Логистика",
      iconId: "Truck",
      title: "События поставки становятся понятным процессом.",
      text: "Возможный сценарий: объединить заявки, статусы перемещения и документы в одном операционном интерфейсе.",
      steps: [
        ["Заявка", "Структурированные вводные и правила обработки."],
        ["Маршрут", "События, ответственные и актуальные статусы."],
        ["Документы", "Связь подтверждений с операциями и исключениями."],
      ],
      guard:
        "Учитывать задержки данных, повторные события и работу с неполной информацией.",
    },
    {
      name: "Профессиональные услуги",
      iconId: "Building2",
      title: "Меньше ручной координации между командами.",
      text: "Возможный сценарий: кабинет клиента, управление задачами и автоматизация согласований вокруг оказания услуги.",
      steps: [
        ["Запрос", "Единая точка входа и уточнение задачи."],
        ["Работа", "Ответственные, доступы и согласования."],
        ["Результат", "Передача материалов и история изменений."],
      ],
      guard:
        "Разграничить доступ между клиентами и определить правила хранения документов.",
    },
    {
      name: "Финансовые сервисы",
      iconId: "Landmark",
      title: "Контролируемая обработка данных и операций.",
      text: "Возможный сценарий: внутренний операционный кабинет или автоматизация сверок. Требования к регулированию определяются отдельно.",
      steps: [
        ["Данные", "Проверка источников, форматов и полноты."],
        ["Правила", "Согласованная логика обработки и эскалации."],
        ["Контроль", "Проверяемые действия и доступ по ролям."],
      ],
      guard:
        "Нужны отдельная оценка рисков, модель доступа и проверка применимых требований; соответствие стандартам не подразумевается.",
    },
    {
      name: "Медицина и сервисы здоровья",
      iconId: "HeartPulse",
      title: "Цифровые сценарии с вниманием к чувствительным данным.",
      text: "Возможный сценарий: запись, административные процессы и взаимодействие с пользователями. Клинические решения требуют отдельной экспертизы.",
      steps: [
        [
          "Обращение",
          "Понятный пользовательский путь и сбор минимальных данных.",
        ],
        ["Координация", "Расписание, роли и события обслуживания."],
        ["Доступ", "Разделение прав и правил обработки информации."],
      ],
      guard:
        "До разработки определить правовое основание обработки данных и ограничения системы. Диагностика не входит в этот пример.",
    },
    {
      name: "Производство",
      iconId: "Factory",
      title: "Операционная информация без разрозненных таблиц.",
      text: "Возможный сценарий: рабочие кабинеты для планирования, учёта задач и регистрации событий производства.",
      steps: [
        ["План", "Связь задач, ресурсов и ограничений."],
        ["Операции", "Фиксация выполнения и причин отклонений."],
        ["Обзор", "Актуальные данные для ответственных ролей."],
      ],
      guard:
        "Сначала изучить источники данных, доступность оборудования и допустимый уровень вмешательства в процессы.",
    },
  ],
  en: [
    {
      name: "Retail & e-commerce",
      iconId: "ShoppingBag",
      title: "A connected journey from catalog to fulfillment.",
      text: "Possible scenario: connect the storefront, inventory, orders and customer operations. Details depend on the sales model and existing systems.",
      steps: [
        ["Catalog", "Consistent product data, prices and publishing rules."],
        ["Order", "A clear purchasing journey and order states."],
        [
          "Fulfillment",
          "Handoff to operations, notifications and exception handling.",
        ],
      ],
      guard:
        "Plan for payment errors, inventory drift and personal-data protection.",
    },
    {
      name: "Logistics",
      iconId: "Truck",
      title: "Delivery events become a clear operating process.",
      text: "Possible scenario: bring requests, movement status and documents into a single operational interface.",
      steps: [
        ["Request", "Structured inputs and processing rules."],
        ["Journey", "Events, owners and current statuses."],
        ["Documents", "Connect evidence to operations and exceptions."],
      ],
      guard:
        "Account for delayed data, duplicate events and incomplete information.",
    },
    {
      name: "Professional services",
      iconId: "Building2",
      title: "Less manual coordination between teams.",
      text: "Possible scenario: customer workspaces, task management and automated approvals organized around service delivery.",
      steps: [
        ["Request", "A consistent entry point and scope clarification."],
        ["Delivery", "Ownership, access and approvals."],
        ["Result", "Material handoff and change history."],
      ],
      guard: "Separate client access and define document-retention rules.",
    },
    {
      name: "Financial services",
      iconId: "Landmark",
      title: "Controlled handling of data and operations.",
      text: "Possible scenario: internal operating workspaces or automated reconciliation. Regulatory requirements need a separate assessment.",
      steps: [
        ["Data", "Check sources, formats and completeness."],
        ["Rules", "Agreed processing and escalation logic."],
        ["Control", "Traceable actions and role-based access."],
      ],
      guard:
        "Assess risks, access models and applicable requirements separately. Standards compliance is not implied.",
    },
    {
      name: "Health services",
      iconId: "HeartPulse",
      title: "Digital journeys that respect sensitive information.",
      text: "Possible scenario: scheduling, administrative workflows and user interactions. Clinical decisions need separate expertise.",
      steps: [
        ["Intake", "Clear journeys and minimum necessary data."],
        ["Coordination", "Schedules, roles and service events."],
        ["Access", "Separate permissions and processing rules."],
      ],
      guard:
        "Define lawful processing grounds and system limits before development. Diagnosis is outside this example.",
    },
    {
      name: "Manufacturing",
      iconId: "Factory",
      title: "Operational information beyond disconnected spreadsheets.",
      text: "Possible scenario: workspaces for planning, task tracking and recording production events.",
      steps: [
        ["Plan", "Connect tasks, resources and constraints."],
        ["Operations", "Record execution and reasons for deviations."],
        ["Overview", "Current information for responsible roles."],
      ],
      guard:
        "Assess data sources, equipment availability and permitted interventions before designing integrations.",
    },
  ],
};
export const expertiseCopy = {
  ru: {
    services: {
      label: "Услуги",
      title: "Технологии под задачу.\nНе наоборот.",
      description:
        "От отдельного интерфейса до связанной цифровой системы. Выберите направление и узнайте, какие задачи оно решает, что входит в работу и с чего начать.",
      diagramLabel: "PRODUCT × SYSTEM",
      sectionLabel: "НАПРАВЛЕНИЯ РАЗРАБОТКИ",
      sectionTitle: "От цели —\nк нужным инструментам.",
      engagementLabel: "КАК ВЫБРАТЬ НАПРАВЛЕНИЕ",
      engagementTitle: "Можно начать\nс самой задачи.",
      engagementText:
        "Не обязательно заранее выбирать услугу или стек. Достаточно описать текущий процесс, пользователей и то, что должно измениться. Несколько направлений могут стать частями одного решения.",
      processLink: "Посмотреть процесс работы",
      catalog: {
        placeholder: "Найти услугу",
        searchLabel: "Поиск услуг",
        categoriesLabel: "Направления услуг",
        all: "Все направления",
        resultLabel: "Найдено направлений",
        detailLink: "Задачи и подход",
        emptyTitle: "Такого направления не найдено",
        emptyText: "Попробуйте другой запрос или сбросьте фильтры.",
        reset: "Сбросить фильтры",
      },
    },
    detail: {
      back: "Все услуги",
      needsLabel: "КОГДА ЭТО НУЖНО",
      needsTitle: "Задачи,\nс которых начинаем.",
      outputsLabel: "РЕЗУЛЬТАТ РАБОТЫ",
      outputsTitle: "Что определяем\nи создаём.",
      scopeNote:
        "Точный состав и критерии готовности согласовываются после изучения задачи.",
      workflowLabel: "ПОДХОД К ЗАДАЧЕ",
      workflowTitle: "Последовательность,\nа не набор обещаний.",
      faqTitle: "Перед стартом.",
      relatedTitle: "Рядом с этой задачей.",
      ctaTitle: "Обсудим вашу задачу?",
    },
    industries: {
      label: "Отрасли",
      title: "Разные процессы.\nСистемный подход.",
      description:
        "Контекст бизнеса меняет требования к продукту. Ниже — примеры возможного применения цифровых решений, а не перечень выполненных проектов или клиентов.",
      sectionLabel: "ИССЛЕДУЙТЕ СЦЕНАРИЙ",
      sectionTitle: "Что может\nизмениться в работе.",
      principlesLabel: "ПЕРЕД РАЗРАБОТКОЙ",
      principlesTitle: "Сначала контекст.\nПотом архитектура.",
      principles: [
        [
          "Процессы",
          "Изучаем реальную последовательность действий, участников и исключения.",
        ],
        [
          "Данные",
          "Определяем источники истины, качество информации и необходимые права доступа.",
        ],
        [
          "Ограничения",
          "Уточняем инфраструктуру, требования к безопасности и применимые правила.",
        ],
      ],
      tabsLabel: "Возможные отраслевые применения",
      scenarioLabel: "ВОЗМОЖНЫЙ СЦЕНАРИЙ",
      stepsLabel: "Этапы сценария",
      items: industryItems.ru,
    },
  },
  en: {
    services: {
      label: "Services",
      title: "Technology around\nyour challenge.",
      description:
        "From one interface to a connected digital system. Explore each service, the problems it addresses, what the work includes and where to begin.",
      diagramLabel: "PRODUCT × SYSTEM",
      sectionLabel: "AREAS OF EXPERTISE",
      sectionTitle: "From your goal\nto the right tools.",
      engagementLabel: "WHERE TO START",
      engagementTitle: "Start with\nthe problem itself.",
      engagementText:
        "You do not need to choose a service or stack upfront. Describe the current process, its users and what needs to change. Several areas can become parts of one solution.",
      processLink: "Explore our process",
      catalog: {
        placeholder: "Find a service",
        searchLabel: "Search services",
        categoriesLabel: "Service categories",
        all: "All services",
        resultLabel: "Services found",
        detailLink: "Scope & approach",
        emptyTitle: "No services found",
        emptyText: "Try another search or clear the filters.",
        reset: "Clear filters",
      },
    },
    detail: {
      back: "All services",
      needsLabel: "WHEN IT HELPS",
      needsTitle: "Challenges\nwe start with.",
      outputsLabel: "WORK OUTPUTS",
      outputsTitle: "What we define\nand build.",
      scopeNote:
        "Exact scope and acceptance criteria are agreed after exploring your requirements.",
      workflowLabel: "DELIVERY APPROACH",
      workflowTitle: "A clear sequence,\nnot a list of promises.",
      faqTitle: "Before we start.",
      relatedTitle: "Related capabilities.",
      ctaTitle: "Let’s explore your challenge.",
    },
    industries: {
      label: "Industries",
      title: "Different industries.\nA systematic approach.",
      description:
        "Business context shapes product requirements. Explore possible uses for digital solutions—not a list of delivered projects or clients.",
      sectionLabel: "EXPLORE A SCENARIO",
      sectionTitle: "What could change\nin your workflow.",
      principlesLabel: "BEFORE DEVELOPMENT",
      principlesTitle: "Context first.\nArchitecture next.",
      principles: [
        [
          "Processes",
          "Understand the actual sequence of actions, participants and exceptions.",
        ],
        [
          "Data",
          "Identify sources of truth, data quality and necessary access permissions.",
        ],
        [
          "Constraints",
          "Clarify infrastructure, security requirements and applicable rules.",
        ],
      ],
      tabsLabel: "Possible industry applications",
      scenarioLabel: "POSSIBLE SCENARIO",
      stepsLabel: "Scenario stages",
      items: industryItems.en,
    },
  },
};
