export const locales = ["ru", "en"] as const;
export type Locale = (typeof locales)[number];
export const isLocale = (value: string): value is Locale =>
  locales.includes(value as Locale);
export const content = {
  en: {
    nav: ["Expertise", "Approach", "Technologies", "Contact"],
    talk: "Let’s talk",
    menu: "Menu",
    close: "Close menu",
    skip: "Skip to content",
    eyebrow: "SOFTWARE ENGINEERING. BUSINESS THINKING.",
    title: ["Build what’s", "next."],
    intro:
      "From your next big idea to the systems that power your business. We design, build and automate digital products.",
    primary: "Discuss your project",
    secondary: "Explore our expertise",
    scroll: "SCROLL TO EXPLORE",
    visual: "FROM IDEA TO IMPACT",
    system: "CONNECTED BY DESIGN",
    visualLabels: [
      "Digital products",
      "Intelligent systems",
      "Business growth",
    ],
    expertise: "OUR EXPERTISE",
    servicesTitle: "Complex challenges.\nClear solutions.",
    servicesIntro:
      "The right technology, built around your business. From a single product to a connected digital ecosystem.",
    detail: "Discuss this service",
    services: [
      {
        title: "Software & digital products",
        text: "Purpose-built software that turns business requirements into intuitive digital experiences.",
        tags: ["Custom software", "Web & mobile apps", "SaaS & B2B platforms"],
      },
      {
        title: "AI & automation",
        text: "Intelligent tools and connected workflows that give your team room to focus on what matters.",
        tags: [
          "AI solutions & agents",
          "Process automation",
          "System integration",
        ],
      },
      {
        title: "Enterprise systems",
        text: "Connected operations, structured data and business tools designed for the way you work.",
        tags: ["CRM & ERP", "Business analysis", "Cloud & DevOps"],
      },
      {
        title: "Design & quality",
        text: "Thoughtful interfaces and rigorous testing, from the first user journey to the final release.",
        tags: ["UI/UX design", "Quality assurance", "Product experience"],
      },
    ],
    aboutLabel: "THE TASKONFF APPROACH",
    aboutTitle: "Technology is the tool.\nYour business is the point.",
    aboutText:
      "We develop software and implement digital solutions for business. Our approach connects product thinking, engineering and automation in one continuous process.",
    processLabel: "HOW WE WORK",
    processTitle: "A clear path forward.",
    process: [
      [
        "Discover",
        "Understand your goals, users and constraints. Define a practical scope together.",
      ],
      [
        "Design",
        "Turn requirements into architecture, user journeys and a shared product direction.",
      ],
      [
        "Build",
        "Develop in focused iterations, with testing and feedback throughout.",
      ],
      [
        "Evolve",
        "Plan deployment, integration and the next steps for your product.",
      ],
    ],
    techLabel: "ENGINEERING FOUNDATION",
    techTitle: "Built to connect.\nReady to evolve.",
    techText:
      "We choose the stack around the product. A modular foundation makes room for integrations and future growth.",
    techCaption: "FOUNDATION OF THIS WEBSITE",
    contactLabel: "WHAT’S NEXT?",
    contactTitle: "Let’s build\nsomething that matters.",
    contactText:
      "Tell us what you have in mind. Prepare a project brief to share with the TASKONFF team.",
    formName: "Your name",
    formEmail: "Work email",
    formService: "Area of interest",
    formMessage: "About your project",
    formPlaceholder: "What would you like to build or improve?",
    formSubmit: "Download project brief",
    formNote:
      "Your data is sent to this site’s server to validate and generate the brief, without saving the message. Downloading a brief does not send an inquiry to the team.",
    formSuccess:
      "Your brief is ready. Share the downloaded file with TASKONFF through your established contact channel.",
    formError:
      "Check your name, email and project description (20–5000 characters). If they are correct, the server may be temporarily unavailable or the request limit reached. Try again shortly.",
    formPending: "Preparing…",
    general: "Let’s explore together",
    footer: "Software engineering & digital solutions.",
    rights: "All rights reserved.",
    top: "Back to top",
    language: "Switch to Russian",
    brandNote: "Company name shown as text; original brand assets pending.",
  },
  ru: {
    nav: ["Экспертиза", "Подход", "Технологии", "Контакт"],
    talk: "Обсудим проект",
    menu: "Меню",
    close: "Закрыть меню",
    skip: "Перейти к содержимому",
    eyebrow: "ИНЖЕНЕРНЫЙ ПОДХОД. ФОКУС НА БИЗНЕСЕ.",
    title: ["Создаём то,", "что дальше."],
    intro:
      "От новой идеи до систем, на которых работает ваш бизнес. Проектируем, разрабатываем и автоматизируем цифровые продукты.",
    primary: "Обсудить проект",
    secondary: "Наша экспертиза",
    scroll: "ЛИСТАЙТЕ, ЧТОБЫ УЗНАТЬ БОЛЬШЕ",
    visual: "ОТ ИДЕИ К РЕЗУЛЬТАТУ",
    system: "СВЯЗАНО АРХИТЕКТУРОЙ",
    visualLabels: ["Цифровые продукты", "Умные системы", "Развитие бизнеса"],
    expertise: "НАША ЭКСПЕРТИЗА",
    servicesTitle: "Сложные задачи.\nПонятные решения.",
    servicesIntro:
      "Технологии вокруг задач вашего бизнеса. От отдельного продукта до единой цифровой экосистемы.",
    detail: "Обсудить услугу",
    services: [
      {
        title: "ПО и цифровые продукты",
        text: "Индивидуальная разработка, которая превращает требования бизнеса в удобные цифровые продукты.",
        tags: [
          "Заказное ПО",
          "Веб и мобильные приложения",
          "SaaS и B2B-платформы",
        ],
      },
      {
        title: "AI и автоматизация",
        text: "Интеллектуальные инструменты и связанные процессы, которые освобождают время для главного.",
        tags: [
          "AI-решения и агенты",
          "Автоматизация процессов",
          "Интеграция систем",
        ],
      },
      {
        title: "Корпоративные системы",
        text: "Единые процессы, структурированные данные и инструменты под особенности вашей работы.",
        tags: ["CRM и ERP", "Бизнес-анализ", "Cloud и DevOps"],
      },
      {
        title: "Дизайн и качество",
        text: "Продуманные интерфейсы и тщательное тестирование — от первого сценария до готового релиза.",
        tags: ["UI/UX-дизайн", "Обеспечение качества", "Продуктовый опыт"],
      },
    ],
    aboutLabel: "ПОДХОД TASKONFF",
    aboutTitle: "Технологии — инструмент.\nВаш бизнес — ориентир.",
    aboutText:
      "Мы разрабатываем программное обеспечение и внедряем цифровые решения для бизнеса. Объединяем продуктовое мышление, инженерию и автоматизацию в непрерывный процесс.",
    processLabel: "КАК МЫ РАБОТАЕМ",
    processTitle: "Понятный путь вперёд.",
    process: [
      [
        "Исследуем",
        "Изучаем цели, пользователей и ограничения. Вместе определяем объём задачи.",
      ],
      [
        "Проектируем",
        "Превращаем требования в архитектуру, пользовательские сценарии и концепцию продукта.",
      ],
      [
        "Разрабатываем",
        "Двигаемся итерациями, проверяя результат и собирая обратную связь.",
      ],
      [
        "Развиваем",
        "Планируем запуск, интеграции и следующие шаги развития продукта.",
      ],
    ],
    techLabel: "ТЕХНОЛОГИЧЕСКАЯ ОСНОВА",
    techTitle: "Открыты к интеграциям.\nГотовы к развитию.",
    techText:
      "Подбираем стек под продукт. Модульная архитектура оставляет пространство для интеграций и будущего роста.",
    techCaption: "ТЕХНОЛОГИИ ЭТОГО САЙТА",
    contactLabel: "ЧТО ДАЛЬШЕ?",
    contactTitle: "Создадим то,\nчто имеет значение.",
    contactText:
      "Расскажите о своей идее. Подготовьте бриф, чтобы передать его команде TASKONFF.",
    formName: "Ваше имя",
    formEmail: "Рабочая почта",
    formService: "Направление",
    formMessage: "О вашем проекте",
    formPlaceholder: "Что вы хотите создать или улучшить?",
    formSubmit: "Скачать бриф проекта",
    formNote:
      "Данные передаются серверу сайта для проверки и создания брифа без сохранения сообщения. Скачивание брифа не отправляет заявку команде.",
    formSuccess:
      "Бриф готов. Передайте скачанный файл TASKONFF через ваш действующий канал связи.",
    formError:
      "Проверьте имя, email и описание проекта (20–5000 символов). Если данные верны, сервер временно недоступен или достигнут лимит запросов. Попробуйте немного позже.",
    formPending: "Подготовка…",
    general: "Определим вместе",
    footer: "Разработка ПО и цифровые решения.",
    rights: "Все права защищены.",
    top: "Наверх",
    language: "Switch to English",
    brandNote:
      "Название компании набрано текстом; ожидаются оригинальные бренд-материалы.",
  },
};
export type SiteContent = (typeof content)[Locale];
