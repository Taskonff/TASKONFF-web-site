import type { Locale } from "./site";
export type ServiceGroup = "build" | "automate" | "operate" | "design";
export type ServiceCopy = {
  title: string;
  intro: string;
  needs: string[];
  deliverables: string[];
  workflow: string[];
  decision: string;
  faq: [string, string][];
};
export type Service = {
  slug: string;
  group: ServiceGroup;
  ru: ServiceCopy;
  en: ServiceCopy;
};
export const serviceGroups: Record<Locale, Record<ServiceGroup, string>> = {
  ru: {
    build: "Цифровые продукты",
    automate: "AI и автоматизация",
    operate: "Корпоративные системы",
    design: "Дизайн и качество",
  },
  en: {
    build: "Digital products",
    automate: "AI & automation",
    operate: "Enterprise systems",
    design: "Design & quality",
  },
};
export const services: Service[] = [
  {
    slug: "custom-software",
    group: "build",
    ru: {
      title: "Заказная разработка ПО",
      intro:
        "Когда готовые инструменты ограничивают процессы, нужен продукт под вашу бизнес-логику. Начинаем с задачи и проектируем программное обеспечение с понятными границами, ролями и интеграциями.",
      needs: [
        "Уникальная бизнес-логика и сложные правила",
        "Замена разрозненных таблиц и ручных операций",
        "Развитие существующей системы без потери контекста",
      ],
      deliverables: [
        "Требования и архитектура решения",
        "Работающие модули и автоматизированные проверки",
        "Инструкции по запуску, эксплуатации и развитию",
      ],
      workflow: [
        "Исследуем текущие процессы и ограничения",
        "Выделяем ядро продукта и планируем итерации",
        "Разрабатываем, проверяем и готовим к запуску",
      ],
      decision:
        "Собственный продукт оправдан, если критические процессы нельзя надёжно поддержать готовыми решениями.",
      faq: [
        [
          "Можно ли доработать существующую систему?",
          "Да. Сначала изучаем код, данные, окружение и ограничения. После этого определяем, какие части сохранять и где нужны изменения.",
        ],
        [
          "С чего начинается оценка?",
          "С описания пользователей, ключевых сценариев, интеграций и критериев готовности. Без этого нельзя обоснованно определить объём.",
        ],
      ],
    },
    en: {
      title: "Custom software development",
      intro:
        "When off-the-shelf tools constrain your processes, build around your business logic. We start with the problem and design software with clear boundaries, roles and integrations.",
      needs: [
        "Unique business logic and complex rules",
        "Replacing disconnected spreadsheets and manual work",
        "Evolving an existing system without losing context",
      ],
      deliverables: [
        "Requirements and solution architecture",
        "Working modules and automated checks",
        "Deployment, operation and evolution guidance",
      ],
      workflow: [
        "Explore current processes and constraints",
        "Define the product core and iteration plan",
        "Build, validate and prepare for launch",
      ],
      decision:
        "Custom software makes sense when business-critical processes cannot be supported reliably by ready-made tools.",
      faq: [
        [
          "Can you extend an existing system?",
          "Yes. We first examine the code, data, environment and constraints, then decide what to preserve and where changes are necessary.",
        ],
        [
          "What is needed for an estimate?",
          "Users, key workflows, integrations and acceptance criteria. These define a scope that can be assessed meaningfully.",
        ],
      ],
    },
  },
  {
    slug: "web-mobile",
    group: "build",
    ru: {
      title: "Веб и мобильные приложения",
      intro:
        "Цифровой сервис должен быть удобен там, где работает пользователь. Проектируем веб-интерфейсы и мобильные сценарии вокруг задач, устройств и реальных условий использования.",
      needs: [
        "Личный кабинет, портал или клиентский сервис",
        "Работа на смартфонах, планшетах и компьютерах",
        "Связь интерфейса с внутренними данными и API",
      ],
      deliverables: [
        "Пользовательские сценарии и адаптивный интерфейс",
        "Клиентское приложение и необходимые API",
        "Проверки доступности, производительности и ошибок",
      ],
      workflow: [
        "Определяем устройства и ключевые действия",
        "Проверяем прототип и технический подход",
        "Разрабатываем и тестируем целевые сценарии",
      ],
      decision:
        "Выбор между вебом, PWA и отдельным мобильным приложением зависит от нужных функций устройства и способа распространения.",
      faq: [
        [
          "Всегда ли нужно отдельное мобильное приложение?",
          "Нет. Адаптивный веб или PWA могут решить задачу. Отдельное приложение рассматриваем, если важны возможности устройства или требования платформ.",
        ],
        [
          "Как проверяется адаптивность?",
          "На нескольких ширинах экрана и в ключевых сценариях: навигация, формы, ошибки, загрузка данных и управление с клавиатуры.",
        ],
      ],
    },
    en: {
      title: "Web & mobile applications",
      intro:
        "A digital service should work wherever its users are. We design web interfaces and mobile experiences around tasks, devices and real conditions of use.",
      needs: [
        "Customer portals and self-service products",
        "Experiences across phones, tablets and desktops",
        "Interfaces connected to internal data and APIs",
      ],
      deliverables: [
        "User journeys and responsive interfaces",
        "Client application and required APIs",
        "Accessibility, performance and error-state checks",
      ],
      workflow: [
        "Define devices and essential actions",
        "Validate the prototype and technical approach",
        "Build and test target journeys",
      ],
      decision:
        "Web, PWA or a dedicated mobile app depends on device capabilities and distribution requirements.",
      faq: [
        [
          "Is a separate mobile app always necessary?",
          "No. Responsive web or a PWA can be enough. A dedicated app is considered when device capabilities or platform requirements justify it.",
        ],
        [
          "How is responsiveness tested?",
          "Across screen widths and key journeys: navigation, forms, errors, data loading and keyboard operation.",
        ],
      ],
    },
  },
  {
    slug: "ai-agents",
    group: "automate",
    ru: {
      title: "AI-решения и агенты",
      intro:
        "AI полезен там, где есть конкретная задача, подходящие данные и способ проверить результат. Проектируем помощников и агентные сценарии с управляемым доступом к инструментам.",
      needs: [
        "Поиск и работа с внутренними знаниями",
        "Разбор документов и подготовка черновиков",
        "Помощник, выполняющий действия через разрешённые API",
      ],
      deliverables: [
        "Проверяемый сценарий и набор оценки качества",
        "Подключение источников знаний и инструментов",
        "Ограничения доступа, наблюдаемость и эскалация человеку",
      ],
      workflow: [
        "Проверяем данные, ограничения и критерии качества",
        "Собираем прототип на ограниченном сценарии",
        "Тестируем ошибки и интегрируем в рабочий процесс",
      ],
      decision:
        "До внедрения оцениваем точность, стоимость запросов и допустимые ошибки. Ответственные действия требуют контролируемых разрешений.",
      faq: [
        [
          "Можно ли подключить корпоративные документы?",
          "Да, после определения прав доступа, форматов, актуальности данных и требований к конфиденциальности.",
        ],
        [
          "Агент может ошибаться?",
          "Да. Поэтому нужны проверки качества, ограничения инструментов и понятный переход к человеку в спорных ситуациях.",
        ],
      ],
    },
    en: {
      title: "AI solutions & intelligent agents",
      intro:
        "AI is useful when there is a specific task, suitable data and a way to evaluate results. We design assistants and agent workflows with controlled access to tools.",
      needs: [
        "Searching and working with internal knowledge",
        "Document analysis and draft preparation",
        "Assistants acting through explicitly permitted APIs",
      ],
      deliverables: [
        "Defined use case and quality evaluation set",
        "Knowledge-source and tool integrations",
        "Access controls, observability and human escalation",
      ],
      workflow: [
        "Assess data, constraints and quality criteria",
        "Prototype a tightly scoped use case",
        "Test failure modes and integrate into the workflow",
      ],
      decision:
        "We assess accuracy, request costs and acceptable errors before rollout. Consequential actions need controlled permissions.",
      faq: [
        [
          "Can corporate documents be connected?",
          "Yes, after defining access rights, formats, freshness and confidentiality requirements.",
        ],
        [
          "Can an agent make mistakes?",
          "Yes. Quality checks, limited tool permissions and a clear path to human review are necessary.",
        ],
      ],
    },
  },
  {
    slug: "business-automation",
    group: "automate",
    ru: {
      title: "Автоматизация бизнес-процессов",
      intro:
        "Убираем повторяющиеся ручные действия, сохраняя управляемость процесса. Соединяем события, правила, системы и людей в последовательный рабочий сценарий.",
      needs: [
        "Перенос данных между несколькими системами",
        "Согласования, уведомления и обработка заявок",
        "Повторяющиеся операции с понятными правилами",
      ],
      deliverables: [
        "Карта процесса и точки автоматизации",
        "Рабочие сценарии с обработкой исключений",
        "Журнал событий, уведомления и инструкции",
      ],
      workflow: [
        "Фиксируем процесс как он работает сейчас",
        "Определяем правила, исключения и ответственных",
        "Внедряем по этапам и проверяем весь маршрут",
      ],
      decision:
        "Сначала упрощаем процесс. Автоматизация не должна закреплять лишние шаги и неясную ответственность.",
      faq: [
        [
          "Что автоматизировать в первую очередь?",
          "Повторяющиеся действия с ясными входными данными, правилами и измеримым результатом.",
        ],
        [
          "Что происходит при ошибке интеграции?",
          "Нужны повторные попытки, защита от дублирования и уведомление ответственного. Эти сценарии включаем в проектирование.",
        ],
      ],
    },
    en: {
      title: "Business process automation",
      intro:
        "Remove repetitive manual actions while keeping processes manageable. Connect events, rules, systems and people into coherent workflows.",
      needs: [
        "Moving data between multiple systems",
        "Approvals, notifications and request handling",
        "Repetitive operations with clear rules",
      ],
      deliverables: [
        "Process map and automation opportunities",
        "Working flows with exception handling",
        "Event logs, notifications and operating guidance",
      ],
      workflow: [
        "Map the process as it works today",
        "Define rules, exceptions and ownership",
        "Roll out in stages and test the full journey",
      ],
      decision:
        "Simplify the process first. Automation should not preserve unnecessary steps or unclear accountability.",
      faq: [
        [
          "What should be automated first?",
          "Repetitive actions with clear inputs, rules and a measurable outcome.",
        ],
        [
          "What happens when an integration fails?",
          "Retries, deduplication and owner notifications need to be designed into the workflow.",
        ],
      ],
    },
  },
  {
    slug: "crm-erp",
    group: "operate",
    ru: {
      title: "CRM и ERP-системы",
      intro:
        "Объединяем клиентские данные и операционные процессы в рабочую систему. Определяем модель данных, роли и жизненные циклы, прежде чем переходить к интерфейсам.",
      needs: [
        "Единая история взаимодействий с клиентами",
        "Учёт ресурсов, задач и операционных статусов",
        "Связь продаж с исполнением и внутренним учётом",
      ],
      deliverables: [
        "Модель данных и правила доступа",
        "Рабочие кабинеты и операционные маршруты",
        "План миграции и интеграции с существующими системами",
      ],
      workflow: [
        "Изучаем роли, данные и реальные операции",
        "Проектируем сущности и переходы состояний",
        "Переносим данные и внедряем по подразделениям",
      ],
      decision:
        "Выбор между настройкой готовой платформы и собственной системой определяется процессами, интеграциями и стоимостью дальнейшего развития.",
      faq: [
        [
          "Обязательно разрабатывать CRM с нуля?",
          "Нет. Сначала сравниваем готовые платформы, их ограничения и возможности расширения.",
        ],
        [
          "Как переносить данные?",
          "После аудита структуры и качества: сопоставление полей, пробная миграция, проверка связей и согласованный план переключения.",
        ],
      ],
    },
    en: {
      title: "CRM & ERP development",
      intro:
        "Bring customer information and operational processes into one usable system. Define the data model, roles and lifecycles before designing screens.",
      needs: [
        "A consistent history of customer interactions",
        "Resource, task and operational status management",
        "Connecting sales, delivery and internal records",
      ],
      deliverables: [
        "Data model and access rules",
        "Working dashboards and operational workflows",
        "Migration and existing-system integration plan",
      ],
      workflow: [
        "Study roles, data and real operations",
        "Design entities and state transitions",
        "Migrate data and introduce the system in stages",
      ],
      decision:
        "Configuration versus custom development depends on processes, integrations and the cost of continued evolution.",
      faq: [
        [
          "Must a CRM be built from scratch?",
          "No. We first compare available platforms, their constraints and extension options.",
        ],
        [
          "How is data migrated?",
          "After a structure and quality audit: field mapping, trial migration, relationship validation and an agreed switchover plan.",
        ],
      ],
    },
  },
  {
    slug: "saas-b2b",
    group: "build",
    ru: {
      title: "SaaS и B2B-платформы",
      intro:
        "Создаём основу продукта для нескольких организаций и разных ролей. Продумываем изоляцию данных, доступы и ключевой пользовательский путь от подключения до ежедневной работы.",
      needs: [
        "Корпоративный продукт с несколькими организациями",
        "Партнёрский портал или B2B-кабинет",
        "Продуктовая модель с тарифами и ограничениями",
      ],
      deliverables: [
        "Архитектура организаций, ролей и доступа",
        "Основной продуктовый сценарий и onboarding",
        "Основа биллинга и интеграций, если они входят в объём",
      ],
      workflow: [
        "Определяем пользователей и границы организаций",
        "Проверяем основной сценарий и модель доступа",
        "Запускаем ядро продукта и планируем развитие",
      ],
      decision:
        "На раннем этапе важно проверить полезность основного сценария, не усложняя продукт преждевременными функциями.",
      faq: [
        [
          "Как разделяются данные организаций?",
          "Модель изоляции выбирается при проектировании и проверяется на уровне запросов, API и прав доступа.",
        ],
        [
          "Можно ли начать с MVP?",
          "Да. Определяем минимальный законченный сценарий и критерии, по которым можно оценить его полезность.",
        ],
      ],
    },
    en: {
      title: "SaaS & B2B platforms",
      intro:
        "Build a product foundation for multiple organizations and roles. Consider data isolation, access and the journey from onboarding to everyday work.",
      needs: [
        "Multi-organization business products",
        "Partner portals and B2B workspaces",
        "Products with plans and usage entitlements",
      ],
      deliverables: [
        "Organization, role and access architecture",
        "Core product workflow and onboarding",
        "Billing and integration foundations when in scope",
      ],
      workflow: [
        "Define users and organization boundaries",
        "Validate the main workflow and access model",
        "Launch the product core and plan its evolution",
      ],
      decision:
        "Early work should validate the value of the core journey without premature feature complexity.",
      faq: [
        [
          "How is organizational data separated?",
          "The isolation model is designed upfront and tested at query, API and authorization levels.",
        ],
        [
          "Can we start with an MVP?",
          "Yes. We define a minimal complete workflow and criteria for assessing its usefulness.",
        ],
      ],
    },
  },
  {
    slug: "system-integration",
    group: "automate",
    ru: {
      title: "Интеграция систем",
      intro:
        "Связываем приложения так, чтобы данные проходили полный маршрут предсказуемо. Проектируем контракты API, обработку событий и поведение при сбоях.",
      needs: [
        "Обмен данными между внутренними и внешними сервисами",
        "Синхронизация справочников и операционных событий",
        "Замена ручного экспорта и повторного ввода",
      ],
      deliverables: [
        "Карта потоков и контракты данных",
        "API, адаптеры и обработчики событий",
        "Повторы, защита от дублей и диагностика ошибок",
      ],
      workflow: [
        "Изучаем API, ограничения и владельцев данных",
        "Определяем источник истины и контракты обмена",
        "Проверяем нормальные и аварийные сценарии",
      ],
      decision:
        "Надёжная интеграция учитывает не только успешный запрос, но и задержки, повторную доставку, изменения схем и недоступность сервиса.",
      faq: [
        [
          "Можно ли интегрировать старую систему?",
          "Зависит от доступных интерфейсов: API, файлового обмена, очередей или доступа к данным. Сначала проверяем допустимый способ.",
        ],
        [
          "Как избежать дублирования?",
          "Используем идентификаторы операций, идемпотентность и согласованные правила разрешения конфликтов.",
        ],
      ],
    },
    en: {
      title: "System integration",
      intro:
        "Connect applications so data follows a predictable end-to-end route. Design API contracts, event handling and failure behavior together.",
      needs: [
        "Data exchange across internal and external services",
        "Reference data and operational event synchronization",
        "Replacing manual exports and repeated entry",
      ],
      deliverables: [
        "Flow map and data contracts",
        "APIs, adapters and event handlers",
        "Retries, deduplication and failure diagnostics",
      ],
      workflow: [
        "Study APIs, constraints and data ownership",
        "Define sources of truth and exchange contracts",
        "Validate both normal and failure scenarios",
      ],
      decision:
        "Reliable integration includes delays, redelivery, schema changes and service outages—not only successful requests.",
      faq: [
        [
          "Can a legacy system be integrated?",
          "It depends on its available interfaces: APIs, file exchange, queues or permitted data access. We assess the appropriate route first.",
        ],
        [
          "How are duplicates prevented?",
          "Through operation identifiers, idempotency and agreed conflict-resolution rules.",
        ],
      ],
    },
  },
  {
    slug: "cloud-devops",
    group: "operate",
    ru: {
      title: "Cloud и DevOps",
      intro:
        "Подготавливаем среду, в которой продукт можно собирать, проверять и выпускать повторяемо. Соединяем инфраструктуру, поставку изменений и наблюдаемость.",
      needs: [
        "Повторяемая сборка и развёртывание",
        "Разделение окружений и управление конфигурацией",
        "Наблюдаемость и план восстановления",
      ],
      deliverables: [
        "Конфигурация окружений и pipeline поставки",
        "Проверки готовности и диагностические сигналы",
        "План резервирования и восстановления по согласованным требованиям",
      ],
      workflow: [
        "Определяем ограничения и требования эксплуатации",
        "Описываем инфраструктуру и поставку изменений",
        "Проверяем запуск, откат и восстановление",
      ],
      decision:
        "Облако и инструменты выбираем по требованиям продукта, доступности платформы и возможностям команды сопровождения.",
      faq: [
        [
          "Нужен ли Kubernetes каждому продукту?",
          "Нет. Сложность платформы должна быть оправдана требованиями, а не популярностью инструмента.",
        ],
        [
          "Что входит в готовность к эксплуатации?",
          "Запуск, конфигурация, доступы, диагностика, резервирование и проверенный план действий при сбое.",
        ],
      ],
    },
    en: {
      title: "Cloud & DevOps",
      intro:
        "Prepare an environment where a product can be built, checked and released repeatably. Connect infrastructure, delivery and observability.",
      needs: [
        "Repeatable builds and deployments",
        "Separated environments and configuration management",
        "Observability and a recovery plan",
      ],
      deliverables: [
        "Environment configuration and delivery pipeline",
        "Readiness checks and diagnostic signals",
        "Backup and recovery plans based on agreed requirements",
      ],
      workflow: [
        "Define operational constraints and needs",
        "Describe infrastructure and change delivery",
        "Test startup, rollback and recovery",
      ],
      decision:
        "Cloud services and tools should match the product, platform availability and the operating team’s capabilities.",
      faq: [
        [
          "Does every product need Kubernetes?",
          "No. Platform complexity should be justified by requirements rather than tool popularity.",
        ],
        [
          "What defines operational readiness?",
          "Startup, configuration, access, diagnostics, backups and a tested response plan for failures.",
        ],
      ],
    },
  },
  {
    slug: "ui-ux-design",
    group: "design",
    ru: {
      title: "UI/UX-дизайн",
      intro:
        "Превращаем сложные процессы в понятные интерфейсы. Начинаем с задач пользователей и проверяем сценарии до того, как детализировать визуальный язык.",
      needs: [
        "Новый цифровой продукт или сложный кабинет",
        "Неочевидные пользовательские пути и ошибки интерфейса",
        "Единый язык компонентов для развития продукта",
      ],
      deliverables: [
        "Сценарии, информационная архитектура и прототип",
        "Адаптивные макеты и состояния компонентов",
        "Дизайн-система и описание взаимодействий",
      ],
      workflow: [
        "Исследуем задачи и ограничения интерфейса",
        "Проверяем структуру и интерактивный прототип",
        "Детализируем визуальную систему и передачу в разработку",
      ],
      decision:
        "Красивый интерфейс должен помогать действовать: понимать статус, принимать решение и исправлять ошибку.",
      faq: [
        [
          "Можно ли начать с редизайна одного сценария?",
          "Да. Выбираем проблемный путь, определяем цель и проверяем изменение на ограниченном участке продукта.",
        ],
        [
          "Дизайн учитывает ошибки и загрузку?",
          "Да. Пустые состояния, ожидание, ошибки, права доступа и адаптивность являются частью интерфейса.",
        ],
      ],
    },
    en: {
      title: "UI/UX design",
      intro:
        "Turn complex processes into understandable interfaces. Start with user tasks and validate journeys before refining the visual language.",
      needs: [
        "New digital products or complex workspaces",
        "Unclear journeys and interface errors",
        "A consistent component language for product evolution",
      ],
      deliverables: [
        "Journeys, information architecture and prototype",
        "Responsive screens and component states",
        "Design system and interaction specifications",
      ],
      workflow: [
        "Explore tasks and interface constraints",
        "Validate structure and interactive prototype",
        "Refine the visual system and development handoff",
      ],
      decision:
        "A good interface helps people act: understand status, make decisions and recover from errors.",
      faq: [
        [
          "Can a redesign start with one workflow?",
          "Yes. We choose a problematic journey, define its goal and validate a focused change.",
        ],
        [
          "Does design include errors and loading?",
          "Yes. Empty states, waiting, errors, permissions and responsiveness are part of the interface.",
        ],
      ],
    },
  },
  {
    slug: "business-analysis-qa",
    group: "design",
    ru: {
      title: "Бизнес-анализ и QA",
      intro:
        "Делаем требования проверяемыми, а качество — частью процесса разработки. Уточняем правила, риски и критерии готовности до выпуска изменений.",
      needs: [
        "Неясные требования и разные ожидания участников",
        "Критические сценарии с высокой ценой ошибки",
        "Проверки перед запуском или развитием продукта",
      ],
      deliverables: [
        "Карта требований и критерии приёмки",
        "Тестовые сценарии и приоритизация рисков",
        "Результаты проверок и рекомендации по автоматизации",
      ],
      workflow: [
        "Уточняем процессы, правила и ожидаемый результат",
        "Выбираем проверки по рискам и критическим путям",
        "Проверяем изменения и фиксируем основания готовности",
      ],
      decision:
        "Проверки должны подтверждать поведение продукта, а не только формально увеличивать число тестов.",
      faq: [
        [
          "Когда подключать QA?",
          "На этапе требований: ранние вопросы часто предотвращают ошибки, которые дороже исправлять после разработки.",
        ],
        [
          "Все проверки нужно автоматизировать?",
          "Нет. Автоматизация полезна для повторяющихся стабильных сценариев; исследовательские проверки и оценка удобства требуют отдельного подхода.",
        ],
      ],
    },
    en: {
      title: "Business analysis & QA",
      intro:
        "Make requirements testable and quality part of delivery. Clarify rules, risks and readiness criteria before releasing changes.",
      needs: [
        "Unclear requirements and conflicting expectations",
        "Critical journeys with costly failure modes",
        "Validation before launch or product expansion",
      ],
      deliverables: [
        "Requirement map and acceptance criteria",
        "Test scenarios and risk prioritization",
        "Validation findings and automation recommendations",
      ],
      workflow: [
        "Clarify processes, rules and expected results",
        "Select checks around risks and critical paths",
        "Validate changes and document release evidence",
      ],
      decision:
        "Checks should establish product behavior rather than merely increase a test count.",
      faq: [
        [
          "When should QA be involved?",
          "During requirements work: early questions often prevent defects that cost more to fix after implementation.",
        ],
        [
          "Should every check be automated?",
          "No. Repeated stable workflows benefit from automation; exploratory testing and usability evaluation need a different approach.",
        ],
      ],
    },
  },
];
export const serviceSlugs: string[] = services.map((service) => service.slug);
export const serviceTitles = Object.fromEntries(
  services.map((service) => [
    service.slug,
    { ru: service.ru.title, en: service.en.title },
  ]),
);
export function getService(slug: string) {
  return services.find((service) => service.slug === slug);
}
