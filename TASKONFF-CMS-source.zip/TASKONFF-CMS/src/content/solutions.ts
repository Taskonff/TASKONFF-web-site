/** Serializable scenario copy. iconId is an immutable visual selector. */
const scenarios = {
  ru: [
    {
      tab: "Запуск продукта",
      title: "От идеи — к работающему продукту.",
      description:
        "Объединяем пользовательский опыт, разработку и инфраструктуру в одну систему. Исследуйте возможную архитектуру вашего продукта.",
      iconId: "Rocket",
      nodes: [
        {
          title: "Идея и задачи",
          label: "Стратегия",
          detail:
            "Начинаем с бизнес-задачи: кому нужен продукт, какую проблему он решает и что важно проверить до разработки.",
          iconId: "Lightbulb",
        },
        {
          title: "Опыт пользователя",
          label: "Дизайн",
          detail:
            "Собираем сценарии в понятный интерфейс. Прототип помогает проверить логику и согласовать решения до написания кода.",
          iconId: "Layers3",
        },
        {
          title: "Модульная система",
          label: "Разработка",
          detail:
            "Разделяем продукт на понятные модули и интеграции. Это упрощает тестирование, сопровождение и добавление новых возможностей.",
          iconId: "Braces",
        },
        {
          title: "Запуск и развитие",
          label: "Инфраструктура",
          detail:
            "Планируем окружения, проверку качества и выпуск продукта. Архитектура учитывает будущие изменения и интеграции.",
          iconId: "Rocket",
        },
      ],
    },
    {
      tab: "Автоматизация бизнеса",
      title: "Меньше ручных действий. Больше связей.",
      description:
        "Соединяем данные, инструменты и процессы. Посмотрите, как может выглядеть путь задачи от входящего события до результата.",
      iconId: "Workflow",
      nodes: [
        {
          title: "Входящие данные",
          label: "Источники",
          detail:
            "Определяем, откуда приходят заявки и документы, какие данные нужны команде и где сейчас появляются повторные действия.",
          iconId: "FileInput",
        },
        {
          title: "Единая логика",
          label: "Процессы",
          detail:
            "Описываем правила маршрутизации, согласования и обработки исключений. Сохраняем контроль сотрудников там, где он необходим.",
          iconId: "GitBranch",
        },
        {
          title: "Связанные системы",
          label: "Интеграции",
          detail:
            "Связываем CRM, ERP и другие инструменты через согласованные интерфейсы. Учитываем права доступа и проверку данных.",
          iconId: "Network",
        },
        {
          title: "Понятный результат",
          label: "Контроль",
          detail:
            "Проектируем статусы, уведомления и возможность проследить путь задачи. Ошибки должны быть заметны и доступны для разбора.",
          iconId: "CircleCheck",
        },
      ],
    },
    {
      tab: "AI-агенты",
      title: "Интеллект, встроенный в ваш процесс.",
      description:
        "AI приносит пользу в контексте конкретной задачи. Исследуйте сценарий помощника, который использует знания компании и работает в заданных границах.",
      iconId: "Bot",
      nodes: [
        {
          title: "База знаний",
          label: "Контекст",
          detail:
            "Выбираем разрешённые источники и правила доступа. Подготовка данных определяет, какую информацию помощник сможет использовать.",
          iconId: "Database",
        },
        {
          title: "AI-помощник",
          label: "Модель",
          detail:
            "Подбираем модель под задачу, ограничения и требования к данным. Проектируем инструкции и способы проверки качества ответов.",
          iconId: "Sparkles",
        },
        {
          title: "Инструменты",
          label: "Действия",
          detail:
            "Даём агенту только необходимые инструменты: поиск, подготовку документов или работу с разрешёнными API. Определяем границы каждого действия.",
          iconId: "Boxes",
        },
        {
          title: "Контроль человека",
          label: "Проверка",
          detail:
            "Предусматриваем подтверждение значимых действий, передачу сложных запросов сотруднику и проверку результата перед использованием.",
          iconId: "ShieldCheck",
        },
      ],
    },
  ],
  en: [
    {
      tab: "Product launch",
      title: "From an idea to a working product.",
      description:
        "Connect user experience, engineering and infrastructure into one system. Explore a possible architecture for your next product.",
      iconId: "Rocket",
      nodes: [
        {
          title: "Idea & purpose",
          label: "Strategy",
          detail:
            "Start with the business problem: who needs the product, what it should solve and what needs to be tested before development.",
          iconId: "Lightbulb",
        },
        {
          title: "User experience",
          label: "Design",
          detail:
            "Turn user journeys into a clear interface. A prototype helps validate the logic and align decisions before writing code.",
          iconId: "Layers3",
        },
        {
          title: "Modular system",
          label: "Engineering",
          detail:
            "Organize the product into clear modules and integrations, making it easier to test, maintain and introduce new capabilities.",
          iconId: "Braces",
        },
        {
          title: "Launch & evolve",
          label: "Infrastructure",
          detail:
            "Plan environments, quality checks and product releases. Leave room in the architecture for future changes and integrations.",
          iconId: "Rocket",
        },
      ],
    },
    {
      tab: "Business automation",
      title: "Fewer manual steps. More connections.",
      description:
        "Connect data, tools and workflows. Explore how a task could move from an incoming event to a clear, traceable result.",
      iconId: "Workflow",
      nodes: [
        {
          title: "Incoming data",
          label: "Sources",
          detail:
            "Identify where requests and documents originate, what information the team needs and where repetitive work happens today.",
          iconId: "FileInput",
        },
        {
          title: "Shared logic",
          label: "Workflows",
          detail:
            "Define routing, approval and exception handling. Keep people in control wherever their judgment is required.",
          iconId: "GitBranch",
        },
        {
          title: "Connected tools",
          label: "Integrations",
          detail:
            "Connect CRM, ERP and other tools through agreed interfaces, with appropriate access permissions and data validation.",
          iconId: "Network",
        },
        {
          title: "A clear result",
          label: "Visibility",
          detail:
            "Design statuses, notifications and a traceable task journey. Errors should be visible and available for investigation.",
          iconId: "CircleCheck",
        },
      ],
    },
    {
      tab: "AI agents",
      title: "Intelligence, built into your workflow.",
      description:
        "AI is useful in the context of a real task. Explore an assistant that uses company knowledge and works within defined boundaries.",
      iconId: "Bot",
      nodes: [
        {
          title: "Knowledge base",
          label: "Context",
          detail:
            "Choose approved sources and access rules. Data preparation determines what information the assistant will be able to use.",
          iconId: "Database",
        },
        {
          title: "AI assistant",
          label: "Model",
          detail:
            "Select a model around the task, constraints and data requirements. Design instructions and ways to assess response quality.",
          iconId: "Sparkles",
        },
        {
          title: "Connected tools",
          label: "Actions",
          detail:
            "Give the agent only the tools it needs: search, document preparation or approved APIs. Define the boundaries of every action.",
          iconId: "Boxes",
        },
        {
          title: "Human oversight",
          label: "Review",
          detail:
            "Include approval for consequential actions, handover of complex requests and a review of results before they are used.",
          iconId: "ShieldCheck",
        },
      ],
    },
  ],
};

export const solutionCopy = {
  ru: {
    eyebrow: "ТЕХНОЛОГИИ В ДЕЙСТВИИ",
    title: "Посмотрите, как всё\nсоединяется.",
    intro:
      "Выберите задачу. Исследуйте логику решения. Каждый элемент схемы раскрывает свой этап.",
    tabsLabel: "Сценарии решений",
    scenarioLabel: "ВОЗМОЖНЫЙ СЦЕНАРИЙ",
    explore: "Исследовать",
    contact: "Обсудить свою задачу",
    scenarios: scenarios.ru,
  },
  en: {
    eyebrow: "TECHNOLOGY IN ACTION",
    title: "See how it all\nconnects.",
    intro:
      "Choose a challenge. Explore the solution. Each element reveals a part of the process.",
    tabsLabel: "Solution scenarios",
    scenarioLabel: "A POSSIBLE SCENARIO",
    explore: "Explore",
    contact: "Discuss your challenge",
    scenarios: scenarios.en,
  },
};
