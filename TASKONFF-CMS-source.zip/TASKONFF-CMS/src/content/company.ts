import type { Locale } from "@/content/site";
export const companyContent = {
  ru: {
    about: {
      label: "О КОМПАНИИ",
      title: "Создаём системы.\nДумаем о бизнесе.",
      intro:
        "TASKONFF разрабатывает программное обеспечение и внедряет цифровые решения для бизнеса. Соединяем продукты, процессы и технологии в единую логику.",
      heading: "Важен не только запуск.\nВажен смысл того, что мы создаём.",
      body: "Разработка начинается с понимания задачи: кто пользуется системой, какое действие она упрощает и с чем должна взаимодействовать. Так цифровой продукт становится частью бизнеса, а не отдельным инструментом.",
      principles: [
        [
          "Сначала контекст",
          "Разбираем цели, ограничения, текущие процессы и потребности пользователей. Технологическое решение следует из задачи.",
        ],
        [
          "Ясная архитектура",
          "Определяем границы системы, роли и интеграции. Продумываем развитие до того, как сложность станет препятствием.",
        ],
        [
          "Качество в процессе",
          "Проектирование, разработка и проверка связаны. Обратная связь помогает уточнять продукт на каждом этапе.",
        ],
      ],
      capTitle: "От идеи до связанных систем.",
      capText:
        "Направления дополняют друг друга: интерфейс, логика, данные и инфраструктура должны работать вместе.",
      capabilities: [
        [
          "Цифровые продукты",
          "Веб, мобильные приложения и SaaS-платформы.",
          "web-mobile",
        ],
        [
          "Интеллект и автоматизация",
          "AI-агенты, бизнес-процессы и интеграции.",
          "ai-agents",
        ],
        [
          "Корпоративные инструменты",
          "CRM, ERP и системы для рабочих процессов.",
          "crm-erp",
        ],
        [
          "Дизайн и качество",
          "Пользовательские сценарии, интерфейсы и QA.",
          "ui-ux-design",
        ],
      ],
      cta: "С чего начнём ваш проект?",
      capabilitiesLabel: "ЧТО МЫ ОБЪЕДИНЯЕМ",
      processLink: "Как устроена работа над проектом",
    },
    tech: {
      label: "ТЕХНОЛОГИИ",
      title: "Технологии, которые\nработают вместе.",
      intro:
        "Подбираем инструменты под задачу, интеграции и ограничения проекта. Исследуйте слои цифрового продукта: от взаимодействия с пользователем до инфраструктуры.",
      heading: "Не список инструментов.\nСвязанная архитектура.",
      note: "Интерактивная схема показывает возможную архитектуру продукта. Конкретный состав компонентов определяется на этапе анализа.",
      toolTitle: "Основа этого сайта.",
      toolText:
        "Инструменты для интерфейса, серверной логики и данных выбираются по сценариям продукта, требованиям к интеграциям и ограничениям эксплуатации.",
      tools: [
        ["Next.js / React", "Маршрутизация, серверный рендеринг и компоненты."],
        ["TypeScript", "Типы на границах модулей и предсказуемые контракты."],
        [
          "Tailwind CSS / shadcn/ui",
          "Единые визуальные правила и доступные интерфейсные примитивы.",
        ],
        [
          "Motion / Canvas",
          "Переходы, интерактивные схемы и объёмная визуализация.",
        ],
      ],
      future: "Расширение архитектуры",
      futureText:
        "Ясные границы компонентов и согласованные контракты интеграции помогают подключать новые сервисы и развивать функции без полной переработки продукта. Изменения оцениваются с учётом данных, зависимостей и требований бизнеса.",
      cta: "Подберём стек под вашу задачу.",
    },
    process: {
      label: "ПРОЦЕСС",
      title: "От ясной задачи\nк работающему продукту.",
      intro:
        "Исследование, проектирование, разработка и развитие — связанные этапы. Исследуйте, какие решения и материалы формируются на каждом из них.",
      heading: "Прозрачная логика движения.",
      note: "Состав работ, последовательность и объём итераций согласуются под конкретный проект. Схема описывает подход, а не фиксированный срок или универсальный пакет.",
      feedbackTitle: "Обратная связь — часть работы.",
      feedbackText:
        "Проверяем промежуточные результаты на понятных сценариях. Решения, вопросы и изменения обсуждаются до перехода к следующему объёму работ.",
      feedback: [
        [
          "Согласованная задача",
          "Фиксируем, какую проблему решаем и как проверяется результат.",
        ],
        [
          "Видимый промежуточный результат",
          "Демонстрируем сценарии и собираем комментарии к ним.",
        ],
        [
          "Осознанные изменения",
          "Оцениваем влияние новых требований на объём и архитектуру.",
        ],
      ],
      faqTitle: "Что важно знать перед стартом?",
      faq: [
        [
          "Можно начать без готового технического задания?",
          "Да. Для первого обсуждения достаточно описать цель, текущий процесс и ограничения. Формирование требований может стать отдельным этапом.",
        ],
        [
          "Когда выбирается стек?",
          "После уточнения сценариев, интеграций, требований к данным и инфраструктуре. Предпочтения и существующие системы учитываются при выборе.",
        ],
        [
          "Как учитываются изменения?",
          "Новые требования сопоставляются с согласованным объёмом. Приоритеты, зависимости и влияние на план уточняются до реализации.",
        ],
        [
          "Что происходит после запуска?",
          "Обсуждаются эксплуатация, документация, интеграции и дальнейшее развитие. Формат поддержки и состав работ определяются отдельно.",
        ],
      ],
      cta: "Давайте определим первый шаг.",
    },
    architecture: {
      label: "СЛОИ ПРОДУКТА",
      hint: "Выберите слой, чтобы увидеть его роль.",
      items: [
        {
          title: "Опыт пользователя",
          eyebrow: "INTERFACE",
          text: "Пользовательские сценарии превращаются в интерфейс, в котором понятны действия, состояния и обратная связь.",
          chips: ["Веб и мобильные приложения", "UI/UX", "Доступность"],
          outputs: [
            "Карта пользовательских сценариев",
            "Компоненты и состояния интерфейса",
            "Контракты взаимодействия с API",
          ],
          nodes: ["Пользователь", "Интерфейс", "Сценарий"],
        },
        {
          title: "Логика и интеграции",
          eyebrow: "APPLICATION",
          text: "Правила бизнеса, права доступа и процессы соединяют интерфейс с данными и внешними сервисами.",
          chips: ["API", "CRM / ERP", "Интеграции"],
          outputs: [
            "Границы модулей и сервисов",
            "Сценарии ошибок и повторов",
            "Согласованные контракты интеграции",
          ],
          nodes: ["Интерфейс", "Бизнес-логика", "Внешние сервисы"],
        },
        {
          title: "Данные и интеллект",
          eyebrow: "DATA / AI",
          text: "Структура данных и интеллектуальные функции подчинены задаче. Для AI определяются контекст, доступные действия и ограничения.",
          chips: ["Модели данных", "AI-агенты", "Качество данных"],
          outputs: [
            "Модель данных и правила доступа",
            "Контекст и инструменты AI-агента",
            "Критерии проверки результата",
          ],
          nodes: ["Данные", "Контекст", "Интеллект"],
        },
        {
          title: "Инфраструктура",
          eyebrow: "CLOUD / DEVOPS",
          text: "Среды, сборка, развёртывание и наблюдаемость позволяют безопасно доставлять изменения и разбирать сбои.",
          chips: ["Cloud", "CI / CD", "Наблюдаемость"],
          outputs: [
            "Структура окружений",
            "Процесс сборки и развёртывания",
            "Требования к эксплуатации",
          ],
          nodes: ["Код", "Доставка", "Рабочая среда"],
        },
      ],
      outputLabel: "ЧТО ОПРЕДЕЛЯЕМ",
    },
    phases: {
      label: "ЭТАПЫ ПРОЕКТА",
      hint: "Выберите этап и изучите его результат.",
      items: [
        {
          title: "Исследуем",
          eyebrow: "DISCOVER",
          text: "Изучаем цели, пользователей, ограничения и существующие процессы. Формируем общую картину задачи.",
          chips: ["Цели", "Сценарии", "Ограничения"],
          outputs: [
            "Описание задачи и приоритетов",
            "Ключевые пользовательские сценарии",
            "Границы первого объёма работ",
          ],
          nodes: ["Контекст", "Анализ", "Требования"],
        },
        {
          title: "Проектируем",
          eyebrow: "DESIGN",
          text: "Связываем требования с архитектурой и пользовательскими сценариями. Проверяем ключевые решения до полномасштабной разработки.",
          chips: ["Архитектура", "Прототип", "План"],
          outputs: [
            "Структура компонентов и интеграций",
            "Прототипы ключевых сценариев",
            "Согласованный план реализации",
          ],
          nodes: ["Требования", "Прототип", "Архитектура"],
        },
        {
          title: "Разрабатываем",
          eyebrow: "BUILD",
          text: "Реализуем продукт итерациями. Связываем разработку, проверку и обсуждение промежуточных результатов.",
          chips: ["Итерации", "QA", "Обратная связь"],
          outputs: [
            "Работающие сценарии продукта",
            "Результаты проверок",
            "Уточнённые приоритеты следующих шагов",
          ],
          nodes: ["Реализация", "Проверка", "Демонстрация"],
        },
        {
          title: "Развиваем",
          eyebrow: "EVOLVE",
          text: "Планируем запуск, документацию и эксплуатацию. Определяем, как продукт будет меняться с появлением новых задач.",
          chips: ["Запуск", "Документация", "Развитие"],
          outputs: [
            "План развёртывания и эксплуатации",
            "Материалы для передачи системы",
            "Согласованный список следующих задач",
          ],
          nodes: ["Запуск", "Эксплуатация", "Следующий этап"],
        },
      ],
      outputLabel: "ЧТО ОПРЕДЕЛЯЕМ",
    },
  },
  en: {
    about: {
      label: "ABOUT US",
      title: "Building systems.\nThinking business.",
      intro:
        "TASKONFF develops software and implements digital solutions for business. We connect products, processes and technology into a coherent system.",
      heading: "Beyond launching.\nTowards something that matters.",
      body: "Development starts with understanding the challenge: who uses the system, what it makes easier and what it must connect with. A digital product becomes part of the business rather than an isolated tool.",
      principles: [
        [
          "Context comes first",
          "Explore goals, constraints, existing processes and user needs. The technology follows the challenge.",
        ],
        [
          "Clear architecture",
          "Define system boundaries, roles and integrations. Plan for evolution before complexity becomes an obstacle.",
        ],
        [
          "Quality throughout",
          "Design, development and validation stay connected. Feedback helps refine the product at every stage.",
        ],
      ],
      capTitle: "From an idea to connected systems.",
      capText:
        "The disciplines complement each other: interface, logic, data and infrastructure need to work together.",
      capabilities: [
        [
          "Digital products",
          "Web, mobile applications and SaaS platforms.",
          "web-mobile",
        ],
        [
          "Intelligence & automation",
          "AI agents, business processes and integrations.",
          "ai-agents",
        ],
        [
          "Enterprise tools",
          "CRM, ERP and systems for operational workflows.",
          "crm-erp",
        ],
        [
          "Design & quality",
          "User journeys, interfaces and quality assurance.",
          "ui-ux-design",
        ],
      ],
      cta: "Where should your project begin?",
      capabilitiesLabel: "WHAT WE CONNECT",
      processLink: "How a project takes shape",
    },
    tech: {
      label: "TECHNOLOGIES",
      title: "Technology that\nworks together.",
      intro:
        "We choose tools around the challenge, integrations and constraints. Explore the layers of a digital product, from the user experience to infrastructure.",
      heading: "Beyond a list of tools.\nA connected architecture.",
      note: "This interactive diagram illustrates a possible product architecture. Specific components are chosen during project analysis.",
      toolTitle: "The foundation of this website.",
      toolText:
        "Interface, application and data tools are chosen around product scenarios, integration requirements and operational constraints.",
      tools: [
        [
          "Next.js / React",
          "Routing, server rendering and component composition.",
        ],
        ["TypeScript", "Typed module boundaries and predictable contracts."],
        [
          "Tailwind CSS / shadcn/ui",
          "Shared visual rules and accessible interface primitives.",
        ],
        [
          "Motion / Canvas",
          "Transitions, interactive diagrams and a dimensional visualization.",
        ],
      ],
      future: "Room to extend",
      futureText:
        "Clear component boundaries and agreed integration contracts help connect new services and evolve features without rebuilding the entire product. Changes are evaluated against data, dependencies and business requirements.",
      cta: "Choose a stack around your challenge.",
    },
    process: {
      label: "OUR PROCESS",
      title: "From a clear challenge\nto a working product.",
      intro:
        "Discovery, design, development and evolution are connected stages. Explore the decisions and deliverables that take shape in each one.",
      heading: "A clear way forward.",
      note: "Scope, sequence and iteration size are agreed for each project. This describes an approach, not a fixed timeline or universal package.",
      feedbackTitle: "Feedback belongs in the process.",
      feedbackText:
        "We review intermediate results through clear scenarios. Decisions, questions and changes are discussed before moving into the next scope of work.",
      feedback: [
        [
          "A shared challenge",
          "Define the problem and how the result will be evaluated.",
        ],
        [
          "Visible intermediate outcomes",
          "Demonstrate scenarios and collect feedback around them.",
        ],
        [
          "Deliberate changes",
          "Evaluate how new requirements affect scope and architecture.",
        ],
      ],
      faqTitle: "Before we begin.",
      faq: [
        [
          "Can we start without a technical specification?",
          "Yes. Describe the goal, current process and constraints for the first conversation. Requirements discovery can be a separate stage.",
        ],
        [
          "When is the technology stack chosen?",
          "After clarifying scenarios, integrations, data requirements and infrastructure. Existing systems and preferences inform the decision.",
        ],
        [
          "How are changes handled?",
          "New requirements are compared with the agreed scope. Priorities, dependencies and planning impact are discussed before implementation.",
        ],
        [
          "What happens after launch?",
          "We discuss operations, documentation, integrations and future development. Support arrangements and scope are agreed separately.",
        ],
      ],
      cta: "Let’s define the first step.",
    },
    architecture: {
      label: "PRODUCT LAYERS",
      hint: "Choose a layer to explore its role.",
      items: [
        {
          title: "User experience",
          eyebrow: "INTERFACE",
          text: "User journeys become an interface with clear actions, states and feedback.",
          chips: ["Web & mobile", "UI/UX", "Accessibility"],
          outputs: [
            "Key user journeys",
            "Interface components and states",
            "API interaction contracts",
          ],
          nodes: ["User", "Interface", "Journey"],
        },
        {
          title: "Logic & integrations",
          eyebrow: "APPLICATION",
          text: "Business rules, access rights and workflows connect the interface to data and external services.",
          chips: ["API", "CRM / ERP", "Integrations"],
          outputs: [
            "Module and service boundaries",
            "Error and retry scenarios",
            "Agreed integration contracts",
          ],
          nodes: ["Interface", "Business logic", "External services"],
        },
        {
          title: "Data & intelligence",
          eyebrow: "DATA / AI",
          text: "Data structure and intelligent functions serve the challenge. AI requires context, available actions and explicit constraints.",
          chips: ["Data models", "AI agents", "Data quality"],
          outputs: [
            "Data model and access rules",
            "AI-agent context and tools",
            "Criteria for evaluating output",
          ],
          nodes: ["Data", "Context", "Intelligence"],
        },
        {
          title: "Infrastructure",
          eyebrow: "CLOUD / DEVOPS",
          text: "Environments, builds, deployment and observability support reliable delivery and investigation of failures.",
          chips: ["Cloud", "CI / CD", "Observability"],
          outputs: [
            "Environment structure",
            "Build and deployment process",
            "Operational requirements",
          ],
          nodes: ["Code", "Delivery", "Environment"],
        },
      ],
      outputLabel: "WHAT TAKES SHAPE",
    },
    phases: {
      label: "PROJECT STAGES",
      hint: "Choose a stage and explore its deliverables.",
      items: [
        {
          title: "Discover",
          eyebrow: "DISCOVER",
          text: "Explore goals, users, constraints and existing processes. Form a shared understanding of the challenge.",
          chips: ["Goals", "Journeys", "Constraints"],
          outputs: [
            "Challenge description and priorities",
            "Key user journeys",
            "Boundaries of the initial scope",
          ],
          nodes: ["Context", "Analysis", "Requirements"],
        },
        {
          title: "Design",
          eyebrow: "DESIGN",
          text: "Connect requirements to architecture and user journeys. Validate key decisions before full development.",
          chips: ["Architecture", "Prototype", "Plan"],
          outputs: [
            "Component and integration structure",
            "Prototypes of key journeys",
            "An agreed implementation plan",
          ],
          nodes: ["Requirements", "Prototype", "Architecture"],
        },
        {
          title: "Build",
          eyebrow: "BUILD",
          text: "Develop iteratively, keeping implementation, validation and review of intermediate results connected.",
          chips: ["Iterations", "QA", "Feedback"],
          outputs: [
            "Working product scenarios",
            "Validation results",
            "Refined priorities for the next steps",
          ],
          nodes: ["Implement", "Validate", "Review"],
        },
        {
          title: "Evolve",
          eyebrow: "EVOLVE",
          text: "Plan launch, documentation and operations. Define how the product can evolve with new challenges.",
          chips: ["Launch", "Documentation", "Evolution"],
          outputs: [
            "Deployment and operations plan",
            "System handover materials",
            "Agreed list of upcoming work",
          ],
          nodes: ["Launch", "Operations", "What comes next"],
        },
      ],
      outputLabel: "WHAT TAKES SHAPE",
    },
  },
} satisfies Record<Locale, unknown>;
