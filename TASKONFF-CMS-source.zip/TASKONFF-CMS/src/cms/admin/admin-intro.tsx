import Link from "next/link";
import {
  ArrowUpRight,
  FileText,
  Images,
  PanelTop,
  Globe2,
  Check,
} from "lucide-react";
import "./admin-intro.css";

const destinations = [
  {
    href: "/admin/collections/pages",
    icon: FileText,
    number: "01",
    title: "Страницы и тексты",
    text: "Откройте нужную страницу, выберите язык и отредактируйте заголовки, описания и подписи.",
  },
  {
    href: "/admin/collections/media",
    icon: Images,
    number: "02",
    title: "Медиатека",
    text: "Загружайте изображения и логотипы. Добавляйте понятное название и описание для каждого файла.",
  },
  {
    href: "/admin/globals/site-settings",
    icon: PanelTop,
    number: "03",
    title: "Настройки сайта",
    text: "Выбирайте логотип и изображения сайта из медиатеки. Файлы можно заменить в одном месте.",
  },
];

export function AdminIntro() {
  return (
    <section className="cms-intro" aria-labelledby="cms-intro-title">
      <div className="cms-intro-top">
        <span className="cms-intro-eyebrow">
          <span />
          TASKONFF / CONTENT STUDIO
        </span>
        <div className="cms-intro-preview">
          <Globe2 size={14} />
          <span>Открыть сайт</span>
          <Link href="/ru" target="_blank" rel="noopener noreferrer">
            RU
            <ArrowUpRight size={12} />
          </Link>
          <Link href="/en" target="_blank" rel="noopener noreferrer">
            EN
            <ArrowUpRight size={12} />
          </Link>
        </div>
      </div>
      <div className="cms-intro-heading">
        <h2 id="cms-intro-title">
          Ваш контент.
          <br />
          <span>Ваше управление.</span>
        </h2>
        <p>
          Тексты на двух языках, логотип и изображения — всё, что нужно для
          обновления сайта.
        </p>
      </div>
      <div className="cms-intro-grid">
        {destinations.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href} className="cms-intro-card">
              <div className="cms-intro-card-top">
                <span className="cms-intro-icon">
                  <Icon size={21} strokeWidth={1.5} />
                </span>
                <span>{item.number}</span>
              </div>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
              <span className="cms-intro-card-link">
                Открыть раздел
                <ArrowUpRight size={17} />
              </span>
            </Link>
          );
        })}
      </div>
      <div className="cms-intro-help">
        <span className="cms-intro-help-icon">
          <Check size={17} />
        </span>
        <div>
          <strong>Сначала черновик, затем публикация.</strong>
          <p>
            Сохраните изменения страницы, проверьте текст и опубликуйте готовую
            версию. После публикации откройте сайт и проверьте результат.
          </p>
        </div>
      </div>
    </section>
  );
}
