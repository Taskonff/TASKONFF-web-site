"use client";

import { useField } from "@payloadcms/ui";
import {
  Search,
  Languages,
  ChevronDown,
  LockKeyhole,
  FileText,
} from "lucide-react";
import { useId, useMemo, useRef, useState, type KeyboardEvent } from "react";
import type { JSONFieldClientComponent } from "payload";
import "./text-tree-field.css";

type Segment = string | number;
type JsonValue =
  string | number | boolean | null | JsonValue[] | { [key: string]: JsonValue };
type Leaf = { path: Segment[]; value: string; labels: string[] };
const protectedKeys = new Set([
  "id",
  "key",
  "slug",
  "href",
  "url",
  "icon",
  "iconid",
  "group",
  "route",
  "blocktype",
  "locale",
  "_status",
  "createdat",
  "updatedat",
  "__proto__",
  "prototype",
  "constructor",
]);
// Route values also appear inside legacy content tuples. Keep the route intact
// while allowing the human-facing title and description to change.
const fixedRouteValues = new Set([
  "custom-software",
  "web-mobile",
  "ai-agents",
  "business-automation",
  "crm-erp",
  "saas-b2b",
  "system-integration",
  "cloud-devops",
  "ui-ux-design",
  "business-analysis-qa",
]);
function editableText(value: string) {
  return (
    !fixedRouteValues.has(value) &&
    !value.startsWith("/ru/") &&
    !value.startsWith("/en/") &&
    !value.startsWith("#")
  );
}
const labels: Record<string, string> = {
  ru: "Русский",
  en: "English",
  home: "Главная страница",
  site: "Тексты разделов главной",
  shared: "Меню и общие элементы",
  explorer: "Интерактивная схема",
  hero: "Первый экран",
  nav: "Навигация",
  title: "Заголовок",
  titlefirst: "Первая строка заголовка",
  titlesecond: "Вторая строка заголовка",
  label: "Название",
  name: "Название",
  text: "Текст",
  description: "Описание",
  intro: "Вводный текст",
  heading: "Заголовок раздела",
  eyebrow: "Подпись над заголовком",
  primary: "Основная кнопка",
  secondary: "Дополнительная кнопка",
  scroll: "Подсказка прокрутки",
  visual: "Подпись визуализации",
  system: "Подпись схемы",
  visuallabels: "Подписи визуализации",
  services: "Услуги",
  expertisе: "Экспертиза",
  expertise: "Экспертиза",
  servicestitle: "Заголовок услуг",
  servicesintro: "Описание услуг",
  detail: "Кнопка услуги",
  tags: "Направления и теги",
  about: "О компании",
  aboutlabel: "Подпись раздела о компании",
  abouttitle: "Заголовок раздела о компании",
  abouttext: "Текст о компании",
  process: "Процесс работы",
  processlabel: "Подпись процесса",
  processtitle: "Заголовок процесса",
  tech: "Технологии",
  technologies: "Технологии",
  techlabel: "Подпись технологий",
  techtitle: "Заголовок технологий",
  techtext: "Текст о технологиях",
  techcaption: "Подпись списка технологий",
  contact: "Контакты",
  contactlabel: "Подпись контактов",
  contacttitle: "Заголовок контактов",
  contacttext: "Описание контактов",
  formname: "Поле «Имя»",
  formemail: "Поле «Email»",
  formservice: "Поле «Направление»",
  formmessage: "Поле «О проекте»",
  formplaceholder: "Подсказка описания проекта",
  formsubmit: "Кнопка брифа",
  formnote: "Пояснение к форме",
  formsuccess: "Успешный результат формы",
  formerror: "Ошибка формы",
  formpending: "Загрузка формы",
  general: "Значение по умолчанию",
  footer: "Подвал сайта",
  rights: "Права и копирайт",
  top: "Кнопка «Наверх»",
  language: "Подпись переключения языка",
  menu: "Кнопка меню",
  close: "Закрытие меню",
  skip: "Переход к содержимому",
  brandnote: "Примечание о бренде",
  body: "Основной текст",
  note: "Примечание",
  caption: "Подпись",
  button: "Кнопка",
  cta: "Призыв к действию",
  ctatitle: "Заголовок призыва",
  ctatext: "Текст призыва",
  ctalabel: "Кнопка призыва",
  items: "Элементы",
  cards: "Карточки",
  sections: "Разделы",
  steps: "Этапы",
  faq: "Вопросы и ответы",
  question: "Вопрос",
  answer: "Ответ",
  principles: "Принципы",
  capabilities: "Направления работы",
  architecture: "Архитектура",
  phases: "Этапы проекта",
  responsibilities: "Зоны ответственности",
  deliverables: "Результаты работы",
  needs: "Задачи",
  workflow: "Как проходит работа",
  decision: "Критерий выбора",
  summary: "Краткое описание",
  portfolio: "Портфолио",
  industries: "Отрасли",
  scenarios: "Сценарии",
  scenario: "Сценарий",
  scenarioslabel: "Подпись сценариев",
  tools: "Инструменты",
  future: "Развитие",
  futuretext: "Текст о развитии",
  emptytitle: "Заголовок пустого состояния",
  emptytext: "Описание пустого состояния",
  evidence: "Содержание кейса",
  evidencelabel: "Подпись содержания кейса",
  evidencetitle: "Заголовок содержания кейса",
  mode: "Подпись режима",
  modetitle: "Заголовок режима",
  modetext: "Описание режима",
  modehelp: "Подсказка режима",
  prepare: "Подготовка к проекту",
  preparelabel: "Подпись подготовки",
  preparetitle: "Заголовок подготовки",
  faqtitle: "Заголовок FAQ",
  privacylink: "Ссылка об обработке данных",
  privacy: "Конфиденциальность",
  terms: "Условия использования",
  legal: "Правовая информация",
  draftlabel: "Подпись проекта документа",
  drafttext: "Описание проекта документа",
  contents: "Оглавление",
  backcontact: "Переход к контактам",
  headline: "Заголовок",
  slogan: "Слоган",
  kicker: "Короткая подпись",
  hint: "Подсказка",
  active: "Подписи активных режимов",
  pause: "Кнопка паузы",
  play: "Кнопка воспроизведения",
  groups: "Группы",
  links: "Ссылки",
  value: "Текст",
  alt: "Описание изображения",
  result: "Результат",
  features: "Возможности",
  objectives: "Цели",
  client: "Участие заказчика",
  acceptance: "Критерии готовности",
  chips: "Теги",
  diagram: "Схема",
  nodes: "Элементы схемы",
  actions: "Действия",
  copy: "Тексты",
  content: "Содержимое",
  titlelines: "Строки заголовка",
  titleparts: "Части заголовка",
  benefits: "Преимущества",
  lead: "Вводный текст",
  navigation: "Навигация",
  settings: "Настройки",
  common: "Общие тексты",
  page: "Страница",
  pages: "Страницы",
  solutions: "Сценарии решений",
  service: "Услуга",
  technology: "Технология",
  tagline: "Короткое описание",
  preview: "Предпросмотр",
  eyebrowlabel: "Подпись раздела",
  tab: "Название вкладки",
  tablabel: "Название вкладки",
  contactdescription: "Описание контактов",
  herointro: "Описание первого экрана",
  herotitle: "Заголовок первого экрана",
  form: "Форма брифа",
  footertext: "Описание в подвале",
  illustration: "Подписи иллюстрации",
};
function record(value: unknown): value is Record<string, JsonValue> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function editableKey(key: string) {
  return !protectedKeys.has(key.toLowerCase());
}
function labelFor(key: Segment): string {
  if (typeof key === "number") return `Элемент ${key + 1}`;
  return (
    labels[key.toLowerCase()] ??
    key
      .replace(/([a-z\d])([A-Z])/g, "$1 $2")
      .replace(/[_-]+/g, " ")
      .replace(/^./, (first) => first.toUpperCase())
  );
}
function itemLabel(value: JsonValue, index: number) {
  if (record(value)) {
    for (const key of ["title", "name", "heading", "label", "question"]) {
      const text = value[key];
      if (typeof text === "string" && text.trim())
        return `${index + 1}. ${text.replace(/\s+/g, " ").slice(0, 70)}`;
    }
  }
  if (Array.isArray(value) && typeof value[0] === "string" && value[0].trim())
    return `${index + 1}. ${value[0].replace(/\s+/g, " ").slice(0, 70)}`;
  return `Элемент ${index + 1}`;
}
function collect(
  value: JsonValue | undefined,
  path: Segment[] = [],
  trail: string[] = [],
): Leaf[] {
  if (typeof value === "string")
    return editableText(value) ? [{ path, value, labels: trail }] : [];
  if (Array.isArray(value))
    return value.flatMap((item, index) =>
      collect(item, [...path, index], [...trail, itemLabel(item, index)]),
    );
  if (record(value))
    return Object.entries(value)
      .filter(([key]) => editableKey(key))
      .flatMap(([key, child]) =>
        collect(child, [...path, key], [...trail, labelFor(key)]),
      );
  return [];
}
function replace(value: JsonValue, path: Segment[], text: string): JsonValue {
  if (!path.length) return typeof value === "string" ? text : value;
  const [key, ...rest] = path;
  if (
    Array.isArray(value) &&
    typeof key === "number" &&
    key >= 0 &&
    key < value.length
  ) {
    const next = value.slice();
    next[key] = replace(value[key], rest, text);
    return next;
  }
  if (
    record(value) &&
    typeof key === "string" &&
    editableKey(key) &&
    Object.hasOwn(value, key)
  )
    return { ...value, [key]: replace(value[key], rest, text) };
  return value;
}
function TextInput({
  leaf,
  idPrefix,
  readOnly,
  onEdit,
  search = false,
}: {
  leaf: Leaf;
  idPrefix: string;
  readOnly: boolean;
  onEdit: (path: Segment[], value: string) => void;
  search?: boolean;
}) {
  const id = `${idPrefix}-${leaf.path.map((segment) => encodeURIComponent(String(segment))).join("-")}`;
  const title = leaf.labels.at(-1) ?? "Текст";
  const lines = Math.min(
    7,
    Math.max(
      2,
      leaf.value.split("\n").length,
      Math.ceil(leaf.value.length / 105),
    ),
  );
  return (
    <div className="cms-tree-input">
      {search && leaf.labels.length > 1 && (
        <div className="cms-tree-breadcrumb">
          {leaf.labels.slice(0, -1).join(" / ")}
        </div>
      )}
      <label htmlFor={id}>
        {title}
        {readOnly && <LockKeyhole size={12} aria-label="Только чтение" />}
      </label>
      <textarea
        id={id}
        value={leaf.value}
        readOnly={readOnly}
        rows={lines}
        onChange={(event) => onEdit(leaf.path, event.target.value)}
        spellCheck
        className={leaf.value.length > 220 ? "cms-tree-long" : undefined}
      />
    </div>
  );
}
function GroupNode({
  value,
  path,
  title,
  depth,
  idPrefix,
  readOnly,
  onEdit,
}: {
  value: JsonValue;
  path: Segment[];
  title: string;
  depth: number;
  idPrefix: string;
  readOnly: boolean;
  onEdit: (path: Segment[], value: string) => void;
}) {
  const [open, setOpen] = useState(depth < 1);
  const count = collect(value).length;
  if (!count) return null;
  if (typeof value === "string")
    return (
      <TextInput
        leaf={{ path, value, labels: [title] }}
        idPrefix={idPrefix}
        readOnly={readOnly}
        onEdit={onEdit}
      />
    );
  const entries: { key: Segment; value: JsonValue; label: string }[] =
    Array.isArray(value)
      ? value.map((item, index) => ({
          key: index,
          value: item,
          label: itemLabel(item, index),
        }))
      : record(value)
        ? Object.entries(value)
            .filter(([key]) => editableKey(key))
            .map(([key, child]) => ({
              key,
              value: child,
              label: labelFor(key),
            }))
        : [];
  return (
    <details
      className={`cms-tree-group cms-tree-depth-${Math.min(depth, 3)}`}
      open={open}
      onToggle={(event) => setOpen(event.currentTarget.open)}
    >
      <summary>
        <ChevronDown size={15} />
        <span>{title}</span>
        <span className="cms-tree-group-count">{count}</span>
      </summary>
      <div className="cms-tree-group-body">
        {entries.map((entry) => (
          <GroupNode
            key={entry.key}
            value={entry.value}
            path={[...path, entry.key]}
            title={entry.label}
            depth={depth + 1}
            idPrefix={idPrefix}
            readOnly={readOnly}
            onEdit={onEdit}
          />
        ))}
      </div>
    </details>
  );
}
export const TextTreeField: JSONFieldClientComponent = ({
  path,
  field,
  readOnly,
}) => {
  const { value, setValue, showError, errorMessage, disabled, formProcessing } =
    useField<JsonValue>({
      path,
    });
  const uid = useId();
  const [language, setLanguage] = useState<"ru" | "en">("ru");
  const [query, setQuery] = useState("");
  const tabRefs = useRef<
    Partial<Record<"ru" | "en", HTMLButtonElement | null>>
  >({});
  const isReadOnly = Boolean(
    readOnly || field.admin?.readOnly || disabled || formProcessing,
  );
  const localized = record(value) && ("ru" in value || "en" in value);
  const languageKey =
    localized && record(value) && !(language in value)
      ? "ru" in value
        ? "ru"
        : "en"
      : language;
  const selected = localized && record(value) ? value[languageKey] : value;
  const prefix: Segment[] = localized ? [languageKey] : [];
  const leaves = useMemo(
    () => collect(selected, localized ? [languageKey] : [], []),
    [selected, localized, languageKey],
  );
  const normalized = query.trim().toLocaleLowerCase();
  const results = normalized
    ? leaves.filter((leaf) =>
        `${leaf.labels.join(" ")} ${leaf.value}`
          .toLocaleLowerCase()
          .includes(normalized),
      )
    : leaves;
  const fieldLabel =
    typeof field.label === "string"
      ? field.label
      : record(field.label) && typeof field.label.ru === "string"
        ? field.label.ru
        : "Тексты страницы";
  function navigateLanguage(
    event: KeyboardEvent<HTMLButtonElement>,
    locale: "ru" | "en",
  ) {
    const available = (["ru", "en"] as const).filter(
      (item) => record(value) && item in value,
    );
    const index = available.indexOf(locale);
    let next = index;
    if (event.key === "ArrowRight") next = (index + 1) % available.length;
    else if (event.key === "ArrowLeft")
      next = (index + available.length - 1) % available.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = available.length - 1;
    else return;
    event.preventDefault();
    const target = available[next];
    if (!target) return;
    setLanguage(target);
    tabRefs.current[target]?.focus();
  }
  function edit(target: Segment[], text: string) {
    if (!isReadOnly && value !== undefined)
      setValue(replace(value, target, text));
  }
  const entries = Array.isArray(selected)
    ? selected.map((item, index) => ({
        key: index as Segment,
        value: item,
        label: itemLabel(item, index),
      }))
    : record(selected)
      ? Object.entries(selected)
          .filter(([key]) => editableKey(key))
          .map(([key, item]) => ({
            key: key as Segment,
            value: item,
            label: labelFor(key),
          }))
      : [];
  return (
    <section className="cms-tree" aria-label={fieldLabel}>
      <div className="cms-tree-heading">
        <div>
          <span className="cms-tree-kicker">
            <FileText size={14} />
            РЕДАКТОР СТРАНИЦЫ
          </span>
          <h3>{fieldLabel}</h3>
          <p>
            Меняйте текст в полях. Сохраните черновик или опубликуйте изменения
            кнопками страницы.
          </p>
        </div>
        {isReadOnly && (
          <span className="cms-tree-readonly">
            <LockKeyhole size={13} />
            Только чтение
          </span>
        )}
      </div>
      <div className="cms-tree-toolbar">
        {localized && (
          <div
            className="cms-tree-languages"
            role="tablist"
            aria-label="Язык контента"
          >
            <Languages size={16} aria-hidden="true" />
            {(["ru", "en"] as const)
              .filter((locale) => record(value) && locale in value)
              .map((locale) => (
                <button
                  type="button"
                  id={`${uid}-tab-${locale}`}
                  key={locale}
                  role="tab"
                  ref={(node) => {
                    tabRefs.current[locale] = node;
                  }}
                  tabIndex={languageKey === locale ? 0 : -1}
                  onKeyDown={(event) => navigateLanguage(event, locale)}
                  aria-selected={languageKey === locale}
                  aria-controls={`${uid}-panel`}
                  onClick={() => setLanguage(locale)}
                >
                  {locale === "ru" ? "Русский" : "English"}
                  <span>
                    {record(value) ? collect(value[locale]).length : 0}
                  </span>
                </button>
              ))}
          </div>
        )}
        <label className="cms-tree-search">
          <Search size={16} />
          <span className="cms-tree-sr-only">Найти текст или раздел</span>
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Найти текст или раздел"
          />
        </label>
      </div>
      <div
        className="cms-tree-panel"
        id={`${uid}-panel`}
        role={localized ? "tabpanel" : undefined}
        tabIndex={localized ? 0 : undefined}
        lang={localized ? languageKey : undefined}
        aria-labelledby={localized ? `${uid}-tab-${languageKey}` : undefined}
      >
        {selected === undefined || selected === null ? (
          <div className="cms-tree-empty">
            <FileText size={25} />
            <h4>Тексты пока не загружены</h4>
            <p>
              Сначала добавьте начальные материалы страницы через команду
              подготовки CMS.
            </p>
          </div>
        ) : normalized ? (
          <>
            <p className="cms-tree-result-count" role="status">
              Найдено полей: <strong>{results.length}</strong>
            </p>
            {results.length ? (
              <div className="cms-tree-search-results">
                {results.map((leaf) => (
                  <TextInput
                    key={JSON.stringify(leaf.path)}
                    leaf={leaf}
                    idPrefix={uid}
                    readOnly={isReadOnly}
                    onEdit={edit}
                    search
                  />
                ))}
              </div>
            ) : (
              <div className="cms-tree-empty">
                <Search size={25} />
                <h4>Совпадений нет</h4>
                <p>Попробуйте другое слово или выберите другой язык.</p>
              </div>
            )}
          </>
        ) : typeof selected === "string" ? (
          <TextInput
            leaf={{ path: prefix, value: selected, labels: [fieldLabel] }}
            idPrefix={uid}
            readOnly={isReadOnly}
            onEdit={edit}
          />
        ) : (
          <div className="cms-tree-groups">
            {entries.map((entry) => (
              <GroupNode
                key={`${languageKey}-${entry.key}`}
                value={entry.value}
                path={[...prefix, entry.key]}
                title={entry.label}
                depth={0}
                idPrefix={uid}
                readOnly={isReadOnly}
                onEdit={edit}
              />
            ))}
          </div>
        )}
      </div>
      {showError && (
        <p className="cms-tree-error" role="alert">
          {typeof errorMessage === "string"
            ? errorMessage
            : "Проверьте содержимое страницы."}
        </p>
      )}
      <p className="cms-tree-footnote">
        Изменения в русском и английском тексте сохраняются вместе. Переносы
        строк поддерживаются.
      </p>
    </section>
  );
};
