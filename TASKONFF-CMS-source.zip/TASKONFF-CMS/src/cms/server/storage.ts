import { randomBytes } from "node:crypto";
import {
  chmodSync,
  existsSync,
  linkSync,
  mkdirSync,
  readFileSync,
  unlinkSync,
  writeFileSync,
} from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

/** Keep the database, uploaded files and signing key outside public/ and source archives. */
export function getCMSPaths() {
  const dataDir = path.resolve(
    /* turbopackIgnore: true */
    process.env.CMS_DATA_DIR || path.join(process.cwd(), "data"),
  );
  const publicDir = path.resolve(process.cwd(), "public");
  if (dataDir === publicDir || dataDir.startsWith(`${publicDir}${path.sep}`)) {
    throw new Error(
      "CMS_DATA_DIR must be outside the publicly served public directory.",
    );
  }
  mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  chmodSync(dataDir, 0o700);
  const mediaDir = path.join(dataDir, "media");
  mkdirSync(mediaDir, { recursive: true, mode: 0o700 });
  return {
    dataDir,
    mediaDir,
    secretPath: path.join(dataDir, ".payload-secret"),
    databaseURL: pathToFileURL(path.join(dataDir, "taskonff.sqlite")).href,
  };
}

export function getCMSSecret(): string {
  if (process.env.PAYLOAD_SECRET) {
    if (Buffer.byteLength(process.env.PAYLOAD_SECRET) < 32) {
      throw new Error("PAYLOAD_SECRET must contain at least 32 bytes.");
    }
    return process.env.PAYLOAD_SECRET;
  }

  const { secretPath } = getCMSPaths();
  if (!existsSync(/* turbopackIgnore: true */ secretPath)) {
    // Linking a fully written private file prevents concurrent workers reading a partial key.
    const temporaryPath = `${secretPath}.${process.pid}.${randomBytes(8).toString("hex")}`;
    writeFileSync(temporaryPath, randomBytes(48).toString("hex"), {
      flag: "wx",
      mode: 0o600,
    });
    try {
      linkSync(temporaryPath, secretPath);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
    } finally {
      unlinkSync(temporaryPath);
    }
  }
  chmodSync(secretPath, 0o600);
  const secret = readFileSync(
    /* turbopackIgnore: true */ secretPath,
    "utf8",
  ).trim();
  if (Buffer.byteLength(secret) < 32) {
    throw new Error(
      "The stored CMS signing key is invalid. Restore it from a private backup.",
    );
  }
  return secret;
}
