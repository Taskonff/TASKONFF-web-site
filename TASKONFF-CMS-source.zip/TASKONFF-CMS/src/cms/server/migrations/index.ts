import * as migration_20261105_094319_initial from "./20261105_094319_initial";

export const migrations = [
  {
    up: migration_20261105_094319_initial.up,
    down: migration_20261105_094319_initial.down,
    name: "20261105_094319_initial",
  },
];
