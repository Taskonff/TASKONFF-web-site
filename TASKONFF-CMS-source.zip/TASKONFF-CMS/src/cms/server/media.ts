import { readFile } from "node:fs/promises";
import path from "node:path";
import { APIError, type CollectionBeforeOperationHook } from "payload";
import sharp from "sharp";

export const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
export const MAX_IMAGE_PIXELS = 32_000_000;
export const IMAGE_MIME_TYPES = [
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/gif",
];

export async function validateImageBuffer(buffer: Buffer, mimeType: string) {
  if (buffer.byteLength > MAX_IMAGE_BYTES)
    throw new APIError("Images must be no larger than 8 MB.", 413);
  if (!IMAGE_MIME_TYPES.includes(mimeType)) {
    throw new APIError(
      "Upload a PNG, JPEG, WebP or GIF image. SVG files are not supported.",
      400,
    );
  }
  try {
    const metadata = await sharp(buffer, {
      limitInputPixels: MAX_IMAGE_PIXELS,
    }).metadata();
    const matchingFormat: Record<string, string> = {
      "image/png": "png",
      "image/jpeg": "jpeg",
      "image/webp": "webp",
      "image/gif": "gif",
    };
    if (
      metadata.format !== matchingFormat[mimeType] ||
      !metadata.width ||
      !metadata.height ||
      metadata.width * metadata.height * (metadata.pages || 1) >
        MAX_IMAGE_PIXELS
    ) {
      throw new Error("Unsupported image");
    }
    // Metadata alone may accept a truncated header; decode pixels before persisting the file.
    await sharp(buffer, { limitInputPixels: MAX_IMAGE_PIXELS }).stats();
  } catch {
    throw new APIError(
      "The image is invalid or exceeds the 32 megapixel limit.",
      400,
    );
  }
}

export const validateMediaUpload: CollectionBeforeOperationHook = async ({
  req,
  operation,
  overrideAccess,
}) => {
  if (operation !== "create" && operation !== "update") return;
  // Collection beforeOperation runs before Payload's access checks and image decoding.
  if (!req.user && !overrideAccess)
    throw new APIError("Sign in to upload images.", 403);
  if (!req.file) return;
  const file = req.file;
  if (file.size > MAX_IMAGE_BYTES)
    throw new APIError("Images must be no larger than 8 MB.", 413);
  const buffer = file.data?.length
    ? file.data
    : file.tempFilePath
      ? await readFile(file.tempFilePath)
      : undefined;
  if (!buffer) throw new APIError("The uploaded image could not be read.", 400);
  await validateImageBuffer(buffer, file.mimetype);
  const extensions: Record<string, string> = {
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/webp": "webp",
    "image/gif": "gif",
  };
  const sourceName = path.basename(file.name, path.extname(file.name));
  const safeName =
    sourceName.replace(/[^a-zA-Z0-9_-]/g, "-").slice(0, 100) || "image";
  file.name = `${safeName}.${extensions[file.mimetype]}`;
};
