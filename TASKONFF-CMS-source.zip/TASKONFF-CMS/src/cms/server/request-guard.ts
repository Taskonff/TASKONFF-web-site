export const MAX_CMS_JSON_BYTES = 1024 * 1024;

type CMSRouteContext = { params: Promise<{ slug?: string[] }> };
type CMSHandler = (
  request: Request,
  context: CMSRouteContext,
) => Promise<Response>;

function rejection(status: number, message: string) {
  return Response.json(
    { errors: [{ message }] },
    { status, headers: { "Cache-Control": "no-store" } },
  );
}

/** Authenticate browser origin before Payload reads a body or handles session cookies. */
export async function guardCMSMutation(
  request: Request,
): Promise<Request | Response> {
  const origin = request.headers.get("origin");
  const fetchSite = request.headers.get("sec-fetch-site");
  try {
    const incoming = new URL(request.url);
    const configuredURL =
      process.env.SITE_URL || process.env.NEXT_PUBLIC_SITE_URL;
    const host = request.headers.get("host");
    const expected = configuredURL
      ? new URL(configuredURL).origin
      : host
        ? new URL(`${incoming.protocol}//${host}`).origin
        : incoming.origin;
    if (!origin || origin !== expected || fetchSite === "cross-site") {
      return rejection(403, "A same-origin request is required.");
    }
  } catch {
    return rejection(403, "A same-origin request is required.");
  }

  // Payload applies its multipart limit separately. Its JSON parser otherwise reads unbounded text.
  if (
    request.headers
      .get("content-type")
      ?.toLowerCase()
      .startsWith("multipart/form-data")
  )
    return request;
  const declaredSize = request.headers.get("content-length");
  if (
    declaredSize &&
    (!/^\d+$/.test(declaredSize) || Number(declaredSize) > MAX_CMS_JSON_BYTES)
  ) {
    return rejection(413, "The request body must be no larger than 1 MB.");
  }
  if (!request.body) return request;
  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let length = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      length += value.byteLength;
      if (length > MAX_CMS_JSON_BYTES) {
        await reader.cancel();
        return rejection(413, "The request body must be no larger than 1 MB.");
      }
      chunks.push(value);
    }
  } catch {
    return rejection(400, "The request body could not be read.");
  } finally {
    reader.releaseLock();
  }
  const body = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    body.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return new Request(request, { body: body.buffer });
}

export function protectCMSMutation(handler: CMSHandler): CMSHandler {
  return async (request, context) => {
    const checked = await guardCMSMutation(request);
    return checked instanceof Response ? checked : handler(checked, context);
  };
}
