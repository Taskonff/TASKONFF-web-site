import {
  APIError,
  type Access,
  type CollectionBeforeChangeHook,
  type CollectionBeforeDeleteHook,
  type CollectionBeforeOperationHook,
} from "payload";

export const authenticated = ({ req }: Parameters<Access>[0]) =>
  Boolean(req.user);
export const publishedOrAuthenticated: Access = ({ req }) =>
  req.user ? true : { _status: { equals: "published" } };

/** The public register-first-user endpoint bypasses access.create; this hook must not. */
export const protectAccountCreation: CollectionBeforeChangeHook = async ({
  operation,
  req,
  context,
  data,
}) => {
  if (operation === "create" && !req.user) {
    if (context.bootstrap !== true) {
      throw new APIError(
        "Public registration is disabled. Run npm run admin:setup on the server.",
        403,
      );
    }
    const existing = await req.payload.count({
      collection: "users",
      overrideAccess: true,
      req,
    });
    if (existing.totalDocs > 0) {
      throw new APIError(
        "The first administrator already exists. Sign in to manage accounts.",
        409,
      );
    }
  }
  if (typeof data.password === "string" && data.password.length < 12) {
    throw new APIError(
      "Use a password containing at least 12 characters.",
      400,
    );
  }
  return data;
};

export const protectLastAccount: CollectionBeforeDeleteHook = async ({
  req,
}) => {
  const existing = await req.payload.count({
    collection: "users",
    overrideAccess: true,
    req,
  });
  if (existing.totalDocs <= 1) {
    throw new APIError("The last administrator cannot be deleted.", 409);
  }
};

export const disableUnconfiguredPasswordEmail: CollectionBeforeOperationHook =
  ({ operation }) => {
    if (operation === "forgotPassword") {
      // Payload's default email adapter logs messages. Never send reset tokens to that adapter.
      throw new APIError(
        "Email recovery is not configured. The server owner can run npm run admin:setup -- --reset-password.",
        503,
      );
    }
  };
