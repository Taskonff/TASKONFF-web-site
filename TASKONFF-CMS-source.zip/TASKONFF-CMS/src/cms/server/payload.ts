import { getPayload } from "payload";
import config from "@payload-config";

export function getCms() {
  return getPayload({ config });
}

export { seedSiteDefaults } from "./seed";
