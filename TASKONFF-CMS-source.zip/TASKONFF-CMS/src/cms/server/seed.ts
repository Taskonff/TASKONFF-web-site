import type { Page } from "@/cms/payload-types";
import type { Payload } from "payload";
import { pageDefinitions } from "@/cms/defaults";

/** Only add missing pages. Rerunning setup never overwrites an editor's content. */
export async function seedSiteDefaults(payload: Payload) {
  let created = 0;
  for (const definition of pageDefinitions) {
    const existing = await payload.find({
      collection: "pages",
      where: { key: { equals: definition.key } },
      limit: 1,
      depth: 0,
      overrideAccess: true,
    });
    if (existing.totalDocs) continue;
    await payload.create({
      collection: "pages",
      data: {
        key: definition.key as Page["key"],
        title: definition.title,
        content: definition.content,
        _status: "published",
      },
      overrideAccess: true,
    });
    created += 1;
  }
  return created;
}
