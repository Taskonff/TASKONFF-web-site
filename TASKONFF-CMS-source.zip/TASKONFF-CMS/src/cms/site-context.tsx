"use client";
import { createContext, useContext } from "react";
import type { CmsSiteData } from "./defaults";
const SiteContext = createContext<CmsSiteData | null>(null);
export function SiteContentProvider({
  value,
  children,
}: {
  value: CmsSiteData;
  children: React.ReactNode;
}) {
  return <SiteContext.Provider value={value}>{children}</SiteContext.Provider>;
}
export function useSiteContent() {
  const data = useContext(SiteContext);
  if (!data) throw new Error("SiteContentProvider is required");
  return data;
}
