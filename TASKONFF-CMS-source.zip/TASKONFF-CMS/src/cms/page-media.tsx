import Image from "next/image";
import { getSiteData } from "./site-data";
export async function PageMedia({
  pageKey,
  className = "",
  hero = false,
}: {
  pageKey: string;
  className?: string;
  hero?: boolean;
}) {
  const data = await getSiteData();
  const image = data.pageMedia[pageKey];
  if (!image) return null;
  return (
    <section
      className={`cms-page-media ${hero ? "cms-page-media-hero" : ""} ${className}`}
    >
      <div className="container">
        <Image
          src={image.url}
          alt={image.alt}
          width={1600}
          height={900}
          unoptimized
          sizes="(max-width:640px) 100vw, 1320px"
          style={{
            width: "100%",
            height: "auto",
            maxHeight: hero ? "640px" : "560px",
            objectFit: "contain",
            borderRadius: "10px",
          }}
        />
      </div>
    </section>
  );
}
