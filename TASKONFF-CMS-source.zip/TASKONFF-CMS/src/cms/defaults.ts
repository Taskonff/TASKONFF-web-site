import { content } from "@/content/site";
import { companyContent } from "@/content/company";
import { trustContent } from "@/content/trust";
import { services, serviceGroups } from "@/content/services";
import { homeCopy } from "@/content/home";
import { solutionCopy } from "@/content/solutions";
import { expertiseCopy } from "@/content/expertise";
import { pageNames } from "@/lib/routes";
export const sharedCopy = {
  ru: {
    navigation: pageNames.ru,
    homeLabel: "Главная",
    cta: {
      eyebrow: "СЛЕДУЮЩИЙ ШАГ",
      title: "От задачи — к решению.",
      description:
        "Расскажите, что вы хотите создать или улучшить. Начнём с ясного описания задачи.",
      button: "Обсудить проект",
    },
    brandTagline: "BUILD • AUTOMATE • GROW",
  },
  en: {
    navigation: pageNames.en,
    homeLabel: "Home",
    cta: {
      eyebrow: "WHAT’S NEXT",
      title: "From challenge to solution.",
      description:
        "Tell us what you want to build or improve. Let’s start with a clear project brief.",
      button: "Discuss a project",
    },
    brandTagline: "BUILD • AUTOMATE • GROW",
  },
};
export type MediaAsset = { url: string; alt: string };
export type PublishedCase = {
  id: string;
  slug: string;
  ru: { title: string; summary: string; body: string };
  en: { title: string; summary: string; body: string };
  image?: MediaAsset;
};
export type SiteSettings = {
  brandName?: string;
  logoUrl?: string;
  heroImageUrl?: string;
  ogImageUrl?: string;
  contactEmail?: string;
  contactPhone?: string;
  address?: string;
};
export type CmsSiteData = {
  site: typeof content;
  company: typeof companyContent;
  trust: typeof trustContent;
  services: typeof services;
  groups: typeof serviceGroups;
  home: typeof homeCopy;
  solutions: typeof solutionCopy;
  expertise: typeof expertiseCopy;
  shared: typeof sharedCopy;
  settings: SiteSettings;
  pageMedia: Record<string, MediaAsset>;
  cases: PublishedCase[];
};
export function defaultSiteData(): CmsSiteData {
  return structuredClone({
    site: content,
    company: companyContent,
    trust: trustContent,
    services,
    groups: serviceGroups,
    home: homeCopy,
    solutions: solutionCopy,
    expertise: expertiseCopy,
    shared: sharedCopy,
    settings: { brandName: "TASKONFF" },
    pageMedia: {},
    cases: [],
  });
}
function bilingual(ru: unknown, en: unknown) {
  return { ru, en } as Record<string, unknown>;
}
export type PageDefinition = {
  key: string;
  title: string;
  content: Record<string, unknown>;
};
export const pageDefinitions: PageDefinition[] = [
  {
    key: "home",
    title: "Главная страница",
    content: bilingual(
      {
        site: editableSite("ru"),
        home: homeCopy.ru,
        solutions: solutionCopy.ru,
      },
      {
        site: editableSite("en"),
        home: homeCopy.en,
        solutions: solutionCopy.en,
      },
    ),
  },
  {
    key: "shared",
    title: "Меню и общие элементы",
    content: bilingual(
      {
        shared: sharedCopy.ru,
        groups: serviceGroups.ru,
        legal: sharedLegal("ru"),
      },
      {
        shared: sharedCopy.en,
        groups: serviceGroups.en,
        legal: sharedLegal("en"),
      },
    ),
  },
  {
    key: "about",
    title: "О компании",
    content: bilingual(companyContent.ru.about, companyContent.en.about),
  },
  {
    key: "technologies",
    title: "Технологии",
    content: bilingual(
      {
        page: companyContent.ru.tech,
        explorer: companyContent.ru.architecture,
      },
      {
        page: companyContent.en.tech,
        explorer: companyContent.en.architecture,
      },
    ),
  },
  {
    key: "process",
    title: "Процесс работы",
    content: bilingual(
      { page: companyContent.ru.process, explorer: companyContent.ru.phases },
      { page: companyContent.en.process, explorer: companyContent.en.phases },
    ),
  },
  ...(["portfolio", "contact"] as const).map((key) => ({
    key,
    title:
      key === "portfolio"
        ? "Портфолио — тексты страницы"
        : "Контакты — тексты страницы",
    content: bilingual(trustContent.ru[key], trustContent.en[key]),
  })),
  ...(["privacy", "terms"] as const).map((key) => ({
    key,
    title:
      key === "privacy"
        ? "Политика конфиденциальности"
        : "Условия использования",
    content: bilingual(trustContent.ru.legal[key], trustContent.en.legal[key]),
  })),
  {
    key: "services",
    title: "Услуги — каталог",
    content: bilingual(
      { page: expertiseCopy.ru.services, detail: expertiseCopy.ru.detail },
      { page: expertiseCopy.en.services, detail: expertiseCopy.en.detail },
    ),
  },
  {
    key: "industries",
    title: "Отраслевые сценарии",
    content: bilingual(
      expertiseCopy.ru.industries,
      expertiseCopy.en.industries,
    ),
  },
  ...services.map((service) => ({
    key: `service-${service.slug}`,
    title: service.ru.title,
    content: bilingual(service.ru, service.en),
  })),
];
function editableSite(locale: "ru" | "en") {
  const result: Record<string, unknown> = { ...content[locale] };
  for (const key of [
    "title",
    "intro",
    "eyebrow",
    "secondary",
    "visual",
    "system",
    "visualLabels",
    "servicesTitle",
    "aboutTitle",
    "techTitle",
    "contactTitle",
    "brandNote",
    "top",
    "nav",
  ])
    delete result[key];
  return result;
}
function sharedLegal(locale: "ru" | "en") {
  const { draftLabel, draftText, contents, backContact, documentState } =
    trustContent[locale].legal;
  return { draftLabel, draftText, contents, backContact, documentState };
}
export function getPageDefinition(key: string) {
  return pageDefinitions.find((page) => page.key === key);
}
const immutableValues = new Set(services.map((service) => service.slug));
function locked(key: string, value: unknown) {
  return (
    ["slug", "group", "iconId", "href", "key", "id"].includes(key) ||
    (typeof value === "string" &&
      (immutableValues.has(value) ||
        value.startsWith("/ru/") ||
        value.startsWith("/en/") ||
        value.startsWith("#")))
  );
}
export function validatePageContent(
  key: string,
  value: unknown,
): true | string {
  const template = getPageDefinition(key)?.content;
  if (!template) return "Неизвестная страница.";
  if (JSON.stringify(value ?? null).length > 1_000_000)
    return "Слишком большой объём текста.";
  function check(base: unknown, next: unknown, path: string): boolean {
    if (locked(path.split(".").at(-1) ?? "", base)) return base === next;
    if (typeof base === "string")
      return typeof next === "string" && next.length <= 12000;
    if (Array.isArray(base))
      return (
        Array.isArray(next) &&
        base.length === next.length &&
        base.every((v, i) => check(v, next[i], `${path}.${i}`))
      );
    if (base && typeof base === "object") {
      if (!next || typeof next !== "object" || Array.isArray(next))
        return false;
      const a = Object.keys(base);
      const b = Object.keys(next);
      return (
        a.length === b.length &&
        a.every(
          (k) =>
            Object.hasOwn(next, k) &&
            check(
              (base as Record<string, unknown>)[k],
              (next as Record<string, unknown>)[k],
              `${path}.${k}`,
            ),
        )
      );
    }
    return base === next;
  }
  return check(template, value, "")
    ? true
    : "Структура страницы и системные ссылки должны сохраняться. Изменяйте текстовые поля.";
}
/** Merge only the recognized shape; older documents inherit newly introduced fields. */
export function mergeContent<T>(base: T, stored: unknown): T {
  function merge(a: unknown, b: unknown, key: string): unknown {
    if (locked(key, a)) return a;
    if (typeof a === "string")
      return typeof b === "string" && b.length <= 12000 ? b : a;
    if (Array.isArray(a))
      return a.map((v, i) =>
        merge(v, Array.isArray(b) ? b[i] : undefined, String(i)),
      );
    if (a && typeof a === "object") {
      const out: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(a))
        out[k] = merge(
          v,
          b && typeof b === "object"
            ? (b as Record<string, unknown>)[k]
            : undefined,
          k,
        );
      return out;
    }
    return a;
  }
  return merge(base, stored, "") as T;
}
