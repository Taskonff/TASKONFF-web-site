import "server-only";
import { cache } from "react";
import { readSiteData } from "./read-site-data";
export const getSiteData = cache(readSiteData);
export { mediaAsset } from "./read-site-data";
