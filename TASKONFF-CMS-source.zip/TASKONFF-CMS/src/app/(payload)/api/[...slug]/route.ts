import config from "@payload-config";
import {
  REST_DELETE,
  REST_GET,
  REST_OPTIONS,
  REST_PATCH,
  REST_POST,
  REST_PUT,
} from "@payloadcms/next/routes";
import { protectCMSMutation } from "@/cms/server/request-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const GET = REST_GET(config);
export const POST = protectCMSMutation(REST_POST(config));
export const DELETE = protectCMSMutation(REST_DELETE(config));
export const PATCH = protectCMSMutation(REST_PATCH(config));
export const PUT = protectCMSMutation(REST_PUT(config));
export const OPTIONS = REST_OPTIONS(config);
