import { TextTreeField as TextTreeField_eb5ee5a57476ddc7dec8376ba964b49d } from '@/cms/admin/text-tree-field'
import { AdminIntro as AdminIntro_05129e08f3822412ec04a575dba8739e } from '@/cms/admin/admin-intro'
import { CollectionCards as CollectionCards_f9c02e79a4aed9a3924487c0cd4cafb1 } from '@payloadcms/next/rsc'

/** @type import('payload').ImportMap */
export const importMap = {
  "@/cms/admin/text-tree-field#TextTreeField": TextTreeField_eb5ee5a57476ddc7dec8376ba964b49d,
  "@/cms/admin/admin-intro#AdminIntro": AdminIntro_05129e08f3822412ec04a575dba8739e,
  "@payloadcms/next/rsc#CollectionCards": CollectionCards_f9c02e79a4aed9a3924487c0cd4cafb1
}
