import config from "@payload-config";
import Link from "next/link";
import { generatePageMetadata, RootPage } from "@payloadcms/next/views";
import { getCms } from "@/cms/server/payload";
import { importMap } from "../importMap";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

type Args = {
  params: Promise<{ segments: string[] }>;
  searchParams: Promise<{ [key: string]: string | string[] }>;
};

export function generateMetadata({ params, searchParams }: Args) {
  return generatePageMetadata({ config, params, searchParams });
}

export default async function AdminPage({ params, searchParams }: Args) {
  const payload = await getCms();
  const accounts = await payload.count({
    collection: "users",
    overrideAccess: true,
  });
  if (!accounts.totalDocs) {
    return (
      <main style={{ maxWidth: 700, margin: "12vh auto", padding: 32 }}>
        <p style={{ letterSpacing: ".16em", color: "#00c3cf" }}>
          TASKONFF / ADMIN
        </p>
        <h1>Первый запуск · Initial setup</h1>
        <p>Создайте первого администратора из терминала сервера:</p>
        <p>Create your first administrator from the server terminal:</p>
        <pre
          style={{ padding: 24, border: "1px solid #334155", borderRadius: 12 }}
        >
          npm run admin:setup
        </pre>
        <p>Пароль задаётся вами. Публичная регистрация отключена.</p>
        <p>You choose the password. Public registration is disabled.</p>
        <Link href="/ru">Вернуться на сайт / Back to website →</Link>
      </main>
    );
  }
  return RootPage({ config, importMap, params, searchParams });
}
