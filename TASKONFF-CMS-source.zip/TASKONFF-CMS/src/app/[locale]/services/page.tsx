import { getSiteData } from "@/cms/site-data";
import { notFound } from "next/navigation";
import { isLocale } from "@/content/site";
import { pageMetadata } from "@/lib/metadata";
import { ServicesPage } from "@/components/pages/expertise-pages";
export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const c = (await getSiteData()).expertise[locale].services;
  return pageMetadata(locale, "services", c.label, c.description);
}
export default async function Page({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return <ServicesPage locale={locale} />;
}
