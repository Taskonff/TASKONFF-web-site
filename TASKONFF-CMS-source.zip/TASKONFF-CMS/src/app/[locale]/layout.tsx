import { getSiteData } from "@/cms/site-data";
import { SiteContentProvider } from "@/cms/site-context";
export const dynamic = "force-dynamic";
import { Header } from "@/components/home/header";
import { Footer } from "@/components/site/footer";
import { ScrollProgress } from "@/components/home/experience";
import { getBrandLogo } from "@/lib/brand";
import "../internal.css";
import "@fontsource-variable/manrope";
import "../globals.css";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { isLocale } from "@/content/site";
export function generateStaticParams() {
  return [{ locale: "ru" }, { locale: "en" }];
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const data = await getSiteData();
  const ru = locale === "ru";
  const base = process.env.SITE_URL;
  return {
    metadataBase: base ? new URL(base) : undefined,
    title: ru
      ? "TASKONFF — Разработка ПО и цифровые решения"
      : "TASKONFF — Software Engineering & Digital Solutions",
    description: ru
      ? "Заказная разработка, AI-решения и автоматизация бизнеса. BUILD • AUTOMATE • GROW."
      : "Custom software, AI solutions and business automation. BUILD • AUTOMATE • GROW.",
    alternates: base
      ? {
          canonical: `/${locale}`,
          languages: { ru: "/ru", en: "/en", "x-default": "/ru" },
        }
      : undefined,
    robots: base
      ? { index: true, follow: true }
      : { index: false, follow: false },
    openGraph: {
      type: "website",
      siteName: data.settings.brandName || "TASKONFF",
      locale: ru ? "ru_RU" : "en_US",
      title: "TASKONFF — BUILD • AUTOMATE • GROW",
      description: data.home[locale].hero.intro,
      ...(data.settings.ogImageUrl
        ? { images: [data.settings.ogImageUrl] }
        : {}),
    },
  };
}
export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const data = await getSiteData();
  const logo = data.settings.logoUrl ?? getBrandLogo();
  return (
    <html lang={locale}>
      <body>
        <SiteContentProvider value={data}>
          <ScrollProgress />
          <Header locale={locale} copy={data.site[locale]} logo={logo} />
          {children}
          <Footer locale={locale} logo={logo} />
        </SiteContentProvider>
      </body>
    </html>
  );
}
