import { notFound } from "next/navigation";
import { isLocale } from "@/content/site";
import { getSiteData } from "@/cms/site-data";
import { pageMetadata } from "@/lib/metadata";
import { ProcessPage } from "@/components/pages/company-pages";
type Props = { params: Promise<{ locale: string }> };
export async function generateMetadata({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const snapshot = await getSiteData();
  const c = snapshot.company[locale].process;
  return pageMetadata(locale, "process", c.label, c.intro);
}
export default async function Page({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return <ProcessPage locale={locale} />;
}
