import { getSiteData } from "@/cms/site-data";
import { notFound } from "next/navigation";
import { isLocale } from "@/content/site";
import { pageMetadata } from "@/lib/metadata";
import { IndustriesPage } from "@/components/pages/expertise-pages";
export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const c = (await getSiteData()).expertise[locale].industries;
  return pageMetadata(locale, "industries", c.label, c.description);
}
export default async function Page({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return <IndustriesPage locale={locale} />;
}
