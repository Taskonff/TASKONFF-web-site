import { getSiteData } from "@/cms/site-data";
import { getCMSPaths } from "@/cms/server/storage";
import fs from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";
export const dynamic = "force-dynamic";
import { ImageResponse } from "next/og";
export const alt = "TASKONFF — BUILD • AUTOMATE • GROW";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";
export default async function Image() {
  const data = await getSiteData();
  if (data.settings.ogImageUrl) {
    const url = new URL(data.settings.ogImageUrl, "https://local.invalid");
    if (url.pathname.startsWith("/api/media/file/")) {
      const name = decodeURIComponent(url.pathname.split("/").at(-1) || "");
      if (name && name === path.basename(name) && !name.includes("..")) {
        const bytes = await fs.readFile(
          /* turbopackIgnore: true */ path.join(getCMSPaths().mediaDir, name),
        );
        const png = await sharp(bytes)
          .resize(1200, 630, { fit: "contain", background: "#020e1b" })
          .png()
          .toBuffer();
        return new Response(new Uint8Array(png), {
          headers: { "Content-Type": "image/png", "Cache-Control": "no-cache" },
        });
      }
    }
  }
  return new ImageResponse(
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        padding: "70px",
        background: "linear-gradient(135deg,#020e1b,#034888)",
        color: "#fff",
        fontFamily: "sans-serif",
      }}
    >
      <div style={{ display: "flex", fontSize: 32, letterSpacing: 3 }}>
        {data.settings.brandName || "TASKONFF"}
      </div>
      <div style={{ display: "flex", fontSize: 88, lineHeight: 1.1 }}>
        Build what’s next.
      </div>
      <div
        style={{
          display: "flex",
          fontSize: 24,
          letterSpacing: 7,
          color: "#00cbd5",
        }}
      >
        BUILD • AUTOMATE • GROW
      </div>
    </div>,
    size,
  );
}
