"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ArrowUpRight } from "lucide-react";
export default function NotFound() {
  const ru = !usePathname().startsWith("/en");
  return (
    <main id="main" className="not-found-page container">
      <span>404 / TASKONFF</span>
      <h1>{ru ? "Здесь пока нет страницы." : "There’s no page here."}</h1>
      <p>
        {ru
          ? "Проверьте адрес или вернитесь на главную."
          : "Check the address or return to the homepage."}
      </p>
      <Link className="button button-primary" href={ru ? "/ru" : "/en"}>
        {ru ? "На главную" : "Back home"}
        <ArrowUpRight size={18} />
      </Link>
    </main>
  );
}
