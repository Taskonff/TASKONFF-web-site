import { notFound } from "next/navigation";
import { isLocale } from "@/content/site";
import { getSiteData } from "@/cms/site-data";
import { pageMetadata } from "@/lib/metadata";
import { ContactPage } from "@/components/pages/trust-pages";
type Props = { params: Promise<{ locale: string }> };
export async function generateMetadata({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const snapshot = await getSiteData();
  const copy = snapshot.trust[locale].contact;
  return pageMetadata(locale, "contact", copy.label, copy.description);
}
export default async function Page({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return <ContactPage locale={locale} />;
}
