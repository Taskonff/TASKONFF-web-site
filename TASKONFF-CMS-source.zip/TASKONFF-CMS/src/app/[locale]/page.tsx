import { notFound } from "next/navigation";
import { content, isLocale } from "@/content/site";
import { Home } from "@/components/home/home";
export default async function Page({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return <Home locale={locale} copy={content[locale]} />;
}
