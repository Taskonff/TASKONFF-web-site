import type { MetadataRoute } from "next";
import { pageSlugs } from "@/lib/routes";
import { serviceSlugs } from "@/content/services";
export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.SITE_URL?.replace(/\/$/, "");
  if (!base) return [];
  const paths = [
    "",
    ...pageSlugs.filter((slug) => slug !== "privacy" && slug !== "terms"),
    ...serviceSlugs.map((slug) => `services/${slug}`),
  ];
  return paths.flatMap((path) =>
    ["ru", "en"].map((locale) => ({
      url: `${base}/${locale}${path ? `/${path}` : ""}`,
      alternates: {
        languages: {
          ru: `${base}/ru${path ? `/${path}` : ""}`,
          en: `${base}/en${path ? `/${path}` : ""}`,
        },
      },
    })),
  );
}
