import { createBrief } from "@/lib/brief";
import { readFormRequest, checkFormRate, formError } from "@/lib/form-security";
export const runtime = "nodejs";
export async function POST(request: Request) {
  try {
    const data = await readFormRequest(request);
    checkFormRate(request, "brief");
    const text = createBrief(data);
    return new Response(text, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Disposition":
          'attachment; filename="TASKONFF-project-brief.txt"',
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch (error) {
    return formError(error);
  }
}
