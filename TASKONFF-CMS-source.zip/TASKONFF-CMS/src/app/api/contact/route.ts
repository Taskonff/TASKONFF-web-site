import { createHmac } from "node:crypto";
import { z } from "zod";
import { briefSchema } from "@/lib/brief";
import { readFormRequest, checkFormRate, formError } from "@/lib/form-security";
export const runtime = "nodejs";
export async function POST(request: Request) {
  try {
    const raw = await readFormRequest(request);
    checkFormRate(request, "contact");
    const parsed = briefSchema
      .extend({ consent: z.literal(true) })
      .safeParse(raw);
    // No successful delivery response is possible without explicitly enabled destination and approved policies.
    if (!parsed.success)
      return Response.json(
        { error: "invalid" },
        { status: 400, headers: { "Cache-Control": "no-store" } },
      );
    if ((raw as { consent?: unknown }).consent !== true)
      return Response.json(
        { error: "consent" },
        { status: 400, headers: { "Cache-Control": "no-store" } },
      );
    const url = process.env.CONTACT_WEBHOOK_URL;
    if (process.env.CONTACT_FORM_ENABLED !== "true" || !url)
      return Response.json(
        { error: "not_configured" },
        { status: 503, headers: { "Cache-Control": "no-store" } },
      );
    let target: URL;
    try {
      target = new URL(url);
    } catch {
      return Response.json({ error: "not_configured" }, { status: 503 });
    }
    if (target.protocol !== "https:" || target.username || target.password)
      return Response.json({ error: "not_configured" }, { status: 503 });
    const payload = JSON.stringify({
      type: "project_inquiry",
      ...parsed.data,
      consent: true,
    });
    const secret = process.env.CONTACT_WEBHOOK_SECRET;
    let response: Response;
    try {
      response = await fetch(target, {
        method: "POST",
        redirect: "error",
        cache: "no-store",
        headers: {
          "Content-Type": "application/json",
          ...(secret
            ? {
                "X-Taskonff-Signature": createHmac("sha256", secret)
                  .update(payload)
                  .digest("hex"),
              }
            : {}),
        },
        body: payload,
        signal: AbortSignal.timeout(8000),
      });
    } catch {
      return Response.json(
        { error: "delivery_failed" },
        { status: 502, headers: { "Cache-Control": "no-store" } },
      );
    }
    if (!response.ok)
      return Response.json(
        { error: "delivery_failed" },
        { status: 502, headers: { "Cache-Control": "no-store" } },
      );
    return Response.json(
      { accepted: true },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (error) {
    return formError(error);
  }
}
