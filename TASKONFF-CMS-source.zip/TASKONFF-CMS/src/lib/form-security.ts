/** Per-process abuse limits. Use a shared external store before multi-instance deployment. */
const windows = new Map<string, { count: number; until: number }>();
const MAX_BODY = 16_384;
export class FormRequestError extends Error {
  constructor(
    public status: number,
    public code: string,
  ) {
    super(code);
  }
}
export async function readFormRequest(request: Request): Promise<unknown> {
  const origin = request.headers.get("origin");
  const incoming = new URL(request.url);
  // Next may build request.url with its bind hostname. Host is set by the browser;
  // do not trust forwarded host/protocol values without deployment configuration.
  const host = request.headers.get("host");
  const expected = process.env.SITE_URL
    ? new URL(process.env.SITE_URL).origin
    : host
      ? new URL(`${incoming.protocol}//${host}`).origin
      : incoming.origin;
  if (!origin || origin !== expected) throw new FormRequestError(403, "origin");
  if (
    !request.headers
      .get("content-type")
      ?.toLowerCase()
      .startsWith("application/json")
  )
    throw new FormRequestError(415, "content_type");
  if (Number(request.headers.get("content-length") ?? 0) > MAX_BODY)
    throw new FormRequestError(413, "too_large");
  const reader = request.body?.getReader();
  if (!reader) throw new FormRequestError(400, "invalid");
  const parts: Uint8Array[] = [];
  let length = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      length += value.byteLength;
      if (length > MAX_BODY) {
        await reader.cancel();
        throw new FormRequestError(413, "too_large");
      }
      parts.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (const part of parts) {
    bytes.set(part, offset);
    offset += part.byteLength;
  }
  try {
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    throw new FormRequestError(400, "invalid");
  }
}
export function checkFormRate(
  request: Request,
  scope: string,
  now = Date.now(),
) {
  for (const [key, window] of windows) {
    if (window.until <= now) windows.delete(key);
  }
  // Forwarded IP headers are not trusted unless the deployment explicitly names a sanitized ingress header.
  const trusted = process.env.TRUSTED_CLIENT_IP_HEADER;
  const client = trusted
    ? (request.headers.get(trusted)?.slice(0, 100) ?? "shared")
    : "shared";
  const key = `${scope}:${client}`;
  const limit = trusted ? 10 : 60;
  const window = windows.get(key);
  if (window && window.count >= limit)
    throw new FormRequestError(429, "rate_limit");
  if (window) {
    window.count++;
    return;
  }
  if (windows.size >= 2048) throw new FormRequestError(429, "rate_limit");
  windows.set(key, { count: 1, until: now + 60_000 });
}
export function formError(error: unknown) {
  const known = error instanceof FormRequestError;
  return Response.json(
    { error: known ? error.code : "invalid" },
    {
      status: known ? error.status : 400,
      headers: {
        "Cache-Control": "no-store",
        ...(known && error.status === 429 ? { "Retry-After": "60" } : {}),
      },
    },
  );
}
