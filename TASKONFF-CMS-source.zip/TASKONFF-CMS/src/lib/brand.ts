import "server-only";
import { existsSync } from "node:fs";
import path from "node:path";
/** Only explicitly supplied originals are eligible. No generated or traced marks. */
export function getBrandLogo(): string | undefined {
  for (const file of [
    "taskonff-logo.svg",
    "taskonff-logo.png",
    "taskonff-logo.webp",
  ]) {
    if (existsSync(path.join(process.cwd(), "public", "brand", file)))
      return `/brand/${file}`;
  }
}
