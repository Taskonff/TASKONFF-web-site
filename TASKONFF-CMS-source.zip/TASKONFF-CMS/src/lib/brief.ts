import { z } from "zod";
export const briefSchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.email().max(254),
  service: z.string().trim().max(120),
  message: z.string().trim().min(20).max(5000),
  website: z.string().max(0),
  locale: z.enum(["ru", "en"]).default("en"),
});
export function createBrief(input: unknown) {
  const data = briefSchema.parse(input);
  return data.locale === "ru"
    ? `TASKONFF — БРИФ ПРОЕКТА\n\nИмя: ${data.name}\nEmail: ${data.email}\nНаправление: ${data.service}\n\n${data.message}\n`
    : `TASKONFF — PROJECT BRIEF\n\nName: ${data.name}\nEmail: ${data.email}\nArea: ${data.service}\n\n${data.message}\n`;
}
