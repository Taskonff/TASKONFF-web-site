import type { Metadata } from "next";
import type { Locale } from "@/content/site";
export function pageMetadata(
  locale: Locale,
  slug: string,
  title: string,
  description: string,
): Metadata {
  const base = process.env.SITE_URL;
  const path = slug ? `/${slug.replace(/^\//, "")}` : "";
  const legal = slug === "privacy" || slug === "terms";
  return {
    title: `${title} — TASKONFF`,
    description,
    alternates: base
      ? {
          canonical: `/${locale}${path}`,
          languages: {
            ru: `/ru${path}`,
            en: `/en${path}`,
            "x-default": `/ru${path}`,
          },
        }
      : undefined,
    robots:
      !base || legal
        ? { index: false, follow: !legal }
        : { index: true, follow: true },
    openGraph: {
      title: `${title} — TASKONFF`,
      description,
      type: "website",
      locale: locale === "ru" ? "ru_RU" : "en_US",
      siteName: "TASKONFF",
      url: base ? `${base}/${locale}${path}` : undefined,
    },
  };
}
