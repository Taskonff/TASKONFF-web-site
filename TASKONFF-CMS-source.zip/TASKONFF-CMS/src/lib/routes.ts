import type { Locale } from "@/content/site";
export const pageSlugs = [
  "about",
  "services",
  "industries",
  "portfolio",
  "technologies",
  "process",
  "contact",
  "privacy",
  "terms",
] as const;
export type PageSlug = (typeof pageSlugs)[number];
export const pageNames: Record<Locale, Record<PageSlug, string>> = {
  ru: {
    about: "О компании",
    services: "Услуги",
    industries: "Отрасли",
    portfolio: "Портфолио",
    technologies: "Технологии",
    process: "Процесс",
    contact: "Контакты",
    privacy: "Конфиденциальность",
    terms: "Условия использования",
  },
  en: {
    about: "About us",
    services: "Services",
    industries: "Industries",
    portfolio: "Portfolio",
    technologies: "Technologies",
    process: "Our process",
    contact: "Contact",
    privacy: "Privacy",
    terms: "Terms of use",
  },
};
export function localizedPath(locale: Locale, slug = "") {
  return `/${locale}${slug ? `/${slug.replace(/^\//, "")}` : ""}`;
}
