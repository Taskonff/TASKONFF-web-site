"use client";
import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { useAnimate, useReducedMotion } from "motion/react";
export function RouteTransition({ children }: { children: React.ReactNode }) {
  const [scope, animate] = useAnimate();
  const reduced = useReducedMotion();
  const pathname = usePathname();
  useEffect(() => {
    if (reduced) return;
    const controls = animate(
      scope.current,
      { opacity: [0.5, 1], y: [10, 0] },
      { duration: 0.38, ease: "easeOut" },
    );
    return () => controls.stop();
  }, [animate, reduced, scope, pathname]);
  return (
    <div className="route-transition" ref={scope}>
      {children}
    </div>
  );
}
