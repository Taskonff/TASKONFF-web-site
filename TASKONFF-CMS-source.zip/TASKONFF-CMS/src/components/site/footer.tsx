import { getSiteData } from "@/cms/site-data";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { BrandLogo } from "@/components/brand-logo";
import { type Locale } from "@/content/site";
import { pageSlugs } from "@/lib/routes";
export async function Footer({
  locale,
  logo,
}: {
  locale: Locale;
  logo?: string;
}) {
  const data = await getSiteData();
  const copy = data.site[locale];
  const pageNames = {
    ru: data.shared.ru.navigation,
    en: data.shared.en.navigation,
  };
  const brandName = data.settings.brandName || "TASKONFF";
  return (
    <footer className="footer site-footer">
      <div className="container">
        <div className="footer-directory">
          <div className="footer-brand">
            <Link
              href={`/${locale}`}
              className="company-name"
              aria-label={brandName}
            >
              <BrandLogo src={logo} name={brandName} />
            </Link>
            <p>{copy.footer}</p>
            <span>{data.shared[locale].brandTagline}</span>
          </div>
          <nav
            aria-label={locale === "ru" ? "Разделы сайта" : "Site directory"}
            className="footer-page-links"
          >
            {pageSlugs
              .filter((s) => s !== "privacy" && s !== "terms")
              .map((slug) => (
                <Link key={slug} href={`/${locale}/${slug}`}>
                  {pageNames[locale][slug]}
                  <ArrowUpRight size={12} />
                </Link>
              ))}
          </nav>
        </div>
        <div className="footer-bottom">
          <span>
            © {new Date().getFullYear()} {brandName}. {copy.rights}
          </span>
          <nav
            aria-label={
              locale === "ru" ? "Правовая информация" : "Legal information"
            }
          >
            <Link href={`/${locale}/privacy`}>{pageNames[locale].privacy}</Link>
            <Link href={`/${locale}/terms`}>{pageNames[locale].terms}</Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}
