import { getSiteData } from "@/cms/site-data";
import Link from "next/link";
import { ArrowUpRight, ArrowLeft } from "lucide-react";
import type { Locale } from "@/content/site";
import { Reveal } from "@/components/home/reveal";
export async function InternalHero({
  locale,
  eyebrow,
  title,
  description,
  index = "TASKONFF",
  children,
}: {
  locale: Locale;
  eyebrow: string;
  title: string;
  description: string;
  index?: string;
  children?: React.ReactNode;
}) {
  const data = await getSiteData();
  return (
    <section className="internal-hero" id="top">
      <div className="internal-hero-grid" aria-hidden="true" />
      <div className="container">
        <nav
          className="breadcrumbs"
          aria-label={locale === "ru" ? "Хлебные крошки" : "Breadcrumbs"}
        >
          <Link href={`/${locale}`}>
            <ArrowLeft size={13} />
            {data.shared[locale].homeLabel}
          </Link>
          <span>/</span>
          <span aria-current="page">{eyebrow}</span>
        </nav>
        <div className="internal-hero-content">
          <Reveal>
            <p className="eyebrow">
              <span className="eyebrow-cross">+</span>
              {eyebrow}
            </p>
            <h1>{title}</h1>
            <p className="internal-intro">{description}</p>
          </Reveal>
          <div className="internal-hero-art">
            {children ?? (
              <div className="page-sculpture" aria-hidden="true">
                <div />
                <div />
                <div />
                <span>
                  BUILD
                  <br />
                  AUTOMATE
                  <br />
                  GROW
                </span>
              </div>
            )}
          </div>
        </div>
        <div className="internal-hero-bottom">
          <span>{index}</span>
          <span>BUILD • AUTOMATE • GROW</span>
        </div>
      </div>
    </section>
  );
}
export async function PageCTA({
  locale,
  title,
  description,
}: {
  locale: Locale;
  title?: string;
  description?: string;
}) {
  const data = await getSiteData();
  const c = data.shared[locale].cta;
  return (
    <section className="internal-cta">
      <div className="container">
        <Reveal>
          <p className="eyebrow">{c.eyebrow}</p>
          <h2>{title ?? c.title}</h2>
          <p>{description ?? c.description}</p>
        </Reveal>
        <Link className="internal-cta-link" href={`/${locale}/contact`}>
          <span>{c.button}</span>
          <ArrowUpRight size={32} />
        </Link>
      </div>
    </section>
  );
}
