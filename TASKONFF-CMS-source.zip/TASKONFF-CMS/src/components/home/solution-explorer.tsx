"use client";

import { useId, useRef, useState, type KeyboardEvent } from "react";
import { motion, useReducedMotion } from "motion/react";
import {
  ArrowRight,
  ArrowUpRight,
  Bot,
  Boxes,
  Braces,
  CircleCheck,
  Database,
  FileInput,
  GitBranch,
  Layers3,
  Lightbulb,
  Network,
  Rocket,
  ShieldCheck,
  Sparkles,
  Workflow,
  type LucideIcon,
} from "lucide-react";
import "./solution-explorer.css";
import { useSiteContent } from "@/cms/site-context";
const iconRegistry: Record<string, LucideIcon> = {
  Rocket,
  Lightbulb,
  Layers3,
  Braces,
  Workflow,
  FileInput,
  GitBranch,
  Network,
  CircleCheck,
  Bot,
  Database,
  Sparkles,
  Boxes,
  ShieldCheck,
};

export function SolutionExplorer({ locale }: { locale: "ru" | "en" }) {
  const [selected, setSelected] = useState(0);
  const [node, setNode] = useState(0);
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);
  const uid = useId();
  const reduced = useReducedMotion();
  const data = useSiteContent().solutions[locale];
  const items = data.scenarios;
  const scenario = items[selected];
  const detail = scenario.nodes[node];
  const DetailIcon = iconRegistry[detail.iconId] ?? Braces;

  function select(index: number) {
    setSelected(index);
    setNode(0);
  }

  function navigate(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next = index;
    if (event.key === "ArrowRight") next = (index + 1) % items.length;
    else if (event.key === "ArrowLeft")
      next = (index + items.length - 1) % items.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = items.length - 1;
    else return;
    event.preventDefault();
    select(next);
    tabs.current[next]?.focus();
  }

  return (
    <section
      className="solutions-section"
      id="solutions"
      aria-labelledby={`${uid}-heading`}
    >
      <div className="solutions-container">
        <div className="solutions-heading-row">
          <div>
            <p className="solutions-eyebrow">
              <span />
              {data.eyebrow}
            </p>
            <h2 id={`${uid}-heading`}>{data.title}</h2>
          </div>
          <p className="solutions-intro">{data.intro}</p>
        </div>

        <div
          className="solutions-tabs"
          role="tablist"
          aria-label={data.tabsLabel}
        >
          {items.map((item, index) => {
            const Icon = iconRegistry[item.iconId] ?? Braces;
            return (
              <button
                key={index}
                id={`${uid}-tab-${index}`}
                ref={(element) => {
                  tabs.current[index] = element;
                }}
                type="button"
                role="tab"
                aria-selected={selected === index}
                tabIndex={selected === index ? 0 : -1}
                aria-controls={`${uid}-panel`}
                className="solutions-tab"
                onClick={() => select(index)}
                onKeyDown={(event) => navigate(event, index)}
              >
                <Icon size={18} strokeWidth={1.5} />
                <span>{item.tab}</span>
                <ArrowUpRight size={16} />
              </button>
            );
          })}
        </div>

        <motion.div
          key={selected}
          role="tabpanel"
          id={`${uid}-panel`}
          aria-labelledby={`${uid}-tab-${selected}`}
          tabIndex={0}
          className="solutions-panel"
          initial={reduced ? false : { opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.22 }}
        >
          <div className="solutions-panel-heading">
            <div>
              <span className="solutions-scenario-label">
                {data.scenarioLabel}
              </span>
              <h3>{scenario.title}</h3>
            </div>
            <p>{scenario.description}</p>
          </div>
          <div className="solutions-workflow">
            {scenario.nodes.map((item, index) => {
              const Icon = iconRegistry[item.iconId] ?? Braces;
              return (
                <div className="solutions-node-wrap" key={index}>
                  <button
                    type="button"
                    className="solutions-node"
                    aria-pressed={node === index}
                    aria-controls={`${uid}-detail`}
                    onClick={() => setNode(index)}
                  >
                    <span className="solutions-node-top">
                      <span className="solutions-node-icon">
                        <Icon size={25} strokeWidth={1.5} />
                      </span>
                      <span className="solutions-node-index">0{index + 1}</span>
                    </span>
                    <span className="solutions-node-label">{item.label}</span>
                    <strong>{item.title}</strong>
                    <span className="solutions-node-action">
                      <span>{data.explore}</span>
                      <ArrowUpRight size={15} />
                    </span>
                  </button>
                  {index < scenario.nodes.length - 1 && (
                    <span className="solutions-connector" aria-hidden="true">
                      <i />
                      <ArrowRight size={13} />
                    </span>
                  )}
                </div>
              );
            })}
          </div>
          <div
            className="solutions-detail"
            id={`${uid}-detail`}
            aria-live="polite"
            aria-atomic="true"
          >
            <div className="solutions-detail-icon">
              <DetailIcon size={22} strokeWidth={1.5} />
            </div>
            <div>
              <span>{detail.label}</span>
              <p>{detail.detail}</p>
            </div>
            <a href="#contact">
              {data.contact}
              <ArrowUpRight size={17} />
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
