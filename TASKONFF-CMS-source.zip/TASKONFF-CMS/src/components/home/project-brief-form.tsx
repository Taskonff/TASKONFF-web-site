"use client";
import { useState, useEffect } from "react";
import { ArrowDownToLine, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { briefSchema } from "@/lib/brief";
import Link from "next/link";
import type { Locale } from "@/content/site";
import type { SiteContent } from "@/content/site";
export function ProjectBriefForm({
  copy,
  locale = "ru",
  options,
}: {
  copy: SiteContent;
  locale?: Locale;
  options: { slug: string; title: string }[];
}) {
  const [pending, setPending] = useState(false);
  const [status, setStatus] = useState<"idle" | "error" | "success">("idle");
  const [service, setService] = useState("");
  useEffect(() => {
    const choose = (event: Event) => {
      const value = (event as CustomEvent<string>).detail;
      if (
        copy.services.some((item) => item.title === value) ||
        options.some((item) => item.title === value)
      )
        setService(value);
    };
    window.addEventListener("taskonff:service", choose);
    return () => window.removeEventListener("taskonff:service", choose);
  }, [copy, options]);
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (pending) return;
    const form = new FormData(event.currentTarget);
    setPending(true);
    setStatus("idle");
    try {
      const data = briefSchema.parse({ ...Object.fromEntries(form), locale });
      const response = await fetch("/api/brief", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("brief_failed");
      const url = URL.createObjectURL(await response.blob());
      const link = document.createElement("a");
      link.href = url;
      link.download = "TASKONFF-project-brief.txt";
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setStatus("success");
    } catch {
      setStatus("error");
    } finally {
      setPending(false);
    }
  }
  return (
    <form className="brief-form" onSubmit={submit} aria-busy={pending}>
      <div className="form-row">
        <label>
          {copy.formName}
          <input
            name="name"
            autoComplete="name"
            required
            minLength={2}
            maxLength={100}
          />
        </label>
        <label>
          {copy.formEmail}
          <input
            name="email"
            type="email"
            autoComplete="email"
            required
            maxLength={254}
          />
        </label>
      </div>
      <label>
        {copy.formService}
        <select
          name="service"
          value={service}
          onChange={(event) => setService(event.target.value)}
        >
          <option value="">{copy.general}</option>
          <optgroup
            label={
              locale === "ru" ? "Комплексные направления" : "Solution areas"
            }
          >
            {copy.services.map((s) => (
              <option key={s.title}>{s.title}</option>
            ))}
          </optgroup>
          <optgroup
            label={locale === "ru" ? "Конкретные услуги" : "Specific services"}
          >
            {options.map((s) => (
              <option key={s.slug}>{s.title}</option>
            ))}
          </optgroup>
        </select>
      </label>
      <label>
        {copy.formMessage}
        <textarea
          name="message"
          placeholder={copy.formPlaceholder}
          rows={4}
          minLength={20}
          maxLength={5000}
          required
        />
      </label>
      <div className="honeypot" aria-hidden="true">
        <label>
          Website
          <input name="website" tabIndex={-1} autoComplete="off" />
        </label>
      </div>
      <Button type="submit" disabled={pending}>
        {pending ? copy.formPending : copy.formSubmit}
        <ArrowDownToLine size={17} />
      </Button>
      <p className="form-note">
        {copy.formNote}{" "}
        <Link href={`/${locale}/privacy`}>
          {locale === "ru" ? "Обработка данных" : "Data processing"}
        </Link>
      </p>
      <div role="status" aria-live="polite">
        {status === "error" && <p className="form-error">{copy.formError}</p>}
        {status === "success" && (
          <p className="form-success">
            <CheckCircle2 size={18} />
            {copy.formSuccess}
          </p>
        )}
      </div>
    </form>
  );
}
