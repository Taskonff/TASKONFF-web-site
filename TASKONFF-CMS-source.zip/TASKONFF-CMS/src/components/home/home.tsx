import Link from "next/link";
import {
  ArrowDown,
  ArrowUpRight,
  ArrowRight,
  Plus,
  Braces,
  Layers3,
  Orbit,
  Workflow,
} from "lucide-react";
import { Reveal } from "./reveal";
import { DigitalEngine } from "./digital-engine";
import { ServiceGrid } from "./service-grid";
import { SolutionExplorer } from "./solution-explorer";
import { CapabilityStrip } from "./experience";
import { ProjectBrief } from "./project-brief";
import { Button } from "@/components/ui/button";
import { getSiteData } from "@/cms/site-data";
import { PageMedia } from "@/cms/page-media";
import type { Locale, SiteContent } from "@/content/site";

export async function Home({ locale }: { locale: Locale; copy?: SiteContent }) {
  const data = await getSiteData();
  const copy = data.site[locale];
  const h = data.home[locale];
  return (
    <main id="main">
      <section className="hero" id="top">
        <div className="hero-grid-bg" aria-hidden="true" />
        <div className="container hero-topline">
          <span>
            <i />
            {h.hero.eyebrow}
          </span>
          <span>{h.hero.signature}</span>
        </div>
        <div className="container hero-grid">
          <div className="hero-content">
            <Reveal>
              <p className="hero-kicker">{h.hero.kicker}</p>
              <h1>
                {h.hero.titleFirst}
                <br />
                <span className="hero-type-outline">{h.hero.titleOutline}</span>
                <br />
                <span className="gradient-text">{h.hero.titleAccent}</span>
              </h1>
              <p className="hero-intro">{h.hero.intro}</p>
              <div className="hero-buttons">
                <Button asChild>
                  <a href="#contact">
                    {copy.primary}
                    <span>
                      <ArrowUpRight size={19} />
                    </span>
                  </a>
                </Button>
                <a className="hero-explore" href="#solutions">
                  {h.hero.explore}
                  <ArrowDown size={16} />
                </a>
              </div>
            </Reveal>
          </div>
          <div className="hero-visual">
            <DigitalEngine locale={locale} />
            <div className="visual-tag tag-product">
              <span className="tag-icon">
                <Braces size={16} />
              </span>
              <div>
                {h.visual.product}
                <small>{h.visual.productTypes}</small>
              </div>
            </div>
            <div className="visual-tag tag-ai">
              <span className="tag-icon">
                <Orbit size={16} />
              </span>
              <div>
                {h.visual.intelligence}
                <small>{h.visual.intelligenceTypes}</small>
              </div>
            </div>
          </div>
        </div>
        <div className="container hero-bottom">
          <a href="#expertise">
            <span className="scroll-mouse">
              <i />
            </span>
            {copy.scroll}
          </a>
          <span className="hero-bottom-note">
            {h.hero.bottomNote}
            <ArrowUpRight size={14} />
          </span>
        </div>
      </section>
      <PageMedia pageKey="home" />
      <CapabilityStrip locale={locale} />
      <section className="expertise light-section section" id="expertise">
        <div className="container">
          <Reveal>
            <div className="section-topline">
              <p className="eyebrow">
                <span className="eyebrow-cross">+</span>
                {copy.expertise}
              </p>
              <span className="section-number">
                {h.sections.expertiseIndex}
              </span>
            </div>
            <div className="section-heading">
              <h2>
                {h.sections.expertiseTitle}
                <br />
                <span>{h.sections.expertiseAccent}</span>
              </h2>
              <p>{copy.servicesIntro}</p>
            </div>
          </Reveal>
          <ServiceGrid copy={copy} locale={locale} />
          <div className="home-page-link">
            <Link href={`/${locale}/services`}>
              {h.sections.allServices}
              <ArrowUpRight size={18} />
            </Link>
          </div>
        </div>
      </section>
      <SolutionExplorer locale={locale} />
      <section className="approach light-section section" id="approach">
        <div className="container">
          <Reveal>
            <div className="section-topline">
              <p className="eyebrow">
                <span className="eyebrow-cross">+</span>
                {copy.aboutLabel}
              </p>
              <span className="section-number">{h.sections.approachIndex}</span>
            </div>
            <div className="manifesto">
              <h2>
                {h.manifesto.lead}{" "}
                <span className="manifesto-blue">{h.manifesto.accent}</span>
                <br />
                {h.manifesto.secondLine}
                <br />
                {h.manifesto.thirdLine}
                <span className="manifesto-dot">{h.manifesto.punctuation}</span>
              </h2>
              <div className="manifesto-note">
                <span className="manifesto-icon">
                  <ArrowUpRight size={30} />
                </span>
                <p>{copy.aboutText}</p>
              </div>
            </div>
          </Reveal>
          <div className="process-heading">
            <h3>{copy.processTitle}</h3>
            <span>{copy.processLabel}</span>
          </div>
          <div className="process-grid">
            {copy.process.map(([title, description], i) => (
              <Reveal key={i} delay={i * 0.08}>
                <article className="process-step">
                  <div className="step-track">
                    <span>0{i + 1}</span>
                    <ArrowRight size={18} />
                  </div>
                  <h4>{title}</h4>
                  <p>{description}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="technologies section" id="technologies">
        <div className="container tech-grid">
          <Reveal>
            <p className="eyebrow">
              <span className="eyebrow-cross">+</span>
              {copy.techLabel}
            </p>
            <h2>
              {h.technology.title}
              <br />
              <span className="gradient-text">{h.technology.accent}</span>
            </h2>
            <p className="tech-description">{copy.techText}</p>
            <a href="#contact" className="text-link">
              {h.technology.action}
              <ArrowUpRight size={18} />
            </a>
          </Reveal>
          <Reveal className="tech-panel">
            <div className="tech-panel-heading">
              <span>{copy.techCaption}</span>
              <span aria-hidden="true">
                <Plus size={16} />
              </span>
            </div>
            <div className="tech-core">
              <div className="tech-core-icon">
                <Layers3 size={32} strokeWidth={1.2} />
              </div>
              <span>{h.technology.connected}</span>
            </div>
            <div className="tech-list">
              {h.technology.items.map((item, i) => (
                <div key={i}>
                  <span className="tech-symbol">{item.symbol}</span>
                  <span>{item.name}</span>
                  <i />
                </div>
              ))}
            </div>
            <div className="tech-panel-footer">
              <Workflow size={14} />
              <span>{h.technology.footer}</span>
            </div>
          </Reveal>
        </div>
      </section>
      <section className="contact section" id="contact">
        <div className="container">
          <div className="contact-intro">
            <Reveal>
              <p className="eyebrow">
                <span className="eyebrow-cross">+</span>
                {copy.contactLabel}
              </p>
              <h2>
                {h.contact.title}
                <br />
                <span>{h.contact.accent}</span>
              </h2>
            </Reveal>
            <ArrowUpRight
              className="contact-arrow"
              strokeWidth={0.8}
              aria-hidden="true"
            />
          </div>
          <div className="contact-grid">
            <div className="contact-aside">
              <p>{copy.contactText}</p>
              <span className="contact-local-label">
                <span />
                {h.contact.briefHint}
              </span>
              <div className="contact-lines" aria-hidden="true">
                <i />
                <i />
                <i />
              </div>
            </div>
            <Reveal>
              <ProjectBrief copy={copy} locale={locale} />
            </Reveal>
          </div>
        </div>
      </section>
    </main>
  );
}
