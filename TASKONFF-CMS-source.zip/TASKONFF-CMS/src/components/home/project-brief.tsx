import { getSiteData } from "@/cms/site-data";
import type { Locale, SiteContent } from "@/content/site";
import { ProjectBriefForm } from "./project-brief-form";
export async function ProjectBrief({
  copy,
  locale = "ru",
}: {
  copy: SiteContent;
  locale?: Locale;
}) {
  const data = await getSiteData();
  return (
    <ProjectBriefForm
      copy={data.site[locale] ?? copy}
      locale={locale}
      options={data.services.map((service) => ({
        slug: service.slug,
        title: service[locale].title,
      }))}
    />
  );
}
