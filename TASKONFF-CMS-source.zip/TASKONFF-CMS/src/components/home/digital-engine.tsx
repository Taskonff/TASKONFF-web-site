"use client";

import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { ArrowUpRight, Pause, Play } from "lucide-react";
import type { Locale } from "@/content/site";
import { useSiteContent } from "@/cms/site-context";

type Point3 = { x: number; y: number; z: number };
type Projected = Point3 & { depth: number };

function subscribeMotionPreference(listener: () => void) {
  const media = window.matchMedia("(prefers-reduced-motion: reduce)");
  media.addEventListener("change", listener);
  return () => media.removeEventListener("change", listener);
}
function readMotionPreference() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

/** A projected 3D field, not a logo or a representation of operational data. */
export function DigitalEngine({ locale }: { locale: Locale }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const modeRef = useRef(0);
  const pausedRef = useRef(false);
  const pauseOverrideRef = useRef<boolean | null>(null);
  const forceRender = useRef<(() => void) | undefined>(undefined);
  const [mode, setMode] = useState(0);
  const [pauseOverride, setPauseOverride] = useState<boolean | null>(null);
  const reducedMotion = useSyncExternalStore(
    subscribeMotionPreference,
    readMotionPreference,
    () => true,
  );
  const paused = pauseOverride ?? reducedMotion;
  const copy = useSiteContent().home[locale].engine;
  const modes = copy.modes;

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const context = canvas.getContext("2d", { alpha: true });
    if (!context) return;
    const ctx = context;
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    let width = 600;
    let height = 530;
    let frame = 0;
    let visible = true;
    let tick = 0;
    let last = 0;
    let blend = 0;
    let pointerX = 0;
    let pointerY = 0;
    let tiltX = 0;
    let tiltY = 0;
    let alive = true;
    const tau = Math.PI * 2;

    const shape = (u: number, v: number): Point3 => {
      const primary = 1.39 + Math.sin(u * 3 + blend * 0.8) * 0.035 * blend;
      const tube = 0.43 + Math.cos(u * 2 + blend) * 0.045 * blend;
      const twist = v + u * blend * 0.22;
      const radius = primary + tube * Math.cos(twist);
      return {
        x: radius * Math.cos(u),
        y: radius * Math.sin(u),
        z: tube * Math.sin(twist) + Math.sin(u * 2 + blend) * 0.065 * blend,
      };
    };
    const project = (point: Point3, rotation = 0): Projected => {
      const rz = -0.44 + rotation;
      const rx = 0.53 + tiltY * 0.2;
      const ry = -0.5 + tiltX * 0.3;
      const x1 = point.x * Math.cos(rz) - point.y * Math.sin(rz);
      const y1 = point.x * Math.sin(rz) + point.y * Math.cos(rz);
      const y2 = y1 * Math.cos(rx) - point.z * Math.sin(rx);
      const z2 = y1 * Math.sin(rx) + point.z * Math.cos(rx);
      const x3 = x1 * Math.cos(ry) + z2 * Math.sin(ry);
      const z3 = -x1 * Math.sin(ry) + z2 * Math.cos(ry);
      const perspective = 5.7 / (5.7 - z3);
      const scale = Math.min(width / 4.9, height / 4.8);
      return {
        x: width * 0.5 + x3 * scale * perspective,
        y: height * 0.485 + y2 * scale * perspective,
        z: z3,
        depth: perspective,
      };
    };

    const trace = (
      points: Projected[],
      alpha: number,
      strokeWidth: number,
      front: boolean,
    ) => {
      ctx.lineWidth = strokeWidth;
      ctx.strokeStyle = `rgba(${front ? "33,166,255" : "27,98,192"},${alpha})`;
      ctx.beginPath();
      for (let index = 1; index < points.length; index += 1) {
        const a = points[index - 1];
        const b = points[index];
        const depth = (a.z + b.z) / 2;
        if (depth >= 0 !== front) continue;
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
      }
      ctx.stroke();
    };

    const render = () => {
      if (!alive) return;
      ctx.clearRect(0, 0, width, height);
      const centerX = width * 0.5;
      const centerY = height * 0.485;
      const haloSize = Math.min(width, height) * 0.48;
      const halo = ctx.createRadialGradient(
        centerX,
        centerY,
        0,
        centerX,
        centerY,
        haloSize,
      );
      halo.addColorStop(0, "rgba(0,94,255,0.12)");
      halo.addColorStop(0.5, "rgba(0,78,255,0.055)");
      halo.addColorStop(1, "rgba(0,70,255,0)");
      ctx.fillStyle = halo;
      ctx.fillRect(0, 0, width, height);

      // Fine registration marks ground the sculptural field without fake telemetry.
      ctx.strokeStyle = "rgba(94,155,191,0.24)";
      ctx.lineWidth = 0.7;
      for (const [x, y] of [
        [22, 26],
        [width - 22, 26],
        [22, height - 24],
        [width - 22, height - 24],
      ]) {
        ctx.beginPath();
        ctx.moveTo(x - 4, y);
        ctx.lineTo(x + 4, y);
        ctx.moveTo(x, y - 4);
        ctx.lineTo(x, y + 4);
        ctx.stroke();
      }
      const rotation = tick * 0.055;
      const wires: Projected[][] = [];
      // Meridians describe the volume; longitudinal ribbons reveal its flow.
      for (let ring = 0; ring < 27; ring += 1) {
        const points = [];
        for (let step = 0; step <= 36; step += 1)
          points.push(
            project(shape((ring / 27) * tau, (step / 36) * tau), rotation),
          );
        wires.push(points);
      }
      for (let ring = 0; ring < 11; ring += 1) {
        const points = [];
        for (let step = 0; step <= 96; step += 1)
          points.push(
            project(shape((step / 96) * tau, (ring / 11) * tau), rotation),
          );
        wires.push(points);
      }
      for (const wire of wires) trace(wire, 0.27, 0.65, false);

      // Luminous hollow core: a lens, rather than a solid default sphere.
      const coreRadius = Math.min(width, height) * 0.125;
      const core = ctx.createRadialGradient(
        centerX - coreRadius * 0.3,
        centerY - coreRadius * 0.4,
        0,
        centerX,
        centerY,
        coreRadius,
      );
      core.addColorStop(0, "rgba(173,245,255,0.24)");
      core.addColorStop(0.38, "rgba(35,177,255,0.17)");
      core.addColorStop(0.79, "rgba(0,80,255,0.03)");
      core.addColorStop(1, "rgba(0,80,255,0)");
      ctx.fillStyle = core;
      ctx.beginPath();
      ctx.arc(centerX, centerY, coreRadius, 0, tau);
      ctx.fill();
      for (let i = 0; i < 5; i += 1) {
        ctx.beginPath();
        ctx.ellipse(
          centerX,
          centerY,
          coreRadius * (0.35 + i * 0.13),
          coreRadius * (0.34 + i * 0.06),
          -0.4,
          0,
          tau,
        );
        ctx.strokeStyle = `rgba(67,207,245,${0.1 + i * 0.035})`;
        ctx.lineWidth = 0.6;
        ctx.stroke();
      }
      for (const wire of wires) trace(wire, 0.45, 0.72, true);

      // The two bright surface paths give the volume a continuous liquid edge.
      for (let ribbon = 0; ribbon < 3; ribbon += 1) {
        const points = [];
        for (let step = 0; step <= 150; step += 1) {
          const u = (step / 150) * tau;
          points.push(
            project(
              shape(u, ribbon * 1.95 + Math.sin(u * 2 + tick * 0.35) * 0.15),
              rotation,
            ),
          );
        }
        const gradient = ctx.createLinearGradient(
          width * 0.2,
          height * 0.75,
          width * 0.8,
          height * 0.2,
        );
        gradient.addColorStop(0, "rgba(6,75,255,0.8)");
        gradient.addColorStop(0.5, "rgba(20,151,255,0.85)");
        gradient.addColorStop(1, "rgba(0,225,219,0.95)");
        ctx.strokeStyle = gradient;
        ctx.lineWidth = ribbon === 0 ? 1.8 : 1.1;
        ctx.shadowColor = "#008cff";
        ctx.shadowBlur = ribbon === 0 ? 12 : 5;
        ctx.beginPath();
        points.forEach((p, i) =>
          i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y),
        );
        ctx.stroke();
        ctx.shadowBlur = 0;
      }

      const particles: (Projected & { intensity: number })[] = [];
      for (let ring = 0; ring < 74; ring += 1) {
        for (let row = 0; row < 10; row += 1) {
          const u = (ring / 74) * tau + tick * 0.075 * (row % 2 ? 1 : -0.6);
          const v = (row / 10) * tau;
          particles.push({
            ...project(shape(u, v), rotation),
            intensity: 0.35 + (Math.sin(ring * 1.7 + row * 2.3) + 1) * 0.3,
          });
        }
      }
      particles.sort((a, b) => a.z - b.z);
      for (const p of particles) {
        const alpha = (p.z < 0 ? 0.3 : 0.85) * p.intensity;
        ctx.fillStyle =
          p.z > 0.5 ? `rgba(61,226,239,${alpha})` : `rgba(38,133,255,${alpha})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, (p.z > 0.6 ? 1.4 : 0.8) * p.depth, 0, tau);
        ctx.fill();
      }
      // A small set of moving nodes follows the same field — no random star dust.
      for (let node = 0; node < 4; node += 1) {
        const point = project(
          shape((node / 4) * tau + tick * 0.11, node * 1.45),
          rotation,
        );
        const glow = ctx.createRadialGradient(
          point.x,
          point.y,
          0,
          point.x,
          point.y,
          13,
        );
        glow.addColorStop(0, "rgba(156,255,255,0.9)");
        glow.addColorStop(0.15, "rgba(0,218,239,0.65)");
        glow.addColorStop(1, "rgba(0,137,255,0)");
        ctx.fillStyle = glow;
        ctx.fillRect(point.x - 13, point.y - 13, 26, 26);
      }
    };

    const shouldAnimate = () =>
      alive && visible && !document.hidden && !pausedRef.current;
    const loop = (time: number) => {
      frame = 0;
      if (!shouldAnimate()) return;
      const elapsed = last ? Math.min((time - last) / 1000, 0.04) : 0.016;
      last = time;
      tick += elapsed;
      blend += (modeRef.current - blend) * 0.035;
      tiltX += (pointerX - tiltX) * 0.035;
      tiltY += (pointerY - tiltY) * 0.035;
      render();
      frame = requestAnimationFrame(loop);
    };
    const refresh = () => {
      if (!alive) return;
      if (pausedRef.current) {
        blend = modeRef.current;
        render();
      }
      if (shouldAnimate() && !frame) {
        last = 0;
        frame = requestAnimationFrame(loop);
      } else if (!shouldAnimate() && frame) {
        cancelAnimationFrame(frame);
        frame = 0;
      }
    };
    forceRender.current = refresh;
    const resize = () => {
      const bounds = wrap.getBoundingClientRect();
      width = Math.max(280, bounds.width);
      height = Math.max(320, bounds.height || 530);
      const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      render();
      refresh();
    };
    const move = (event: PointerEvent) => {
      if (event.pointerType === "touch" || pausedRef.current) return;
      const bounds = wrap.getBoundingClientRect();
      pointerX = ((event.clientX - bounds.left) / bounds.width - 0.5) * 2;
      pointerY = ((event.clientY - bounds.top) / bounds.height - 0.5) * 2;
    };
    const leave = () => {
      pointerX = 0;
      pointerY = 0;
    };
    const changePreference = () => {
      if (pauseOverrideRef.current === null) pausedRef.current = media.matches;
      refresh();
    };
    const intersection = new IntersectionObserver(
      ([entry]) => {
        visible = entry.isIntersecting;
        refresh();
      },
      { threshold: 0.05 },
    );
    const observer = new ResizeObserver(resize);
    observer.observe(wrap);
    intersection.observe(wrap);
    wrap.addEventListener("pointermove", move);
    wrap.addEventListener("pointerleave", leave);
    document.addEventListener("visibilitychange", refresh);
    media.addEventListener("change", changePreference);
    pausedRef.current = pauseOverrideRef.current ?? media.matches;
    resize();
    refresh();
    return () => {
      alive = false;
      cancelAnimationFrame(frame);
      observer.disconnect();
      intersection.disconnect();
      wrap.removeEventListener("pointermove", move);
      wrap.removeEventListener("pointerleave", leave);
      document.removeEventListener("visibilitychange", refresh);
      media.removeEventListener("change", changePreference);
      forceRender.current = undefined;
    };
  }, []);

  function selectMode(value: number) {
    modeRef.current = value;
    setMode(value);
    forceRender.current?.();
  }
  function toggleAnimation() {
    pausedRef.current = !pausedRef.current;
    pauseOverrideRef.current = pausedRef.current;
    setPauseOverride(pausedRef.current);
    forceRender.current?.();
  }
  return (
    <div className="digital-engine">
      <div className="engine-canvas-wrap" ref={wrapRef}>
        <canvas
          ref={canvasRef}
          className="engine-canvas"
          role="img"
          aria-label={copy.title}
        />
        <div className="engine-caption" aria-hidden="true">
          <span>{copy.caption}</span>
          <ArrowUpRight size={15} />
        </div>
      </div>
      <div className="engine-control-label">
        <span>{copy.hint}</span>
        <button
          type="button"
          className="engine-pause"
          onClick={toggleAnimation}
          aria-label={paused ? copy.play : copy.pause}
          aria-pressed={paused}
        >
          {paused ? <Play size={13} /> : <Pause size={13} />}
        </button>
      </div>
      <div className="engine-controls" role="group" aria-label={copy.mode}>
        {modes.map((label, index) => (
          <button
            type="button"
            className={`engine-mode${mode === index ? " is-active" : ""}`}
            key={index}
            aria-pressed={mode === index}
            onClick={() => selectMode(index)}
          >
            <span>0{index + 1}</span>
            {label}
            <i aria-hidden="true" />
          </button>
        ))}
      </div>
      <p className="engine-mode-description" aria-live="polite">
        {copy.active[mode]}
      </p>
    </div>
  );
}
