"use client";
import Link from "next/link";
import { useId, useRef, useState, type KeyboardEvent } from "react";
import { motion, useReducedMotion } from "motion/react";
import {
  Search,
  ArrowUpRight,
  ArrowRight,
  Building2,
  ShoppingBag,
  Truck,
  HeartPulse,
  Landmark,
  Factory,
  ShieldCheck,
} from "lucide-react";
import type { ServiceGroup } from "@/content/services";
import { useSiteContent } from "@/cms/site-context";
import type { Locale } from "@/content/site";
const groupIds: ServiceGroup[] = ["build", "automate", "operate", "design"];
export function ServiceCatalog({ locale }: { locale: Locale }) {
  const snapshot = useSiteContent();
  const { services, groups: serviceGroups } = snapshot;
  const c = snapshot.expertise[locale].services.catalog;
  const [query, setQuery] = useState("");
  const [group, setGroup] = useState<ServiceGroup | "all">("all");
  const reduced = useReducedMotion();
  const input = useId();
  const normalized = query.toLocaleLowerCase(locale).trim();
  const visible = services.filter(
    (service) =>
      (group === "all" || service.group === group) &&
      `${service[locale].title} ${service[locale].intro} ${serviceGroups[locale][service.group]}`
        .toLocaleLowerCase(locale)
        .includes(normalized),
  );
  return (
    <div className="expertise-catalog">
      <div className="expertise-catalog-tools">
        <label className="expertise-search" htmlFor={input}>
          <Search size={18} />
          <input
            id={input}
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={c.placeholder}
            aria-label={c.searchLabel}
          />
        </label>
        <div
          className="expertise-filters"
          role="group"
          aria-label={c.categoriesLabel}
        >
          {(["all", ...groupIds] as const).map((id) => (
            <button
              key={id}
              type="button"
              aria-pressed={group === id}
              onClick={() => setGroup(id)}
            >
              {id === "all" ? c.all : serviceGroups[locale][id]}
            </button>
          ))}
        </div>
      </div>
      <p className="expertise-result-count" aria-live="polite">
        {c.resultLabel}: {visible.length}
      </p>
      <div className="expertise-catalog-grid">
        {visible.map((service) => (
          <motion.article
            key={service.slug}
            className="expertise-service-card"
            initial={false}
            animate={reduced ? undefined : { opacity: [0.55, 1], y: [8, 0] }}
            transition={{ duration: 0.3 }}
          >
            <div className="expertise-card-top">
              <span>{serviceGroups[locale][service.group]}</span>
              <span>
                {String(
                  services.findIndex((item) => item.slug === service.slug) + 1,
                ).padStart(2, "0")}
              </span>
            </div>
            <h3>
              <Link href={`/${locale}/services/${service.slug}`}>
                {service[locale].title}
              </Link>
            </h3>
            <p>{service[locale].intro}</p>
            <ul>
              {service[locale].deliverables.slice(0, 2).map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
            <Link
              className="expertise-card-link"
              href={`/${locale}/services/${service.slug}`}
            >
              <span>{c.detailLink}</span>
              <ArrowUpRight size={19} />
            </Link>
          </motion.article>
        ))}
      </div>
      {!visible.length && (
        <div className="expertise-no-results">
          <h3>{c.emptyTitle}</h3>
          <p>{c.emptyText}</p>
          <button
            type="button"
            onClick={() => {
              setGroup("all");
              setQuery("");
            }}
          >
            {c.reset}
            <ArrowRight size={15} />
          </button>
        </div>
      )}
    </div>
  );
}

const industryIcons: Record<string, typeof Building2> = {
  Building2,
  ShoppingBag,
  Truck,
  HeartPulse,
  Landmark,
  Factory,
};
export function IndustryExplorer({ locale }: { locale: Locale }) {
  const [active, setActive] = useState(0);
  const [step, setStep] = useState(0);
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  const uid = useId();
  const reduced = useReducedMotion();
  const c = useSiteContent().expertise[locale].industries;
  const items = c.items;
  const item = items[active];
  const Icon = industryIcons[item.iconId] ?? Building2;
  function select(index: number) {
    setActive(index);
    setStep(0);
  }
  function navigate(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next = index;
    if (event.key === "ArrowDown" || event.key === "ArrowRight")
      next = (index + 1) % items.length;
    else if (event.key === "ArrowUp" || event.key === "ArrowLeft")
      next = (index + items.length - 1) % items.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = items.length - 1;
    else return;
    event.preventDefault();
    select(next);
    refs.current[next]?.focus();
  }
  return (
    <div className="expertise-industry-explorer">
      <div
        className="expertise-industry-tabs"
        role="tablist"
        aria-label={c.tabsLabel}
      >
        {items.map((industry, index) => {
          const TabIcon = industryIcons[industry.iconId] ?? Building2;
          return (
            <button
              key={industry.name}
              ref={(el) => {
                refs.current[index] = el;
              }}
              type="button"
              role="tab"
              id={`${uid}-tab-${index}`}
              aria-selected={active === index}
              aria-controls={`${uid}-panel`}
              tabIndex={active === index ? 0 : -1}
              onClick={() => select(index)}
              onKeyDown={(event) => navigate(event, index)}
            >
              <TabIcon size={18} />
              {industry.name}
              <ArrowUpRight size={15} />
            </button>
          );
        })}
      </div>
      <motion.div
        className="expertise-industry-panel"
        id={`${uid}-panel`}
        role="tabpanel"
        aria-labelledby={`${uid}-tab-${active}`}
        tabIndex={0}
        key={active}
        initial={false}
        animate={reduced ? undefined : { opacity: [0.5, 1], y: [10, 0] }}
        transition={{ duration: 0.3 }}
      >
        <div className="expertise-industry-panel-top">
          <span>
            <Icon size={25} />
          </span>
          <small>{c.scenarioLabel}</small>
        </div>
        <h3>{item.title}</h3>
        <p>{item.text}</p>
        <div
          className="expertise-industry-flow"
          role="group"
          aria-label={c.stepsLabel}
        >
          {item.steps.map(([title], index) => (
            <button
              key={title}
              type="button"
              aria-pressed={step === index}
              aria-controls={`${uid}-detail`}
              onClick={() => setStep(index)}
            >
              <span>0{index + 1}</span>
              {title}
              {index < 2 && <ArrowRight size={14} />}
            </button>
          ))}
        </div>
        <p
          className="expertise-industry-step"
          id={`${uid}-detail`}
          aria-live="polite"
        >
          {item.steps[step][1]}
        </p>
        <div className="expertise-industry-guard">
          <ShieldCheck size={19} />
          <p>{item.guard}</p>
        </div>
      </motion.div>
    </div>
  );
}
