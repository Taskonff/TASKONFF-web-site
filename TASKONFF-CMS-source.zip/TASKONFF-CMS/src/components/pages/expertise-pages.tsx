import Link from "next/link";
import {
  ArrowUpRight,
  Check,
  ArrowRight,
  Braces,
  Workflow,
} from "lucide-react";
import { InternalHero, PageCTA } from "@/components/site/page-primitives";
import { Reveal } from "@/components/home/reveal";
import { ServiceCatalog, IndustryExplorer } from "./expertise-interactions";
import type { Service } from "@/content/services";
import { getSiteData } from "@/cms/site-data";
import { PageMedia } from "@/cms/page-media";
import type { Locale } from "@/content/site";
import "./expertise-pages.css";
export async function ServicesPage({ locale }: { locale: Locale }) {
  const snapshot = await getSiteData();
  const c = snapshot.expertise[locale].services;
  return (
    <main id="main" className="internal-page">
      <InternalHero
        locale={locale}
        eyebrow={c.label}
        title={c.title}
        description={c.description}
        index="02 / EXPERTISE"
      >
        <div className="expertise-hero-diagram" aria-hidden="true">
          <Braces size={38} />
          <i />
          <Workflow size={38} />
          <span>{c.diagramLabel}</span>
        </div>
      </InternalHero>
      <PageMedia pageKey="services" />
      <section className="section light-section">
        <div className="container">
          <Reveal>
            <div className="expertise-section-heading">
              <p className="eyebrow">{c.sectionLabel}</p>
              <h2>{c.sectionTitle}</h2>
            </div>
          </Reveal>
          <ServiceCatalog locale={locale} />
        </div>
      </section>
      <section className="section expertise-engagement">
        <div className="container">
          <div>
            <p className="eyebrow">{c.engagementLabel}</p>
            <h2>{c.engagementTitle}</h2>
          </div>
          <div>
            <p>{c.engagementText}</p>
            <Link href={`/${locale}/process`}>
              {c.processLink}
              <ArrowUpRight size={18} />
            </Link>
          </div>
        </div>
      </section>
      <PageCTA locale={locale} />
    </main>
  );
}
export async function ServiceDetailPage({
  locale,
  service,
}: {
  locale: Locale;
  service: Service;
}) {
  const snapshot = await getSiteData();
  const { services, groups: serviceGroups } = snapshot;
  const c = snapshot.expertise[locale].detail;
  const copy = service[locale];
  return (
    <main id="main" className="internal-page">
      <InternalHero
        locale={locale}
        eyebrow={copy.title}
        title={copy.title}
        description={copy.intro}
        index={serviceGroups[locale][service.group]}
      >
        <div className="expertise-detail-mark" aria-hidden="true">
          <span>
            {String(
              services.findIndex((item) => item.slug === service.slug) + 1,
            ).padStart(2, "0")}
          </span>
          <Braces size={36} />
        </div>
      </InternalHero>
      <PageMedia pageKey={`service-${service.slug}`} />
      <section className="section light-section">
        <div className="container">
          <Link href={`/${locale}/services`} className="expertise-back-link">
            ← {c.back}
          </Link>
          <div className="expertise-detail-columns">
            <Reveal>
              <p className="eyebrow">{c.needsLabel}</p>
              <h2>{c.needsTitle}</h2>
              <ul className="expertise-needs">
                {copy.needs.map((need) => (
                  <li key={need}>
                    <ArrowRight size={17} />
                    {need}
                  </li>
                ))}
              </ul>
            </Reveal>
            <Reveal className="expertise-deliverables">
              <p className="eyebrow">{c.outputsLabel}</p>
              <h3>{c.outputsTitle}</h3>
              <ul>
                {copy.deliverables.map((item) => (
                  <li key={item}>
                    <Check size={18} />
                    {item}
                  </li>
                ))}
              </ul>
              <p>{c.scopeNote}</p>
            </Reveal>
          </div>
        </div>
      </section>
      <section className="section expertise-workflow">
        <div className="container">
          <div className="expertise-section-heading">
            <p className="eyebrow">{c.workflowLabel}</p>
            <h2>{c.workflowTitle}</h2>
          </div>
          <div className="expertise-workflow-grid">
            {copy.workflow.map((step, index) => (
              <Reveal key={step} delay={index * 0.06}>
                <article>
                  <span>0{index + 1}</span>
                  <h3>{step}</h3>
                </article>
              </Reveal>
            ))}
          </div>
          <div className="expertise-decision">
            <span>+</span>
            <p>{copy.decision}</p>
          </div>
        </div>
      </section>
      <section className="section light-section">
        <div className="container expertise-faq-grid">
          <div>
            <p className="eyebrow">FAQ</p>
            <h2>{c.faqTitle}</h2>
          </div>
          <div className="expertise-faq">
            {copy.faq.map(([question, answer]) => (
              <details key={question}>
                <summary>
                  {question}
                  <span>+</span>
                </summary>
                <p>{answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
      <section className="expertise-related">
        <div className="container">
          <h2>{c.relatedTitle}</h2>
          <div>
            {services
              .filter(
                (item) =>
                  item.slug !== service.slug && item.group === service.group,
              )
              .concat(services.filter((item) => item.group !== service.group))
              .slice(0, 3)
              .map((item) => (
                <Link key={item.slug} href={`/${locale}/services/${item.slug}`}>
                  {item[locale].title}
                  <ArrowUpRight size={18} />
                </Link>
              ))}
          </div>
        </div>
      </section>
      <PageCTA locale={locale} title={c.ctaTitle} />
    </main>
  );
}
export async function IndustriesPage({ locale }: { locale: Locale }) {
  const snapshot = await getSiteData();
  const c = snapshot.expertise[locale].industries;
  return (
    <main id="main" className="internal-page">
      <InternalHero
        locale={locale}
        eyebrow={c.label}
        title={c.title}
        description={c.description}
        index="03 / INDUSTRIES"
      />
      <PageMedia pageKey="industries" />
      <section className="section expertise-industries-section">
        <div className="container">
          <div className="expertise-section-heading">
            <p className="eyebrow">{c.sectionLabel}</p>
            <h2>{c.sectionTitle}</h2>
          </div>
          <IndustryExplorer locale={locale} />
        </div>
      </section>
      <section className="section light-section">
        <div className="container expertise-industry-principles">
          <div>
            <p className="eyebrow">{c.principlesLabel}</p>
            <h2>{c.principlesTitle}</h2>
          </div>
          <div>
            {c.principles.map(([title, text]) => (
              <article key={title}>
                <h3>{title}</h3>
                <p>{text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
      <PageCTA locale={locale} />
    </main>
  );
}
