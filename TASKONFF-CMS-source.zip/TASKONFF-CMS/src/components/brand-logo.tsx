import Image from "next/image";
export function BrandLogo({
  src,
  name = "TASKONFF",
}: {
  src?: string;
  name?: string;
}) {
  return src ? (
    <span className="brand-logo">
      <Image
        src={src}
        alt={name}
        fill
        sizes="(max-width: 640px) 152px, 200px"
        style={{ objectFit: "contain" }}
        unoptimized
        priority
      />
    </span>
  ) : (
    <span className="brand-name-text">{name}</span>
  );
}
