import path from "node:path";
import { buildConfig, APIError, type CollectionConfig } from "payload";
import {
  sqliteAdapter,
  type MigrateUpArgs,
  type MigrateDownArgs,
} from "@payloadcms/db-sqlite";
import { en } from "@payloadcms/translations/languages/en";
import { ru } from "@payloadcms/translations/languages/ru";
import sharp from "sharp";
import { pageDefinitions, validatePageContent } from "@/cms/defaults";
import {
  authenticated,
  publishedOrAuthenticated,
  protectAccountCreation,
  protectLastAccount,
  disableUnconfiguredPasswordEmail,
} from "@/cms/server/access";
import {
  IMAGE_MIME_TYPES,
  MAX_IMAGE_BYTES,
  validateMediaUpload,
} from "@/cms/server/media";
import { getCMSPaths, getCMSSecret } from "@/cms/server/storage";
import { migrations } from "@/cms/server/migrations";

const paths = getCMSPaths();
const siteURL = process.env.SITE_URL || process.env.NEXT_PUBLIC_SITE_URL;
const siteOrigin = siteURL ? new URL(siteURL).origin : undefined;
const pageOptions = pageDefinitions.map(({ key, title }) => ({
  label: title,
  value: key,
}));

const users: CollectionConfig = {
  slug: "users",
  labels: {
    singular: { ru: "Администратор", en: "Administrator" },
    plural: { ru: "Администраторы", en: "Administrators" },
  },
  admin: {
    useAsTitle: "email",
    group: { ru: "Управление", en: "Administration" },
  },
  auth: {
    useSessions: true,
    tokenExpiration: 60 * 60 * 8,
    maxLoginAttempts: 5,
    lockTime: 15 * 60 * 1000,
    cookies: {
      sameSite: "Lax",
      secure: siteOrigin?.startsWith("https://") || false,
    },
  },
  access: {
    admin: authenticated,
    create: authenticated,
    read: authenticated,
    update: authenticated,
    delete: authenticated,
    unlock: authenticated,
  },
  hooks: {
    beforeChange: [protectAccountCreation],
    beforeDelete: [protectLastAccount],
    beforeOperation: [disableUnconfiguredPasswordEmail],
  },
  fields: [
    {
      name: "name",
      label: { ru: "Имя", en: "Name" },
      type: "text",
      maxLength: 120,
    },
  ],
};

const pages: CollectionConfig = {
  slug: "pages",
  labels: {
    singular: { ru: "Страница", en: "Page" },
    plural: { ru: "Страницы сайта", en: "Website pages" },
  },
  admin: {
    useAsTitle: "title",
    defaultColumns: ["title", "key", "_status", "updatedAt"],
    group: { ru: "Контент", en: "Content" },
    description: {
      ru: "Тексты на русском и английском. Сохраните черновик или опубликуйте изменения на сайте.",
      en: "Russian and English website content. Save a draft or publish changes to the website.",
    },
  },
  access: {
    create: () => false,
    read: publishedOrAuthenticated,
    update: authenticated,
    delete: () => false,
    readVersions: authenticated,
  },
  versions: { drafts: { validate: true }, maxPerDoc: 30 },
  hooks: {
    beforeValidate: [
      ({ data, originalDoc, operation }) => {
        const key = data?.key ?? originalDoc?.key;
        if (!pageDefinitions.some((definition) => definition.key === key)) {
          throw new APIError("Choose a supported website page.", 400);
        }
        if (
          operation === "update" &&
          originalDoc?.key &&
          data?.key &&
          data.key !== originalDoc.key
        ) {
          throw new APIError("A website page key cannot be changed.", 400);
        }
        const result = validatePageContent(
          key,
          data?.content ?? originalDoc?.content,
        );
        if (result !== true)
          throw new APIError(
            typeof result === "string" ? result : "Invalid page content.",
            400,
          );
        return data;
      },
    ],
  },
  fields: [
    {
      name: "title",
      label: { ru: "Название в панели", en: "Admin title" },
      type: "text",
      required: true,
      maxLength: 160,
    },
    {
      name: "key",
      label: { ru: "Страница", en: "Page" },
      type: "select",
      required: true,
      unique: true,
      options: pageOptions,
      admin: { readOnly: true, position: "sidebar" },
    },
    {
      name: "content",
      label: { ru: "Тексты страницы", en: "Page content" },
      type: "json",
      required: true,
      admin: {
        components: { Field: "@/cms/admin/text-tree-field#TextTreeField" },
      },
    },
    {
      name: "heroImage",
      label: { ru: "Изображение страницы", en: "Page image" },
      type: "upload",
      relationTo: "media",
      admin: { condition: (data) => data?.key !== "shared" },
    },
    {
      name: "imageAlt",
      admin: { condition: (data) => data?.key !== "shared" },
      label: { ru: "Описание изображения", en: "Image description" },
      type: "text",
      maxLength: 300,
    },
  ],
};

const media: CollectionConfig = {
  slug: "media",
  labels: {
    singular: { ru: "Изображение", en: "Image" },
    plural: { ru: "Медиатека", en: "Media library" },
  },
  admin: { useAsTitle: "alt", group: { ru: "Контент", en: "Content" } },
  access: {
    read: () => true,
    create: authenticated,
    update: authenticated,
    delete: authenticated,
  },
  hooks: { beforeOperation: [validateMediaUpload] },
  upload: {
    staticDir: paths.mediaDir,
    mimeTypes: IMAGE_MIME_TYPES,
    pasteURL: false,
    focalPoint: false,
    // Keep the original logo's proportions; never crop or redraw uploaded originals.
    imageSizes: [
      {
        name: "thumbnail",
        width: 480,
        height: undefined,
        withoutEnlargement: true,
      },
    ],
    adminThumbnail: "thumbnail",
  },
  fields: [
    {
      name: "alt",
      label: { ru: "Описание изображения", en: "Image description" },
      type: "text",
      required: true,
      maxLength: 300,
    },
    {
      name: "caption",
      label: { ru: "Подпись", en: "Caption" },
      type: "text",
      localized: true,
      maxLength: 500,
    },
  ],
};

const caseStudies: CollectionConfig = {
  slug: "case-studies",
  labels: {
    singular: { ru: "Кейс", en: "Case study" },
    plural: { ru: "Кейсы", en: "Case studies" },
  },
  admin: {
    useAsTitle: "title",
    group: { ru: "Контент", en: "Content" },
    description: {
      ru: "Добавляйте только реальные проекты с разрешёнными к публикации материалами.",
      en: "Add only real projects with material approved for publication.",
    },
  },
  access: {
    create: authenticated,
    read: publishedOrAuthenticated,
    update: authenticated,
    delete: authenticated,
    readVersions: authenticated,
  },
  versions: { drafts: true, maxPerDoc: 30 },
  fields: [
    {
      name: "title",
      label: { ru: "Заголовок", en: "Title" },
      type: "text",
      localized: true,
      required: true,
      maxLength: 180,
    },
    {
      name: "slug",
      label: { ru: "Идентификатор", en: "Slug" },
      type: "text",
      required: true,
      unique: true,
      maxLength: 100,
      validate: (value: unknown) =>
        (typeof value === "string" &&
          /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value)) ||
        "Use lowercase Latin letters, numbers and hyphens.",
    },
    {
      name: "summary",
      label: { ru: "Краткое описание", en: "Summary" },
      type: "textarea",
      localized: true,
      required: true,
      maxLength: 1000,
    },
    {
      name: "body",
      label: { ru: "Описание проекта", en: "Project description" },
      type: "textarea",
      localized: true,
      maxLength: 20000,
    },
    {
      name: "heroImage",
      label: { ru: "Изображение", en: "Image" },
      type: "upload",
      relationTo: "media",
    },
  ],
};

export default buildConfig({
  telemetry: false,
  secret: getCMSSecret(),
  ...(siteOrigin
    ? { serverURL: siteOrigin, csrf: [siteOrigin], cors: [siteOrigin] }
    : {}),
  admin: {
    avatar: "default",
    user: "users",
    components: { beforeDashboard: ["@/cms/admin/admin-intro#AdminIntro"] },
    meta: {
      titleSuffix: " | TASKONFF Admin",
      robots: "noindex, nofollow",
      defaultOGImageType: "off",
    },
    importMap: {
      baseDir: path.resolve(process.cwd(), "src"),
      importMapFile: path.resolve(
        process.cwd(),
        "src/app/(payload)/admin/importMap.ts",
      ),
    },
  },
  i18n: { fallbackLanguage: "ru", supportedLanguages: { ru, en } },
  localization: {
    defaultLocale: "ru",
    locales: [
      { code: "ru", label: "Русский" },
      { code: "en", label: "English" },
    ],
    fallback: true,
  },
  collections: [users, pages, media, caseStudies],
  globals: [
    {
      slug: "site-settings",
      label: { ru: "Настройки сайта", en: "Site settings" },
      admin: { group: { ru: "Управление", en: "Administration" } },
      access: { read: () => true, update: authenticated },
      fields: [
        {
          name: "logo",
          label: { ru: "Оригинальный логотип", en: "Original logo" },
          type: "upload",
          relationTo: "media",
        },
        {
          name: "heroImage",
          label: { ru: "Изображение главной страницы", en: "Home hero image" },
          type: "upload",
          relationTo: "media",
        },
        {
          name: "ogImage",
          label: {
            ru: "Изображение для социальных сетей",
            en: "Social sharing image",
          },
          type: "upload",
          relationTo: "media",
        },
        {
          name: "pageImages",
          label: { ru: "Изображения разделов", en: "Page images" },
          type: "array",
          maxRows: 30,
          fields: [
            {
              name: "key",
              label: { ru: "Страница", en: "Page" },
              type: "select",
              required: true,
              options: pageOptions.filter(
                (option) => option.value !== "shared",
              ),
            },
            {
              name: "image",
              label: { ru: "Изображение", en: "Image" },
              type: "upload",
              relationTo: "media",
              required: true,
            },
            {
              name: "alt",
              label: { ru: "Описание", en: "Description" },
              type: "text",
              maxLength: 300,
            },
          ],
        },
        {
          name: "brandName",
          label: { ru: "Название компании", en: "Company name" },
          type: "text",
          maxLength: 100,
        },
        {
          name: "contactEmail",
          label: { ru: "Публичный email", en: "Public email" },
          type: "email",
        },
        {
          name: "contactPhone",
          label: { ru: "Публичный телефон", en: "Public phone" },
          type: "text",
          maxLength: 60,
        },
        {
          name: "address",
          label: { ru: "Публичный адрес", en: "Public address" },
          type: "textarea",
          maxLength: 1000,
        },
      ],
    },
  ],
  db: sqliteAdapter({
    client: { url: paths.databaseURL },
    migrationDir: path.resolve(process.cwd(), "src/cms/server/migrations"),
    push: false,
    prodMigrations: migrations,
    wal: true,
    busyTimeout: 5000,
  }),
  onInit: async (payload) => {
    if (process.env.NODE_ENV !== "production") {
      // Payload's generic adapter API erases the SQLite migration argument type.
      await payload.db.migrate({
        migrations: migrations.map((migration) => ({
          name: migration.name,
          up: (args: unknown) => migration.up(args as MigrateUpArgs),
          down: (args: unknown) => migration.down(args as MigrateDownArgs),
        })),
      });
    }
  },
  sharp,
  graphQL: { disable: true },
  upload: {
    abortOnLimit: true,
    requestSizeLimit: MAX_IMAGE_BYTES + 256 * 1024,
    responseOnLimit: "Images must be no larger than 8 MB.",
  },
  typescript: {
    autoGenerate: false,
    outputFile: path.resolve(process.cwd(), "src/cms/payload-types.ts"),
  },
});
