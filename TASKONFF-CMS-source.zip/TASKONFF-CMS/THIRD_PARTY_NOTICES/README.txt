Third-party notices for the TASKONFF public website runtime and font.
Original licenses are preserved in package folders. Package and version list: packages.json.
Development and CMS server dependencies installed by npm retain their own licenses in node_modules.
