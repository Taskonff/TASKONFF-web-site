import { test } from "node:test";
import assert from "node:assert/strict";
import { createBrief } from "../src/lib/brief";
const valid = {
  name: "Test User",
  email: "user@example.com",
  service: "AI",
  message: "We need to automate our document workflow.",
  website: "",
};
test("brief contains supplied details and preserves Unicode", () => {
  const result = createBrief({ ...valid, name: "Иван" });
  assert.ok(result.includes("Иван"));
  assert.ok(result.includes(valid.message));
  assert.ok(result.includes(valid.email));
});
test("rejects invalid email, short brief and honeypot", () => {
  for (const patch of [
    { email: "invalid" },
    { message: "short" },
    { website: "spam" },
    { name: " " },
    { message: "x".repeat(5001) },
  ])
    assert.throws(() => createBrief({ ...valid, ...patch }));
});
