import { test, expect } from "@playwright/test";
for (const locale of ["ru", "en"])
  for (const width of [360, 390, 768, 1440]) {
    test(`${locale} homepage at ${width}px`, async ({ page }) => {
      await page.setViewportSize({ width, height: 1000 });
      await page.emulateMedia({ reducedMotion: "reduce" });
      const errors: string[] = [];
      page.on("pageerror", (error) => errors.push(error.message));
      const response = await page.goto(`/${locale}`);
      expect(response?.status()).toBe(200);
      await expect(page.locator("html")).toHaveAttribute("lang", locale);
      await expect(page.locator("h1")).toHaveCount(1);
      await expect
        .poll(() =>
          page.evaluate(
            () => document.documentElement.scrollWidth <= innerWidth,
          ),
        )
        .toBe(true);
      for (const link of await page.locator('a[href^="#"]').all()) {
        const id = (await link.getAttribute("href"))!.slice(1);
        expect(
          await page.evaluate((id) => !!document.getElementById(id), id),
        ).toBe(true);
      }
      const canvas = page.locator(".engine-canvas");
      const pause = page.locator(".engine-pause");
      await expect(pause).toHaveAttribute("aria-pressed", "true");
      const before = await canvas.evaluate((el: HTMLCanvasElement) =>
        el.toDataURL(),
      );
      await page.locator(".engine-mode").nth(1).click();
      await expect(page.locator(".engine-mode").nth(1)).toHaveAttribute(
        "aria-pressed",
        "true",
      );
      await expect
        .poll(() => canvas.evaluate((el: HTMLCanvasElement) => el.toDataURL()))
        .not.toBe(before);
      await page.locator(".engine-mode").nth(0).click();
      if (width <= 900) {
        await page.locator(".menu-toggle").click();
        await expect(page.locator(".menu-toggle")).toHaveAttribute(
          "aria-expanded",
          "true",
        );
        await page.locator("#mobile-nav a").first().click();
        await expect(page.locator(".menu-toggle")).toHaveAttribute(
          "aria-expanded",
          "false",
        );
      }
      const tabs = page.getByRole("tab");
      await tabs.nth(1).click();
      await expect(tabs.nth(1)).toHaveAttribute("aria-selected", "true");
      await tabs.nth(1).press("ArrowRight");
      await expect(tabs.nth(2)).toBeFocused();
      await expect(tabs.nth(2)).toHaveAttribute("aria-selected", "true");
      await tabs.nth(2).press("Home");
      await expect(tabs.nth(0)).toHaveAttribute("aria-selected", "true");
      for (let index = 0; index < 4; index++) {
        await page.locator(".solutions-node").nth(index).click();
        await expect(
          page.locator(".solutions-node").nth(index),
        ).toHaveAttribute("aria-pressed", "true");
      }
      const missing = await page
        .locator("[aria-controls]")
        .evaluateAll(
          (elements) =>
            elements.filter(
              (el) =>
                !document.getElementById(el.getAttribute("aria-controls")!),
            ).length,
        );
      expect(missing).toBe(0);
      const selected = await page
        .locator(".service-card h3")
        .nth(1)
        .innerText();
      await page.locator(".service-link").nth(1).click();
      await expect(page.locator('select[name="service"]')).toHaveValue(
        selected,
      );
      await page.locator('input[name="name"]').fill("Иван Test");
      await page.locator('input[name="email"]').fill("ivan@example.com");
      await page
        .locator('textarea[name="message"]')
        .fill("We need a custom business workflow and a new web application.");
      const downloading = page.waitForEvent("download");
      await page.locator('button[type="submit"]').click();
      const download = await downloading;
      expect(download.suggestedFilename()).toBe("TASKONFF-project-brief.txt");
      await expect(page.locator(".form-success")).toBeVisible();
      await page.locator(".language").click();
      await expect(page).toHaveURL(
        new RegExp(`/${locale === "ru" ? "en" : "ru"}$`),
      );
      await expect(page.locator("html")).toHaveAttribute(
        "lang",
        locale === "ru" ? "en" : "ru",
      );
      expect(errors).toEqual([]);
    });
  }
test("animation plays, pauses and stops offscreen", async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await page.goto("/en");
  const canvas = page.locator(".engine-canvas");
  const read = () => canvas.evaluate((el: HTMLCanvasElement) => el.toDataURL());
  const pause = page.locator(".engine-pause");
  await expect(pause).toHaveAttribute("aria-pressed", "false");
  const initial = await read();
  await expect.poll(read).not.toBe(initial);
  await pause.click();
  await expect(pause).toHaveAttribute("aria-pressed", "true");
  const frozen = await read();
  await page.waitForTimeout(180);
  expect(await read()).toBe(frozen);
  await pause.click();
  const resumed = await read();
  await expect.poll(read).not.toBe(resumed);
  await page.locator("#contact").scrollIntoViewIfNeeded();
  await page.waitForTimeout(100);
  const offscreen = await read();
  await page.waitForTimeout(180);
  expect(await read()).toBe(offscreen);
  await page.locator(".ribbon-toggle").scrollIntoViewIfNeeded();
  await page.locator(".ribbon-toggle").click();
  await expect(page.locator(".ribbon-toggle")).toHaveAttribute(
    "aria-pressed",
    "true",
  );
});
test("routing and preview SEO", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveURL(/\/ru$/);
  expect((await page.goto("/fr"))?.status()).toBe(404);
  const og = await page.request.get("/en/opengraph-image");
  expect(og.status()).toBe(200);
  expect(og.headers()["content-type"]).toContain("image/png");
  const robots = await page.request.get("/robots.txt");
  expect(await robots.text()).toContain("Disallow: /");
});
