import { test, expect } from "@playwright/test";
import sharp from "sharp";

test("CMS editor publishes RU/EN and binds uploaded logo and image", async ({
  page,
  browser,
}) => {
  test.skip(
    process.env.CMS_E2E_WRITE_TESTS !== "1" ||
      !process.env.CMS_E2E_EMAIL ||
      !process.env.CMS_E2E_PASSWORD,
    "Run against a disposable CMS database with explicit credentials and write-test opt-in.",
  );
  test.setTimeout(90000);
  const base = "http://127.0.0.1:3000";
  const headers = { origin: base };
  await page.goto("/admin/login");
  await page.locator('input[name="email"]').fill(process.env.CMS_E2E_EMAIL!);
  await page
    .locator('input[name="password"]')
    .fill(process.env.CMS_E2E_PASSWORD!);
  await page.locator('button[type="submit"]').click();
  await expect(page).toHaveURL(/\/admin$/);
  const result = await (
    await page.request.get(
      "/api/pages?where[key][equals]=home&limit=1&draft=false&depth=0",
    )
  ).json();
  const home = result.docs[0] as {
    id: number;
    content: unknown;
    heroImage: number | null;
    imageAlt?: string;
  };
  const settings = (await (
    await page.request.get("/api/globals/site-settings?depth=0")
  ).json()) as {
    logo: number | null;
    heroImage: number | null;
    ogImage: number | null;
  };
  const anon = await browser.newContext({ reducedMotion: "reduce" });
  const site = await anon.newPage();
  let mediaId: number | undefined;
  try {
    await page.goto(`/admin/collections/pages/${home.id}`);
    await page
      .locator(".cms-tree-search input")
      .fill("Первая строка заголовка");
    await page.locator(".cms-tree-input textarea").fill("CMS E2E русский");
    await page.locator(".cms-tree-languages [role=tab]").nth(1).click();
    await page.locator(".cms-tree-input textarea").fill("CMS E2E English");
    let saved = page.waitForResponse(
      (r) =>
        r.url().includes(`/api/pages/${home.id}`) &&
        r.request().method() === "PATCH",
    );
    await page.locator("#action-save-draft").click();
    expect((await saved).status()).toBe(200);
    await site.goto(base + "/ru");
    await expect(site.locator("h1")).not.toContainText("CMS E2E русский");
    saved = page.waitForResponse(
      (r) =>
        r.url().includes(`/api/pages/${home.id}`) &&
        r.request().method() === "PATCH",
    );
    await page.locator("#action-save").click();
    expect((await saved).status()).toBe(200);
    await site.goto(base + "/ru");
    await expect(site.locator("h1")).toContainText("CMS E2E русский");
    await site.goto(base + "/en");
    await expect(site.locator("h1")).toContainText("CMS E2E English");
    const image = await sharp({
      create: { width: 32, height: 16, channels: 3, background: "#0059ff" },
    })
      .png()
      .toBuffer();
    const uploaded = await page.request.post("/api/media", {
      headers,
      multipart: {
        file: {
          name: "cms-e2e-fixture.png",
          mimeType: "image/png",
          buffer: image,
        },
        _payload: JSON.stringify({ alt: "CMS E2E fixture" }),
      },
    });
    expect(uploaded.status()).toBe(201);
    const body = await uploaded.json();
    mediaId = (body.doc ?? body).id;
    expect(
      (
        await page.request.post("/api/globals/site-settings", {
          headers,
          data: { logo: mediaId },
        })
      ).status(),
    ).toBe(200);
    expect(
      (
        await page.request.patch(`/api/pages/${home.id}`, {
          headers,
          data: {
            heroImage: mediaId,
            imageAlt: "CMS E2E image",
            _status: "published",
          },
        })
      ).status(),
    ).toBe(200);
    await site.goto(base + "/ru");
    await expect(site.locator(".brand-logo img")).toHaveCount(2);
    await expect(site.locator(".cms-page-media img")).toHaveAttribute(
      "alt",
      "CMS E2E image",
    );
    expect(
      (
        await anon.request.post("/api/media", {
          headers,
          multipart: {
            file: { name: "blocked.png", mimeType: "image/png", buffer: image },
          },
        })
      ).status(),
    ).toBe(403);
  } finally {
    await page.request.patch(`/api/pages/${home.id}`, {
      headers,
      data: {
        content: home.content,
        heroImage: home.heroImage ?? null,
        imageAlt: home.imageAlt ?? "",
        _status: "published",
      },
    });
    await page.request.post("/api/globals/site-settings", {
      headers,
      data: {
        logo: settings.logo ?? null,
        heroImage: settings.heroImage ?? null,
        ogImage: settings.ogImage ?? null,
      },
    });
    if (mediaId)
      await page.request.delete(`/api/media/${mediaId}`, { headers });
    await anon.close();
  }
});
