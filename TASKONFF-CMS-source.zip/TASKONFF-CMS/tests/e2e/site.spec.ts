import { test, expect } from "@playwright/test";
import { pageSlugs } from "../../src/lib/routes";
import { serviceSlugs } from "../../src/content/services";
for (const locale of ["ru", "en"])
  for (const width of [390, 1440]) {
    test(`${locale} internal pages, navigation and SEO at ${width}px`, async ({
      page,
    }) => {
      test.setTimeout(90000);
      await page.setViewportSize({ width, height: 1000 });
      await page.emulateMedia({ reducedMotion: "reduce" });
      const errors: string[] = [];
      page.on("pageerror", (err) => errors.push(err.message));
      const titles = new Set<string>();
      for (const slug of pageSlugs) {
        const response = await page.goto(`/${locale}/${slug}`);
        expect(response?.status()).toBe(200);
        await expect(page.locator("h1")).toHaveCount(1);
        await expect(page.locator("main")).toHaveCount(1);
        await expect(page.locator(".site-header")).toHaveCount(1);
        await expect(page.locator(".site-footer")).toHaveCount(1);
        await expect(page.locator("html")).toHaveAttribute("lang", locale);
        expect(
          await page.evaluate(
            () => document.documentElement.scrollWidth <= innerWidth,
          ),
        ).toBe(true);
        const title = await page.title();
        expect(title).toContain("TASKONFF");
        expect(titles.has(title)).toBe(false);
        titles.add(title);
        if (slug === "privacy" || slug === "terms")
          await expect(page.locator('meta[name="robots"]')).toHaveAttribute(
            "content",
            /noindex/,
          );
      }
      await page.goto(`/${locale}/about`);
      await page.locator(".language").click();
      await expect(page).toHaveURL(
        new RegExp(`/${locale === "ru" ? "en" : "ru"}/about$`),
      );
      if (width === 390) {
        await page.locator(".menu-toggle").click();
        await page
          .locator("#mobile-nav")
          .getByRole("link", {
            name: locale === "ru" ? "Services" : "Услуги",
            exact: false,
          })
          .first()
          .click();
        await expect(page.locator(".menu-toggle")).toHaveAttribute(
          "aria-expanded",
          "false",
        );
        await expect(page).toHaveURL(/\/services$/);
      }
      expect(errors).toEqual([]);
    });
  }
for (const locale of ["ru", "en"])
  test(`${locale} all service detail routes and translated counterpart`, async ({
    page,
  }) => {
    test.setTimeout(90000);
    await page.emulateMedia({ reducedMotion: "reduce" });
    const seen = new Set<string>();
    for (const slug of serviceSlugs) {
      expect((await page.goto(`/${locale}/services/${slug}`))?.status()).toBe(
        200,
      );
      await expect(page.locator("h1")).toHaveCount(1);
      const title = await page.locator("h1").innerText();
      expect(seen.has(title)).toBe(false);
      seen.add(title);
      expect(
        await page.locator('main a[href*="/contact"]').count(),
      ).toBeGreaterThan(0);
    }
    await page.locator(".language").click();
    await expect(page).toHaveURL(
      new RegExp(
        `/${locale === "ru" ? "en" : "ru"}/services/${serviceSlugs.at(-1)}$`,
      ),
    );
    expect(
      (await page.goto(`/${locale}/services/not-a-service`))?.status(),
    ).toBe(404);
  });
test("server rejects invalid briefs, spam and cross-origin requests", async ({
  request,
}) => {
  const data = {
    name: "Test User",
    email: "test@example.com",
    service: "AI",
    message: "A workflow automation project for our business.",
    website: "",
    locale: "en",
  };
  const headers = { origin: "http://127.0.0.1:3000" };
  const good = await request.post("/api/brief", { headers, data });
  expect(good.status()).toBe(200);
  expect(good.headers()["cache-control"]).toBe("no-store");
  expect(await good.text()).toContain(data.message);
  for (const patch of [
    { email: "invalid" },
    { message: "short" },
    { website: "spam" },
  ])
    expect(
      (
        await request.post("/api/brief", {
          headers,
          data: { ...data, ...patch },
        })
      ).status(),
    ).toBe(400);
  expect(
    (
      await request.post("/api/brief", {
        headers: { origin: "https://untrusted.example" },
        data,
      })
    ).status(),
  ).toBe(403);
  const delivery = await request.post("/api/contact", {
    headers,
    data: { ...data, consent: true },
  });
  expect(delivery.status()).toBe(503);
  expect(await delivery.json()).toEqual({ error: "not_configured" });
});
