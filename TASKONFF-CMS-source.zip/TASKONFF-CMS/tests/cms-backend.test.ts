import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, stat } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { randomBytes } from "node:crypto";
import { test } from "node:test";
import {
  guardCMSMutation,
  MAX_CMS_JSON_BYTES,
} from "../src/cms/server/request-guard";

test("CMS REST rejects cross-origin and oversized streamed mutations", async () => {
  const originalURL = process.env.SITE_URL;
  const originalPublicURL = process.env.NEXT_PUBLIC_SITE_URL;
  delete process.env.SITE_URL;
  delete process.env.NEXT_PUBLIC_SITE_URL;
  const request = (
    headers: Record<string, string> = {},
    body: string | ReadableStream<Uint8Array> = "{}",
  ) =>
    new Request("http://0.0.0.0:3000/api/users/login", {
      method: "POST",
      headers: {
        host: "localhost:3000",
        "content-type": "application/json",
        ...headers,
      },
      body,
      ...(typeof body !== "string" ? { duplex: "half" } : {}),
    });
  try {
    const deniedHeaders: Record<string, string>[] = [
      {},
      { authorization: "Bearer invalid" },
      { origin: "https://attacker.example" },
      { origin: "http://localhost:3000", "sec-fetch-site": "cross-site" },
    ];
    for (const headers of deniedHeaders) {
      const response = await guardCMSMutation(request(headers));
      assert.ok(response instanceof Response);
      assert.equal(response.status, 403);
    }
    const accepted = await guardCMSMutation(
      request({ origin: "http://localhost:3000" }, '{"ok":true}'),
    );
    assert.ok(accepted instanceof Request);
    assert.equal(await accepted.text(), '{"ok":true}');
    const tooLarge = await guardCMSMutation(
      request({
        origin: "http://localhost:3000",
        "content-length": String(MAX_CMS_JSON_BYTES + 1),
      }),
    );
    assert.ok(tooLarge instanceof Response);
    assert.equal(tooLarge.status, 413);
    const streamed = new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(new Uint8Array(MAX_CMS_JSON_BYTES));
        controller.enqueue(new Uint8Array(1));
        controller.close();
      },
    });
    const oversizedStream = await guardCMSMutation(
      request({ origin: "http://localhost:3000" }, streamed),
    );
    assert.ok(oversizedStream instanceof Response);
    assert.equal(oversizedStream.status, 413);
    process.env.SITE_URL = "https://taskonff.example";
    const configured = await guardCMSMutation(
      request({ origin: "https://taskonff.example" }),
    );
    assert.ok(configured instanceof Request);
  } finally {
    if (originalURL === undefined) delete process.env.SITE_URL;
    else process.env.SITE_URL = originalURL;
    if (originalPublicURL === undefined)
      delete process.env.NEXT_PUBLIC_SITE_URL;
    else process.env.NEXT_PUBLIC_SITE_URL = originalPublicURL;
  }
});

test(
  "CMS protects bootstrap, drafts, uploads and persisted content",
  { timeout: 90000 },
  async () => {
    const directory = await mkdtemp(
      path.join(os.tmpdir(), "taskonff-cms-test-"),
    );
    const originalDirectory = process.env.CMS_DATA_DIR;
    const originalSecret = process.env.PAYLOAD_SECRET;
    process.env.CMS_DATA_DIR = directory;
    delete process.env.PAYLOAD_SECRET;
    let payload: import("payload").Payload | undefined;
    try {
      const { getCms, seedSiteDefaults } =
        await import("../src/cms/server/payload");
      const { createLocalReq, registerFirstUserOperation } =
        await import("payload");
      const { pageDefinitions } = await import("../src/cms/defaults");
      const { getCMSSecret } = await import("../src/cms/server/storage");
      const { validateImageBuffer } = await import("../src/cms/server/media");
      const sharp = (await import("sharp")).default;
      payload = await getCms();
      const password = randomBytes(24).toString("hex");

      await assert.rejects(
        registerFirstUserOperation({
          collection: payload.collections.users,
          data: { email: "intruder@example.test", password },
          req: await createLocalReq({}, payload),
        }),
        /Public registration is disabled/,
      );
      assert.equal((await payload.count({ collection: "users" })).totalDocs, 0);
      await assert.rejects(
        payload.create({
          collection: "users",
          data: { email: "intruder@example.test", password },
          overrideAccess: false,
        }),
      );

      const admin = await payload.create({
        collection: "users",
        data: { email: "owner@example.test", password },
        context: { bootstrap: true },
        overrideAccess: true,
      });
      await assert.rejects(
        payload.create({
          collection: "users",
          data: { email: "other@example.test", password },
          context: { bootstrap: true },
          overrideAccess: true,
        }),
        /already exists/,
      );
      await assert.rejects(
        payload.delete({
          collection: "users",
          id: admin.id,
          overrideAccess: true,
        }),
        /last administrator/,
      );
      await assert.rejects(
        payload.forgotPassword({
          collection: "users",
          data: { email: admin.email },
        }),
        /Email recovery is not configured/,
      );

      assert.equal(await seedSiteDefaults(payload), pageDefinitions.length);
      assert.equal(await seedSiteDefaults(payload), 0);
      const page = (
        await payload.find({
          collection: "pages",
          where: { key: { equals: "home" } },
          limit: 1,
        })
      ).docs[0];
      assert.ok(page);
      const originalContent = structuredClone(page.content);
      await assert.rejects(
        payload.update({
          collection: "pages",
          id: page.id,
          data: { title: "Unauthorized" },
          overrideAccess: false,
        }),
      );
      await assert.rejects(
        payload.update({
          collection: "pages",
          id: page.id,
          data: { content: { ru: "<script>bad</script>", en: {} } },
        }),
        /structure|Структура/,
      );
      await payload.update({
        collection: "pages",
        id: page.id,
        data: { title: "Saved draft" },
        draft: true,
      });
      const published = await payload.findByID({
        collection: "pages",
        id: page.id,
        draft: false,
        overrideAccess: false,
      });
      assert.notEqual(published.title, "Saved draft");
      assert.deepEqual(published.content, originalContent);
      await payload.create({
        collection: "case-studies",
        draft: true,
        data: {
          slug: "private-draft",
          title: "Draft project",
          summary: "Private draft, not published.",
        },
      });
      assert.equal(
        (
          await payload.find({
            collection: "case-studies",
            overrideAccess: false,
            draft: true,
          })
        ).totalDocs,
        0,
      );

      const image = await sharp({
        create: { width: 2, height: 2, channels: 3, background: "#0047ff" },
      })
        .png()
        .toBuffer();
      await validateImageBuffer(image, "image/png");
      await assert.rejects(
        validateImageBuffer(
          Buffer.from(
            '<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>',
          ),
          "image/png",
        ),
      );
      await assert.rejects(validateImageBuffer(image, "image/svg+xml"));
      await assert.rejects(
        validateImageBuffer(Buffer.alloc(8 * 1024 * 1024 + 1), "image/png"),
      );
      const secretPath = path.join(directory, ".payload-secret");
      if (process.platform !== "win32")
        assert.equal((await stat(secretPath)).mode & 0o777, 0o600);
      assert.equal(getCMSSecret(), (await readFile(secretPath, "utf8")).trim());
      if (process.platform !== "win32")
        assert.equal((await stat(directory)).mode & 0o777, 0o700);
    } finally {
      await payload?.destroy();
      if (originalDirectory === undefined) delete process.env.CMS_DATA_DIR;
      else process.env.CMS_DATA_DIR = originalDirectory;
      if (originalSecret === undefined) delete process.env.PAYLOAD_SECRET;
      else process.env.PAYLOAD_SECRET = originalSecret;
      await rm(directory, { recursive: true, force: true });
    }
  },
);
