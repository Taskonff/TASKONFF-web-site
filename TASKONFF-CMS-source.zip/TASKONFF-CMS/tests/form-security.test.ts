import { test } from "node:test";
import assert from "node:assert/strict";
import {
  readFormRequest,
  checkFormRate,
  FormRequestError,
} from "../src/lib/form-security";
function request(body: string, headers: Record<string, string> = {}) {
  return new Request("https://site.example/api/brief", {
    method: "POST",
    headers: {
      origin: "https://site.example",
      "content-type": "application/json",
      ...headers,
    },
    body,
  });
}
test("accepts only same-origin JSON with a bounded body", async () => {
  assert.deepEqual(await readFormRequest(request('{"ok":true}')), { ok: true });
  for (const [body, headers, status] of [
    ["{}", { origin: "https://other.example" }, 403],
    ["{}", { "content-type": "text/plain" }, 415],
    ["x".repeat(16385), {}, 413],
    ["bad json", {}, 400],
  ] as [string, Record<string, string>, number][]) {
    await assert.rejects(
      readFormRequest(request(body, headers)),
      (err: unknown) =>
        err instanceof FormRequestError && err.status === status,
    );
  }
});
test("server-side rate window expires and untrusted forwarded headers do not bypass it", () => {
  const req = request("{}", { "x-forwarded-for": "fake" });
  for (let i = 0; i < 60; i++) checkFormRate(req, "unit", 100);
  assert.throws(() => checkFormRate(req, "unit", 101), FormRequestError);
  checkFormRate(req, "unit", 60101);
});

test("uses browser Host when Next request URL contains the bind hostname", async () => {
  const saved = process.env.SITE_URL;
  delete process.env.SITE_URL;
  try {
    const req = new Request("http://0.0.0.0:3000/api/brief", {
      method: "POST",
      headers: {
        host: "127.0.0.1:3000",
        origin: "http://127.0.0.1:3000",
        "content-type": "application/json",
      },
      body: '{"ok":true}',
    });
    assert.deepEqual(await readFormRequest(req), { ok: true });
  } finally {
    if (saved === undefined) delete process.env.SITE_URL;
    else process.env.SITE_URL = saved;
  }
});
