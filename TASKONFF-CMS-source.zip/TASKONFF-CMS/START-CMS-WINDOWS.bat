@echo off
cd /d "%~dp0"
node scripts/check-node.mjs
if errorlevel 1 goto failed
if exist node_modules goto setup
call npm ci
if errorlevel 1 goto failed
:setup
call npm run admin:setup
if errorlevel 1 goto failed
call npm run build
if errorlevel 1 goto failed
call npm start
goto done
:failed
echo Setup did not finish. Read the message above. / Proverte soobshchenie vyshe.
:done
pause
