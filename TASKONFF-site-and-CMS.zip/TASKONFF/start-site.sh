#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")/site"
printf '%s\n' 'Site: http://localhost:3000/ru' 'Admin: http://localhost:3000/admin'
exec sh start-cms.sh
