@echo off
echo Site: http://localhost:3000/ru
echo Admin: http://localhost:3000/admin
call "%~dp0site\START-CMS-WINDOWS.bat"
