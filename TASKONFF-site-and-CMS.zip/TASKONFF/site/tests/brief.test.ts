import { test } from "node:test";
import assert from "node:assert/strict";
import { createBrief, inquirySchema } from "../src/lib/brief";
const valid = {
  name: "Test User",
  email: "user@example.com",
  service: "AI",
  message: "We need to automate our document workflow.",
  website: "",
};
test("brief contains supplied details and preserves Unicode", () => {
  const result = createBrief({ ...valid, name: "Иван" });
  assert.ok(result.includes("Иван"));
  assert.ok(result.includes(valid.message));
  assert.ok(result.includes(valid.email));
});

test("includes and normalizes optional contact details in the project brief", () => {
  const fields = { phone: "  +1 (202) 555-0147  ", telegram: " tester_202 " };
  const data = inquirySchema.parse({ ...valid, ...fields, consent: true });
  assert.equal(data.phone, "+1 (202) 555-0147");
  assert.equal(data.telegram, "@tester_202");
  assert.match(
    createBrief({ ...valid, ...fields }),
    /^Phone: \+1 \(202\) 555-0147$/m,
  );
  const russian = createBrief({ ...valid, ...fields, locale: "ru" });
  assert.match(russian, /^Телефон: \+1 \(202\) 555-0147$/m);
  assert.match(russian, /^Telegram: @tester_202$/m);
  assert.equal(
    createBrief({ ...valid, phone: " ", telegram: "" }),
    createBrief(valid),
  );
});

test("rejects invalid email, short brief and honeypot", () => {
  for (const patch of [
    { email: "invalid" },
    { message: "short" },
    { website: "spam" },
    { name: " " },
    { message: "x".repeat(5001) },
    { phone: "123" },
    { phone: "1234567\n1234567" },
    { telegram: "@invalid/handle" },
    { telegram: "@short".repeat(8) },
  ])
    assert.throws(() => createBrief({ ...valid, ...patch }));
});
