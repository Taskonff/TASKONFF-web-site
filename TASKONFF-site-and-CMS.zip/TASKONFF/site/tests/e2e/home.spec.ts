import { test, expect } from "@playwright/test";
for (const locale of ["ru", "en"])
  for (const width of [360, 390, 768, 1440]) {
    test(`${locale} homepage at ${width}px`, async ({ page }) => {
      await page.setViewportSize({ width, height: 1000 });
      await page.emulateMedia({ reducedMotion: "reduce" });
      const errors: string[] = [];
      page.on("pageerror", (error) => errors.push(error.message));
      const response = await page.goto(`/${locale}`);
      expect(response?.status()).toBe(200);
      await expect(page.locator("html")).toHaveAttribute("lang", locale);
      await expect(page.locator("h1")).toHaveCount(1);
      await expect
        .poll(() =>
          page.evaluate(
            () => document.documentElement.scrollWidth <= innerWidth,
          ),
        )
        .toBe(true);
      for (const link of await page.locator('a[href^="#"]').all()) {
        const id = (await link.getAttribute("href"))!.slice(1);
        expect(
          await page.evaluate((id) => !!document.getElementById(id), id),
        ).toBe(true);
      }
      const canvas = page.locator(".engine-canvas");
      const pause = page.locator(".engine-pause");
      await expect(pause).toHaveAttribute("aria-pressed", "true");
      const before = await canvas.evaluate((el: HTMLCanvasElement) =>
        el.toDataURL(),
      );
      await page.locator(".engine-mode").nth(1).click();
      await expect(page.locator(".engine-mode").nth(1)).toHaveAttribute(
        "aria-pressed",
        "true",
      );
      await expect
        .poll(() => canvas.evaluate((el: HTMLCanvasElement) => el.toDataURL()))
        .not.toBe(before);
      await page.locator(".engine-mode").nth(0).click();
      if (width <= 900) {
        await page.locator(".menu-toggle").click();
        await expect(page.locator(".menu-toggle")).toHaveAttribute(
          "aria-expanded",
          "true",
        );
        await page.locator("#mobile-nav a").first().click();
        await expect(page.locator(".menu-toggle")).toHaveAttribute(
          "aria-expanded",
          "false",
        );
      }
      if (width === 390) {
        expect(
          await page.locator("main").evaluate((main) => main.scrollHeight),
        ).toBeLessThanOrEqual(8_000);
      }
      if (await page.locator(".products-preview").count()) {
        await expect(
          page.locator(".home-first-screen + .products-preview"),
        ).toHaveCount(1);
      }
      expect(
        await pause.evaluate((button) => button.getBoundingClientRect().height),
      ).toBeGreaterThanOrEqual(44);
      const missing = await page
        .locator("[aria-controls]")
        .evaluateAll(
          (elements) =>
            elements.filter(
              (el) =>
                !document.getElementById(el.getAttribute("aria-controls")!),
            ).length,
        );
      expect(missing).toBe(0);
      const selected = await page
        .locator(".service-card h3")
        .nth(1)
        .innerText();
      await page.locator(".service-link").nth(1).click();
      await expect(page.locator('select[name="service"]')).toHaveValue(
        selected,
      );
      const form = page.locator(".brief-form");
      const send = form.locator(
        'button[type="submit"]:not([value="download"])',
      );
      await send.click();
      await expect(form.locator('input[name="email"]')).toHaveAttribute(
        "aria-invalid",
        "true",
      );
      await expect(form.locator('input[name="consent"]')).toHaveAttribute(
        "aria-invalid",
        "true",
      );
      await form.locator('input[name="name"]').fill("Иван Test");
      await form.locator('input[name="email"]').fill("ivan@example.com");
      await form
        .locator('textarea[name="message"]')
        .fill("We need a custom business workflow and a new web application.");
      const downloading = page.waitForEvent("download");
      await form.locator('button[value="download"]').click();
      const download = await downloading;
      expect(download.suggestedFilename()).toBe("TASKONFF-project-brief.txt");
      await expect(form.locator(".form-success")).toBeVisible();
      await page.route("**/api/contact", async (route) => {
        expect(route.request().postDataJSON()).toMatchObject({
          source: "home",
          consent: true,
          locale,
        });
        await route.fulfill({ status: 201, json: { accepted: true } });
      });
      await form.locator('input[name="consent"]').check();
      await send.click();
      await expect(
        page.locator(".inquiry-confirmation .form-success"),
      ).toBeVisible();
      await page.locator(".language").click();
      await expect(page).toHaveURL(
        new RegExp(`/${locale === "ru" ? "en" : "ru"}$`),
      );
      await expect(page.locator("html")).toHaveAttribute(
        "lang",
        locale === "ru" ? "en" : "ru",
      );
      expect(errors).toEqual([]);
    });
  }
test("animation plays, pauses and stops offscreen", async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await page.goto("/en");
  const ribbon = page.locator(".capability-strip");
  await expect
    .poll(() =>
      ribbon.evaluate((strip) =>
        Math.abs(strip.getBoundingClientRect().bottom - innerHeight),
      ),
    )
    .toBeLessThanOrEqual(1);
  const ribbonPause = ribbon.locator(".ribbon-toggle");
  const track = ribbon.locator(".capability-track");
  await ribbonPause.click();
  await expect(ribbonPause).toHaveAttribute("aria-pressed", "true");
  await expect(track).toHaveCSS("animation-play-state", "paused");
  await ribbonPause.click();
  await expect(track).toHaveCSS("animation-play-state", "running");
  const canvas = page.locator(".engine-canvas");
  const read = () => canvas.evaluate((el: HTMLCanvasElement) => el.toDataURL());
  const pause = page.locator(".engine-pause");
  await expect(pause).toHaveAttribute("aria-pressed", "false");
  const initial = await read();
  await expect.poll(read).not.toBe(initial);
  await pause.click();
  await expect(pause).toHaveAttribute("aria-pressed", "true");
  const frozen = await read();
  await page.waitForTimeout(180);
  expect(await read()).toBe(frozen);
  await pause.click();
  const resumed = await read();
  await expect.poll(read).not.toBe(resumed);
  await page.locator("#contact").scrollIntoViewIfNeeded();
  await page.waitForTimeout(100);
  const offscreen = await read();
  await page.waitForTimeout(180);
  expect(await read()).toBe(offscreen);
});
test("routing and preview SEO", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveURL(/\/ru$/);
  expect((await page.goto("/fr"))?.status()).toBe(404);
  const og = await page.request.get("/en/opengraph-image");
  expect(og.status()).toBe(200);
  expect(og.headers()["content-type"]).toContain("image/png");
  const robots = await page.request.get("/robots.txt");
  expect(await robots.text()).toContain("Disallow: /");
});
