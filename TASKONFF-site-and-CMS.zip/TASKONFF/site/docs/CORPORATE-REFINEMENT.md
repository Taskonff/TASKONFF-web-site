# Corporate presentation — 19 November 2026

The TASKONFF site now presents its existing engineering capabilities through a more structured corporate layout. The navy, electric blue, teal and white palette remains unchanged. Existing brand artwork continues to be rendered without filters or geometry changes.

## Composition

- The homepage has a business-focused three-line headline, two calls to action and direct links into three service areas. A layered architectural Canvas illustration replaces the earlier torus. BUILD, AUTOMATE and GROW change its arrangement; pause, reduced motion, pointer input and offscreen suspension are preserved.
- Desktop Services navigation opens a four-group directory of all ten service pages. The service link itself still opens the catalog. Escape, keyboard focus, outside clicks, navigation and the responsive breakpoint close the directory appropriately. Mobile navigation includes the complete service directory.
- Four homepage cards now expose all ten actual service routes. Selecting the discussion action still fills the project brief with the corresponding area of interest.
- The homepage industry spotlight has six keyboard-accessible scenarios. Texts are drawn from the Industries CMS document and continue to describe possible applications rather than completed projects.
- Company principles and the process are drawn from existing editable content. Published case previews appear only when real case-study documents exist in CMS.
- The project brief appears on a white form surface inside a navy section. Its validation, local download behavior and delivery limitations remain explicit. Footer navigation includes all service pages and shows contact channels only when configured.
- Shared internal pages receive larger typography, clearer surfaces and responsive corporate grids through a separate stylesheet.

## Content and architecture

No CMS keys, field types, template structure, route identity, uploads or database schema changed. Existing published values are preserved. Updated default copy applies when no content has been published; owners can edit existing homepage headline fields in `/admin` as before.

New blocks reuse `getSiteData()` or `useSiteContent()`. New visual rules are scoped to the homepage, shared public page primitives, header and footer, with no admin CSS changes. No new dependencies or external image services are required. Original logo upload remains available in Site settings.

The supplied reference addresses were `https://dataru.ru/` and `https://i-teco.ru/`. Both were blocked by the environment's destination policy during implementation (proxy CONNECT 403). Their current pages and artwork were not inspected or copied. This revision applies an independent enterprise IT presentation to TASKONFF; a direct reference comparison requires allowing those destinations in the environment.

## Verification

- Production build, ESLint, TypeScript and the seven unit/backend checks pass.
- Local Chromium captures verify both locales at 320, 390, 768, 1024 and 1440 pixels, with ten service links and no horizontal document overflow or uncaught JavaScript errors.
- `tests/e2e/corporate.spec.ts` adds service-directory navigation, keyboard/focus behavior and all six industry scenarios for RU/EN at mobile and desktop sizes.
- All **22 browser tests passed, none skipped**, including public routes, animation controls, validated brief download and the CMS draft/publish/media flow on a separate disposable database.

No website deployment or GitHub archive replacement is part of this revision. Previously delivered ZIP files remain historical versions until a new export is requested.
