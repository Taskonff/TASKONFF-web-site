import { sql, type MigrateUpArgs } from "@payloadcms/db-sqlite";
import {
  BVOICE_PRODUCT_SLUG,
  launchProductCopy,
  MEDVOICE_PRODUCT_SLUG,
} from "@/content/products";

type LaunchSlug = keyof typeof launchProductCopy;

async function createProduct(
  { payload, req }: MigrateUpArgs,
  slug: LaunchSlug,
) {
  const product = await payload.create({
    collection: "products",
    data: { slug, ...launchProductCopy[slug].ru, _status: "published" },
    locale: "ru",
    overrideAccess: true,
    req,
  });
  return product.id;
}

async function fillDefaultCopy(
  { db }: MigrateUpArgs,
  id: number,
  slug: LaunchSlug,
) {
  const oldTitle = slug === MEDVOICE_PRODUCT_SLUG ? "MedVoice" : "";
  for (const locale of ["ru", "en"] as const) {
    const { title, summary } = launchProductCopy[slug][locale];
    // Fill missing localizations, including after a retry. Keep editorial text.
    await db.run(sql`
      INSERT INTO products_locales (title, summary, _locale, _parent_id)
      VALUES (${title}, ${summary}, ${locale}, ${id})
      ON CONFLICT (_locale, _parent_id) DO UPDATE SET
        title = CASE WHEN trim(coalesce(title, '')) IN ('', ${oldTitle}) THEN excluded.title ELSE title END,
        summary = CASE WHEN trim(coalesce(summary, '')) = '' THEN excluded.summary ELSE summary END
    `);
    await db.run(sql`
      INSERT INTO _products_v_locales (version_title, version_summary, _locale, _parent_id)
      SELECT ${title}, ${summary}, ${locale}, id
      FROM _products_v WHERE parent_id = ${id} AND latest = 1
      ON CONFLICT (_locale, _parent_id) DO UPDATE SET
        version_title = CASE WHEN trim(coalesce(version_title, '')) IN ('', ${oldTitle}) THEN excluded.version_title ELSE version_title END,
        version_summary = CASE WHEN trim(coalesce(version_summary, '')) = '' THEN excluded.version_summary ELSE version_summary END
    `);
  }
}

async function archiveProduct({ payload, req }: MigrateUpArgs, slug: string) {
  const {
    docs: [product],
  } = await payload.find({
    collection: "products",
    where: { slug: { equals: slug } },
    limit: 1,
    depth: 0,
    draft: false,
    overrideAccess: true,
    req,
  });
  if (product?._status === "published") {
    await payload.update({
      collection: "products",
      id: product.id,
      data: { _status: "draft" },
      unpublishAllLocales: true,
      overrideAccess: true,
      req,
    });
  }
}

export async function up(args: MigrateUpArgs): Promise<void> {
  const { db } = args;
  await archiveProduct(args, "arckpi");

  const {
    rows: [canonical],
  } = await db.run(
    sql`SELECT id FROM products WHERE slug = ${MEDVOICE_PRODUCT_SLUG}`,
  );
  const {
    rows: [legacy],
  } = await db.run(sql`SELECT id FROM products WHERE slug = 'medvoice'`);

  let medvoiceId: number;
  if (canonical) {
    medvoiceId = Number(canonical.id);
    await archiveProduct(args, "medvoice");
  } else if (legacy) {
    medvoiceId = Number(legacy.id);
    // Retain the ID, localizations, visibility, media and version history.
    await db.run(
      sql`UPDATE products SET slug = ${MEDVOICE_PRODUCT_SLUG} WHERE id = ${medvoiceId}`,
    );
  } else {
    medvoiceId = await createProduct(args, MEDVOICE_PRODUCT_SLUG);
  }
  await db.run(sql`
    UPDATE _products_v
    SET version_slug = ${MEDVOICE_PRODUCT_SLUG}
    WHERE parent_id = ${medvoiceId} AND version_slug = 'medvoice'
  `);
  await fillDefaultCopy(args, medvoiceId, MEDVOICE_PRODUCT_SLUG);

  const {
    rows: [bvoice],
  } = await db.run(
    sql`SELECT id FROM products WHERE slug = ${BVOICE_PRODUCT_SLUG}`,
  );
  const bvoiceId = bvoice
    ? Number(bvoice.id)
    : await createProduct(args, BVOICE_PRODUCT_SLUG);
  await fillDefaultCopy(args, bvoiceId, BVOICE_PRODUCT_SLUG);
}

export async function down(): Promise<void> {
  // This editorial migration changes no tables. Keep the products, edited
  // versions and publication decisions if a server deployment rolls back.
}
