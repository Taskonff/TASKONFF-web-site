import {
  sql,
  type MigrateDownArgs,
  type MigrateUpArgs,
} from "@payloadcms/db-sqlite";

export async function up({ db }: MigrateUpArgs): Promise<void> {
  const columns = await db.all<{ name: string }>(
    sql`PRAGMA table_info(site_settings)`,
  );
  if (!columns.some(({ name }) => name === "instagram"))
    await db.run(sql`ALTER TABLE site_settings ADD COLUMN instagram text`);
  if (!columns.some(({ name }) => name === "linkedin"))
    await db.run(sql`ALTER TABLE site_settings ADD COLUMN linkedin text`);
}

export async function down({ db }: MigrateDownArgs): Promise<void> {
  const columns = await db.all<{ name: string }>(
    sql`PRAGMA table_info(site_settings)`,
  );
  if (columns.some(({ name }) => name === "linkedin"))
    await db.run(sql`ALTER TABLE site_settings DROP COLUMN linkedin`);
  if (columns.some(({ name }) => name === "instagram"))
    await db.run(sql`ALTER TABLE site_settings DROP COLUMN instagram`);
}
