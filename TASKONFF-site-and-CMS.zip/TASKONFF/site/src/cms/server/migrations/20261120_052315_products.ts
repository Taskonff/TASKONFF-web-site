import { MigrateUpArgs, MigrateDownArgs, sql } from "@payloadcms/db-sqlite";

export async function up({ db }: MigrateUpArgs): Promise<void> {
  await db.run(sql`CREATE TABLE \`products\` (
  	\`id\` integer PRIMARY KEY NOT NULL,
  	\`slug\` text,
  	\`image_id\` integer,
  	\`website\` text,
  	\`updated_at\` text DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')) NOT NULL,
  	\`created_at\` text DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')) NOT NULL,
  	\`_status\` text DEFAULT 'draft',
  	FOREIGN KEY (\`image_id\`) REFERENCES \`media\`(\`id\`) ON UPDATE no action ON DELETE set null
  );
  `);
  await db.run(
    sql`CREATE UNIQUE INDEX \`products_slug_idx\` ON \`products\` (\`slug\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`products_image_idx\` ON \`products\` (\`image_id\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`products_updated_at_idx\` ON \`products\` (\`updated_at\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`products_created_at_idx\` ON \`products\` (\`created_at\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`products__status_idx\` ON \`products\` (\`_status\`);`,
  );
  await db.run(sql`CREATE TABLE \`products_locales\` (
  	\`title\` text,
  	\`summary\` text,
  	\`body\` text,
  	\`id\` integer PRIMARY KEY NOT NULL,
  	\`_locale\` text NOT NULL,
  	\`_parent_id\` integer NOT NULL,
  	FOREIGN KEY (\`_parent_id\`) REFERENCES \`products\`(\`id\`) ON UPDATE no action ON DELETE cascade
  );
  `);
  await db.run(
    sql`CREATE UNIQUE INDEX \`products_locales_locale_parent_id_unique\` ON \`products_locales\` (\`_locale\`,\`_parent_id\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`products_locales_parent_id_idx\` ON \`products_locales\` (\`_parent_id\`);`,
  );
  await db.run(sql`CREATE TABLE \`_products_v\` (
  	\`id\` integer PRIMARY KEY NOT NULL,
  	\`parent_id\` integer,
  	\`version_slug\` text,
  	\`version_image_id\` integer,
  	\`version_website\` text,
  	\`version_updated_at\` text,
  	\`version_created_at\` text,
  	\`version__status\` text DEFAULT 'draft',
  	\`created_at\` text DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')) NOT NULL,
  	\`updated_at\` text DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')) NOT NULL,
  	\`snapshot\` integer,
  	\`published_locale\` text,
  	\`latest\` integer,
  	FOREIGN KEY (\`parent_id\`) REFERENCES \`products\`(\`id\`) ON UPDATE no action ON DELETE set null,
  	FOREIGN KEY (\`version_image_id\`) REFERENCES \`media\`(\`id\`) ON UPDATE no action ON DELETE set null
  );
  `);
  await db.run(
    sql`CREATE INDEX \`_products_v_parent_idx\` ON \`_products_v\` (\`parent_id\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`_products_v_version_version_slug_idx\` ON \`_products_v\` (\`version_slug\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`_products_v_version_version_image_idx\` ON \`_products_v\` (\`version_image_id\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`_products_v_version_version_updated_at_idx\` ON \`_products_v\` (\`version_updated_at\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`_products_v_version_version_created_at_idx\` ON \`_products_v\` (\`version_created_at\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`_products_v_version_version__status_idx\` ON \`_products_v\` (\`version__status\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`_products_v_created_at_idx\` ON \`_products_v\` (\`created_at\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`_products_v_updated_at_idx\` ON \`_products_v\` (\`updated_at\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`_products_v_snapshot_idx\` ON \`_products_v\` (\`snapshot\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`_products_v_published_locale_idx\` ON \`_products_v\` (\`published_locale\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`_products_v_latest_idx\` ON \`_products_v\` (\`latest\`);`,
  );
  await db.run(sql`CREATE TABLE \`_products_v_locales\` (
  	\`version_title\` text,
  	\`version_summary\` text,
  	\`version_body\` text,
  	\`id\` integer PRIMARY KEY NOT NULL,
  	\`_locale\` text NOT NULL,
  	\`_parent_id\` integer NOT NULL,
  	FOREIGN KEY (\`_parent_id\`) REFERENCES \`_products_v\`(\`id\`) ON UPDATE no action ON DELETE cascade
  );
  `);
  await db.run(
    sql`CREATE UNIQUE INDEX \`_products_v_locales_locale_parent_id_unique\` ON \`_products_v_locales\` (\`_locale\`,\`_parent_id\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`_products_v_locales_parent_id_idx\` ON \`_products_v_locales\` (\`_parent_id\`);`,
  );
  await db.run(
    sql`ALTER TABLE \`payload_locked_documents_rels\` ADD \`products_id\` integer REFERENCES \`products\`(\`id\`) ON DELETE cascade;`,
  );
  await db.run(
    sql`CREATE INDEX \`payload_locked_documents_rels_products_id_idx\` ON \`payload_locked_documents_rels\` (\`products_id\`);`,
  );

  // The names are confirmed. Keep descriptions, imagery and links for the owner to add.
  const initialProducts = [
    { slug: "medvoice", title: "MedVoice" },
    { slug: "arckpi", title: "ArcKPI" },
  ];
  for (const { slug, title } of initialProducts) {
    await db.run(
      sql`INSERT INTO products (slug, _status) VALUES (${slug}, 'published');`,
    );
    await db.run(sql`INSERT INTO products_locales (title, _locale, _parent_id)
      SELECT ${title}, 'ru', id FROM products WHERE slug = ${slug}
      UNION ALL
      SELECT ${title}, 'en', id FROM products WHERE slug = ${slug};`);
    await db.run(sql`INSERT INTO _products_v (parent_id, version_slug, version_updated_at, version_created_at, version__status, latest)
      SELECT id, slug, updated_at, created_at, _status, 1 FROM products WHERE slug = ${slug};`);
    await db.run(sql`INSERT INTO _products_v_locales (version_title, _locale, _parent_id)
      SELECT ${title}, 'ru', id FROM _products_v WHERE version_slug = ${slug}
      UNION ALL
      SELECT ${title}, 'en', id FROM _products_v WHERE version_slug = ${slug};`);
  }
}

export async function down({ db }: MigrateDownArgs): Promise<void> {
  await db.run(
    sql`DELETE FROM payload_locked_documents_rels WHERE products_id IS NOT NULL;`,
  );
  await db.run(sql`DROP INDEX payload_locked_documents_rels_products_id_idx;`);
  await db.run(
    sql`ALTER TABLE payload_locked_documents_rels DROP COLUMN products_id;`,
  );
  await db.run(sql`DROP TABLE \`products_locales\`;`);
  await db.run(sql`DROP TABLE \`_products_v_locales\`;`);
  await db.run(sql`DROP TABLE \`_products_v\`;`);
  await db.run(sql`DROP TABLE \`products\`;`);
}
