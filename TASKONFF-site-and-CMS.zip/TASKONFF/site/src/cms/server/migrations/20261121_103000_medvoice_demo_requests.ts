import {
  sql,
  type MigrateDownArgs,
  type MigrateUpArgs,
} from "@payloadcms/db-sqlite";

export async function up({ db }: MigrateUpArgs): Promise<void> {
  await db.run(sql`ALTER TABLE product_requests ADD COLUMN organization text`);
  await db.run(sql`ALTER TABLE product_requests ADD COLUMN role text`);
  await db.run(sql`ALTER TABLE product_requests ADD COLUMN phone text`);
  await db.run(sql`ALTER TABLE product_requests ADD COLUMN branches numeric`);
}

export async function down({ db }: MigrateDownArgs): Promise<void> {
  await db.run(sql`ALTER TABLE product_requests DROP COLUMN branches`);
  await db.run(sql`ALTER TABLE product_requests DROP COLUMN phone`);
  await db.run(sql`ALTER TABLE product_requests DROP COLUMN role`);
  await db.run(sql`ALTER TABLE product_requests DROP COLUMN organization`);
}
