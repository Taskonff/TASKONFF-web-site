import { MigrateUpArgs, MigrateDownArgs, sql } from "@payloadcms/db-sqlite";

export async function up({ db }: MigrateUpArgs): Promise<void> {
  await db.run(sql`CREATE TABLE \`project_inquiries\` (
  	\`id\` integer PRIMARY KEY NOT NULL,
  	\`status\` text DEFAULT 'new' NOT NULL,
  	\`name\` text NOT NULL,
  	\`email\` text NOT NULL,
  	\`service\` text,
  	\`message\` text NOT NULL,
  	\`source\` text NOT NULL,
  	\`locale\` text NOT NULL,
  	\`consent\` integer DEFAULT false NOT NULL,
  	\`updated_at\` text DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')) NOT NULL,
  	\`created_at\` text DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')) NOT NULL
  );
  `);
  await db.run(
    sql`CREATE INDEX \`project_inquiries_updated_at_idx\` ON \`project_inquiries\` (\`updated_at\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`project_inquiries_created_at_idx\` ON \`project_inquiries\` (\`created_at\`);`,
  );
  await db.run(sql`CREATE TABLE \`site_settings_locales\` (
  	\`city\` text,
  	\`response_hours\` text,
  	\`response_time\` text,
  	\`legal_name\` text,
  	\`id\` integer PRIMARY KEY NOT NULL,
  	\`_locale\` text NOT NULL,
  	\`_parent_id\` integer NOT NULL,
  	FOREIGN KEY (\`_parent_id\`) REFERENCES \`site_settings\`(\`id\`) ON UPDATE no action ON DELETE cascade
  );
  `);
  await db.run(
    sql`CREATE UNIQUE INDEX \`site_settings_locales_locale_parent_id_unique\` ON \`site_settings_locales\` (\`_locale\`,\`_parent_id\`);`,
  );
  await db.run(
    sql`CREATE INDEX \`site_settings_locales_parent_id_idx\` ON \`site_settings_locales\` (\`_parent_id\`);`,
  );
  await db.run(
    sql`ALTER TABLE \`payload_locked_documents_rels\` ADD \`project_inquiries_id\` integer REFERENCES project_inquiries(id) ON DELETE cascade;`,
  );
  await db.run(
    sql`CREATE INDEX \`payload_locked_documents_rels_project_inquiries_id_idx\` ON \`payload_locked_documents_rels\` (\`project_inquiries_id\`);`,
  );
  await db.run(sql`ALTER TABLE \`site_settings\` ADD \`telegram\` text;`);
  await db.run(
    sql`ALTER TABLE \`site_settings\` ADD \`legal_registration\` text;`,
  );
  await db.run(sql`ALTER TABLE \`site_settings\` ADD \`privacy_email\` text;`);
}

export async function down({ db }: MigrateDownArgs): Promise<void> {
  await db.run(
    sql`DROP INDEX \`payload_locked_documents_rels_project_inquiries_id_idx\`;`,
  );
  await db.run(
    sql`ALTER TABLE \`payload_locked_documents_rels\` DROP COLUMN \`project_inquiries_id\`;`,
  );
  await db.run(sql`DROP TABLE \`project_inquiries\`;`);
  await db.run(sql`DROP TABLE \`site_settings_locales\`;`);
  await db.run(sql`ALTER TABLE \`site_settings\` DROP COLUMN \`telegram\`;`);
  await db.run(
    sql`ALTER TABLE \`site_settings\` DROP COLUMN \`legal_registration\`;`,
  );
  await db.run(
    sql`ALTER TABLE \`site_settings\` DROP COLUMN \`privacy_email\`;`,
  );
}
