import {
  sql,
  type MigrateDownArgs,
  type MigrateUpArgs,
} from "@payloadcms/db-sqlite";

export async function up({ db }: MigrateUpArgs): Promise<void> {
  const columns = await db.all<{ name: string }>(
    sql`PRAGMA table_info(project_inquiries)`,
  );
  if (!columns.some(({ name }) => name === "phone"))
    await db.run(sql`ALTER TABLE project_inquiries ADD COLUMN phone text`);
  if (!columns.some(({ name }) => name === "telegram"))
    await db.run(sql`ALTER TABLE project_inquiries ADD COLUMN telegram text`);
}

export async function down({ db }: MigrateDownArgs): Promise<void> {
  const columns = await db.all<{ name: string }>(
    sql`PRAGMA table_info(project_inquiries)`,
  );
  if (columns.some(({ name }) => name === "telegram"))
    await db.run(sql`ALTER TABLE project_inquiries DROP COLUMN telegram`);
  if (columns.some(({ name }) => name === "phone"))
    await db.run(sql`ALTER TABLE project_inquiries DROP COLUMN phone`);
}
