import type { CollectionConfig, Field } from "payload";
import { authenticated } from "./access";

const readOnly = { readOnly: true } as const;
const preventFieldUpdate = { update: () => false };
type ReceivedField = Extract<
  Field,
  { type: "text" | "email" | "textarea" | "select" | "checkbox" }
>;
const receivedFields: ReceivedField[] = [
  {
    name: "name",
    label: { ru: "Имя", en: "Name" },
    type: "text",
    required: true,
    minLength: 2,
    maxLength: 100,
  },
  { name: "email", label: "Email", type: "email", required: true },
  {
    name: "phone",
    label: { ru: "Телефон", en: "Phone" },
    type: "text",
    maxLength: 40,
  },
  {
    name: "telegram",
    label: "Telegram",
    type: "text",
    maxLength: 33,
  },
  {
    name: "service",
    label: { ru: "Направление", en: "Area of interest" },
    type: "text",
    maxLength: 120,
  },
  {
    name: "message",
    label: { ru: "Описание проекта", en: "Project description" },
    type: "textarea",
    required: true,
    minLength: 20,
    maxLength: 5000,
  },
  {
    name: "source",
    label: { ru: "Страница формы", en: "Form page" },
    type: "select",
    required: true,
    options: [
      { label: { ru: "Главная", en: "Home" }, value: "home" },
      { label: { ru: "Контакты", en: "Contact" }, value: "contact" },
    ],
  },
  {
    name: "locale",
    label: { ru: "Язык формы", en: "Form language" },
    type: "select",
    required: true,
    options: [
      { label: "Русский", value: "ru" },
      { label: "English", value: "en" },
    ],
  },
  {
    name: "consent",
    label: {
      ru: "Согласие на обработку данных",
      en: "Data processing consent",
    },
    type: "checkbox",
    required: true,
  },
];

export const projectInquiries: CollectionConfig = {
  slug: "project-inquiries",
  labels: {
    singular: { ru: "Заявка на проект", en: "Project inquiry" },
    plural: { ru: "Заявки на проекты", en: "Project inquiries" },
  },
  admin: {
    useAsTitle: "name",
    group: { ru: "Управление", en: "Administration" },
    defaultColumns: ["name", "email", "service", "status", "createdAt"],
  },
  access: {
    create: () => false,
    read: authenticated,
    update: authenticated,
    delete: authenticated,
    readVersions: () => false,
  },
  fields: [
    {
      name: "status",
      label: { ru: "Статус", en: "Status" },
      type: "select",
      required: true,
      defaultValue: "new",
      options: [
        { label: { ru: "Новая", en: "New" }, value: "new" },
        { label: { ru: "Обработана", en: "Reviewed" }, value: "reviewed" },
      ],
    },
    ...receivedFields.map((field) => ({
      ...field,
      admin: readOnly,
      access: preventFieldUpdate,
    })),
  ],
};
