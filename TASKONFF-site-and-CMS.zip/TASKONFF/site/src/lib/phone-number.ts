import { z } from "zod";

export const phoneNumberSchema = z
  .string()
  .trim()
  .max(40)
  .regex(/^\+?[\d(). -]+$/)
  .refine((value) => /^\d{7,15}$/.test(value.replace(/\D/g, "")));
