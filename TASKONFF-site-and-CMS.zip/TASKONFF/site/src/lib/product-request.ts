import { z } from "zod";
import { phoneNumberSchema } from "./phone-number";

export const productRequestKinds = ["trial", "connection"] as const;
export type ProductRequestKind = (typeof productRequestKinds)[number] | "demo";

const requestFields = z.object({
  productSlug: z
    .string()
    .max(100)
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().pipe(z.email().max(254)),
  message: z.string().trim().max(2000).default(""),
  consent: z.literal(true),
  website: z.literal(""),
  locale: z.enum(["ru", "en"]),
});

export const productRequestSchema = z.discriminatedUnion("kind", [
  requestFields.extend({ kind: z.enum(productRequestKinds) }),
  requestFields.extend({
    kind: z.literal("demo"),
    organization: z.string().trim().min(2).max(180),
    role: z.string().trim().min(2).max(100),
    phone: phoneNumberSchema,
    branches: z.number().int().min(1).max(10_000).optional(),
  }),
]);

const downloadLabels = {
  ru: {
    title: "TASKONFF — ЗАПРОС ПО ПРОДУКТУ",
    product: "Продукт",
    request: "Запрос",
    name: "Имя",
    organization: "Организация",
    role: "Должность",
    phone: "Рабочий телефон",
    branches: "Количество филиалов",
    trial: "Тестовый период",
    connection: "Подключение",
    demo: "Демонстрация",
  },
  en: {
    title: "TASKONFF — PRODUCT REQUEST",
    product: "Product",
    request: "Request",
    name: "Name",
    organization: "Organisation",
    role: "Role",
    phone: "Work phone",
    branches: "Number of branches",
    trial: "Trial",
    connection: "Connection",
    demo: "Demo",
  },
};

export function createProductRequest(input: unknown, productTitle: string) {
  const request = productRequestSchema.parse(input);
  const labels = downloadLabels[request.locale];
  const lines = [
    labels.title,
    "",
    `${labels.product}: ${productTitle}`,
    `${labels.request}: ${labels[request.kind]}`,
    `${labels.name}: ${request.name}`,
    `Email: ${request.email}`,
  ];
  if (request.kind === "demo") {
    lines.push(
      `${labels.organization}: ${request.organization}`,
      `${labels.role}: ${request.role}`,
      `${labels.phone}: ${request.phone}`,
    );
    if (request.branches !== undefined) {
      lines.push(`${labels.branches}: ${request.branches}`);
    }
  }
  return [...lines, "", request.message, ""].join("\n");
}
