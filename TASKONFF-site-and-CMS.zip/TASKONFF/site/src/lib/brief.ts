import { z } from "zod";
import { phoneNumberSchema } from "./phone-number";

function optionalContact(format: z.ZodType<string, string>) {
  return z
    .string()
    .trim()
    .pipe(z.union([z.literal(""), format]))
    .transform((value) => value || undefined)
    .optional();
}

const telegramHandleSchema = z
  .string()
  .regex(/^@?[a-z0-9_]{5,32}$/i)
  .transform((value) => (value.startsWith("@") ? value : `@${value}`));

export const briefSchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().pipe(z.email().max(254)),
  phone: optionalContact(phoneNumberSchema),
  telegram: optionalContact(telegramHandleSchema),
  service: z.string().trim().max(120),
  message: z.string().trim().min(20).max(5000),
  website: z.string().max(0),
  locale: z.enum(["ru", "en"]).default("en"),
});
export const inquirySchema = briefSchema.extend({
  consent: z.literal(true),
  source: z.enum(["home", "contact"]).default("contact"),
});

export function createBrief(input: unknown) {
  const data = briefSchema.parse(input);
  const labels =
    data.locale === "ru"
      ? {
          title: "БРИФ ПРОЕКТА",
          name: "Имя",
          phone: "Телефон",
          service: "Направление",
        }
      : {
          title: "PROJECT BRIEF",
          name: "Name",
          phone: "Phone",
          service: "Area",
        };
  const lines = [
    `TASKONFF — ${labels.title}`,
    "",
    `${labels.name}: ${data.name}`,
    `Email: ${data.email}`,
  ];
  if (data.phone) lines.push(`${labels.phone}: ${data.phone}`);
  if (data.telegram) lines.push(`Telegram: ${data.telegram}`);
  return [
    ...lines,
    `${labels.service}: ${data.service}`,
    "",
    data.message,
    "",
  ].join("\n");
}
