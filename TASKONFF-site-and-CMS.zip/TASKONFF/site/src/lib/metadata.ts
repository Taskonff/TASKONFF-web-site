import type { Metadata } from "next";
import { pageDescription, pageTitle } from "@/content/seo";
import type { Locale } from "@/content/site";
import { localizedPath } from "@/lib/routes";

export function getSiteOrigin(): string | undefined {
  const configured = process.env.SITE_URL;
  if (!configured || process.env.CMS_STATIC_EXPORT === "1") return;
  try {
    const url = new URL(configured);
    if (
      url.protocol === "https:" &&
      !url.username &&
      !url.password &&
      url.pathname === "/" &&
      !url.search &&
      !url.hash
    )
      return url.origin;
  } catch {
    return;
  }
}

export function pageMetadata(
  locale: Locale,
  slug: string,
  title: string,
  summary: string,
): Metadata {
  const origin = getSiteOrigin();
  const path = localizedPath(locale, slug);
  const description = pageDescription(locale, slug, summary);
  const label = pageTitle(locale, slug, title);
  const image = origin
    ? {
        url: `${origin}/${locale}/opengraph-image`,
        width: 1200,
        height: 630,
        alt: "TASKONFF — BUILD • AUTOMATE • GROW",
      }
    : undefined;

  return {
    title: label,
    description,
    alternates: origin
      ? {
          canonical: `${origin}${path}`,
          languages: {
            ru: `${origin}${localizedPath("ru", slug)}`,
            en: `${origin}${localizedPath("en", slug)}`,
            "x-default": `${origin}${localizedPath("ru", slug)}`,
          },
        }
      : undefined,
    robots: origin
      ? { index: true, follow: true }
      : { index: false, follow: false },
    openGraph: {
      title: label,
      description,
      type: "website",
      locale: locale === "ru" ? "ru_RU" : "en_US",
      alternateLocale: locale === "ru" ? "en_US" : "ru_RU",
      siteName: "TASKONFF",
      url: origin ? `${origin}${path}` : undefined,
      images: image ? [image] : undefined,
    },
    twitter: {
      card: "summary_large_image",
      title: label,
      description,
      images: image ? [image] : undefined,
    },
  };
}
