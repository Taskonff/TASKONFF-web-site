/** Only public-facing HTTPS links belong in product cards. */
export function productWebsiteUrl(value: unknown): string | undefined {
  if (typeof value !== "string" || /\p{Cc}/u.test(value)) return;
  const input = value.trim();
  if (!/^https:\/\/[^/]/i.test(input) || /[\s\\]/u.test(input)) return;
  try {
    const url = new URL(input);
    if (
      url.protocol === "https:" &&
      url.hostname &&
      !url.username &&
      !url.password
    ) {
      return url.href;
    }
  } catch {
    return;
  }
}
