import type { SiteSettings } from "@/cms/defaults";

export function contactEmailHref(email?: string) {
  // Exclude mailto URI delimiters, line breaks and parameters.
  return email && /^[^\s@<>?&%:/#]+@[^\s@<>?&%:/#]+\.[a-z\d-]+$/i.test(email)
    ? `mailto:${email}`
    : undefined;
}

const instagramReservedPaths = new Set([
  "about",
  "accounts",
  "api",
  "developer",
  "direct",
  "explore",
  "legal",
  "p",
  "privacy",
  "reel",
  "reels",
  "stories",
  "terms",
  "web",
]);

export function contactSocialHref(
  network: "instagram" | "linkedin",
  value?: string,
): string | undefined {
  const address = value?.trim();
  if (!address || !/^https:\/\/[^\s\\]+$/i.test(address)) return;

  try {
    const url = new URL(address);
    if (url.username || url.password || url.port) return;

    if (network === "instagram") {
      if (!/^(?:www\.)?instagram\.com$/.test(url.hostname)) return;
      const profile = url.pathname.match(
        /^\/([a-z\d_][a-z\d_.]{0,29})\/?$/i,
      )?.[1];
      if (profile && !instagramReservedPaths.has(profile.toLowerCase()))
        return `https://www.instagram.com/${profile}/`;
      return;
    }

    if (!/^(?:(?:www|[a-z]{2})\.)?linkedin\.com$/.test(url.hostname)) return;
    const profile = decodeURIComponent(url.pathname).match(
      /^\/(company|in|school|showcase)\/([\p{L}\p{M}\p{N}_.-]+)\/?$/u,
    );
    if (profile)
      return `https://www.linkedin.com/${profile[1]}/${encodeURIComponent(profile[2])}/`;
  } catch {
    // Invalid URLs and malformed escape sequences have no public link.
  }
}

export function hasContactDetails(settings: SiteSettings, locale: "ru" | "en") {
  return Boolean(
    settings.contactEmail ||
    settings.contactPhone ||
    settings.telegram ||
    contactSocialHref("instagram", settings.instagram) ||
    contactSocialHref("linkedin", settings.linkedin) ||
    settings.city?.[locale] ||
    settings.address ||
    settings.responseHours?.[locale],
  );
}
