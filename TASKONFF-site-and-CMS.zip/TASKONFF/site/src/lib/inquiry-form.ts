import type { Locale } from "@/content/site";

export const inquiryFormCopy = {
  ru: {
    name: "Укажите имя длиной от 2 до 100 символов.",
    email: "Укажите корректный адрес электронной почты.",
    phone: "Укажите номер телефона из 7–15 цифр.",
    phoneLabel: "Номер телефона",
    telegram: "Укажите имя пользователя Telegram, например @username.",
    optional: "Необязательно",
    service: "Выберите направление из списка.",
    projectMessage: "Опишите задачу (от 20 до 5000 символов).",
    productMessage: "Сократите комментарий до 2000 символов.",
    consent: "Подтвердите согласие на обработку данных.",
    consentLabel: "Согласен на обработку данных для ответа на заявку.",
    privacy: "Обработка данных",
    fallback: "Скачать копию заявки",
    contact: "Другие способы связи",
    accepted: "Заявка принята",
    reply: "Ответим на указанную электронную почту.",
    another: "Отправить ещё одну заявку",
    downloaded: "Копия заявки сохранена на вашем устройстве.",
  },
  en: {
    name: "Enter a name between 2 and 100 characters.",
    email: "Enter a valid email address.",
    phone: "Enter a phone number with 7 to 15 digits.",
    phoneLabel: "Phone number",
    telegram: "Enter a Telegram username, such as @username.",
    optional: "Optional",
    service: "Select an area from the list.",
    projectMessage: "Describe the project in 20 to 5,000 characters.",
    productMessage: "Keep the message to 2,000 characters.",
    consent: "Confirm your consent to data processing.",
    consentLabel: "I agree to data processing so TASKONFF can respond.",
    privacy: "Data processing",
    fallback: "Download a copy",
    contact: "Other ways to contact us",
    accepted: "Request received",
    reply: "We’ll reply to the email address you entered.",
    another: "Send another request",
    downloaded: "A copy has been saved to your device.",
  },
} satisfies Record<Locale, Record<string, string>>;

export function downloadFormText(text: string, filename: string) {
  const url = URL.createObjectURL(
    new Blob([text], { type: "text/plain;charset=utf-8" }),
  );
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function focusInvalidField(form: HTMLFormElement, field?: PropertyKey) {
  if (typeof field !== "string") return;
  const input = form.elements.namedItem(field);
  if (input instanceof HTMLElement && input.tabIndex >= 0) {
    requestAnimationFrame(() => input.focus());
  }
}
