import type { MetadataRoute } from "next";
import { getSiteOrigin } from "@/lib/metadata";

export const dynamic = "force-dynamic";

export default function robots(): MetadataRoute.Robots {
  const base = getSiteOrigin();
  return {
    rules: {
      userAgent: "*",
      allow: base ? ["/", "/api/media/file/"] : undefined,
      disallow: base ? ["/api/", "/admin"] : "/",
    },
    sitemap: base ? `${base}/sitemap.xml` : undefined,
  };
}
