import { getCms } from "@/cms/server/payload";
import { isComingSoonProduct, MEDVOICE_PRODUCT_SLUG } from "@/content/products";
import {
  checkFormRate,
  formError,
  FormRequestError,
  readFormRequest,
} from "@/lib/form-security";
import { productRequestSchema } from "@/lib/product-request";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const raw = await readFormRequest(request);
    checkFormRate(request, "product-requests");
    const parsed = productRequestSchema.safeParse(raw);
    if (!parsed.success) throw new FormRequestError(400, "invalid");
    const input = parsed.data;
    const { kind, name, email, message, consent, locale } = input;
    const productSlug =
      input.productSlug === "medvoice"
        ? MEDVOICE_PRODUCT_SLUG
        : input.productSlug;
    if (isComingSoonProduct(productSlug)) {
      throw new FormRequestError(404, "product_not_found");
    }
    if (kind === "demo" && productSlug !== MEDVOICE_PRODUCT_SLUG) {
      throw new FormRequestError(400, "invalid");
    }
    const payload = await getCms();
    const {
      docs: [product],
    } = await payload.find({
      collection: "products",
      overrideAccess: false,
      draft: false,
      locale,
      depth: 0,
      limit: 1,
      select: { title: true },
      where: {
        slug: { equals: productSlug },
        _status: { equals: "published" },
      },
    });
    if (!product) throw new FormRequestError(404, "product_not_found");
    const productTitle = product.title || productSlug;

    await payload.create({
      collection: "product-requests",
      // Only this bounded, validated route creates requests for anonymous visitors.
      overrideAccess: true,
      data: {
        status: "new",
        productSlug,
        productTitle,
        kind,
        name,
        email,
        message,
        consent,
        locale,
        ...(input.kind === "demo"
          ? {
              organization: input.organization,
              role: input.role,
              phone: input.phone,
              branches: input.branches,
            }
          : {}),
      },
    });
    return Response.json(
      { accepted: true },
      { status: 201, headers: { "Cache-Control": "no-store" } },
    );
  } catch (error) {
    return formError(
      error instanceof FormRequestError
        ? error
        : new FormRequestError(503, "unavailable"),
    );
  }
}
