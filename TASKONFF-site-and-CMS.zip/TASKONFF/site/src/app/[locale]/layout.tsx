import { getSiteData } from "@/cms/site-data";
import { SiteContentProvider } from "@/cms/site-context";
export const dynamic = "force-dynamic";
import { Header } from "@/components/home/header";
import { Footer } from "@/components/site/footer";
import { ScrollProgress } from "@/components/home/experience";
import { getBrandLogo } from "@/lib/brand";
import "../internal.css";
import "@fontsource-variable/manrope";
import "../globals.css";
import "@/components/site/corporate-pages.css";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { isLocale } from "@/content/site";
import { getSiteOrigin } from "@/lib/metadata";
export function generateStaticParams() {
  return [{ locale: "ru" }, { locale: "en" }];
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const data = await getSiteData();
  const origin = getSiteOrigin();
  const logo = data.settings.logoUrl ?? getBrandLogo();
  return {
    metadataBase: origin ? new URL(origin) : undefined,
    icons: logo ? { icon: logo } : undefined,
  };
}
export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const data = await getSiteData();
  const logo = data.settings.logoUrl ?? getBrandLogo();
  return (
    <html lang={locale}>
      <body>
        <SiteContentProvider value={data}>
          <ScrollProgress />
          <Header locale={locale} copy={data.site[locale]} logo={logo} />
          {children}
          <Footer locale={locale} logo={logo} />
        </SiteContentProvider>
      </body>
    </html>
  );
}
