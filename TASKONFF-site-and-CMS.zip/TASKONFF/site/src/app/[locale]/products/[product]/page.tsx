import { notFound, permanentRedirect, redirect } from "next/navigation";
import { getSiteData } from "@/cms/site-data";
import { ProductDetailPage } from "@/components/pages/products-pages";
import {
  isComingSoonProduct,
  legacyProductTarget,
  productText,
} from "@/content/products";
import { isLocale } from "@/content/site";
import { pageMetadata } from "@/lib/metadata";
import { localizedPath } from "@/lib/routes";

type Props = { params: Promise<{ locale: string; product: string }> };

export async function generateStaticParams() {
  if (process.env.CMS_STATIC_EXPORT !== "1") return [];
  const { products } = await getSiteData();
  return products
    .filter(({ slug }) => !isComingSoonProduct(slug))
    .map(({ slug }) => ({ product: slug }));
}

async function getPublishedProduct(params: Props["params"]) {
  const { locale, product: slug } = await params;
  if (!isLocale(locale)) notFound();
  const { products } = await getSiteData();
  const target = legacyProductTarget(slug, products);
  if (target !== undefined)
    permanentRedirect(
      localizedPath(locale, target ? `products/${target}` : "products"),
    );
  const product = products.find((entry) => entry.slug === slug);
  if (!product) notFound();
  if (isComingSoonProduct(product.slug))
    redirect(`${localizedPath(locale, "products")}#product-${product.slug}`);
  return { locale, product };
}

export async function generateMetadata({ params }: Props) {
  const { locale, product } = await getPublishedProduct(params);
  const copy = productText(product, locale);
  return pageMetadata(
    locale,
    `products/${product.slug}`,
    copy.title,
    copy.summary ||
      (locale === "ru"
        ? `${copy.title} — продукт собственной разработки TASKONFF. Изучите возможности и обсудите варианты тестирования или подключения.`
        : `${copy.title} is a product developed by TASKONFF. Learn about its features and discuss trial access or onboarding for your team.`),
  );
}

export default async function Page({ params }: Props) {
  const { locale, product } = await getPublishedProduct(params);
  return (
    <ProductDetailPage
      locale={locale}
      product={product}
      offline={process.env.CMS_STATIC_EXPORT === "1"}
    />
  );
}
