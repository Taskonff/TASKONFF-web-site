import { notFound } from "next/navigation";
import { ProductsPage, productsCopy } from "@/components/pages/products-pages";
import { isLocale } from "@/content/site";
import { pageMetadata } from "@/lib/metadata";
import { productNavLabel } from "@/lib/routes";

type Props = { params: Promise<{ locale: string }> };

export async function generateMetadata({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return pageMetadata(
    locale,
    "products",
    productNavLabel[locale],
    productsCopy[locale].description,
  );
}

export default async function Page({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return <ProductsPage locale={locale} />;
}
