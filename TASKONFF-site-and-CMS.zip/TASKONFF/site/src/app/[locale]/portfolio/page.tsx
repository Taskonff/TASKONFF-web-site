import { notFound, redirect } from "next/navigation";
import { isLocale } from "@/content/site";
import { getSiteData } from "@/cms/site-data";
import { pageMetadata } from "@/lib/metadata";
import { PortfolioPage } from "@/components/pages/trust-pages";
type Props = { params: Promise<{ locale: string }> };
export async function generateMetadata({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const snapshot = await getSiteData();
  if (snapshot.cases.length === 0) redirect(`/${locale}/products`);
  const copy = snapshot.trust[locale].portfolio;
  return pageMetadata(locale, "portfolio", copy.label, copy.description);
}
export default async function Page({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const snapshot = await getSiteData();
  if (snapshot.cases.length === 0) redirect(`/${locale}/products`);
  return <PortfolioPage locale={locale} />;
}
