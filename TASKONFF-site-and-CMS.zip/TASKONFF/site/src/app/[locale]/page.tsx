import { notFound } from "next/navigation";
import { content, isLocale } from "@/content/site";
import { Home } from "@/components/home/home";
import { getSiteData } from "@/cms/site-data";
import { StructuredData } from "@/components/site/structured-data";
import { getBrandLogo } from "@/lib/brand";
import { getSiteOrigin, pageMetadata } from "@/lib/metadata";

type Props = { params: Promise<{ locale: string }> };

export async function generateMetadata({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return pageMetadata(
    locale,
    "",
    locale === "ru"
      ? "Разработка ПО и цифровые решения"
      : "Software Engineering & Digital Solutions",
    "",
  );
}

export default async function Page({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const origin = getSiteOrigin();
  if (!origin) return <Home locale={locale} copy={content[locale]} />;

  const { settings } = await getSiteData();
  const logo = settings.logoUrl ?? getBrandLogo();
  return (
    <>
      <StructuredData
        data={{
          "@type": "Organization",
          "@id": `${origin}/#organization`,
          name: settings.brandName || "TASKONFF",
          url: origin,
          logo: logo ? new URL(logo, origin).href : undefined,
          email: settings.contactEmail,
          telephone: settings.contactPhone,
        }}
      />
      <Home locale={locale} copy={content[locale]} />
    </>
  );
}
