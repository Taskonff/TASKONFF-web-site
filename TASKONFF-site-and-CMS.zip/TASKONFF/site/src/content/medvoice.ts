export const medVoiceCopy = {
  ru: {
    type: "голосовой ИИ-агент для клиник",
    catalog: "Продукты",
    eyebrow: "Решение TASKONFF",
    status: "Готовим пилотные внедрения",
    intro:
      "В пилоте подключаем телефонию и расписание клиники, чтобы проверить запись на приём, подтверждение визитов и передачу сложных звонков администратору.",
    demo: "Запросить демонстрацию",
    explore: "Как это работает",
    impactAction: "Посмотреть эффект в цифрах",
    consoleCaption: "Схема обработки вызова",
    consoleTitle: "Звонок в клинику",
    consoleSteps: [
      "Телефония клиники",
      "Уточнение запроса",
      "Запись или передача сотруднику",
    ],
    overviewTitle: "Доступная запись даже в часы пик",
    overview:
      "MedVoice AI помогает регистратуре с организационными звонками. Целевые сценарии включают ответы о графике и филиалах, поиск времени в расписании, перенос визитов и перевод сложных обращений сотруднику.",
    overviewNote:
      "В пилоте проверим работу 24/7 для типовых обращений, обработку параллельных вызовов и поддержку русского и узбекского языков. Возможности зависят от телефонии и настройки.",
    capabilityTitle: "Что автоматизируем в пилоте",
    capabilities: [
      [
        "Входящие звонки",
        "Уточнение запроса, ответы по базе клиники и регистрация обращений в часы пик или вне графика.",
      ],
      [
        "Запись и перенос визитов",
        "Поиск доступного времени в подключённом расписании, подтверждение записи, перенос или отмена.",
      ],
      [
        "Исходящие напоминания",
        "Напоминания о визитах и фиксация ответа пациента по согласованным правилам связи.",
      ],
      [
        "Передача сотруднику",
        "Соединение с регистратурой по заданному маршруту или запрос обратного звонка.",
      ],
      [
        "Телефония и системы клиники",
        "Проверка совместимости SIP, виртуальной АТС, расписания, CRM и медицинской информационной системы.",
      ],
      [
        "Аналитика и филиалы",
        "Отчёты по звонкам, записям и переводам, с раздельной статистикой филиалов при соответствующей настройке.",
      ],
    ],
    flowTitle: "От звонка до результата",
    flowIntro:
      "Выберите сценарий, чтобы увидеть маршрут вызова и результат для регистратуры.",
    flowLabel: "Демонстрационный сценарий",
    scenarios: [
      {
        key: "booking",
        label: "Запись",
        steps: [
          ["Пациент звонит", "Вызов с номера клиники поступает в MedVoice AI."],
          [
            "Агент уточняет запрос",
            "Сценарий определяет профиль специалиста и подходящее время в подключённом расписании.",
          ],
          [
            "Пациент подтверждает",
            "При доступной интеграции запись фиксируется вместе с итогом обращения.",
          ],
        ],
      },
      {
        key: "reminder",
        label: "Напоминание",
        steps: [
          [
            "Приближается визит",
            "Подключённое расписание передаёт событие по согласованному правилу.",
          ],
          [
            "Агент напоминает",
            "Пациент подтверждает визит или сообщает, что нужно перенести запись.",
          ],
          [
            "Клиника видит ответ",
            "Итог сохраняется. Если нужна помощь, обращение получает администратор.",
          ],
        ],
      },
      {
        key: "handoff",
        label: "Передача сотруднику",
        steps: [
          [
            "Поступает особый запрос",
            "Организационный сценарий определяет, когда для обращения нужен человек.",
          ],
          [
            "Телефония соединяет",
            "Вызов передаётся по согласованному маршруту или формируется запрос обратного звонка.",
          ],
          [
            "Итог попадает в отчёт",
            "При подключении отчётности руководитель видит причину передачи и результат.",
          ],
        ],
      },
    ],
    audienceTitle: "Для каких клиник",
    audiences: [
      [
        "Частные клиники и медцентры",
        "Помогите пациентам записаться на приём и уточнить организационные вопросы без длинной очереди.",
      ],
      [
        "Диагностические центры и лаборатории",
        "Согласуйте время исследований, напоминания и переносы через подключённое расписание.",
      ],
      [
        "Сети клиник",
        "Настройте маршруты по филиалам и сравнивайте нагрузку регистратур.",
      ],
    ],
    audienceNote:
      "Руководитель сможет оценивать доступность линии, разговорные минуты, записи, подтверждения и причины передачи звонков. Показатели согласуем под ваши источники данных.",
    implementationTitle: "Как подключаем",
    implementationSteps: [
      [
        "Анализируем",
        "Уточняем, какие звонки поступают, как устроена телефония и где ведётся расписание.",
      ],
      [
        "Настраиваем",
        "Согласуем правила обработки обращений, роли, интеграции и маршрут передачи человеку.",
      ],
      [
        "Проверяем",
        "Проводим тестовые звонки, проверяем записи и сопоставляем показатели с исходным периодом.",
      ],
      [
        "Подводим итоги",
        "Определяем, какие сценарии готовы к запуску и какой формат обслуживания нужен клинике.",
      ],
    ],
    securityTitle: "Данные и безопасность",
    security:
      "В проекте предусматриваем разграничение прав доступа, изоляцию данных организаций, журналирование и правила хранения записей. Перед работой с реальными обращениями согласуем размещение данных, доступ сотрудников, обработку персональных данных и условия подключения внешних сервисов.",
    faqTitle: "Частые вопросы",
    faq: [
      [
        "Как распределяется работа между ИИ и сотрудниками?",
        "Агент рассчитан на типовые организационные обращения. Запросы, требующие участия человека, передаются клинике по согласованному маршруту.",
      ],
      [
        "Можно ли записать пациента по телефону?",
        "Сценарий записи проверяем с подключённым расписанием, доступными слотами и правилами подтверждения.",
      ],
      [
        "Какие языки поддерживаются?",
        "Русский и узбекский входят в целевой функционал. Качество распознавания и сценарии на каждом языке оцениваем во время пилота.",
      ],
      [
        "Можно ли сохранить номер клиники?",
        "Проверим это по условиям вашего оператора связи и настройкам АТС.",
      ],
      [
        "Подходит ли MedVoice AI сети филиалов?",
        "В пилоте можно согласовать отдельные маршруты и отчётность по филиалам.",
      ],
      [
        "Можете подключить нашу МИС?",
        "Возможность интеграции и состав работ определим после проверки API и инфраструктуры.",
      ],
      [
        "Поможет ли агент с медицинскими вопросами?",
        "MedVoice AI предназначен для организационных звонков. Клинические вопросы передаются сотрудникам клиники.",
      ],
      [
        "Сколько стоит подключение?",
        "MedVoice AI подключается по фиксированному тарифу ежемесячной подписки. Описание тарифов и условия внедрения предоставим по запросу.",
      ],
    ],
    demoTitle: "Посмотрите сценарий для вашей клиники",
    demoDescription:
      "Расскажите о филиалах, текущей телефонии и задачах регистратуры. Подготовим демонстрацию по вашим сценариям и обсудим формат пилота.",
    website: "Сайт продукта",
  },
  en: {
    type: "AI voice agent for clinics",
    catalog: "Products",
    eyebrow: "A TASKONFF solution",
    status: "Preparing pilot deployments",
    intro:
      "During the pilot, we connect your clinic’s phone system and schedule to test appointment booking, visit confirmation and handoffs to staff.",
    demo: "Request a demo",
    explore: "See how it works",
    impactAction: "See the impact in numbers",
    consoleCaption: "Call routing diagram",
    consoleTitle: "Call to the clinic",
    consoleSteps: [
      "Clinic telephony",
      "Understand the request",
      "Book or transfer to staff",
    ],
    overviewTitle: "Appointment access during busy hours",
    overview:
      "MedVoice AI helps front desk teams handle routine calls. Target workflows include answering questions about hours and locations, finding available slots, rescheduling visits and routing complex requests to staff.",
    overviewNote:
      "The pilot will test 24/7 handling of routine calls, concurrent calls and support for Russian and Uzbek. Availability depends on telephony and configuration.",
    capabilityTitle: "What the pilot can automate",
    capabilities: [
      [
        "Incoming calls",
        "Clarify the request, answer approved clinic questions and log inquiries during peak or after-hours periods.",
      ],
      [
        "Bookings and rescheduling",
        "Find available time in the connected schedule, confirm appointments, reschedule or cancel.",
      ],
      [
        "Outbound reminders",
        "Remind patients about visits and record responses under the agreed contact rules.",
      ],
      [
        "Staff handoff",
        "Transfer a call to the clinic team using configured routes or log a request for a callback.",
      ],
      [
        "Clinic systems and telephony",
        "Evaluate compatibility with SIP, cloud PBX, schedules, CRM and medical information systems.",
      ],
      [
        "Analytics and branches",
        "Report on calls, bookings and transfers, with branch-level reporting when configured.",
      ],
    ],
    flowTitle: "From a call to an outcome",
    flowIntro:
      "Choose a scenario to see how the call is routed and what the clinic team receives.",
    flowLabel: "Illustrative workflow",
    scenarios: [
      {
        key: "booking",
        label: "Booking",
        steps: [
          [
            "The patient calls",
            "The clinic line routes the incoming call to MedVoice AI.",
          ],
          [
            "The agent clarifies the request",
            "The workflow checks the type of specialist and available time in the connected schedule.",
          ],
          [
            "The patient confirms",
            "If the integration supports it, the appointment and call outcome are recorded.",
          ],
        ],
      },
      {
        key: "reminder",
        label: "Reminder",
        steps: [
          [
            "The visit is coming up",
            "The connected schedule sends an event under the agreed rules.",
          ],
          [
            "The agent sends a reminder",
            "The patient confirms the visit or requests a new time.",
          ],
          [
            "The clinic gets the response",
            "The outcome is recorded. An administrator receives requests that need help.",
          ],
        ],
      },
      {
        key: "handoff",
        label: "Staff handoff",
        steps: [
          [
            "A special request comes in",
            "The routing scenario identifies calls that need a person.",
          ],
          [
            "The call is connected",
            "Telephony routes the call to staff or creates a callback request.",
          ],
          [
            "The outcome is recorded",
            "With reporting enabled, managers can review why calls were transferred and what happened next.",
          ],
        ],
      },
    ],
    audienceTitle: "Who it’s for",
    audiences: [
      [
        "Private clinics and medical centres",
        "Help patients book visits and get practical information when lines are busy.",
      ],
      [
        "Diagnostic centres and laboratories",
        "Coordinate test appointments, visit reminders and rescheduling through a connected schedule.",
      ],
      [
        "Clinic networks",
        "Set up branch-specific call routing and compare the load on front desk teams.",
      ],
    ],
    audienceNote:
      "Managers can evaluate line availability, call minutes, bookings, confirmations and transfer reasons. We define the metrics around your data sources.",
    implementationTitle: "How we connect the pilot",
    implementationSteps: [
      [
        "Assess",
        "Review your call patterns, phone system and the schedule your team uses.",
      ],
      [
        "Configure",
        "Agree on call rules, roles, connections and when staff should take over.",
      ],
      [
        "Test",
        "Run test calls, check appointments and compare metrics with the baseline period.",
      ],
      [
        "Review",
        "Identify workflows ready to launch and agree on the support your clinic needs.",
      ],
    ],
    securityTitle: "Data and security",
    security:
      "The design calls for role-based access, isolation between clinics, activity logs and retention rules. Before handling live calls, we agree on data location, staff access, personal data processing and any use of external services.",
    faqTitle: "Frequently asked questions",
    faq: [
      [
        "How is work shared between the agent and staff?",
        "The agent is designed to automate routine administrative calls. Requests requiring a person follow the clinic’s agreed handoff path.",
      ],
      [
        "Can a patient book by phone?",
        "We validate booking with the connected schedule, available time slots and the clinic’s confirmation rules.",
      ],
      [
        "Which languages are supported?",
        "Russian and Uzbek are planned. The pilot evaluates speech recognition and workflows for each language.",
      ],
      [
        "Can we keep the clinic’s existing number?",
        "We check the options with your operator and phone system during technical assessment.",
      ],
      [
        "Does MedVoice AI suit a multi-branch clinic?",
        "The pilot can include branch-specific routes and reporting.",
      ],
      [
        "Can you connect our medical information system?",
        "The scope of integration depends on API access and the clinic’s technical infrastructure.",
      ],
      [
        "Can the agent help with medical questions?",
        "MedVoice AI is for administrative calls. Clinical questions are routed to the clinic team.",
      ],
      [
        "How much does setup cost?",
        "MedVoice AI is available on fixed monthly subscription plans. Plan details and implementation terms are available on request.",
      ],
    ],
    demoTitle: "See a workflow for your clinic",
    demoDescription:
      "Tell us about your locations, phone setup and front desk workload. We’ll prepare a demo around your workflows and discuss what a pilot could cover.",
    website: "Product website",
  },
} as const;
