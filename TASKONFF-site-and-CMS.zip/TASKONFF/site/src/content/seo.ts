import type { Locale } from "./site";
import { BVOICE_PRODUCT_SLUG, MEDVOICE_PRODUCT_SLUG } from "./products";

const descriptions: Record<string, Record<Locale, string>> = {
  "": {
    ru: "TASKONFF разрабатывает веб-сервисы и корпоративное ПО, внедряет ИИ и автоматизирует бизнес-процессы от проектирования до запуска.",
    en: "TASKONFF builds web applications and enterprise software, implements AI, and automates business workflows from planning through launch.",
  },
  about: {
    ru: "Узнайте, как TASKONFF соединяет разработку продуктов, интеграцию систем и автоматизацию, чтобы помочь командам выстроить цифровые процессы.",
    en: "Learn how TASKONFF combines software engineering, system integration and automation to help teams build and improve their digital workflows.",
  },
  services: {
    ru: "Услуги TASKONFF включают заказную разработку, веб- и мобильные приложения, ИИ, автоматизацию, CRM, ERP, интеграции, облако и дизайн.",
    en: "Explore TASKONFF services for business, from custom software and AI automation to web and mobile apps, CRM, ERP, integrations, cloud and design.",
  },
  products: {
    ru: "Продукты TASKONFF для голосовых коммуникаций. Познакомьтесь с MedVoice AI для клиник и BVoice, будущим ИИ-колл-центром для финансовых сервисов.",
    en: "Discover TASKONFF voice products: MedVoice AI for clinic calls and bookings, and BVoice, an upcoming AI contact center for financial services.",
  },
  industries: {
    ru: "Изучите отраслевые сценарии для клиентских сервисов, аналитики, автоматизации операций и интеграции внутренних систем вашей компании.",
    en: "Explore industry scenarios for your team, from customer-facing services and analytics to workflow automation and back-office system integrations.",
  },
  portfolio: {
    ru: "В опубликованных кейсах TASKONFF описаны бизнес-задачи, технические решения и результаты разработки или внедрения цифровых систем.",
    en: "Explore published TASKONFF cases to understand the business challenges, software decisions and outcomes behind selected development projects.",
  },
  technologies: {
    ru: "TASKONFF проектирует интерфейсы, бизнес-логику, интеграции и инфраструктуру с учётом требований к данным и сопровождению системы.",
    en: "See how TASKONFF designs digital systems across interfaces, business logic, data, integrations and infrastructure, with maintenance in mind.",
  },
  process: {
    ru: "Узнайте, как TASKONFF ведёт разработку от исследования задачи и согласования требований до проверки результатов, запуска и развития системы.",
    en: "See how TASKONFF runs software projects, from discovery and agreeing on requirements through implementation, acceptance, launch and iteration.",
  },
  contact: {
    ru: "Свяжитесь с TASKONFF, чтобы обсудить разработку, интеграцию или автоматизацию. Опишите задачу, текущие процессы и результат, который вам нужен.",
    en: "Contact TASKONFF to discuss software development, integrations or automation. Tell us about your current workflows and what you need to improve.",
  },
  privacy: {
    ru: "Политика конфиденциальности TASKONFF описывает, какие данные используются на сайте, как обрабатываются обращения и какие права есть у посетителя.",
    en: "The TASKONFF privacy policy explains the data used on this website, how requests and messages are handled, and what rights visitors have.",
  },
  terms: {
    ru: "Условия использования сайта TASKONFF определяют правила работы с материалами, отправки обращений, перехода по ссылкам и использования информации.",
    en: "Read the TASKONFF website terms covering the use of site materials, contact and product requests, external links and company information.",
  },
  [`products/${MEDVOICE_PRODUCT_SLUG}`]: {
    ru: "MedVoice AI от TASKONFF для автоматизации звонков в клиниках, записи к врачу и подтверждения визитов. Оцените эффект и запросите демонстрацию.",
    en: "Explore MedVoice AI by TASKONFF for clinic calls, appointment booking, visit confirmations and analytics. Estimate the impact and request a demo.",
  },
  [`products/${BVOICE_PRODUCT_SLUG}`]: {
    ru: "BVoice от TASKONFF — будущий голосовой ИИ-колл-центр для банков, страховых компаний и финансовых сервисов. Узнайте, к чему мы готовимся.",
    en: "BVoice by TASKONFF is an upcoming AI voice contact center for banks, insurers and financial services. Explore the planned product and use cases.",
  },
  "services/custom-software": {
    ru: "TASKONFF проектирует ПО под бизнес-логику вашей компании, разрабатывает модули, подключает интеграции и готовит систему к запуску.",
    en: "Develop software around your business logic with TASKONFF, from requirements and architecture to working modules, integration, testing and launch.",
  },
  "services/web-mobile": {
    ru: "TASKONFF разрабатывает порталы, личные кабинеты и мобильные приложения с адаптивными интерфейсами, понятными сценариями и связью с API.",
    en: "Build a website, mobile app or customer portal with TASKONFF. Explore user journeys, responsive interfaces, API integration and accessibility.",
  },
  "services/ai-agents": {
    ru: "ИИ-решения и агенты TASKONFF для работы с документами и данными. Обсудите сценарий поиска, подготовки ответа или автоматизации с проверкой человеком.",
    en: "Explore AI assistants for document search, drafting and workflow automation. Discuss human review, data access and evaluation with TASKONFF.",
  },
  "services/business-automation": {
    ru: "TASKONFF помогает автоматизировать ручные операции, настраивает маршруты согласования, уведомления и интеграции с обработкой ошибок.",
    en: "Automate routine business workflows with TASKONFF, including approvals, notifications, data handoffs, integrations and exception handling.",
  },
  "services/crm-erp": {
    ru: "TASKONFF разрабатывает и интегрирует CRM и ERP для учёта клиентов, сделок и операций, настройки ролей и обмена данными между системами.",
    en: "Build or extend CRM and ERP systems with TASKONFF. Connect customer records, deals and business operations with clear permissions and data flows.",
  },
  "services/saas-b2b": {
    ru: "TASKONFF создаёт SaaS и B2B-платформы с рабочими пространствами компаний, ролями, интеграциями и продуманным процессом подключения пользователей.",
    en: "Build SaaS and B2B platforms around team workspaces, roles, integrations and customer workflows. Plan a pilot and a path to expanding the product.",
  },
  "services/system-integration": {
    ru: "TASKONFF связывает системы через API и события, настраивает синхронизацию, обработку повторов и ошибок и наблюдение за потоками данных.",
    en: "Connect business systems with APIs and events. Plan data mappings, synchronization, error handling and monitoring around your current systems.",
  },
  "services/cloud-devops": {
    ru: "TASKONFF настраивает облачные окружения, CI/CD, мониторинг и резервное копирование, чтобы подготовить приложения к эксплуатации.",
    en: "Set up cloud environments and delivery pipelines with TASKONFF. Plan monitoring, backups, release controls and handover for your application.",
  },
  "services/ui-ux-design": {
    ru: "TASKONFF проектирует интерфейсы для приложений и корпоративных сервисов, проверяет пользовательские сценарии и готовит компоненты к разработке.",
    en: "Design applications around real user tasks with TASKONFF. Explore interaction flows, validate a prototype and prepare components for development.",
  },
  "services/business-analysis-qa": {
    ru: "TASKONFF помогает собрать требования, определить критерии приёмки, спланировать проверки и оценить готовность системы к запуску.",
    en: "Use TASKONFF business analysis and QA to clarify requirements, define acceptance criteria, plan tests and assess whether software is ready to launch.",
  },
};

const subjects: Record<string, Record<Locale, string>> = {
  [`products/${BVOICE_PRODUCT_SLUG}`]: {
    ru: "ИИ-колл-центр для финансовых сервисов",
    en: "AI contact center for financial services",
  },
  [`products/${MEDVOICE_PRODUCT_SLUG}`]: {
    ru: "голосовой ИИ-агент для медицинских клиник",
    en: "Voice AI agent for medical clinics",
  },
};

export function pageTitle(locale: Locale, slug: string, title: string) {
  if (!slug) return `TASKONFF — ${title}`;
  const subject = subjects[slug]?.[locale];
  return subject ? `${title} — ${subject} | TASKONFF` : `${title} — TASKONFF`;
}

export function pageDescription(locale: Locale, slug: string, fallback = "") {
  const fixed = descriptions[slug]?.[locale];
  if (fixed) return fixed;

  const text = fallback.trim().replace(/\s+/g, " ");
  if (text.length <= 160) return text;
  const prefix = text.slice(0, 159);
  const boundary = prefix.lastIndexOf(" ");
  return `${boundary > 120 ? prefix.slice(0, boundary) : prefix}…`;
}
