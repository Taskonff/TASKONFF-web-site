import type { PublishedProduct } from "@/cms/defaults";
import type { Locale } from "./site";

export const MEDVOICE_PRODUCT_SLUG = "medvoice-ai";
export const BVOICE_PRODUCT_SLUG = "bvoice";

// An empty target points an archived product URL to the catalog.
export const legacyProductSlugs: Readonly<Record<string, string>> = {
  medvoice: MEDVOICE_PRODUCT_SLUG,
  arckpi: "",
};

export const launchProductCopy = {
  [MEDVOICE_PRODUCT_SLUG]: {
    ru: {
      title: "MedVoice AI",
      summary:
        "Голосовой ИИ-агент для клиник. Помогает принимать звонки, записывать пациентов, подтверждать визиты и передавать сложные вопросы администратору. Готовим пилотные внедрения.",
    },
    en: {
      title: "MedVoice AI",
      summary:
        "A voice AI agent for clinics. Handle calls, book appointments, confirm visits and escalate complex questions to staff. Pilot deployments are in preparation.",
    },
  },
  [BVOICE_PRODUCT_SLUG]: {
    ru: {
      title: "BVoice",
      summary:
        "Готовим голосовой ИИ-колл-центр для банков, страховых компаний и других финансовых сервисов. Сценарии обслуживания и маршрутизации обращений будут представлены ближе к запуску.",
    },
    en: {
      title: "BVoice",
      summary:
        "An upcoming AI voice contact center for banks, insurers and other financial services. We’ll share more about customer service and call routing closer to launch.",
    },
  },
} satisfies Record<string, Record<Locale, { title: string; summary: string }>>;

const editorialOrder = [MEDVOICE_PRODUCT_SLUG, BVOICE_PRODUCT_SLUG];

export const defaultProducts: PublishedProduct[] = editorialOrder.map(
  (slug) => {
    const copy = launchProductCopy[slug as keyof typeof launchProductCopy];
    return {
      id: slug,
      slug,
      ru: { ...copy.ru, body: "" },
      en: { ...copy.en, body: "" },
    };
  },
);

export function productOrder(slug: string) {
  const position = editorialOrder.indexOf(slug);
  return position === -1 ? editorialOrder.length : position;
}

export function isComingSoonProduct(slug: string) {
  return slug === BVOICE_PRODUCT_SLUG;
}

export function legacyProductTarget(
  slug: string,
  products: PublishedProduct[],
) {
  if (!Object.hasOwn(legacyProductSlugs, slug)) return;
  const target = legacyProductSlugs[slug];
  return target && products.some((product) => product.slug === target)
    ? target
    : "";
}

export function productText(product: PublishedProduct, locale: Locale) {
  const content = product[locale];
  const copy =
    launchProductCopy[product.slug as keyof typeof launchProductCopy]?.[locale];
  return {
    ...content,
    title: content.title.trim() || copy?.title || product.slug,
    summary: content.summary.trim() || copy?.summary || "",
  };
}
