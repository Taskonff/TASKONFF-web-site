import type { Locale } from "@/content/site";
export const companyContent = {
  ru: {
    about: {
      label: "О КОМПАНИИ",
      title: "Команда разработки\nTASKONFF.",
      intro:
        "TASKONFF разрабатывает программное обеспечение и внедряет цифровые решения для бизнеса. Соединяем продукты, процессы и технологии в единую логику.",
      heading: "Кто мы и что создаём",
      body: "Разработка начинается с понимания задачи: кто пользуется системой, какое действие она упрощает и с чем должна взаимодействовать. Так цифровой продукт становится частью бизнеса, а не отдельным инструментом.",
      workTitle: "Собственные разработки и кейсы",
      teamTitle: "Команда",
      facts: [
        ["Год основания", ""],
        ["Завершено проектов", ""],
        ["Размер команды", ""],
      ],
      team: [
        { name: "", role: "" },
        { name: "", role: "" },
        { name: "", role: "" },
        { name: "", role: "" },
      ],
      principles: [
        [
          "Сначала контекст",
          "Разбираем цели, ограничения, текущие процессы и потребности пользователей. Технологическое решение следует из задачи.",
        ],
        [
          "Ясная архитектура",
          "Определяем границы системы, роли и интеграции. Продумываем развитие до того, как сложность станет препятствием.",
        ],
        [
          "Качество в процессе",
          "Проектирование, разработка и проверка связаны. Обратная связь помогает уточнять продукт на каждом этапе.",
        ],
      ],
      capTitle: "От идеи до связанных систем.",
      capText:
        "Направления дополняют друг друга: интерфейс, логика, данные и инфраструктура должны работать вместе.",
      capabilities: [
        [
          "Цифровые продукты",
          "Веб, мобильные приложения и SaaS-платформы.",
          "web-mobile",
        ],
        [
          "Интеллект и автоматизация",
          "AI-агенты, бизнес-процессы и интеграции.",
          "ai-agents",
        ],
        [
          "Корпоративные инструменты",
          "CRM, ERP и системы для рабочих процессов.",
          "crm-erp",
        ],
        [
          "Дизайн и качество",
          "Пользовательские сценарии, интерфейсы и QA.",
          "ui-ux-design",
        ],
      ],
      cta: "С чего начнём ваш проект?",
      capabilitiesLabel: "ЧТО МЫ ОБЪЕДИНЯЕМ",
      processLink: "Как устроена работа над проектом",
    },
    tech: {
      label: "ТЕХНОЛОГИИ",
      title: "Архитектура\nцифровых продуктов.",
      intro:
        "Подбираем инструменты под задачу, интеграции и ограничения проекта. Исследуйте слои цифрового продукта: от взаимодействия с пользователем до инфраструктуры.",
      heading: "Из чего складывается\nцифровая система.",
      note: "Выберите слой, чтобы увидеть его роль и примеры инструментов. Точный стек подбираем с учётом вашей системы, данных и условий эксплуатации.",
      future: "Расширение архитектуры",
      futureText:
        "Ясные границы компонентов и согласованные контракты интеграции помогают подключать новые сервисы и развивать функции без полной переработки продукта. Изменения оцениваются с учётом данных, зависимостей и требований бизнеса.",
      cta: "Подберём стек под вашу задачу.",
    },
    process: {
      label: "ПРОЦЕСС",
      title: "От ясной задачи\nк работающему продукту.",
      intro:
        "Исследование, проектирование, разработка и развитие — связанные этапы. Исследуйте, какие решения и материалы формируются на каждом из них.",
      heading: "Роли и результат каждого этапа",
      note: "Определяем календарь работ после уточнения объёма, интеграций и готовности данных. На каждом этапе заранее согласуем решение, которое нужно принять для перехода дальше.",
      feedbackTitle: "Обратная связь — часть работы.",
      feedbackText:
        "Проверяем промежуточные результаты на понятных сценариях. Решения, вопросы и изменения обсуждаются до перехода к следующему объёму работ.",
      feedback: [
        [
          "Согласованная задача",
          "Фиксируем, какую проблему решаем и как проверяется результат.",
        ],
        [
          "Видимый промежуточный результат",
          "Демонстрируем сценарии и собираем комментарии к ним.",
        ],
        [
          "Осознанные изменения",
          "Оцениваем влияние новых требований на объём и архитектуру.",
        ],
      ],
      faqTitle: "Что важно знать перед стартом?",
      faq: [
        [
          "Можно начать без готового технического задания?",
          "Да. Для первого обсуждения достаточно описать цель, текущий процесс и ограничения. Формирование требований может стать отдельным этапом.",
        ],
        [
          "Когда выбирается стек?",
          "После уточнения сценариев, интеграций, требований к данным и инфраструктуре. Предпочтения и существующие системы учитываются при выборе.",
        ],
        [
          "Как учитываются изменения?",
          "Новые требования сопоставляются с согласованным объёмом. Приоритеты, зависимости и влияние на план уточняются до реализации.",
        ],
        [
          "Что происходит после запуска?",
          "Обсуждаются эксплуатация, документация, интеграции и дальнейшее развитие. Формат поддержки и состав работ определяются отдельно.",
        ],
        [
          "Кто на связи и как часто проходят демонстрации?",
          "На старте определяем контактных лиц с обеих сторон. График демонстраций и формат обновлений согласуем вместе. На встречах показываем готовые сценарии и фиксируем решения и открытые вопросы.",
        ],
        [
          "Как согласуем стоимость и оплату?",
          "До начала работ согласуем объём, единицы оценки и порядок оплаты. Для определённого объёма можно обсудить фиксированную оценку; для изменяющихся задач — оценку по трудозатратам.",
        ],
      ],
      cta: "Давайте определим первый шаг.",
    },
    architecture: {
      label: "СЛОИ ПРОДУКТА",
      hint: "Выберите слой, чтобы увидеть его роль.",
      toolsLabel: "Примеры инструментов",
      items: [
        {
          title: "Опыт пользователя",
          eyebrow: "ИНТЕРФЕЙС",
          toolExamples: ["React", "Next.js", "Tailwind CSS", "shadcn/ui"],
          text: "Пользовательские сценарии превращаются в интерфейс, в котором понятны действия, состояния и обратная связь.",
          chips: ["Веб и мобильные приложения", "UI/UX", "Доступность"],
          outputs: [
            "Карта пользовательских сценариев",
            "Компоненты и состояния интерфейса",
            "Контракты взаимодействия с API",
          ],
          nodes: ["Пользователь", "Интерфейс", "Сценарий"],
        },
        {
          title: "Логика и интеграции",
          eyebrow: "ПРИКЛАДНАЯ ЛОГИКА",
          toolExamples: ["TypeScript", "Node.js", "REST API", "GraphQL"],
          text: "Правила бизнеса, права доступа и процессы соединяют интерфейс с данными и внешними сервисами.",
          chips: ["API", "CRM / ERP", "Интеграции"],
          outputs: [
            "Границы модулей и сервисов",
            "Сценарии ошибок и повторов",
            "Согласованные контракты интеграции",
          ],
          nodes: ["Интерфейс", "Бизнес-логика", "Внешние сервисы"],
        },
        {
          title: "Данные и интеллект",
          eyebrow: "ДАННЫЕ И ИИ",
          toolExamples: ["SQL", "SQLite", "Payload CMS"],
          text: "Структура данных и интеллектуальные функции подчинены задаче. Модели ИИ сравниваем по качеству на примерах, условиям размещения и доступу к данным.",
          chips: ["Модели данных", "ИИ-агенты", "Качество данных"],
          outputs: [
            "Модель данных и правила доступа",
            "Контекст и инструменты ИИ-агента",
            "Критерии проверки результата",
          ],
          nodes: ["Данные", "Контекст", "Интеллект"],
        },
        {
          title: "Инфраструктура",
          eyebrow: "ЭКСПЛУАТАЦИЯ",
          toolExamples: ["Node.js", "Git", "Playwright"],
          text: "Среды, сборка, развёртывание и наблюдаемость позволяют безопасно доставлять изменения и разбирать сбои.",
          chips: ["Облачная среда", "Автоматизация выпуска", "Наблюдаемость"],
          outputs: [
            "Структура окружений",
            "Процесс сборки и развёртывания",
            "Требования к эксплуатации",
          ],
          nodes: ["Код", "Доставка", "Рабочая среда"],
        },
      ],
      outputLabel: "ЧТО ОПРЕДЕЛЯЕМ",
    },
    phases: {
      label: "ЭТАПЫ ПРОЕКТА",
      hint: "Выберите этап и изучите его результат.",
      items: [
        {
          title: "Исследуем",
          eyebrow: "Анализ",
          details: [
            [
              "С вашей стороны",
              "Назначить владельца процесса, предоставить примеры задач и описать ограничения.",
            ],
            [
              "Со стороны TASKONFF",
              "Провести разбор процесса и согласовать критерии первого результата.",
            ],
            [
              "Как планируем сроки",
              "После первого разбора оцениваем объём этапа по числу процессов и участников.",
            ],
          ],
          text: "Изучаем цели, пользователей, ограничения и существующие процессы. Формируем общую картину задачи.",
          chips: ["Цели", "Сценарии", "Ограничения"],
          outputs: [
            "Описание задачи и приоритетов",
            "Ключевые пользовательские сценарии",
            "Границы первого объёма работ",
          ],
          nodes: ["Контекст", "Анализ", "Требования"],
        },
        {
          title: "Проектируем",
          eyebrow: "Проектирование",
          details: [
            [
              "С вашей стороны",
              "Проверить прототип с будущими пользователями, подтвердить сценарии и ограничения.",
            ],
            [
              "Со стороны TASKONFF",
              "Подготовить прототип, схему интеграций и план разработки.",
            ],
            [
              "Как планируем сроки",
              "Планируем к согласованной дате проверки прототипа.",
            ],
          ],
          text: "Связываем требования с архитектурой и пользовательскими сценариями. Проверяем ключевые решения до полномасштабной разработки.",
          chips: ["Архитектура", "Прототип", "План"],
          outputs: [
            "Структура компонентов и интеграций",
            "Прототипы ключевых сценариев",
            "Согласованный план реализации",
          ],
          nodes: ["Требования", "Прототип", "Архитектура"],
        },
        {
          title: "Разрабатываем",
          eyebrow: "Разработка",
          details: [
            [
              "С вашей стороны",
              "Дать доступ к тестовым системам и принять ключевые сценарии по согласованным критериям.",
            ],
            [
              "Со стороны TASKONFF",
              "Реализовать приоритетные сценарии, проверить их и показать на демонстрации.",
            ],
            [
              "Как планируем сроки",
              "Делим согласованный объём на итерации. Даты демонстраций добавляем в план.",
            ],
          ],
          text: "Реализуем продукт итерациями. Связываем разработку, проверку и обсуждение промежуточных результатов.",
          chips: ["Итерации", "QA", "Обратная связь"],
          outputs: [
            "Работающие сценарии продукта",
            "Результаты проверок",
            "Уточнённые приоритеты следующих шагов",
          ],
          nodes: ["Реализация", "Проверка", "Демонстрация"],
        },
        {
          title: "Развиваем",
          eyebrow: "Эксплуатация",
          details: [
            [
              "С вашей стороны",
              "Назначить владельцев системы и подтвердить готовность к запуску.",
            ],
            [
              "Со стороны TASKONFF",
              "Подготовить инструкции, провести запуск и согласовать порядок поддержки.",
            ],
            [
              "Как планируем сроки",
              "Окно запуска определяем по готовности среды и команды.",
            ],
          ],
          text: "Планируем запуск, документацию и эксплуатацию. Определяем, как продукт будет меняться с появлением новых задач.",
          chips: ["Запуск", "Документация", "Развитие"],
          outputs: [
            "План развёртывания и эксплуатации",
            "Материалы для передачи системы",
            "Согласованный список следующих задач",
          ],
          nodes: ["Запуск", "Эксплуатация", "Следующий этап"],
        },
      ],
      outputLabel: "ЧТО ОПРЕДЕЛЯЕМ",
    },
  },
  en: {
    about: {
      label: "ABOUT US",
      title: "The TASKONFF\ndevelopment team.",
      intro:
        "TASKONFF develops software and implements digital solutions for business. We connect products, processes and technology into a coherent system.",
      heading: "Who we are and what we build",
      body: "Development starts with understanding the challenge: who uses the system, what it makes easier and what it must connect with. A digital product becomes part of the business rather than an isolated tool.",
      workTitle: "Our products and case studies",
      teamTitle: "The team",
      facts: [
        ["Founded", ""],
        ["Completed projects", ""],
        ["Team size", ""],
      ],
      team: [
        { name: "", role: "" },
        { name: "", role: "" },
        { name: "", role: "" },
        { name: "", role: "" },
      ],
      principles: [
        [
          "Context comes first",
          "Explore goals, constraints, existing processes and user needs. The technology follows the challenge.",
        ],
        [
          "Clear architecture",
          "Define system boundaries, roles and integrations. Plan for evolution before complexity becomes an obstacle.",
        ],
        [
          "Quality throughout",
          "Design, development and validation stay connected. Feedback helps refine the product at every stage.",
        ],
      ],
      capTitle: "From an idea to connected systems.",
      capText:
        "The disciplines complement each other: interface, logic, data and infrastructure need to work together.",
      capabilities: [
        [
          "Digital products",
          "Web, mobile applications and SaaS platforms.",
          "web-mobile",
        ],
        [
          "Intelligence & automation",
          "AI agents, business processes and integrations.",
          "ai-agents",
        ],
        [
          "Enterprise tools",
          "CRM, ERP and systems for operational workflows.",
          "crm-erp",
        ],
        [
          "Design & quality",
          "User journeys, interfaces and quality assurance.",
          "ui-ux-design",
        ],
      ],
      cta: "Where should your project begin?",
      capabilitiesLabel: "WHAT WE CONNECT",
      processLink: "How a project takes shape",
    },
    tech: {
      label: "TECHNOLOGIES",
      title: "Architecture for\ndigital products.",
      intro:
        "We choose tools around the challenge, integrations and constraints. Explore the layers of a digital product, from the user experience to infrastructure.",
      heading: "The layers of\na digital system.",
      note: "Select a layer to see its role and examples of tools. The exact stack depends on your systems, data and operating requirements.",
      future: "Room to extend",
      futureText:
        "Clear component boundaries and agreed integration contracts help connect new services and evolve features without rebuilding the entire product. Changes are evaluated against data, dependencies and business requirements.",
      cta: "Choose a stack around your challenge.",
    },
    process: {
      label: "OUR PROCESS",
      title: "From a clear challenge\nto a working product.",
      intro:
        "Discovery, design, development and evolution are connected stages. Explore the decisions and deliverables that take shape in each one.",
      heading: "Roles and deliverables at each stage",
      note: "We set the schedule once scope, integrations and data readiness are clear. Before each stage, we agree on the decision needed to move forward.",
      feedbackTitle: "Feedback belongs in the process.",
      feedbackText:
        "We review intermediate results through clear scenarios. Decisions, questions and changes are discussed before moving into the next scope of work.",
      feedback: [
        [
          "A shared challenge",
          "Define the problem and how the result will be evaluated.",
        ],
        [
          "Visible intermediate outcomes",
          "Demonstrate scenarios and collect feedback around them.",
        ],
        [
          "Deliberate changes",
          "Evaluate how new requirements affect scope and architecture.",
        ],
      ],
      faqTitle: "Before we begin.",
      faq: [
        [
          "Can we start without a technical specification?",
          "Yes. Describe the goal, current process and constraints for the first conversation. Requirements discovery can be a separate stage.",
        ],
        [
          "When is the technology stack chosen?",
          "After clarifying scenarios, integrations, data requirements and infrastructure. Existing systems and preferences inform the decision.",
        ],
        [
          "How are changes handled?",
          "New requirements are compared with the agreed scope. Priorities, dependencies and planning impact are discussed before implementation.",
        ],
        [
          "What happens after launch?",
          "We discuss operations, documentation, integrations and future development. Support arrangements and scope are agreed separately.",
        ],
        [
          "Who is the point of contact and how often are demos held?",
          "At kickoff, each side identifies a point of contact. We agree on a demo schedule and update format together. In reviews we show completed workflows and record decisions and open questions.",
        ],
        [
          "How is payment agreed?",
          "We agree on scope, how work is estimated and the payment schedule before starting. A defined scope can use a fixed estimate, while evolving work can be estimated based on effort.",
        ],
      ],
      cta: "Let’s define the first step.",
    },
    architecture: {
      label: "PRODUCT LAYERS",
      hint: "Choose a layer to explore its role.",
      toolsLabel: "Example tools",
      items: [
        {
          title: "User experience",
          eyebrow: "INTERFACE",
          toolExamples: ["React", "Next.js", "Tailwind CSS", "shadcn/ui"],
          text: "User journeys become an interface with clear actions, states and feedback.",
          chips: ["Web & mobile", "UI/UX", "Accessibility"],
          outputs: [
            "Key user journeys",
            "Interface components and states",
            "API interaction contracts",
          ],
          nodes: ["User", "Interface", "Journey"],
        },
        {
          title: "Logic & integrations",
          eyebrow: "APPLICATION",
          toolExamples: ["TypeScript", "Node.js", "REST API", "GraphQL"],
          text: "Business rules, access rights and workflows connect the interface to data and external services.",
          chips: ["API", "CRM / ERP", "Integrations"],
          outputs: [
            "Module and service boundaries",
            "Error and retry scenarios",
            "Agreed integration contracts",
          ],
          nodes: ["Interface", "Business logic", "External services"],
        },
        {
          title: "Data & intelligence",
          eyebrow: "DATA / AI",
          toolExamples: ["SQL", "SQLite", "Payload CMS"],
          text: "Data structure and intelligent functions serve the challenge. AI model selection depends on quality against representative examples, hosting constraints and data access.",
          chips: ["Data models", "AI agents", "Data quality"],
          outputs: [
            "Data model and access rules",
            "AI-agent context and tools",
            "Criteria for evaluating output",
          ],
          nodes: ["Data", "Context", "Intelligence"],
        },
        {
          title: "Infrastructure",
          eyebrow: "CLOUD / DEVOPS",
          toolExamples: ["Node.js", "Git", "Playwright"],
          text: "Environments, builds, deployment and observability support reliable delivery and investigation of failures.",
          chips: ["Cloud", "CI / CD", "Observability"],
          outputs: [
            "Environment structure",
            "Build and deployment process",
            "Operational requirements",
          ],
          nodes: ["Code", "Delivery", "Environment"],
        },
      ],
      outputLabel: "WHAT TAKES SHAPE",
    },
    phases: {
      label: "PROJECT STAGES",
      hint: "Choose a stage and explore its deliverables.",
      items: [
        {
          title: "Discover",
          eyebrow: "Discovery",
          details: [
            [
              "Your team",
              "Assign a process owner, share examples and describe constraints.",
            ],
            [
              "TASKONFF",
              "Review the workflow and agree how to judge the first result.",
            ],
            [
              "Scheduling",
              "After the first review, estimate this stage from the number of workflows and stakeholders.",
            ],
          ],
          text: "Explore goals, users, constraints and existing processes. Form a shared understanding of the challenge.",
          chips: ["Goals", "Journeys", "Constraints"],
          outputs: [
            "Challenge description and priorities",
            "Key user journeys",
            "Boundaries of the initial scope",
          ],
          nodes: ["Context", "Analysis", "Requirements"],
        },
        {
          title: "Design",
          eyebrow: "Design",
          details: [
            [
              "Your team",
              "Review the prototype with future users and confirm workflows and constraints.",
            ],
            [
              "TASKONFF",
              "Prepare the prototype, integration diagram and implementation plan.",
            ],
            [
              "Scheduling",
              "Plan around the agreed date for the prototype review.",
            ],
          ],
          text: "Connect requirements to architecture and user journeys. Validate key decisions before full development.",
          chips: ["Architecture", "Prototype", "Plan"],
          outputs: [
            "Component and integration structure",
            "Prototypes of key journeys",
            "An agreed implementation plan",
          ],
          nodes: ["Requirements", "Prototype", "Architecture"],
        },
        {
          title: "Build",
          eyebrow: "Development",
          details: [
            [
              "Your team",
              "Provide access to test systems and accept priority workflows against the agreed criteria.",
            ],
            [
              "TASKONFF",
              "Build priority workflows, validate them and show them in a demo.",
            ],
            [
              "Scheduling",
              "Divide the agreed scope into iterations and put demo dates on the schedule.",
            ],
          ],
          text: "Develop iteratively, keeping implementation, validation and review of intermediate results connected.",
          chips: ["Iterations", "QA", "Feedback"],
          outputs: [
            "Working product scenarios",
            "Validation results",
            "Refined priorities for the next steps",
          ],
          nodes: ["Implement", "Validate", "Review"],
        },
        {
          title: "Evolve",
          eyebrow: "Operations",
          details: [
            ["Your team", "Assign system owners and confirm launch readiness."],
            [
              "TASKONFF",
              "Prepare instructions, support launch and agree on ongoing support.",
            ],
            [
              "Scheduling",
              "Set the launch window based on environment and team readiness.",
            ],
          ],
          text: "Plan launch, documentation and operations. Define how the product can evolve with new challenges.",
          chips: ["Launch", "Documentation", "Evolution"],
          outputs: [
            "Deployment and operations plan",
            "System handover materials",
            "Agreed list of upcoming work",
          ],
          nodes: ["Launch", "Operations", "What comes next"],
        },
      ],
      outputLabel: "WHAT TAKES SHAPE",
    },
  },
} satisfies Record<Locale, unknown>;
