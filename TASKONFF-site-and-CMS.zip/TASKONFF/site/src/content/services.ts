import type { Locale } from "./site";
export type ServiceGroup = "build" | "automate" | "operate" | "design";
export type ServiceCopy = {
  title: string;
  intro: string;
  needs: string[];
  deliverables: string[];
  workflow: string[];
  decision: string;
  timing: string;
  budget: string;
  example: string;
  tools: string[];
  faq: [string, string][];
};
export type Service = {
  slug: string;
  group: ServiceGroup;
  ru: ServiceCopy;
  en: ServiceCopy;
};
export const serviceGroups: Record<Locale, Record<ServiceGroup, string>> = {
  ru: {
    build: "Цифровые продукты",
    automate: "ИИ и автоматизация",
    operate: "Корпоративные системы",
    design: "Дизайн и качество",
  },
  en: {
    build: "Digital products",
    automate: "AI & automation",
    operate: "Enterprise systems",
    design: "Design & quality",
  },
};
export const services: Service[] = [
  {
    slug: "custom-software",
    group: "build",
    ru: {
      title: "Заказная разработка ПО",
      intro:
        "Когда готовые инструменты ограничивают процессы, нужен продукт под вашу бизнес-логику. Начинаем с задачи и проектируем программное обеспечение с понятными границами, ролями и интеграциями.",
      needs: [
        "Уникальная бизнес-логика и сложные правила",
        "Замена разрозненных таблиц и ручных операций",
        "Развитие существующей системы без потери контекста",
      ],
      deliverables: [
        "Требования и архитектура решения",
        "Работающие модули и автоматизированные проверки",
        "Инструкции по запуску, эксплуатации и развитию",
      ],
      workflow: [
        "Исследуем текущие процессы и ограничения",
        "Выделяем ядро продукта и планируем итерации",
        "Разрабатываем, проверяем и готовим к запуску",
      ],
      decision:
        "Собственный продукт оправдан, если критические процессы нельзя надёжно поддержать готовыми решениями.",
      timing:
        "По запросу. Оценка зависит от числа ролей, бизнес-правил и интеграций первой версии.",
      budget: "По запросу, после согласования первого объёма работ.",
      example:
        "Внутренний кабинет, в котором заявки распределяются по правилам, а согласования и изменения сохраняются в истории.",
      tools: ["TypeScript", "Node.js", "реляционная база данных"],
      faq: [
        [
          "Можно ли доработать существующую систему?",
          "Да. Сначала изучаем код, данные, окружение и ограничения. После этого определяем, какие части сохранять и где нужны изменения.",
        ],
        [
          "С чего начинается оценка?",
          "С описания пользователей, ключевых сценариев, интеграций и критериев готовности. Без этого нельзя обоснованно определить объём.",
        ],
        [
          "Что входит в первую версию?",
          "Один критический рабочий процесс целиком: от входных данных до результата и обработки исключений. Остальные роли и интеграции планируем отдельно.",
        ],
        [
          "Что передаётся при запуске?",
          "Состав передачи фиксируем заранее. В него можно включить репозиторий, схему развёртывания, инструкции и проверочный набор сценариев.",
        ],
      ],
    },
    en: {
      title: "Custom software development",
      intro:
        "When off-the-shelf tools constrain your processes, build around your business logic. We start with the problem and design software with clear boundaries, roles and integrations.",
      needs: [
        "Unique business logic and complex rules",
        "Replacing disconnected spreadsheets and manual work",
        "Evolving an existing system without losing context",
      ],
      deliverables: [
        "Requirements and solution architecture",
        "Working modules and automated checks",
        "Deployment, operation and evolution guidance",
      ],
      workflow: [
        "Explore current processes and constraints",
        "Define the product core and iteration plan",
        "Build, validate and prepare for launch",
      ],
      decision:
        "Custom software makes sense when business-critical processes cannot be supported reliably by ready-made tools.",
      timing:
        "On request. The estimate depends on the roles, business rules and integrations in the first release.",
      budget: "On request, after agreeing the first scope of work.",
      example:
        "An internal workspace where requests are routed by business rules and every approval and change is recorded.",
      tools: ["TypeScript", "Node.js", "relational database"],
      faq: [
        [
          "Can you extend an existing system?",
          "Yes. We first examine the code, data, environment and constraints, then decide what to preserve and where changes are necessary.",
        ],
        [
          "What is needed for an estimate?",
          "Users, key workflows, integrations and acceptance criteria. These define a scope that can be assessed meaningfully.",
        ],
        [
          "What goes into the first release?",
          "One critical workflow from input through completion and exception handling. Additional roles and integrations can follow separately.",
        ],
        [
          "What is handed over at launch?",
          "We agree the handover scope upfront. It can include the repository, deployment setup, operating instructions and acceptance scenarios.",
        ],
      ],
    },
  },
  {
    slug: "web-mobile",
    group: "build",
    ru: {
      title: "Веб и мобильные приложения",
      intro:
        "Цифровой сервис должен быть удобен там, где работает пользователь. Проектируем веб-интерфейсы и мобильные сценарии вокруг задач, устройств и реальных условий использования.",
      needs: [
        "Личный кабинет, портал или клиентский сервис",
        "Работа на смартфонах, планшетах и компьютерах",
        "Связь интерфейса с внутренними данными и API",
      ],
      deliverables: [
        "Пользовательские сценарии и адаптивный интерфейс",
        "Клиентское приложение и необходимые API",
        "Проверки доступности, производительности и ошибок",
      ],
      workflow: [
        "Определяем устройства и ключевые действия",
        "Проверяем прототип и технический подход",
        "Разрабатываем и тестируем целевые сценарии",
      ],
      decision:
        "Выбор между вебом, PWA и отдельным мобильным приложением зависит от нужных функций устройства и способа распространения.",
      timing:
        "По запросу. Учитываем устройства, число сценариев, готовность API и требования к публикации.",
      budget: "По запросу, после согласования первого объёма работ.",
      example:
        "Личный кабинет, где клиент подаёт запрос со смартфона, прикрепляет документы и отслеживает статус.",
      tools: ["React", "Next.js", "PWA или нативные компоненты по задаче"],
      faq: [
        [
          "Всегда ли нужно отдельное мобильное приложение?",
          "Нет. Адаптивный веб или PWA могут решить задачу. Отдельное приложение рассматриваем, если важны возможности устройства или требования платформ.",
        ],
        [
          "Как проверяется адаптивность?",
          "На нескольких ширинах экрана и в ключевых сценариях: навигация, формы, ошибки, загрузка данных и управление с клавиатуры.",
        ],
        [
          "Можно ли использовать существующий бэкенд?",
          "Да. Проверяем авторизацию, форматы ответов и доступность тестовой среды. Для отсутствующих операций отдельно оцениваем доработки API.",
        ],
        [
          "Как подготовиться к публикации приложения?",
          "Заранее определяем владельцев аккаунтов, список материалов, разрешения приложения и порядок тестирования на устройствах.",
        ],
      ],
    },
    en: {
      title: "Web & mobile applications",
      intro:
        "A digital service should work wherever its users are. We design web interfaces and mobile experiences around tasks, devices and real conditions of use.",
      needs: [
        "Customer portals and self-service products",
        "Experiences across phones, tablets and desktops",
        "Interfaces connected to internal data and APIs",
      ],
      deliverables: [
        "User journeys and responsive interfaces",
        "Client application and required APIs",
        "Accessibility, performance and error-state checks",
      ],
      workflow: [
        "Define devices and essential actions",
        "Validate the prototype and technical approach",
        "Build and test target journeys",
      ],
      decision:
        "Web, PWA or a dedicated mobile app depends on device capabilities and distribution requirements.",
      timing:
        "On request. Devices, user journeys, API readiness and release requirements shape the estimate.",
      budget: "On request, after agreeing the first scope of work.",
      example:
        "A self-service portal where customers submit requests from a phone, upload documents and track status.",
      tools: ["React", "Next.js", "PWA or native components as needed"],
      faq: [
        [
          "Is a separate mobile app always necessary?",
          "No. Responsive web or a PWA can be enough. A dedicated app is considered when device capabilities or platform requirements justify it.",
        ],
        [
          "How is responsiveness tested?",
          "Across screen widths and key journeys: navigation, forms, errors, data loading and keyboard operation.",
        ],
        [
          "Can you use an existing backend?",
          "Yes. We check authentication, response formats and access to a test environment. Missing API operations are scoped separately.",
        ],
        [
          "How do we prepare for an app release?",
          "We identify account owners, required assets, app permissions and the device testing plan before submission.",
        ],
      ],
    },
  },
  {
    slug: "ai-agents",
    group: "automate",
    ru: {
      title: "ИИ-решения и агенты",
      intro:
        "Искусственный интеллект полезен там, где есть конкретная задача, подходящие данные и способ проверить результат. Проектируем помощников и агентные сценарии с управляемым доступом к инструментам.",
      needs: [
        "Поиск и работа с внутренними знаниями",
        "Разбор документов и подготовка черновиков",
        "Помощник, выполняющий действия через разрешённые API",
      ],
      deliverables: [
        "Проверяемый сценарий и набор оценки качества",
        "Подключение источников знаний и инструментов",
        "Ограничения доступа, наблюдаемость и эскалация человеку",
      ],
      workflow: [
        "Проверяем данные, ограничения и критерии качества",
        "Собираем прототип на ограниченном сценарии",
        "Тестируем ошибки и интегрируем в рабочий процесс",
      ],
      decision:
        "До внедрения оцениваем точность, стоимость запросов и допустимые ошибки. Ответственные действия требуют контролируемых разрешений.",
      timing:
        "По запросу. Сначала проверяем доступность документов, примеров ответов и правил проверки.",
      budget: "По запросу, после согласования первого объёма работ.",
      example:
        "Помощник службы поддержки подбирает справочные материалы и предлагает черновик ответа со ссылками для проверки сотрудником.",
      tools: [
        "языковая модель по требованиям",
        "поиск по документам (RAG)",
        "доступ к API по ролям",
      ],
      faq: [
        [
          "Можно ли подключить корпоративные документы?",
          "Да, после определения прав доступа, форматов, актуальности данных и требований к конфиденциальности.",
        ],
        [
          "Агент может ошибаться?",
          "Да. Поэтому нужны проверки качества, ограничения инструментов и понятный переход к человеку в спорных ситуациях.",
        ],
        [
          "Как проверить, что пилот полезен?",
          "Отбираем реальные типы запросов, готовим ожидаемые ответы и сравниваем точность, время проверки и число обращений к сотруднику.",
        ],
        [
          "От чего зависит выбор модели?",
          "Сравниваем качество на ваших примерах, цену запроса, требования к размещению и доступные способы контроля данных.",
        ],
      ],
    },
    en: {
      title: "AI solutions & intelligent agents",
      intro:
        "AI is useful when there is a specific task, suitable data and a way to evaluate results. We design assistants and agent workflows with controlled access to tools.",
      needs: [
        "Searching and working with internal knowledge",
        "Document analysis and draft preparation",
        "Assistants acting through explicitly permitted APIs",
      ],
      deliverables: [
        "Defined use case and quality evaluation set",
        "Knowledge-source and tool integrations",
        "Access controls, observability and human escalation",
      ],
      workflow: [
        "Assess data, constraints and quality criteria",
        "Prototype a tightly scoped use case",
        "Test failure modes and integrate into the workflow",
      ],
      decision:
        "We assess accuracy, request costs and acceptable errors before rollout. Consequential actions need controlled permissions.",
      timing:
        "On request. We first check access to source documents, example answers and evaluation criteria.",
      budget: "On request, after agreeing the first scope of work.",
      example:
        "A support assistant retrieves reference material and drafts a response with citations for an employee to review.",
      tools: [
        "language model selected by requirements",
        "retrieval-augmented generation (RAG)",
        "role-based API access",
      ],
      faq: [
        [
          "Can corporate documents be connected?",
          "Yes, after defining access rights, formats, freshness and confidentiality requirements.",
        ],
        [
          "Can an agent make mistakes?",
          "Yes. Quality checks, limited tool permissions and a clear path to human review are necessary.",
        ],
        [
          "How can we tell if a pilot helps?",
          "Choose representative questions, define expected answers and compare accuracy, review time and how often staff need to step in.",
        ],
        [
          "How do you choose a model?",
          "Compare quality on your examples, request costs, hosting constraints and available data controls.",
        ],
      ],
    },
  },
  {
    slug: "business-automation",
    group: "automate",
    ru: {
      title: "Автоматизация бизнес-процессов",
      intro:
        "Убираем повторяющиеся ручные действия, сохраняя управляемость процесса. Соединяем события, правила, системы и людей в последовательный рабочий сценарий.",
      needs: [
        "Перенос данных между несколькими системами",
        "Согласования, уведомления и обработка заявок",
        "Повторяющиеся операции с понятными правилами",
      ],
      deliverables: [
        "Карта процесса и точки автоматизации",
        "Рабочие сценарии с обработкой исключений",
        "Журнал событий, уведомления и инструкции",
      ],
      workflow: [
        "Фиксируем процесс как он работает сейчас",
        "Определяем правила, исключения и ответственных",
        "Внедряем по этапам и проверяем весь маршрут",
      ],
      decision:
        "Сначала упрощаем процесс. Автоматизация не должна закреплять лишние шаги и неясную ответственность.",
      timing:
        "По запросу. Важны число веток процесса, состояние интеграций и правила обработки сбоев.",
      budget: "По запросу, после согласования первого объёма работ.",
      example:
        "Заявка на закупку проходит согласование по сумме, уведомляет ответственных и передаётся в учётную систему после одобрения.",
      tools: ["вебхуки", "очередь задач", "журнал операций"],
      faq: [
        [
          "Что автоматизировать в первую очередь?",
          "Повторяющиеся действия с ясными входными данными, правилами и измеримым результатом.",
        ],
        [
          "Что происходит при ошибке интеграции?",
          "Нужны повторные попытки, защита от дублирования и уведомление ответственного. Эти сценарии включаем в проектирование.",
        ],
        [
          "Что произойдёт, если внешняя система недоступна?",
          "Для критичных шагов заранее определяем допустимые повторы, уведомление ответственного и ручное продолжение процесса.",
        ],
        [
          "Что автоматизировать первым?",
          "Подходит частая операция с ясными правилами и измеримыми затратами времени. Начинаем с неё и отдельно разбираем нестандартные случаи.",
        ],
      ],
    },
    en: {
      title: "Business process automation",
      intro:
        "Remove repetitive manual actions while keeping processes manageable. Connect events, rules, systems and people into coherent workflows.",
      needs: [
        "Moving data between multiple systems",
        "Approvals, notifications and request handling",
        "Repetitive operations with clear rules",
      ],
      deliverables: [
        "Process map and automation opportunities",
        "Working flows with exception handling",
        "Event logs, notifications and operating guidance",
      ],
      workflow: [
        "Map the process as it works today",
        "Define rules, exceptions and ownership",
        "Roll out in stages and test the full journey",
      ],
      decision:
        "Simplify the process first. Automation should not preserve unnecessary steps or unclear accountability.",
      timing:
        "On request. The estimate accounts for workflow branches, integration readiness and failure handling.",
      budget: "On request, after agreeing the first scope of work.",
      example:
        "A purchase request follows approval rules based on its value, notifies owners and reaches the accounting system after approval.",
      tools: ["webhooks", "job queue", "operation history"],
      faq: [
        [
          "What should be automated first?",
          "Repetitive actions with clear inputs, rules and a measurable outcome.",
        ],
        [
          "What happens when an integration fails?",
          "Retries, deduplication and owner notifications need to be designed into the workflow.",
        ],
        [
          "What if an external system is unavailable?",
          "For critical steps we define permitted retries, escalation and how an operator can resume the workflow.",
        ],
        [
          "What should we automate first?",
          "Start with a frequent operation that has clear rules and measurable time costs. Review exceptions separately before adding them to the flow.",
        ],
      ],
    },
  },
  {
    slug: "crm-erp",
    group: "operate",
    ru: {
      title: "CRM и ERP-системы",
      intro:
        "Объединяем клиентские данные и операционные процессы в рабочую систему. Определяем модель данных, роли и жизненные циклы, прежде чем переходить к интерфейсам.",
      needs: [
        "Единая история взаимодействий с клиентами",
        "Учёт ресурсов, задач и операционных статусов",
        "Связь продаж с исполнением и внутренним учётом",
      ],
      deliverables: [
        "Модель данных и правила доступа",
        "Рабочие кабинеты и операционные маршруты",
        "План миграции и интеграции с существующими системами",
      ],
      workflow: [
        "Изучаем роли, данные и реальные операции",
        "Проектируем сущности и переходы состояний",
        "Переносим данные и внедряем по подразделениям",
      ],
      decision:
        "Выбор между настройкой готовой платформы и собственной системой определяется процессами, интеграциями и стоимостью дальнейшего развития.",
      timing:
        "По запросу. Срок зависит от модулей, качества справочников и объёма переноса данных.",
      budget: "По запросу, после согласования первого объёма работ.",
      example:
        "Рабочее место менеджера связывает клиента, заказ и документы, показывает статус оплаты и передаёт данные в учёт.",
      tools: ["ролевая модель", "SQL", "интеграция с учётом через API"],
      faq: [
        [
          "Обязательно разрабатывать CRM с нуля?",
          "Нет. Сначала сравниваем готовые платформы, их ограничения и возможности расширения.",
        ],
        [
          "Как переносить данные?",
          "После аудита структуры и качества: сопоставление полей, пробная миграция, проверка связей и согласованный план переключения.",
        ],
        [
          "Как переносится история клиентов?",
          "Согласуем сопоставление полей, правила поиска дублей и проверяем пробный перенос на согласованной выборке.",
        ],
        [
          "Можно ли внедрять систему по отделам?",
          "Да, если можно определить общие справочники и правила обмена с текущими системами на переходный период.",
        ],
      ],
    },
    en: {
      title: "CRM & ERP development",
      intro:
        "Bring customer information and operational processes into one usable system. Define the data model, roles and lifecycles before designing screens.",
      needs: [
        "A consistent history of customer interactions",
        "Resource, task and operational status management",
        "Connecting sales, delivery and internal records",
      ],
      deliverables: [
        "Data model and access rules",
        "Working dashboards and operational workflows",
        "Migration and existing-system integration plan",
      ],
      workflow: [
        "Study roles, data and real operations",
        "Design entities and state transitions",
        "Migrate data and introduce the system in stages",
      ],
      decision:
        "Configuration versus custom development depends on processes, integrations and the cost of continued evolution.",
      timing:
        "On request. Modules, reference data quality and migration scope determine the schedule.",
      budget: "On request, after agreeing the first scope of work.",
      example:
        "A sales workspace connects customer, order and documents, shows payment status and exchanges records with accounting.",
      tools: ["role-based access", "SQL", "accounting integration via API"],
      faq: [
        [
          "Must a CRM be built from scratch?",
          "No. We first compare available platforms, their constraints and extension options.",
        ],
        [
          "How is data migrated?",
          "After a structure and quality audit: field mapping, trial migration, relationship validation and an agreed switchover plan.",
        ],
        [
          "How is customer history migrated?",
          "Agree on field mapping and duplicate rules, then validate a trial migration with an agreed sample.",
        ],
        [
          "Can the rollout happen department by department?",
          "Yes, when shared reference data and exchange rules for the transition between systems can be agreed.",
        ],
      ],
    },
  },
  {
    slug: "saas-b2b",
    group: "build",
    ru: {
      title: "SaaS и B2B-платформы",
      intro:
        "Создаём основу продукта для нескольких организаций и разных ролей. Продумываем изоляцию данных, доступы и ключевой пользовательский путь от подключения до ежедневной работы.",
      needs: [
        "Корпоративный продукт с несколькими организациями",
        "Партнёрский портал или B2B-кабинет",
        "Продуктовая модель с тарифами и ограничениями",
      ],
      deliverables: [
        "Архитектура организаций, ролей и доступа",
        "Основной продуктовый сценарий и onboarding",
        "Основа биллинга и интеграций, если они входят в объём",
      ],
      workflow: [
        "Определяем пользователей и границы организаций",
        "Проверяем основной сценарий и модель доступа",
        "Запускаем ядро продукта и планируем развитие",
      ],
      decision:
        "На раннем этапе важно проверить полезность основного сценария, не усложняя продукт преждевременными функциями.",
      timing:
        "По запросу. Оценку определяют роли организаций, условия доступа, интеграции и сценарий подключения первого клиента.",
      budget: "По запросу, после согласования первого объёма работ.",
      example:
        "Партнёрский портал, в котором каждая организация приглашает сотрудников, подаёт заявки и видит доступные ей материалы.",
      tools: ["Next.js", "TypeScript", "разделение данных организаций"],
      faq: [
        [
          "Как разделяются данные организаций?",
          "Модель изоляции выбирается при проектировании и проверяется на уровне запросов, API и прав доступа.",
        ],
        [
          "Можно ли начать с MVP?",
          "Да. Определяем минимальный законченный сценарий и критерии, по которым можно оценить его полезность.",
        ],
        [
          "Что важно проверить на пилоте?",
          "Подключение организации, приглашение участников, ключевой рабочий сценарий и разделение доступа между организациями.",
        ],
        [
          "Нужно ли сразу запускать биллинг?",
          "Если первый этап служит проверке спроса и сценариев, достаточно согласовать модель тарифов. Автоматические платежи можно оценить отдельно.",
        ],
      ],
    },
    en: {
      title: "SaaS & B2B platforms",
      intro:
        "Build a product foundation for multiple organizations and roles. Consider data isolation, access and the journey from onboarding to everyday work.",
      needs: [
        "Multi-organization business products",
        "Partner portals and B2B workspaces",
        "Products with plans and usage entitlements",
      ],
      deliverables: [
        "Organization, role and access architecture",
        "Core product workflow and onboarding",
        "Billing and integration foundations when in scope",
      ],
      workflow: [
        "Define users and organization boundaries",
        "Validate the main workflow and access model",
        "Launch the product core and plan its evolution",
      ],
      decision:
        "Early work should validate the value of the core journey without premature feature complexity.",
      timing:
        "On request. Organization roles, access requirements, integrations and first-customer onboarding determine the estimate.",
      budget: "On request, after agreeing the first scope of work.",
      example:
        "A partner portal where each organization invites employees, submits requests and accesses only the material available to it.",
      tools: ["Next.js", "TypeScript", "tenant data isolation"],
      faq: [
        [
          "How is organizational data separated?",
          "The isolation model is designed upfront and tested at query, API and authorization levels.",
        ],
        [
          "Can we start with an MVP?",
          "Yes. We define a minimal complete workflow and criteria for assessing its usefulness.",
        ],
        [
          "What should a pilot validate?",
          "Organization setup, inviting participants, the primary workflow and access separation between organizations.",
        ],
        [
          "Do we need billing at launch?",
          "For an initial test of demand and workflows, agreeing the pricing model may be enough. Automated payments can be scoped separately.",
        ],
      ],
    },
  },
  {
    slug: "system-integration",
    group: "automate",
    ru: {
      title: "Интеграция систем",
      intro:
        "Связываем приложения так, чтобы данные проходили полный маршрут предсказуемо. Проектируем контракты API, обработку событий и поведение при сбоях.",
      needs: [
        "Обмен данными между внутренними и внешними сервисами",
        "Синхронизация справочников и операционных событий",
        "Замена ручного экспорта и повторного ввода",
      ],
      deliverables: [
        "Карта потоков и контракты данных",
        "API, адаптеры и обработчики событий",
        "Повторы, защита от дублей и диагностика ошибок",
      ],
      workflow: [
        "Изучаем API, ограничения и владельцев данных",
        "Определяем источник истины и контракты обмена",
        "Проверяем нормальные и аварийные сценарии",
      ],
      decision:
        "Надёжная интеграция учитывает не только успешный запрос, но и задержки, повторную доставку, изменения схем и недоступность сервиса.",
      timing:
        "По запросу. Учитываем доступ к тестовым средам, лимиты систем и объём исторических данных.",
      budget: "По запросу, после согласования первого объёма работ.",
      example:
        "Заказы из магазина попадают в учёт, а статусы и остатки возвращаются обратно. Ошибки видны в журнале обмена.",
      tools: ["REST API", "вебхуки", "схемы и сверка данных"],
      faq: [
        [
          "Можно ли интегрировать старую систему?",
          "Зависит от доступных интерфейсов: API, файлового обмена, очередей или доступа к данным. Сначала проверяем допустимый способ.",
        ],
        [
          "Как избежать дублирования?",
          "Используем идентификаторы операций, идемпотентность и согласованные правила разрешения конфликтов.",
        ],
        [
          "Что будет, если сообщение придёт дважды?",
          "Согласуем уникальные ключи и правила повторной обработки, чтобы повтор не создавал вторую операцию.",
        ],
        [
          "Можно ли синхронизировать системы без API?",
          "Иногда достаточно согласованного обмена файлами. Сначала проверяем форматы, частоту и способ безопасной доставки.",
        ],
      ],
    },
    en: {
      title: "System integration",
      intro:
        "Connect applications so data follows a predictable end-to-end route. Design API contracts, event handling and failure behavior together.",
      needs: [
        "Data exchange across internal and external services",
        "Reference data and operational event synchronization",
        "Replacing manual exports and repeated entry",
      ],
      deliverables: [
        "Flow map and data contracts",
        "APIs, adapters and event handlers",
        "Retries, deduplication and failure diagnostics",
      ],
      workflow: [
        "Study APIs, constraints and data ownership",
        "Define sources of truth and exchange contracts",
        "Validate both normal and failure scenarios",
      ],
      decision:
        "Reliable integration includes delays, redelivery, schema changes and service outages—not only successful requests.",
      timing:
        "On request. Test environment access, system limits and the volume of historical data shape the estimate.",
      budget: "On request, after agreeing the first scope of work.",
      example:
        "Store orders reach accounting, while statuses and stock levels flow back. Exchange errors are visible in a log.",
      tools: ["REST API", "webhooks", "data schemas and reconciliation"],
      faq: [
        [
          "Can a legacy system be integrated?",
          "It depends on its available interfaces: APIs, file exchange, queues or permitted data access. We assess the appropriate route first.",
        ],
        [
          "How are duplicates prevented?",
          "Through operation identifiers, idempotency and agreed conflict-resolution rules.",
        ],
        [
          "What if a message arrives twice?",
          "Agree on unique keys and retry rules so a duplicate message cannot create a second operation.",
        ],
        [
          "Can systems be connected without an API?",
          "A scheduled file exchange can work. First we assess formats, frequency and secure delivery options.",
        ],
      ],
    },
  },
  {
    slug: "cloud-devops",
    group: "operate",
    ru: {
      title: "Облачная инфраструктура и DevOps",
      intro:
        "Подготавливаем среду, в которой продукт можно собирать, проверять и выпускать повторяемо. Соединяем инфраструктуру, поставку изменений и наблюдаемость.",
      needs: [
        "Повторяемая сборка и развёртывание",
        "Разделение окружений и управление конфигурацией",
        "Наблюдаемость и план восстановления",
      ],
      deliverables: [
        "Конфигурация окружений и pipeline поставки",
        "Проверки готовности и диагностические сигналы",
        "План резервирования и восстановления по согласованным требованиям",
      ],
      workflow: [
        "Определяем ограничения и требования эксплуатации",
        "Описываем инфраструктуру и поставку изменений",
        "Проверяем запуск, откат и восстановление",
      ],
      decision:
        "Облако и инструменты выбираем по требованиям продукта, доступности платформы и возможностям команды сопровождения.",
      timing:
        "По запросу. В оценку входят аудит окружений, перенос данных и проверка восстановления.",
      budget: "По запросу, после согласования первого объёма работ.",
      example:
        "Изменения проходят автоматические проверки и тестовое окружение. Выпуск сопровождается журналом и инструкцией по откату.",
      tools: ["Git", "контейнеры", "конвейер сборки и развёртывания"],
      faq: [
        [
          "Нужен ли Kubernetes каждому продукту?",
          "Нет. Сложность платформы должна быть оправдана требованиями, а не популярностью инструмента.",
        ],
        [
          "Что входит в готовность к эксплуатации?",
          "Запуск, конфигурация, доступы, диагностика, резервирование и проверенный план действий при сбое.",
        ],
        [
          "Как выбирается место размещения?",
          "Сравниваем доступные облака и собственную инфраструктуру по требованиям к данным, бюджету и работе вашей команды.",
        ],
        [
          "Как проверяется восстановление?",
          "Согласуем допустимую потерю данных и время простоя, затем проверяем восстановление резервной копии в отдельной среде.",
        ],
      ],
    },
    en: {
      title: "Cloud & DevOps",
      intro:
        "Prepare an environment where a product can be built, checked and released repeatably. Connect infrastructure, delivery and observability.",
      needs: [
        "Repeatable builds and deployments",
        "Separated environments and configuration management",
        "Observability and a recovery plan",
      ],
      deliverables: [
        "Environment configuration and delivery pipeline",
        "Readiness checks and diagnostic signals",
        "Backup and recovery plans based on agreed requirements",
      ],
      workflow: [
        "Define operational constraints and needs",
        "Describe infrastructure and change delivery",
        "Test startup, rollback and recovery",
      ],
      decision:
        "Cloud services and tools should match the product, platform availability and the operating team’s capabilities.",
      timing:
        "On request. The estimate includes environment assessment, data migration and recovery testing.",
      budget: "On request, after agreeing the first scope of work.",
      example:
        "Changes pass automated checks and staging. Releases have an audit trail and rollback instructions.",
      tools: ["Git", "containers", "build and deployment pipelines"],
      faq: [
        [
          "Does every product need Kubernetes?",
          "No. Platform complexity should be justified by requirements rather than tool popularity.",
        ],
        [
          "What defines operational readiness?",
          "Startup, configuration, access, diagnostics, backups and a tested response plan for failures.",
        ],
        [
          "How is the hosting environment chosen?",
          "Compare available clouds and private infrastructure against data requirements, budget and your team’s operating model.",
        ],
        [
          "How is recovery tested?",
          "Agree on acceptable data loss and downtime, then test a backup restore in a separate environment.",
        ],
      ],
    },
  },
  {
    slug: "ui-ux-design",
    group: "design",
    ru: {
      title: "UI/UX-дизайн",
      intro:
        "Превращаем сложные процессы в понятные интерфейсы. Начинаем с задач пользователей и проверяем сценарии до того, как детализировать визуальный язык.",
      needs: [
        "Новый цифровой продукт или сложный кабинет",
        "Неочевидные пользовательские пути и ошибки интерфейса",
        "Единый язык компонентов для развития продукта",
      ],
      deliverables: [
        "Сценарии, информационная архитектура и прототип",
        "Адаптивные макеты и состояния компонентов",
        "Дизайн-система и описание взаимодействий",
      ],
      workflow: [
        "Исследуем задачи и ограничения интерфейса",
        "Проверяем структуру и интерактивный прототип",
        "Детализируем визуальную систему и передачу в разработку",
      ],
      decision:
        "Красивый интерфейс должен помогать действовать: понимать статус, принимать решение и исправлять ошибку.",
      timing:
        "По запросу. Срок зависит от числа сценариев, наличия исследований и возможности проверить прототип с пользователями.",
      budget: "По запросу, после согласования первого объёма работ.",
      example:
        "Кликабельный прототип кабинета клиента, набор компонентов и спецификация состояний ввода, ожидания и ошибки.",
      tools: [
        "интерактивный прототип",
        "библиотека компонентов",
        "проверки WCAG",
      ],
      faq: [
        [
          "Можно ли начать с редизайна одного сценария?",
          "Да. Выбираем проблемный путь, определяем цель и проверяем изменение на ограниченном участке продукта.",
        ],
        [
          "Дизайн учитывает ошибки и загрузку?",
          "Да. Пустые состояния, ожидание, ошибки, права доступа и адаптивность являются частью интерфейса.",
        ],
        [
          "Можно ли проверить дизайн до разработки?",
          "Да. Проверяем основные действия на прототипе и уточняем непонятные шаги до подготовки макетов к реализации.",
        ],
        [
          "Как дизайн передаётся разработчикам?",
          "Передаём структуру компонентов, состояния, адаптивные правила и критерии проверки ключевых сценариев.",
        ],
      ],
    },
    en: {
      title: "UI/UX design",
      intro:
        "Turn complex processes into understandable interfaces. Start with user tasks and validate journeys before refining the visual language.",
      needs: [
        "New digital products or complex workspaces",
        "Unclear journeys and interface errors",
        "A consistent component language for product evolution",
      ],
      deliverables: [
        "Journeys, information architecture and prototype",
        "Responsive screens and component states",
        "Design system and interaction specifications",
      ],
      workflow: [
        "Explore tasks and interface constraints",
        "Validate structure and interactive prototype",
        "Refine the visual system and development handoff",
      ],
      decision:
        "A good interface helps people act: understand status, make decisions and recover from errors.",
      timing:
        "On request. The schedule depends on the number of flows, available research and access to prototype participants.",
      budget: "On request, after agreeing the first scope of work.",
      example:
        "A clickable client portal prototype, component library and specifications for input, loading and error states.",
      tools: ["interactive prototyping", "component library", "WCAG checks"],
      faq: [
        [
          "Can a redesign start with one workflow?",
          "Yes. We choose a problematic journey, define its goal and validate a focused change.",
        ],
        [
          "Does design include errors and loading?",
          "Yes. Empty states, waiting, errors, permissions and responsiveness are part of the interface.",
        ],
        [
          "Can we validate the design before development?",
          "Yes. We test key actions on a prototype and clarify difficult steps before handing off the final designs.",
        ],
        [
          "How are designs handed over to developers?",
          "We provide component structure, states, responsive rules and acceptance criteria for critical flows.",
        ],
      ],
    },
  },
  {
    slug: "business-analysis-qa",
    group: "design",
    ru: {
      title: "Бизнес-анализ и QA",
      intro:
        "Делаем требования проверяемыми, а качество — частью процесса разработки. Уточняем правила, риски и критерии готовности до выпуска изменений.",
      needs: [
        "Неясные требования и разные ожидания участников",
        "Критические сценарии с высокой ценой ошибки",
        "Проверки перед запуском или развитием продукта",
      ],
      deliverables: [
        "Карта требований и критерии приёмки",
        "Тестовые сценарии и приоритизация рисков",
        "Результаты проверок и рекомендации по автоматизации",
      ],
      workflow: [
        "Уточняем процессы, правила и ожидаемый результат",
        "Выбираем проверки по рискам и критическим путям",
        "Проверяем изменения и фиксируем основания готовности",
      ],
      decision:
        "Проверки должны подтверждать поведение продукта, а не только формально увеличивать число тестов.",
      timing:
        "По запросу. Влияют число критичных сценариев, наличие тестовых данных и доступ к среде.",
      budget: "По запросу, после согласования первого объёма работ.",
      example:
        "Карта требований к оформлению заказа, матрица проверок и список дефектов с приоритетом и шагами воспроизведения.",
      tools: ["сценарии приёмки", "Playwright", "проверки API"],
      faq: [
        [
          "Когда подключать QA?",
          "На этапе требований: ранние вопросы часто предотвращают ошибки, которые дороже исправлять после разработки.",
        ],
        [
          "Все проверки нужно автоматизировать?",
          "Нет. Автоматизация полезна для повторяющихся стабильных сценариев; исследовательские проверки и оценка удобства требуют отдельного подхода.",
        ],
        [
          "Что нужно для начала тестирования?",
          "Доступ к согласованной среде, тестовые роли и данные, перечень ключевых сценариев и ожидаемое поведение.",
        ],
        [
          "Как приоритизируются дефекты?",
          "Учитываем влияние на пользователей и бизнес, вероятность, наличие обходного пути и риски исправления перед релизом.",
        ],
      ],
    },
    en: {
      title: "Business analysis & QA",
      intro:
        "Make requirements testable and quality part of delivery. Clarify rules, risks and readiness criteria before releasing changes.",
      needs: [
        "Unclear requirements and conflicting expectations",
        "Critical journeys with costly failure modes",
        "Validation before launch or product expansion",
      ],
      deliverables: [
        "Requirement map and acceptance criteria",
        "Test scenarios and risk prioritization",
        "Validation findings and automation recommendations",
      ],
      workflow: [
        "Clarify processes, rules and expected results",
        "Select checks around risks and critical paths",
        "Validate changes and document release evidence",
      ],
      decision:
        "Checks should establish product behavior rather than merely increase a test count.",
      timing:
        "On request. The number of critical journeys, availability of test data and environment access affect the schedule.",
      budget: "On request, after agreeing the first scope of work.",
      example:
        "A checkout requirements map, test matrix and prioritized defects with reproduction steps.",
      tools: ["acceptance scenarios", "Playwright", "API checks"],
      faq: [
        [
          "When should QA be involved?",
          "During requirements work: early questions often prevent defects that cost more to fix after implementation.",
        ],
        [
          "Should every check be automated?",
          "No. Repeated stable workflows benefit from automation; exploratory testing and usability evaluation need a different approach.",
        ],
        [
          "What do you need to start testing?",
          "Access to an agreed environment, test roles and data, plus key workflows and their expected behavior.",
        ],
        [
          "How are defects prioritized?",
          "Consider user and business impact, likelihood, workarounds and the cost of fixing the issue before release.",
        ],
      ],
    },
  },
];
export const serviceSlugs: string[] = services.map((service) => service.slug);
export const serviceTitles = Object.fromEntries(
  services.map((service) => [
    service.slug,
    { ru: service.ru.title, en: service.en.title },
  ]),
);
export function getService(slug: string) {
  return services.find((service) => service.slug === slug);
}
