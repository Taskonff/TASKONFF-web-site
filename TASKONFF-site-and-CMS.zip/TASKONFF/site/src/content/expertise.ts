const industryItems = {
  ru: [
    {
      name: "Розничная и онлайн-торговля",
      iconId: "ShoppingBag",
      serviceSlugs: ["web-mobile", "system-integration"],
      title: "Единый путь от каталога до исполнения.",
      text: "Связать витрину, остатки, заказы и работу с покупателями. Детали зависят от модели продаж и существующих систем.",
      steps: [
        ["Каталог", "Согласованные карточки, цены и правила публикации."],
        ["Заказ", "Понятный путь покупки и состояния заказа."],
        ["Исполнение", "Передача в учёт, уведомления и обработка исключений."],
      ],
      guard:
        "Предусмотреть ошибки оплаты, рассинхронизацию остатков и защиту персональных данных.",
    },
    {
      name: "Логистика",
      iconId: "Truck",
      serviceSlugs: ["business-automation", "system-integration"],
      title: "События поставки становятся понятным процессом.",
      text: "Объединить заявки, статусы перемещения и документы в одном операционном интерфейсе.",
      steps: [
        ["Заявка", "Структурированные вводные и правила обработки."],
        ["Маршрут", "События, ответственные и актуальные статусы."],
        ["Документы", "Связь подтверждений с операциями и исключениями."],
      ],
      guard:
        "Учитывать задержки данных, повторные события и работу с неполной информацией.",
    },
    {
      name: "Профессиональные услуги",
      iconId: "Building2",
      serviceSlugs: ["saas-b2b", "business-automation"],
      title: "Меньше ручной координации между командами.",
      text: "Кабинет клиента, управление задачами и автоматизация согласований вокруг оказания услуги.",
      steps: [
        ["Запрос", "Единая точка входа и уточнение задачи."],
        ["Работа", "Ответственные, доступы и согласования."],
        ["Результат", "Передача материалов и история изменений."],
      ],
      guard:
        "Разграничить доступ между клиентами и определить правила хранения документов.",
    },
    {
      name: "Финансовые сервисы",
      iconId: "Landmark",
      serviceSlugs: ["custom-software", "business-analysis-qa"],
      title: "Контролируемая обработка данных и операций.",
      text: "Внутренний операционный кабинет или автоматизация сверок. Требования к регулированию определяются отдельно.",
      steps: [
        ["Данные", "Проверка источников, форматов и полноты."],
        ["Правила", "Согласованная логика обработки и эскалации."],
        ["Контроль", "Проверяемые действия и доступ по ролям."],
      ],
      guard:
        "Определить правила доступа и оценить применимые регуляторные требования до разработки.",
    },
    {
      name: "Медицина и сервисы здоровья",
      iconId: "HeartPulse",
      serviceSlugs: ["web-mobile", "ui-ux-design"],
      title: "Цифровые сценарии с вниманием к чувствительным данным.",
      text: "Запись, административные процессы и взаимодействие с пользователями. Клинические решения требуют отдельной экспертизы.",
      steps: [
        [
          "Обращение",
          "Понятный пользовательский путь и сбор минимальных данных.",
        ],
        ["Координация", "Расписание, роли и события обслуживания."],
        ["Доступ", "Разделение прав и правил обработки информации."],
      ],
      guard:
        "До разработки определить правовое основание обработки данных и ограничения административной системы.",
    },
    {
      name: "Производство",
      iconId: "Factory",
      serviceSlugs: ["crm-erp", "system-integration"],
      title: "Операционная информация без разрозненных таблиц.",
      text: "Рабочие кабинеты для планирования, учёта задач и регистрации событий производства.",
      steps: [
        ["План", "Связь задач, ресурсов и ограничений."],
        ["Операции", "Фиксация выполнения и причин отклонений."],
        ["Обзор", "Актуальные данные для ответственных ролей."],
      ],
      guard:
        "Сначала изучить источники данных, доступность оборудования и допустимый уровень вмешательства в процессы.",
    },
  ],
  en: [
    {
      name: "Retail & e-commerce",
      iconId: "ShoppingBag",
      serviceSlugs: ["web-mobile", "system-integration"],
      title: "A connected journey from catalog to fulfillment.",
      text: "Connect the storefront, inventory, orders and customer operations. Details depend on the sales model and existing systems.",
      steps: [
        ["Catalog", "Consistent product data, prices and publishing rules."],
        ["Order", "A clear purchasing journey and order states."],
        [
          "Fulfillment",
          "Handoff to operations, notifications and exception handling.",
        ],
      ],
      guard:
        "Plan for payment errors, inventory drift and personal-data protection.",
    },
    {
      name: "Logistics",
      iconId: "Truck",
      serviceSlugs: ["business-automation", "system-integration"],
      title: "Delivery events become a clear operating process.",
      text: "Bring requests, movement status and documents into a single operational interface.",
      steps: [
        ["Request", "Structured inputs and processing rules."],
        ["Journey", "Events, owners and current statuses."],
        ["Documents", "Connect evidence to operations and exceptions."],
      ],
      guard:
        "Account for delayed data, duplicate events and incomplete information.",
    },
    {
      name: "Professional services",
      iconId: "Building2",
      serviceSlugs: ["saas-b2b", "business-automation"],
      title: "Less manual coordination between teams.",
      text: "Customer workspaces, task management and automated approvals organized around service delivery.",
      steps: [
        ["Request", "A consistent entry point and scope clarification."],
        ["Delivery", "Ownership, access and approvals."],
        ["Result", "Material handoff and change history."],
      ],
      guard: "Separate client access and define document-retention rules.",
    },
    {
      name: "Financial services",
      iconId: "Landmark",
      serviceSlugs: ["custom-software", "business-analysis-qa"],
      title: "Controlled handling of data and operations.",
      text: "Internal operating workspaces or automated reconciliation. Regulatory requirements need a separate assessment.",
      steps: [
        ["Data", "Check sources, formats and completeness."],
        ["Rules", "Agreed processing and escalation logic."],
        ["Control", "Traceable actions and role-based access."],
      ],
      guard:
        "Define access rules and assess applicable regulatory requirements before development.",
    },
    {
      name: "Health services",
      iconId: "HeartPulse",
      serviceSlugs: ["web-mobile", "ui-ux-design"],
      title: "Digital journeys that respect sensitive information.",
      text: "Scheduling, administrative workflows and user interactions. Clinical decisions need separate expertise.",
      steps: [
        ["Intake", "Clear journeys and minimum necessary data."],
        ["Coordination", "Schedules, roles and service events."],
        ["Access", "Separate permissions and processing rules."],
      ],
      guard:
        "Define lawful processing grounds and the administrative system’s limits before development.",
    },
    {
      name: "Manufacturing",
      iconId: "Factory",
      serviceSlugs: ["crm-erp", "system-integration"],
      title: "Operational information beyond disconnected spreadsheets.",
      text: "Workspaces for planning, task tracking and recording production events.",
      steps: [
        ["Plan", "Connect tasks, resources and constraints."],
        ["Operations", "Record execution and reasons for deviations."],
        ["Overview", "Current information for responsible roles."],
      ],
      guard:
        "Assess data sources, equipment availability and permitted interventions before designing integrations.",
    },
  ],
};
export const expertiseCopy = {
  ru: {
    services: {
      label: "Услуги",
      title: "Разработка и автоматизация\nбизнес-систем.",
      description:
        "От отдельного интерфейса до связанной цифровой системы. Выберите направление и узнайте, какие задачи оно решает, что входит в работу и с чего начать.",
      sectionLabel: "НАПРАВЛЕНИЯ РАЗРАБОТКИ",
      sectionTitle: "От цели —\nк нужным инструментам.",
      engagementLabel: "КАК ВЫБРАТЬ НАПРАВЛЕНИЕ",
      engagementTitle: "Можно начать\nс самой задачи.",
      engagementText:
        "Не обязательно заранее выбирать услугу или стек. Достаточно описать текущий процесс, пользователей и то, что должно измениться. Несколько направлений могут стать частями одного решения.",
      processLink: "Посмотреть процесс работы",
      catalog: {
        categoriesLabel: "Направления услуг",
        all: "Все направления",
        resultLabel: "Найдено направлений",
        detailLink: "Подробнее об услуге",
        emptyTitle: "Такого направления не найдено",
        emptyText: "Выберите другую группу или покажите все направления.",
        reset: "Сбросить фильтры",
      },
    },
    detail: {
      timingLabel: "Срок проекта",
      budgetLabel: "Бюджет",
      exampleLabel: "Пример результата",
      toolsLabel: "Инструменты по задаче",
      faqLabel: "ВОПРОСЫ И ОТВЕТЫ",
      needsLabel: "КОГДА ЭТО НУЖНО",
      needsTitle: "Задачи,\nс которых начинаем.",
      outputsLabel: "РЕЗУЛЬТАТ РАБОТЫ",
      outputsTitle: "Что определяем\nи создаём.",
      scopeNote:
        "Точный состав и критерии готовности согласовываются после изучения задачи.",
      workflowLabel: "ПОДХОД К ЗАДАЧЕ",
      workflowTitle: "Этапы работы\nнад решением.",
      faqTitle: "Перед стартом.",
      relatedTitle: "Рядом с этой задачей.",
      ctaTitle: "Обсудим вашу задачу?",
    },
    industries: {
      label: "Отрасли",
      title: "Разные процессы.\nСистемный подход.",
      description:
        "В разных отраслях данные, роли и правила работы устроены по-разному. Выберите отрасль, чтобы найти подходящие услуги и рассмотреть рабочий сценарий.",
      sectionTitle: "Над какими задачами\nможем помочь.",
      principlesLabel: "ПЕРЕД РАЗРАБОТКОЙ",
      principlesTitle: "Сначала контекст.\nПотом архитектура.",
      principles: [
        [
          "Процессы",
          "Изучаем реальную последовательность действий, участников и исключения.",
        ],
        [
          "Данные",
          "Определяем источники истины, качество информации и необходимые права доступа.",
        ],
        [
          "Ограничения",
          "Уточняем инфраструктуру, требования к безопасности и применимые правила.",
        ],
      ],
      tabsLabel: "Отраслевая навигация",
      scenarioLabel: "РАБОЧИЙ СЦЕНАРИЙ",
      servicesLabel: "Подходящие услуги",
      cta: "Обсудим процессы в вашей отрасли?",
      stepsLabel: "Этапы сценария",
      items: industryItems.ru,
    },
  },
  en: {
    services: {
      label: "Services",
      title: "Technology around\nyour challenge.",
      description:
        "From one interface to a connected digital system. Explore each service, the problems it addresses, what the work includes and where to begin.",
      sectionLabel: "AREAS OF EXPERTISE",
      sectionTitle: "From your goal\nto the right tools.",
      engagementLabel: "WHERE TO START",
      engagementTitle: "Start with\nthe problem itself.",
      engagementText:
        "You do not need to choose a service or stack upfront. Describe the current process, its users and what needs to change. Several areas can become parts of one solution.",
      processLink: "Explore our process",
      catalog: {
        categoriesLabel: "Service categories",
        all: "All services",
        resultLabel: "Services found",
        detailLink: "Explore this service",
        emptyTitle: "No services found",
        emptyText: "Choose a different group or show all services.",
        reset: "Clear filters",
      },
    },
    detail: {
      timingLabel: "Project timeline",
      budgetLabel: "Budget",
      exampleLabel: "Example deliverable",
      toolsLabel: "Tools selected for the scope",
      faqLabel: "QUESTIONS & ANSWERS",
      needsLabel: "WHEN IT HELPS",
      needsTitle: "Challenges\nwe start with.",
      outputsLabel: "WORK OUTPUTS",
      outputsTitle: "What we define\nand build.",
      scopeNote:
        "Exact scope and acceptance criteria are agreed after exploring your requirements.",
      workflowLabel: "DELIVERY APPROACH",
      workflowTitle: "How delivery\ntakes shape.",
      faqTitle: "Before we start.",
      relatedTitle: "Related capabilities.",
      ctaTitle: "Let’s explore your challenge.",
    },
    industries: {
      label: "Industries",
      title: "Different industries.\nA systematic approach.",
      description:
        "Different industries organize data, roles and operations in different ways. Choose an industry to explore a workflow and the services that can support it.",
      sectionTitle: "Where we\ncan help.",
      principlesLabel: "BEFORE DEVELOPMENT",
      principlesTitle: "Context first.\nArchitecture next.",
      principles: [
        [
          "Processes",
          "Understand the actual sequence of actions, participants and exceptions.",
        ],
        [
          "Data",
          "Identify sources of truth, data quality and necessary access permissions.",
        ],
        [
          "Constraints",
          "Clarify infrastructure, security requirements and applicable rules.",
        ],
      ],
      tabsLabel: "Industry navigation",
      scenarioLabel: "WORKFLOW",
      servicesLabel: "Relevant services",
      cta: "Explore a solution for your industry.",
      stepsLabel: "Scenario stages",
      items: industryItems.en,
    },
  },
};
