import {
  ArrowUpRight,
  Building2,
  Clock,
  Instagram,
  Linkedin,
  Mail,
  MapPin,
  Phone,
  Send,
} from "lucide-react";
import type { SiteSettings } from "@/cms/defaults";
import type { Locale } from "@/content/site";
import { contactEmailHref, contactSocialHref } from "@/lib/contact-details";
import "./contact-details.css";

const labels = {
  ru: {
    email: "Электронная почта",
    phone: "Телефон",
    city: "Город",
    address: "Адрес офиса",
    social: "Социальные сети",
    example: "Пример оформления контактов",
    exampleAddress: "Ташкент, ул. Примерная, 10",
    hours: "Часы ответа",
    registration: "Регистрационный номер",
  },
  en: {
    email: "Email",
    phone: "Phone",
    city: "City",
    address: "Office address",
    social: "Social media",
    example: "Example contact details",
    exampleAddress: "10 Example Street, Tashkent",
    hours: "Response hours",
    registration: "Registration number",
  },
};

export function ContactDetails({
  settings,
  locale,
  className = "",
  example = false,
}: {
  settings: SiteSettings;
  locale: Locale;
  className?: string;
  example?: boolean;
}) {
  const copy = labels[locale];
  const details: SiteSettings = example
    ? {
        contactPhone: "+1 202 555 0147",
        contactEmail: "hello@taskonff.example",
        telegram: "taskonff_example",
        address: copy.exampleAddress,
      }
    : settings;
  const phone = details.contactPhone?.replace(/[^+\d]/g, "");
  const telegram = details.telegram;
  const socials = [
    {
      name: "Instagram",
      icon: Instagram,
      href: contactSocialHref("instagram", details.instagram),
    },
    {
      name: "LinkedIn",
      icon: Linkedin,
      href: contactSocialHref("linkedin", details.linkedin),
    },
  ].filter(({ href }) => href || example);
  const items = [
    {
      key: "phone",
      icon: Phone,
      label: copy.phone,
      text: details.contactPhone,
      href: phone && /^\+?\d{5,20}$/.test(phone) ? `tel:${phone}` : undefined,
    },
    {
      key: "email",
      icon: Mail,
      label: copy.email,
      text: details.contactEmail,
      href: contactEmailHref(details.contactEmail),
    },
    {
      key: "telegram",
      icon: Send,
      label: "Telegram",
      text: telegram ? `@${telegram}` : undefined,
      href:
        telegram && /^[a-zA-Z][a-zA-Z0-9_]{4,31}$/.test(telegram)
          ? `https://t.me/${telegram}`
          : undefined,
    },
    {
      key: "city",
      icon: Building2,
      label: copy.city,
      text: details.city?.[locale],
    },
    {
      key: "address",
      icon: MapPin,
      label: copy.address,
      text: details.address,
    },
    {
      key: "hours",
      icon: Clock,
      label: copy.hours,
      text: details.responseHours?.[locale],
    },
  ].filter((item) => item.text);
  if (items.length === 0 && socials.length === 0) return null;
  return (
    <>
      {example && (
        <span className="public-contact-example-label">{copy.example}</span>
      )}
      <dl className={`public-contact-list ${className}`.trim()}>
        {items.map(({ key, icon: Icon, label, text, href }) => {
          const external = href?.startsWith("https://");
          return (
            <div className="public-contact-item" data-contact={key} key={key}>
              <dt>
                <Icon size={16} aria-hidden="true" />
                {label}
              </dt>
              <dd>
                {href && !example ? (
                  <a
                    href={href}
                    target={external ? "_blank" : undefined}
                    rel={external ? "noopener noreferrer" : undefined}
                  >
                    <span>{text}</span>
                    {external && <ArrowUpRight size={14} aria-hidden="true" />}
                  </a>
                ) : (
                  <span className="public-contact-value">{text}</span>
                )}
              </dd>
            </div>
          );
        })}
        {socials.length > 0 && (
          <div className="public-contact-item" data-contact="social">
            <dt>{copy.social}</dt>
            <dd className="public-social-links">
              {socials.map(({ name, icon: Icon, href }) =>
                href ? (
                  <a
                    className="public-social-icon"
                    key={name}
                    href={href}
                    aria-label={name}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Icon size={20} aria-hidden="true" />
                  </a>
                ) : (
                  <span
                    className="public-social-icon"
                    key={name}
                    role="img"
                    aria-label={name}
                  >
                    <Icon size={20} aria-hidden="true" />
                  </span>
                ),
              )}
            </dd>
          </div>
        )}
      </dl>
    </>
  );
}

export function OrganizationDetails({
  settings,
  locale,
}: {
  settings: SiteSettings;
  locale: Locale;
}) {
  const name = settings.legalName?.[locale];
  const registration = settings.legalRegistration;
  if (!name && !registration) return null;
  return (
    <p className="public-organization">
      {name}
      {name && registration && " · "}
      {registration && `${labels[locale].registration}: ${registration}`}
    </p>
  );
}
