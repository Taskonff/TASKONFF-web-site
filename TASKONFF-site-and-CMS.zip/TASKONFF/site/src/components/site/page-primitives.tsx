import { getSiteData } from "@/cms/site-data";
import Link from "next/link";
import { ArrowLeft, ArrowRight } from "lucide-react";
import type { Locale } from "@/content/site";
import { Reveal } from "@/components/home/reveal";
export async function InternalHero({
  locale,
  eyebrow,
  title,
  description,
  parent,
  actions,
  children,
}: {
  locale: Locale;
  eyebrow: string;
  title: string;
  description: string;
  parent?: { href: string; label: string };
  actions?: React.ReactNode;
  children?: React.ReactNode;
}) {
  const data = await getSiteData();
  return (
    <section className="internal-hero" id="top">
      <div className="internal-hero-grid" aria-hidden="true" />
      <div className="container">
        <nav
          className="breadcrumbs"
          aria-label={locale === "ru" ? "Хлебные крошки" : "Breadcrumbs"}
        >
          <Link href={`/${locale}`}>
            <ArrowLeft size={13} aria-hidden="true" />
            {data.shared[locale].homeLabel}
          </Link>
          <span>/</span>
          {parent && (
            <>
              <Link href={parent.href}>{parent.label}</Link>
              <span>/</span>
            </>
          )}
          <span aria-current="page">{parent ? title : eyebrow}</span>
        </nav>
        <div className="internal-hero-content">
          <Reveal>
            <p className="eyebrow">
              <span className="eyebrow-cross" aria-hidden="true">
                +
              </span>
              {eyebrow}
            </p>
            <h1>{title}</h1>
            <p className="internal-intro">{description}</p>
            {actions}
          </Reveal>
          <div className="internal-hero-art">
            {children ?? (
              <div className="page-sculpture" aria-hidden="true">
                <div />
                <div />
                <div />
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
export async function PageCTA({
  locale,
  title,
  description,
}: {
  locale: Locale;
  title?: string;
  description?: string;
}) {
  const data = await getSiteData();
  const c = data.shared[locale].cta;
  return (
    <section className="internal-cta">
      <div className="container">
        <Reveal>
          <p className="eyebrow">{c.eyebrow}</p>
          <h2>{title ?? c.title}</h2>
          <p>{description ?? c.description}</p>
        </Reveal>
        <Link className="internal-cta-link" href={`/${locale}/contact`}>
          <span>{c.button}</span>
          <ArrowRight size={32} aria-hidden="true" />
        </Link>
      </div>
    </section>
  );
}
