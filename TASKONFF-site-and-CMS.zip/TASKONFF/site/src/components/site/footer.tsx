import { getSiteData } from "@/cms/site-data";
import Link from "next/link";
import { BrandLogo } from "@/components/brand-logo";
import {
  ContactDetails,
  OrganizationDetails,
} from "@/components/site/contact-details";
import { hasContactDetails } from "@/lib/contact-details";
import { type Locale } from "@/content/site";
import { pageSlugs, productNavLabel } from "@/lib/routes";
import "./corporate-footer.css";
export async function Footer({
  locale,
  logo,
}: {
  locale: Locale;
  logo?: string;
}) {
  const data = await getSiteData();
  const copy = data.site[locale];
  const pageNames = {
    ...data.shared[locale].navigation,
    products: productNavLabel[locale],
  };
  const brandName = data.settings.brandName || "TASKONFF";
  return (
    <footer className="footer site-footer corporate-footer">
      <div className="container">
        <div className="footer-directory">
          <div className="footer-brand">
            <Link
              href={`/${locale}`}
              className="company-name"
              aria-label={brandName}
            >
              <BrandLogo src={logo} name={brandName} />
            </Link>
            <p>{copy.footer}</p>
            <span>{data.shared[locale].brandTagline}</span>
            <OrganizationDetails settings={data.settings} locale={locale} />
          </div>
          <nav
            aria-label={locale === "ru" ? "Разделы сайта" : "Site directory"}
            className="footer-page-links"
          >
            <p className="footer-directory-heading">{copy.menu}</p>
            {pageSlugs
              .filter(
                (s) =>
                  s !== "privacy" &&
                  s !== "terms" &&
                  (s !== "portfolio" || data.cases.length > 0),
              )
              .map((slug) => (
                <Link key={slug} href={`/${locale}/${slug}`}>
                  {pageNames[slug]}
                </Link>
              ))}
          </nav>
          <nav aria-label={pageNames.services} className="footer-services">
            <p className="footer-directory-heading">{pageNames.services}</p>
            <div>
              {data.services.map((service) => (
                <Link
                  key={service.slug}
                  href={`/${locale}/services/${service.slug}`}
                >
                  {service[locale].title}
                </Link>
              ))}
            </div>
          </nav>
          <div className="footer-contact-column">
            <p className="footer-directory-heading">
              {locale === "ru" ? "Связаться" : "Get in touch"}
            </p>
            {hasContactDetails(data.settings, locale) ? (
              <ContactDetails
                settings={data.settings}
                locale={locale}
                className="footer-contacts"
              />
            ) : (
              <Link
                className="footer-contact-link"
                href={`/${locale}/contact#brief`}
              >
                {locale === "ru"
                  ? "Написать о проекте"
                  : "Send a project inquiry"}
              </Link>
            )}
          </div>
        </div>
        <div className="footer-bottom">
          <span>
            © {new Date().getFullYear()} {brandName}. {copy.rights}
          </span>
          <nav
            aria-label={
              locale === "ru" ? "Правовая информация" : "Legal information"
            }
          >
            <Link href={`/${locale}/privacy`}>{pageNames.privacy}</Link>
            <Link href={`/${locale}/terms`}>{pageNames.terms}</Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}
