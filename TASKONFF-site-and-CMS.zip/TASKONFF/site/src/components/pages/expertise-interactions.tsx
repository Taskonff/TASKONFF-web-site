"use client";
import Link from "next/link";
import { useId, useRef, useState, type KeyboardEvent } from "react";
import {
  ArrowRight,
  Building2,
  ShoppingBag,
  Truck,
  HeartPulse,
  Landmark,
  Factory,
  ShieldCheck,
} from "lucide-react";
import type { ServiceGroup } from "@/content/services";
import { useSiteContent } from "@/cms/site-context";
import type { Locale } from "@/content/site";
const groupIds: ServiceGroup[] = ["build", "automate", "operate", "design"];
export function ServiceCatalog({ locale }: { locale: Locale }) {
  const snapshot = useSiteContent();
  const { services, groups: serviceGroups } = snapshot;
  const c = snapshot.expertise[locale].services.catalog;
  const [group, setGroup] = useState<ServiceGroup | "all">("all");
  const detail = snapshot.expertise[locale].detail;
  const visible = services.filter(
    (service) => group === "all" || service.group === group,
  );
  return (
    <div className="expertise-catalog">
      <div
        className="expertise-filters"
        role="group"
        aria-label={c.categoriesLabel}
      >
        {(["all", ...groupIds] as const).map((id) => (
          <button
            key={id}
            type="button"
            aria-pressed={group === id}
            onClick={() => setGroup(id)}
          >
            {id === "all" ? c.all : serviceGroups[locale][id]}
          </button>
        ))}
      </div>
      <p className="expertise-result-count" aria-live="polite">
        {c.resultLabel}: {visible.length}
      </p>
      <div className="expertise-catalog-grid">
        {visible.map((service) => (
          <article key={service.slug} className="expertise-service-card">
            <p className="expertise-card-top">
              {serviceGroups[locale][service.group]}
            </p>
            <h3>{service[locale].title}</h3>
            <p>{service[locale].intro}</p>
            <dl className="expertise-card-facts">
              <div>
                <dt>{detail.exampleLabel}</dt>
                <dd>{service[locale].example}</dd>
              </div>
              <div>
                <dt>{detail.timingLabel}</dt>
                <dd>{service[locale].timing}</dd>
              </div>
            </dl>
            <Link
              className="expertise-card-link"
              href={`/${locale}/services/${service.slug}`}
            >
              <span>{c.detailLink}</span>
              <span className="sr-only"> — {service[locale].title}</span>
              <ArrowRight size={19} aria-hidden="true" />
            </Link>
          </article>
        ))}
      </div>
      {!visible.length && (
        <div className="expertise-no-results">
          <h3>{c.emptyTitle}</h3>
          <p>{c.emptyText}</p>
          <button type="button" onClick={() => setGroup("all")}>
            {c.reset}
            <ArrowRight size={15} />
          </button>
        </div>
      )}
    </div>
  );
}

const industryIcons: Record<string, typeof Building2> = {
  Building2,
  ShoppingBag,
  Truck,
  HeartPulse,
  Landmark,
  Factory,
};
export function IndustryExplorer({ locale }: { locale: Locale }) {
  const [active, setActive] = useState(0);
  const [step, setStep] = useState(0);
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  const uid = useId();
  const snapshot = useSiteContent();
  const c = snapshot.expertise[locale].industries;
  const items = c.items;
  const item = items[active];
  const Icon = industryIcons[item.iconId] ?? Building2;
  const related = snapshot.services.filter((service) =>
    item.serviceSlugs?.includes(service.slug),
  );
  function select(index: number) {
    setActive(index);
    setStep(0);
  }
  function navigate(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next = index;
    if (event.key === "ArrowDown" || event.key === "ArrowRight")
      next = (index + 1) % items.length;
    else if (event.key === "ArrowUp" || event.key === "ArrowLeft")
      next = (index + items.length - 1) % items.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = items.length - 1;
    else return;
    event.preventDefault();
    select(next);
    refs.current[next]?.focus();
  }
  return (
    <div className="expertise-industry-explorer">
      <div
        className="expertise-industry-tabs"
        role="tablist"
        aria-label={c.tabsLabel}
      >
        {items.map((industry, index) => {
          const TabIcon = industryIcons[industry.iconId] ?? Building2;
          return (
            <button
              key={industry.name}
              ref={(el) => {
                refs.current[index] = el;
              }}
              type="button"
              role="tab"
              id={`${uid}-tab-${index}`}
              aria-selected={active === index}
              aria-controls={`${uid}-panel`}
              tabIndex={active === index ? 0 : -1}
              onClick={() => select(index)}
              onKeyDown={(event) => navigate(event, index)}
            >
              <TabIcon size={18} />
              {industry.name}
              <ArrowRight size={15} aria-hidden="true" />
            </button>
          );
        })}
      </div>
      <div
        className="expertise-industry-panel"
        id={`${uid}-panel`}
        role="tabpanel"
        aria-labelledby={`${uid}-tab-${active}`}
        tabIndex={0}
        key={active}
      >
        <div className="expertise-industry-panel-top">
          <span>
            <Icon size={25} />
          </span>
          <small>{c.scenarioLabel}</small>
        </div>
        <h3>{item.title}</h3>
        <p>{item.text}</p>
        <div
          className="expertise-industry-flow"
          role="group"
          aria-label={c.stepsLabel}
        >
          {item.steps.map(([title], index) => (
            <button
              key={title}
              type="button"
              aria-pressed={step === index}
              aria-controls={`${uid}-detail`}
              onClick={() => setStep(index)}
            >
              <span>0{index + 1}</span>
              {title}
              {index < 2 && <ArrowRight size={14} />}
            </button>
          ))}
        </div>
        <p
          className="expertise-industry-step"
          id={`${uid}-detail`}
          aria-live="polite"
        >
          {item.steps[step][1]}
        </p>
        <div className="expertise-industry-guard">
          <ShieldCheck size={19} />
          <p>{item.guard}</p>
        </div>
        {!!related.length && (
          <div className="expertise-industry-services">
            <h4>{c.servicesLabel}</h4>
            <ul>
              {related.map((service) => (
                <li key={service.slug}>
                  <Link href={`/${locale}/services/${service.slug}`}>
                    {service[locale].title}
                    <ArrowRight size={15} aria-hidden="true" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
