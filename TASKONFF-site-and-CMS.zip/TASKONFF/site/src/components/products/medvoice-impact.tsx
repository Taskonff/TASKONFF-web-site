import { CalendarCheck, Clock, Headset, PhoneIncoming } from "lucide-react";
import { Reveal } from "@/components/home/reveal";
import type { Locale } from "@/content/site";
import "./medvoice-impact.css";

const copy = {
  ru: {
    example: "Расчётный пример",
    title: "Эффект для клиники в цифрах",
    intro: "Сценарий для клиники с 1 000 входящих звонков в месяц.",
    metrics: [
      ["Больше записей", "150 → 180 записей в месяц"],
      ["Дополнительных принятых звонков", "750 → 900 звонков в месяц"],
      ["Меньше времени операторов на звонках", "50 → 35 часов в месяц"],
      [
        "Круглосуточный приём звонков",
        "При настроенной телефонии и маршрутизации",
      ],
    ],
    note: "Фактические результаты проверяются на пилоте.",
    methodTitle: "Допущения примера",
    method:
      "Линия ИИ принимает 150 из 250 пропущенных звонков. При конверсии 20% это даёт 30 дополнительных записей. В примере ИИ самостоятельно обрабатывает новые звонки и 30% прежних разговоров средней длительностью 4 минуты, высвобождая 15 часов оператора.",
  },
  en: {
    example: "Illustrative scenario",
    title: "What the impact could look like for a clinic",
    intro: "An example clinic receives 1,000 calls a month.",
    metrics: [
      ["More appointments booked", "150 → 180 appointments per month"],
      ["Additional calls answered", "750 → 900 calls answered per month"],
      ["Less operator time on calls", "50 → 35 hours per month"],
      [
        "Round-the-clock call coverage",
        "With configured telephony and routing",
      ],
    ],
    note: "A pilot measures actual results.",
    methodTitle: "Scenario assumptions",
    method:
      "The AI line handles 150 of 250 missed calls. At a 20% booking conversion rate, this adds 30 appointments. In this example, AI also independently handles 30% of previously answered calls, which average four minutes, freeing up 15 hours of operator time.",
  },
} as const;

const metrics = [
  { value: "+20%", icon: CalendarCheck },
  { value: "+150", icon: PhoneIncoming },
  { value: "−30%", icon: Headset },
  { value: "24/7", icon: Clock },
];

export function MedVoiceImpact({ locale }: { locale: Locale }) {
  const text = copy[locale];

  return (
    <section
      className="medvoice-impact section"
      id="medvoice-impact"
      aria-labelledby="medvoice-impact-title"
    >
      <div className="container">
        <Reveal className="medvoice-impact-heading">
          <p className="eyebrow">{text.example}</p>
          <h2 id="medvoice-impact-title">{text.title}</h2>
          <p>{text.intro}</p>
        </Reveal>
        <ul className="medvoice-impact-grid">
          {metrics.map(({ value, icon: Icon }, index) => {
            const [label, comparison] = text.metrics[index];
            return (
              <li key={value}>
                <Reveal className="medvoice-impact-card" delay={index * 0.07}>
                  <Icon size={23} aria-hidden="true" />
                  <h3>
                    <strong>{value}</strong>
                    {label}
                  </h3>
                  <p>{comparison}</p>
                </Reveal>
              </li>
            );
          })}
        </ul>
        <p className="medvoice-impact-note">{text.note}</p>
        <details className="medvoice-impact-method">
          <summary>{text.methodTitle}</summary>
          <p>{text.method}</p>
        </details>
      </div>
    </section>
  );
}
