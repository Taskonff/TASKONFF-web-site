"use client";

import Link from "next/link";
import { ArrowDownToLine, CheckCircle2, Send } from "lucide-react";
import {
  useEffect,
  useId,
  useRef,
  useState,
  useSyncExternalStore,
  type FormEvent,
} from "react";
import { Button } from "@/components/ui/button";
import { useSiteContent } from "@/cms/site-context";
import { contactEmailHref, hasContactDetails } from "@/lib/contact-details";
import {
  downloadFormText,
  focusInvalidField,
  inquiryFormCopy,
} from "@/lib/inquiry-form";
import "@/components/site/inquiry-form.css";
import type { Locale } from "@/content/site";
import { MEDVOICE_PRODUCT_SLUG } from "@/content/products";
import {
  createProductRequest,
  productRequestKinds,
  productRequestSchema,
  type ProductRequestKind,
} from "@/lib/product-request";
import "./product-request-form.css";

const content = {
  ru: {
    heading: "Заявка на продукт",
    demoHeading: "Запросить демонстрацию MedVoice AI",
    organization: "Клиника или организация",
    role: "Ваша должность",
    phone: "Рабочий телефон",
    branches: "Количество филиалов (необязательно)",
    demoMessage: "Что хотите обсудить? (необязательно)",
    demoHint: "Укажите только свои рабочие контакты и общие задачи клиники.",
    organizationError: "Укажите название длиной от 2 до 180 символов.",
    roleError: "Укажите должность длиной от 2 до 100 символов.",
    phoneError: "Укажите рабочий телефон (от 7 до 15 цифр).",
    branchesError: "Укажите целое число от 1 до 10 000.",
    kind: "Тип заявки",
    trial: "Тестовый период",
    connection: "Подключение",
    name: "Ваше имя",
    email: "Рабочий email",
    message: "Цель и текущий процесс (необязательно)",
    placeholder:
      "Что хотите проверить или улучшить? Как сейчас устроен процесс?",
    consent: "Согласен на обработку данных для ответа на заявку.",
    onlineNote:
      "Данные сохраняются в заявке, чтобы команда TASKONFF могла ответить на указанный email.",
    offlineNote:
      "HTML-версия сохранит заявку в текстовый файл на вашем устройстве. Чтобы команда её получила, передайте файл по вашему каналу связи.",
    submit: "Отправить заявку",
    submitOffline: "Скачать заявку",
    pending: "Отправляем заявку…",
    downloaded: "Файл заявки готов к скачиванию.",
    invalid: "Проверьте поля заявки и попробуйте ещё раз.",
    limited: "Слишком много заявок за короткое время. Попробуйте позже.",
    unavailable: "Приём заявок для этого продукта сейчас недоступен.",
    failed:
      "Заявку не удалось отправить. Попробуйте ещё раз или сохраните копию.",
    downloadFailed: "Не удалось скачать файл. Попробуйте ещё раз.",
  },
  en: {
    heading: "Product request",
    demoHeading: "Request a MedVoice AI demo",
    organization: "Clinic or organisation",
    role: "Your role",
    phone: "Work phone",
    branches: "Number of branches (optional)",
    demoMessage: "What would you like to discuss? (optional)",
    demoHint:
      "Share only your own work contact details and general clinic needs.",
    organizationError:
      "Enter an organisation name between 2 and 180 characters.",
    roleError: "Enter a role between 2 and 100 characters.",
    phoneError: "Enter a work phone number with 7 to 15 digits.",
    branchesError: "Enter a whole number from 1 to 10,000.",
    kind: "Request type",
    trial: "Trial period",
    connection: "Get started",
    name: "Your name",
    email: "Work email",
    message: "Goal and current workflow (optional)",
    placeholder:
      "What would you like to evaluate or improve? How does it work today?",
    consent: "I agree to have my data processed to respond to this request.",
    onlineNote:
      "Your details are saved with the request so the TASKONFF team can reply by email.",
    offlineNote:
      "The HTML version saves your request as a text file on your device. Share that file with the team through your usual contact channel.",
    submit: "Send request",
    submitOffline: "Download request",
    pending: "Sending request…",
    downloaded: "Your request file is ready to download.",
    invalid: "Check the form fields and try again.",
    limited: "Too many requests in a short time. Please try again later.",
    unavailable: "Requests for this product are currently unavailable.",
    failed: "Your request could not be sent. Try again or download a copy.",
    downloadFailed: "The file could not be downloaded. Please try again.",
  },
};

type Status =
  | "idle"
  | "saved"
  | "downloaded"
  | "invalid"
  | "limited"
  | "unavailable"
  | "failed"
  | "downloadFailed";

function subscribeToHash(callback: () => void) {
  window.addEventListener("hashchange", callback);
  return () => window.removeEventListener("hashchange", callback);
}

function requestKindFromHash(hash: string): ProductRequestKind {
  // Standalone HTML stores the page route before the final fragment.
  return hash.split("#").at(-1) === "connection" ? "connection" : "trial";
}

const formFields = [
  "name",
  "email",
  "organization",
  "role",
  "phone",
  "branches",
  "message",
  "consent",
] as const;
type Field = (typeof formFields)[number];

export function ProductRequestForm({
  locale,
  productSlug,
  productTitle,
  offline = false,
}: {
  locale: Locale;
  productSlug: string;
  productTitle: string;
  offline?: boolean;
}) {
  const copy = content[locale];
  const isDemo =
    productSlug === MEDVOICE_PRODUCT_SLUG || productSlug === "medvoice";
  const { settings } = useSiteContent();
  const messages = inquiryFormCopy[locale];
  const fieldCopy: Record<Field, string> = {
    name: messages.name,
    email: messages.email,
    organization: copy.organizationError,
    role: copy.roleError,
    phone: copy.phoneError,
    branches: copy.branchesError,
    message: messages.productMessage,
    consent: messages.consent,
  };
  const prefix = useId();
  const successHeading = useRef<HTMLHeadingElement>(null);
  const mail = contactEmailHref(settings.contactEmail);
  const [errors, setErrors] = useState<Partial<Record<Field, string>>>({});
  const hash = useSyncExternalStore(
    subscribeToHash,
    () => window.location.hash,
    () => "",
  );
  const [choice, setChoice] = useState<{
    hash: string;
    kind: ProductRequestKind;
  }>();
  const [status, setStatus] = useState<Status>("idle");
  const [pending, setPending] = useState(false);
  const submission = useRef(false);
  const chosenKind =
    choice?.hash === hash ? choice.kind : requestKindFromHash(hash);
  const kind = isDemo ? "demo" : chosenKind;
  useEffect(() => {
    if (status === "saved") successHeading.current?.focus();
  }, [status]);

  function fieldAttributes(field: Field) {
    return {
      "aria-invalid": errors[field] ? true : undefined,
      "aria-describedby": errors[field] ? `${prefix}-${field}` : undefined,
    };
  }

  function fieldError(field: Field) {
    return errors[field] ? (
      <span className="inquiry-field-error" id={`${prefix}-${field}`}>
        {errors[field]}
      </span>
    ) : null;
  }

  useEffect(() => {
    if (isDemo) return;

    function chooseFromLink(event: MouseEvent) {
      if (
        event.defaultPrevented ||
        event.button !== 0 ||
        event.altKey ||
        event.ctrlKey ||
        event.metaKey ||
        event.shiftKey ||
        !(event.target instanceof Element)
      )
        return;

      const link = event.target.closest(".product-detail-actions a[href]");
      const href = link?.getAttribute("href");
      if (href === "#trial" || href === "#connection") {
        // Clicking the current fragment does not fire a hashchange event.
        setChoice(undefined);
        setStatus("idle");
      }
    }

    document.addEventListener("click", chooseFromLink, true);
    return () => document.removeEventListener("click", chooseFromLink, true);
  }, [isDemo]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submission.current) return;

    const form = event.currentTarget;
    const fields = new FormData(form);
    const submitter = (event.nativeEvent as SubmitEvent).submitter;
    const download = offline || submitter?.getAttribute("value") === "download";
    const branchCount = fields.get("branches");
    const result = productRequestSchema.safeParse({
      productSlug,
      kind,
      name: fields.get("name"),
      email: fields.get("email"),
      message: fields.get("message"),
      consent: download || fields.get("consent") === "on",
      website: fields.get("website"),
      locale,
      ...(isDemo
        ? {
            organization: fields.get("organization"),
            role: fields.get("role"),
            phone: fields.get("phone"),
            branches:
              typeof branchCount === "string" && branchCount.trim() !== ""
                ? Number(branchCount)
                : undefined,
          }
        : {}),
    });
    if (!result.success) {
      const fieldErrors: Partial<Record<Field, string>> = {};
      for (const issue of result.error.issues) {
        const field = issue.path[0] as Field;
        if (formFields.includes(field)) fieldErrors[field] = fieldCopy[field];
      }
      setErrors(fieldErrors);
      setStatus(Object.keys(fieldErrors).length ? "idle" : "invalid");
      focusInvalidField(form, Object.keys(fieldErrors)[0]);
      return;
    }

    setErrors({});
    submission.current = true;
    setStatus("idle");
    setPending(true);
    try {
      if (download) {
        downloadFormText(
          createProductRequest(result.data, productTitle),
          `TASKONFF-${productSlug}-${kind}.txt`,
        );
        setStatus("downloaded");
        return;
      }

      const response = await fetch("/api/product-requests/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(result.data),
      });
      if (response.status === 429) setStatus("limited");
      else if (response.status === 400) setStatus("invalid");
      else if (response.status === 404) setStatus("unavailable");
      else if (
        response.status === 201 &&
        (await response.json()).accepted === true
      ) {
        form.reset();
        setStatus("saved");
      } else setStatus("failed");
    } catch {
      setStatus(download ? "downloadFailed" : "failed");
    } finally {
      submission.current = false;
      setPending(false);
    }
  }

  return (
    <section
      className="product-request-section"
      aria-labelledby="product-request-heading"
    >
      {isDemo && (
        <span className="product-request-anchor" id="demo" aria-hidden="true" />
      )}
      <span className="product-request-anchor" id="trial" aria-hidden="true" />
      <span
        className="product-request-anchor"
        id="connection"
        aria-hidden="true"
      />
      <h2 id="product-request-heading">
        {isDemo ? copy.demoHeading : copy.heading}
      </h2>
      {!isDemo && <p className="product-request-name">{productTitle}</p>}
      <p className="product-request-note" id="product-request-note">
        {offline ? copy.offlineNote : copy.onlineNote}
      </p>
      <form
        className="product-request-form"
        method="post"
        noValidate
        onSubmit={submit}
        aria-busy={pending}
        aria-describedby="product-request-note"
      >
        {status !== "saved" && (
          <fieldset className="product-request-fields" disabled={pending}>
            {!isDemo && (
              <fieldset className="product-request-kinds">
                <legend>{copy.kind}</legend>
                <div className="product-request-choices">
                  {productRequestKinds.map((option) => (
                    <label key={option}>
                      <input
                        type="radio"
                        name="kind"
                        value={option}
                        checked={kind === option}
                        onChange={() => {
                          setChoice({ hash, kind: option });
                          setStatus("idle");
                        }}
                      />
                      {copy[option]}
                    </label>
                  ))}
                </div>
              </fieldset>
            )}

            <div className="product-request-row">
              <label>
                {copy.name}
                <input
                  name="name"
                  autoComplete="name"
                  minLength={2}
                  maxLength={100}
                  required
                  {...fieldAttributes("name")}
                />
                {fieldError("name")}
              </label>
              <label>
                {copy.email}
                <input
                  name="email"
                  type="email"
                  autoComplete="email"
                  maxLength={254}
                  required
                  {...fieldAttributes("email")}
                />
                {fieldError("email")}
              </label>
            </div>
            {isDemo && (
              <>
                <div className="product-request-row">
                  <label>
                    {copy.organization}
                    <input
                      name="organization"
                      autoComplete="organization"
                      minLength={2}
                      maxLength={180}
                      required
                      {...fieldAttributes("organization")}
                    />
                    {fieldError("organization")}
                  </label>
                  <label>
                    {copy.role}
                    <input
                      name="role"
                      autoComplete="organization-title"
                      minLength={2}
                      maxLength={100}
                      required
                      {...fieldAttributes("role")}
                    />
                    {fieldError("role")}
                  </label>
                </div>
                <div className="product-request-row">
                  <label>
                    {copy.phone}
                    <input
                      name="phone"
                      type="tel"
                      autoComplete="tel"
                      maxLength={40}
                      required
                      {...fieldAttributes("phone")}
                    />
                    {fieldError("phone")}
                  </label>
                  <label>
                    {copy.branches}
                    <input
                      name="branches"
                      type="number"
                      inputMode="numeric"
                      min={1}
                      max={10000}
                      step={1}
                      {...fieldAttributes("branches")}
                    />
                    {fieldError("branches")}
                  </label>
                </div>
              </>
            )}
            <label>
              {isDemo ? copy.demoMessage : copy.message}
              <textarea
                name="message"
                rows={3}
                maxLength={2000}
                placeholder={isDemo ? undefined : copy.placeholder}
                {...fieldAttributes("message")}
                aria-describedby={
                  [
                    fieldAttributes("message")["aria-describedby"],
                    isDemo ? `${prefix}-demo-hint` : undefined,
                  ]
                    .filter(Boolean)
                    .join(" ") || undefined
                }
              />
              {fieldError("message")}
              {isDemo && (
                <small
                  className="product-request-field-hint"
                  id={`${prefix}-demo-hint`}
                >
                  {copy.demoHint}
                </small>
              )}
            </label>
            <div className="honeypot" aria-hidden="true">
              <label>
                Website
                <input name="website" tabIndex={-1} autoComplete="off" />
              </label>
            </div>
            {!offline && (
              <div className="product-request-privacy">
                <label>
                  <input
                    type="checkbox"
                    name="consent"
                    required
                    {...fieldAttributes("consent")}
                  />
                  <span>{copy.consent}</span>
                </label>
                {fieldError("consent")}
                <Link href={`/${locale}/privacy`}>{messages.privacy}</Link>
              </div>
            )}
            <Button
              className="product-request-submit"
              type="submit"
              disabled={pending}
            >
              {pending
                ? copy.pending
                : offline
                  ? copy.submitOffline
                  : copy.submit}
              {offline ? (
                <ArrowDownToLine size={17} aria-hidden="true" />
              ) : (
                <Send size={17} aria-hidden="true" />
              )}
            </Button>
            {!offline && (
              <button
                type="submit"
                value="download"
                className="inquiry-secondary"
              >
                <ArrowDownToLine size={16} aria-hidden="true" />
                {messages.fallback}
              </button>
            )}
          </fieldset>
        )}
        <div role="status" aria-live="polite">
          {status === "saved" ? (
            <div className="inquiry-confirmation">
              <CheckCircle2 size={28} aria-hidden="true" />
              <h3
                className="product-request-result is-success"
                tabIndex={-1}
                ref={successHeading}
              >
                {messages.accepted}
              </h3>
              <p>{settings.responseTime?.[locale] || messages.reply}</p>
              <button
                type="button"
                className="inquiry-secondary"
                onClick={() => setStatus("idle")}
              >
                {messages.another}
              </button>
            </div>
          ) : status !== "idle" ? (
            <>
              <p
                className={`product-request-result ${status === "downloaded" ? "is-success" : "is-error"}`}
              >
                {status === "downloaded" && (
                  <CheckCircle2 size={17} aria-hidden="true" />
                )}
                {copy[status]}
              </p>
              {!offline &&
                (status === "limited" ||
                  status === "failed" ||
                  status === "unavailable") && (
                  <div className="inquiry-delivery-error">
                    {mail ? (
                      <a href={mail}>{settings.contactEmail}</a>
                    ) : hasContactDetails(settings, locale) ? (
                      <Link href={`/${locale}/contact#brief`}>
                        {messages.contact}
                      </Link>
                    ) : null}
                  </div>
                )}
            </>
          ) : null}
        </div>
      </form>
    </section>
  );
}
