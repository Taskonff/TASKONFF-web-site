import { Headset, PhoneIncoming, Route } from "lucide-react";
import "./bvoice-illustration.css";

export function BVoiceIllustration() {
  return (
    <div className="bvoice-illustration" aria-hidden="true">
      <div className="bvoice-route">
        <span className="bvoice-node">
          <PhoneIncoming size={23} />
        </span>
        <span className="bvoice-signal" />
        <span className="bvoice-node bvoice-node-core">
          <Route size={28} />
        </span>
        <span className="bvoice-signal" />
        <span className="bvoice-node">
          <Headset size={23} />
        </span>
      </div>
    </div>
  );
}
