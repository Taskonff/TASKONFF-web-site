import Image from "next/image";
import {
  ArrowDown,
  ArrowDownRight,
  ArrowUpRight,
  BellRing,
  Building2,
  CalendarCheck,
  ChartNoAxesCombined,
  FlaskConical,
  Headset,
  Link2,
  PhoneIncoming,
  ShieldCheck,
  Stethoscope,
} from "lucide-react";
import type { ReactNode } from "react";
import type { PublishedProduct } from "@/cms/defaults";
import { Reveal } from "@/components/home/reveal";
import { InternalHero } from "@/components/site/page-primitives";
import { Button } from "@/components/ui/button";
import { medVoiceCopy } from "@/content/medvoice";
import {
  launchProductCopy,
  MEDVOICE_PRODUCT_SLUG,
  productText,
} from "@/content/products";
import type { Locale } from "@/content/site";
import { MedVoiceCallFlow } from "./medvoice-call-flow";
import { MedVoiceImpact } from "./medvoice-impact";
import { ProductRequestForm } from "./product-request-form";
import "./medvoice-page.css";

const capabilityIcons = [
  PhoneIncoming,
  CalendarCheck,
  BellRing,
  Headset,
  Link2,
  ChartNoAxesCombined,
];
const audienceIcons = [Stethoscope, FlaskConical, Building2];
const routeIcons = [PhoneIncoming, Headset, CalendarCheck];
const barHeights = [
  20, 34, 25, 58, 79, 46, 90, 100, 61, 37, 72, 50, 29, 41, 23, 30,
];

function DemoAction({ children }: { children: ReactNode }) {
  return (
    <Button asChild>
      <a href="#demo">
        {children}
        <ArrowDown size={17} aria-hidden="true" />
      </a>
    </Button>
  );
}

function CallRoutingArt({ locale }: { locale: Locale }) {
  const copy = medVoiceCopy[locale];

  return (
    <figure className="medvoice-console">
      <figcaption>{copy.consoleCaption}</figcaption>
      <div className="medvoice-console-wave">
        <span>{copy.consoleTitle}</span>
        <div aria-hidden="true">
          {barHeights.map((height, index) => (
            <i
              key={index}
              style={{
                height: `${height}%`,
                animationDelay: `${index * 28}ms`,
              }}
            />
          ))}
        </div>
      </div>
      <ol className="medvoice-console-steps">
        {copy.consoleSteps.map((step, index) => {
          const Icon = routeIcons[index];
          return (
            <li key={step}>
              <span className="medvoice-console-icon">
                <Icon size={19} aria-hidden="true" />
              </span>
              {step}
              {index < copy.consoleSteps.length - 1 && (
                <ArrowDownRight
                  className="medvoice-console-arrow"
                  size={17}
                  aria-hidden="true"
                />
              )}
            </li>
          );
        })}
      </ol>
    </figure>
  );
}

export function MedVoicePage({
  locale,
  product,
  offline = false,
}: {
  locale: Locale;
  product: PublishedProduct;
  offline?: boolean;
}) {
  const copy = medVoiceCopy[locale];
  const content = productText(product, locale);
  const defaultSummary =
    launchProductCopy[MEDVOICE_PRODUCT_SLUG][locale].summary;
  const intro =
    content.summary === defaultSummary ? copy.intro : content.summary;

  return (
    <main id="main" className="internal-page medvoice-page">
      <InternalHero
        locale={locale}
        eyebrow={copy.eyebrow}
        title={`${content.title} — ${copy.type}`}
        description={intro || copy.intro}
        parent={{ href: `/${locale}/products`, label: copy.catalog }}
        actions={
          <>
            <p className="medvoice-status">
              <i aria-hidden="true" />
              {copy.status}
            </p>
            <div className="medvoice-actions">
              <DemoAction>{copy.demo}</DemoAction>
              <a className="medvoice-explore" href="#how-it-works">
                {copy.explore}
                <ArrowDown size={17} aria-hidden="true" />
              </a>
            </div>
          </>
        }
      >
        <Reveal className="medvoice-hero-illustration">
          <CallRoutingArt locale={locale} />
        </Reveal>
      </InternalHero>

      <section
        className="medvoice-section medvoice-light"
        aria-labelledby="medvoice-overview"
      >
        <div className="container">
          <Reveal className="medvoice-overview">
            <div>
              <h2 id="medvoice-overview">{copy.overviewTitle}</h2>
              <p>{content.body.trim() || copy.overview}</p>
              {product.website && (
                <a className="medvoice-text-link" href={product.website}>
                  {copy.website}
                  <ArrowUpRight size={17} aria-hidden="true" />
                </a>
              )}
            </div>
            {product.image && (
              <Image
                className="medvoice-overview-image"
                src={product.image.url}
                alt={product.image.alt}
                width={1000}
                height={680}
                unoptimized
                sizes="(max-width: 760px) 100vw, 42vw"
              />
            )}
          </Reveal>
          <p className="medvoice-note">{copy.overviewNote}</p>
          <a className="medvoice-text-link" href="#medvoice-impact">
            {copy.impactAction}
            <ArrowDown size={17} aria-hidden="true" />
          </a>
        </div>
      </section>

      <section
        className="medvoice-section medvoice-light medvoice-capabilities"
        aria-labelledby="medvoice-capabilities"
      >
        <div className="container">
          <Reveal>
            <h2 id="medvoice-capabilities">{copy.capabilityTitle}</h2>
            <ul className="medvoice-capability-grid">
              {copy.capabilities.map(([title, description], index) => {
                const Icon = capabilityIcons[index];
                return (
                  <li key={title}>
                    <Icon size={26} aria-hidden="true" />
                    <h3>{title}</h3>
                    <p>{description}</p>
                  </li>
                );
              })}
            </ul>
            <div className="medvoice-section-actions">
              <DemoAction>{copy.demo}</DemoAction>
            </div>
          </Reveal>
        </div>
      </section>

      <section
        className="medvoice-section medvoice-dark"
        id="how-it-works"
        aria-labelledby="medvoice-workflow"
      >
        <div className="container">
          <Reveal className="medvoice-flow-intro">
            <h2 id="medvoice-workflow">{copy.flowTitle}</h2>
            <p>{copy.flowIntro}</p>
          </Reveal>
          <MedVoiceCallFlow locale={locale} />
        </div>
      </section>

      <MedVoiceImpact locale={locale} />

      <section
        className="medvoice-section medvoice-light medvoice-audience"
        aria-labelledby="medvoice-audience"
      >
        <div className="container">
          <Reveal>
            <h2 id="medvoice-audience">{copy.audienceTitle}</h2>
            <ul className="medvoice-audience-grid">
              {copy.audiences.map(([title, description], index) => {
                const Icon = audienceIcons[index];
                return (
                  <li key={title}>
                    <Icon size={23} aria-hidden="true" />
                    <h3>{title}</h3>
                    <p>{description}</p>
                  </li>
                );
              })}
            </ul>
            <p className="medvoice-note">{copy.audienceNote}</p>
          </Reveal>
        </div>
      </section>

      <section
        className="medvoice-section medvoice-light medvoice-implementation"
        aria-labelledby="medvoice-implementation"
      >
        <div className="container">
          <Reveal>
            <h2 id="medvoice-implementation">{copy.implementationTitle}</h2>
            <ol className="medvoice-steps">
              {copy.implementationSteps.map(([title, description], index) => (
                <li key={title}>
                  <span>{String(index + 1).padStart(2, "0")}</span>
                  <h3>{title}</h3>
                  <p>{description}</p>
                </li>
              ))}
            </ol>
            <div className="medvoice-security">
              <ShieldCheck size={30} aria-hidden="true" />
              <div>
                <h3>{copy.securityTitle}</h3>
                <p>{copy.security}</p>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <section
        className="medvoice-section medvoice-light medvoice-faq"
        aria-labelledby="medvoice-faq"
      >
        <div className="container">
          <Reveal>
            <h2 id="medvoice-faq">{copy.faqTitle}</h2>
            <div className="medvoice-faq-list">
              {copy.faq.map(([question, answer]) => (
                <details key={question}>
                  <summary>{question}</summary>
                  <p>{answer}</p>
                </details>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <section
        className="medvoice-section medvoice-dark medvoice-demo"
        aria-labelledby="medvoice-demo-title"
      >
        <div className="container medvoice-demo-grid">
          <Reveal>
            <h2 id="medvoice-demo-title">{copy.demoTitle}</h2>
            <p>{copy.demoDescription}</p>
          </Reveal>
          <ProductRequestForm
            key={product.slug}
            locale={locale}
            productSlug={product.slug}
            productTitle={content.title}
            offline={offline}
          />
        </div>
      </section>

      <div className="medvoice-mobile-cta">
        <DemoAction>{copy.demo}</DemoAction>
      </div>
    </main>
  );
}
