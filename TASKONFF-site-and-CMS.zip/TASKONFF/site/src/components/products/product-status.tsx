import { isComingSoonProduct } from "@/content/products";
import type { Locale } from "@/content/site";
import "./product-status.css";

const comingSoonLabel = {
  ru: "Скоро",
  en: "Coming soon",
} as const;

export function ProductStatus({
  slug,
  locale,
}: {
  slug: string;
  locale: Locale;
}) {
  if (!isComingSoonProduct(slug)) return null;

  return <span className="product-status">{comingSoonLabel[locale]}</span>;
}
