"use client";

import { ArrowRight, PhoneForwarded } from "lucide-react";
import { Tabs } from "radix-ui";
import { medVoiceCopy } from "@/content/medvoice";
import type { Locale } from "@/content/site";

export function MedVoiceCallFlow({ locale }: { locale: Locale }) {
  const copy = medVoiceCopy[locale];

  return (
    <Tabs.Root defaultValue="booking" className="medvoice-flow">
      <Tabs.List className="medvoice-flow-tabs" aria-label={copy.flowLabel}>
        {copy.scenarios.map((scenario) => (
          <Tabs.Trigger key={scenario.key} value={scenario.key}>
            {scenario.label}
          </Tabs.Trigger>
        ))}
      </Tabs.List>
      {copy.scenarios.map((scenario) => (
        <Tabs.Content
          key={scenario.key}
          value={scenario.key}
          className="medvoice-flow-panel"
        >
          <div className="medvoice-flow-label">
            <PhoneForwarded size={19} aria-hidden="true" />
            {copy.flowLabel}
          </div>
          <ol className="medvoice-flow-steps">
            {scenario.steps.map(([title, description], index) => (
              <li key={title}>
                <div className="medvoice-flow-step-heading">
                  <span>{String(index + 1).padStart(2, "0")}</span>
                  {index < scenario.steps.length - 1 && (
                    <ArrowRight size={19} aria-hidden="true" />
                  )}
                </div>
                <h3>{title}</h3>
                <p>{description}</p>
              </li>
            ))}
          </ol>
        </Tabs.Content>
      ))}
    </Tabs.Root>
  );
}
