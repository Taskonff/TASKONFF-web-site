import { getSiteData } from "@/cms/site-data";
import type { Locale, SiteContent } from "@/content/site";
import { hasContactDetails } from "@/lib/contact-details";
import { ProjectBriefForm } from "./project-brief-form";

export async function ProjectBrief({
  copy,
  locale = "ru",
  source = "home",
  offline = process.env.CMS_STATIC_EXPORT === "1",
}: {
  copy: SiteContent;
  locale?: Locale;
  source?: "home" | "contact";
  offline?: boolean;
}) {
  const data = await getSiteData();
  return (
    <ProjectBriefForm
      copy={data.site[locale] ?? copy}
      locale={locale}
      source={source}
      offline={offline}
      responseTime={data.settings.responseTime?.[locale]}
      contactEmail={data.settings.contactEmail}
      fallbackContact={
        source === "home" && hasContactDetails(data.settings, locale)
      }
      options={data.services.map((service) => ({
        slug: service.slug,
        title: service[locale].title,
      }))}
    />
  );
}
