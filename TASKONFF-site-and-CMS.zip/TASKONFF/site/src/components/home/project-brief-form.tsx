"use client";

import { useEffect, useId, useRef, useState, type FormEvent } from "react";
import { ArrowDownToLine, CheckCircle2, Send } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { briefSchema, createBrief, inquirySchema } from "@/lib/brief";
import { contactEmailHref } from "@/lib/contact-details";
import {
  downloadFormText,
  focusInvalidField,
  inquiryFormCopy,
} from "@/lib/inquiry-form";
import type { Locale, SiteContent } from "@/content/site";
import "@/components/site/inquiry-form.css";

const deliveryCopy = {
  ru: {
    send: "Отправить заявку",
    pending: "Отправляем заявку…",
    note: "Расскажите о задаче. Ответим по электронной почте.",
    offline:
      "В этой версии заявку можно сохранить на устройстве и передать команде через согласованный канал связи.",
    limited: "Слишком много запросов. Подождите минуту и попробуйте снова.",
    failed:
      "Заявку не удалось отправить. Попробуйте ещё раз или сохраните копию.",
  },
  en: {
    send: "Send request",
    pending: "Sending request…",
    note: "Tell us what you need. We’ll respond by email.",
    offline:
      "Save your request to your device and share it with the team through your agreed contact channel.",
    limited: "Too many requests. Wait a minute and try again.",
    failed: "Your request could not be sent. Try again or download a copy.",
  },
};

const fields = [
  "name",
  "email",
  "phone",
  "telegram",
  "service",
  "message",
  "consent",
] as const;
type Field = (typeof fields)[number];
type Status =
  | "idle"
  | "accepted"
  | "downloaded"
  | "invalid"
  | "limited"
  | "failed"
  | "downloadFailed";

export function ProjectBriefForm({
  copy,
  locale,
  options,
  source,
  offline,
  responseTime,
  fallbackContact,
  contactEmail,
}: {
  copy: SiteContent;
  locale: Locale;
  options: { slug: string; title: string }[];
  source: "home" | "contact";
  offline: boolean;
  responseTime?: string;
  fallbackContact?: boolean;
  contactEmail?: string;
}) {
  const prefix = useId();
  const inFlight = useRef(false);
  const successHeading = useRef<HTMLHeadingElement>(null);
  const [pending, setPending] = useState(false);
  const [status, setStatus] = useState<Status>("idle");
  const [service, setService] = useState("");
  const [errors, setErrors] = useState<Partial<Record<Field, string>>>({});
  const delivery = deliveryCopy[locale];
  const messages = inquiryFormCopy[locale];
  const fieldCopy = { ...messages, message: messages.projectMessage };
  const mail = contactEmailHref(contactEmail);

  useEffect(() => {
    const choose = (event: Event) => {
      const value = (event as CustomEvent<string>).detail;
      if (
        copy.services.some((item) => item.title === value) ||
        options.some((item) => item.title === value)
      )
        setService(value);
    };
    window.addEventListener("taskonff:service", choose);
    return () => window.removeEventListener("taskonff:service", choose);
  }, [copy, options]);

  useEffect(() => {
    if (status === "accepted") successHeading.current?.focus();
  }, [status]);

  function fieldAttributes(field: Field) {
    return {
      "aria-invalid": errors[field] ? true : undefined,
      "aria-describedby": errors[field] ? `${prefix}-${field}` : undefined,
    };
  }

  function fieldError(field: Field) {
    return errors[field] ? (
      <span className="inquiry-field-error" id={`${prefix}-${field}`}>
        {errors[field]}
      </span>
    ) : null;
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (inFlight.current) return;
    const form = event.currentTarget;
    const submitter = (event.nativeEvent as SubmitEvent).submitter;
    const download = offline || submitter?.getAttribute("value") === "download";
    const values = Object.fromEntries(new FormData(form));
    const input = {
      ...values,
      locale,
      source,
      consent: values.consent === "on",
    };
    const result = (download ? briefSchema : inquirySchema).safeParse(input);
    if (!result.success) {
      const fieldErrors: Partial<Record<Field, string>> = {};
      for (const issue of result.error.issues) {
        const field = issue.path[0] as Field;
        if (fields.includes(field)) fieldErrors[field] = fieldCopy[field];
      }
      setErrors(fieldErrors);
      setStatus(Object.keys(fieldErrors).length ? "idle" : "invalid");
      focusInvalidField(form, Object.keys(fieldErrors)[0]);
      return;
    }
    setErrors({});
    setStatus("idle");
    inFlight.current = true;
    setPending(true);
    try {
      if (download) {
        downloadFormText(
          createBrief(result.data),
          "TASKONFF-project-brief.txt",
        );
        setStatus("downloaded");
        return;
      }
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(result.data),
      });
      if (
        response.status === 201 &&
        (await response.json()).accepted === true
      ) {
        form.reset();
        setService("");
        setStatus("accepted");
      } else {
        setStatus(response.status === 429 ? "limited" : "failed");
      }
    } catch {
      setStatus(download ? "downloadFailed" : "failed");
    } finally {
      inFlight.current = false;
      setPending(false);
    }
  }

  if (status === "accepted") {
    return (
      <div className="inquiry-confirmation" role="status">
        <CheckCircle2 size={28} aria-hidden="true" />
        <h3 ref={successHeading} tabIndex={-1} className="form-success">
          {messages.accepted}
        </h3>
        <p>{responseTime || messages.reply}</p>
        <button
          className="inquiry-secondary"
          type="button"
          onClick={() => setStatus("idle")}
        >
          {messages.another}
        </button>
      </div>
    );
  }

  return (
    <form
      className="brief-form"
      method="post"
      noValidate
      onSubmit={submit}
      aria-busy={pending}
    >
      <fieldset className="inquiry-fields" disabled={pending}>
        <div className="form-row">
          <label>
            {copy.formName}
            <input
              name="name"
              autoComplete="name"
              required
              minLength={2}
              maxLength={100}
              {...fieldAttributes("name")}
            />
            {fieldError("name")}
          </label>
          <label>
            {copy.formEmail}
            <input
              name="email"
              type="email"
              autoComplete="email"
              required
              maxLength={254}
              {...fieldAttributes("email")}
            />
            {fieldError("email")}
          </label>
        </div>
        <div className="form-row">
          <label>
            <span className="inquiry-field-label">
              {messages.phoneLabel}
              <span>{messages.optional}</span>
            </span>
            <input
              name="phone"
              type="tel"
              autoComplete="tel"
              maxLength={40}
              {...fieldAttributes("phone")}
            />
            {fieldError("phone")}
          </label>
          <label>
            <span className="inquiry-field-label">
              Telegram
              <span>{messages.optional}</span>
            </span>
            <input
              name="telegram"
              autoCapitalize="none"
              spellCheck={false}
              placeholder="@username"
              maxLength={33}
              {...fieldAttributes("telegram")}
            />
            {fieldError("telegram")}
          </label>
        </div>
        <label>
          {copy.formService}
          <select
            name="service"
            value={service}
            onChange={(event) => setService(event.target.value)}
            {...fieldAttributes("service")}
          >
            <option value="">{copy.general}</option>
            <optgroup
              label={
                locale === "ru" ? "Комплексные направления" : "Solution areas"
              }
            >
              {copy.services.map((item) => (
                <option key={item.title}>{item.title}</option>
              ))}
            </optgroup>
            <optgroup
              label={
                locale === "ru" ? "Конкретные услуги" : "Specific services"
              }
            >
              {options.map((item) => (
                <option key={item.slug}>{item.title}</option>
              ))}
            </optgroup>
          </select>
          {fieldError("service")}
        </label>
        <label>
          {copy.formMessage}
          <textarea
            name="message"
            placeholder={copy.formPlaceholder}
            rows={4}
            minLength={20}
            maxLength={5000}
            required
            {...fieldAttributes("message")}
          />
          {fieldError("message")}
        </label>
        <div className="honeypot" aria-hidden="true">
          <label>
            Website
            <input name="website" tabIndex={-1} autoComplete="off" />
          </label>
        </div>
        {!offline && (
          <div className="inquiry-consent">
            <label>
              <input
                type="checkbox"
                name="consent"
                required
                {...fieldAttributes("consent")}
              />
              <span>{messages.consentLabel}</span>
            </label>
            {fieldError("consent")}
            <Link href={`/${locale}/privacy`}>{messages.privacy}</Link>
          </div>
        )}
        <Button type="submit">
          {offline
            ? copy.formSubmit
            : pending
              ? delivery.pending
              : delivery.send}
          {offline ? (
            <ArrowDownToLine size={17} aria-hidden="true" />
          ) : (
            <Send size={17} aria-hidden="true" />
          )}
        </Button>
        {!offline && (
          <button className="inquiry-secondary" type="submit" value="download">
            <ArrowDownToLine size={16} aria-hidden="true" />
            {messages.fallback}
          </button>
        )}
        <p className="form-note">
          {offline ? delivery.offline : delivery.note}
        </p>
      </fieldset>
      <div role="status" aria-live="polite">
        {status === "downloaded" && (
          <p className="form-success">
            <CheckCircle2 size={18} aria-hidden="true" />
            {messages.downloaded}
          </p>
        )}
        {(status === "invalid" || status === "downloadFailed") && (
          <p className="form-error">{copy.formError}</p>
        )}
        {(status === "limited" || status === "failed") && (
          <div className="inquiry-delivery-error">
            <p className="form-error">{delivery[status]}</p>
            {mail ? (
              <a href={mail}>{contactEmail}</a>
            ) : fallbackContact ? (
              <Link href={`/${locale}/contact#brief`}>{messages.contact}</Link>
            ) : null}
          </div>
        )}
      </div>
    </form>
  );
}
