"use client";

import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { Pause, Play } from "lucide-react";
import type { Locale } from "@/content/site";
import { useSiteContent } from "@/cms/site-context";

type Point3 = { x: number; y: number; z: number };

const clamp = (value: number) => Math.max(0, Math.min(1, value));

function subscribeMotionPreference(listener: () => void) {
  const media = window.matchMedia("(prefers-reduced-motion: reduce)");
  media.addEventListener("change", listener);
  return () => media.removeEventListener("change", listener);
}
function readMotionPreference() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

/** An abstract connected architecture, not a logo or operational data. */
export function DigitalEngine({ locale }: { locale: Locale }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const modeRef = useRef(0);
  const pausedRef = useRef(false);
  const pauseOverrideRef = useRef<boolean | null>(null);
  const forceRender = useRef<(() => void) | undefined>(undefined);
  const [mode, setMode] = useState(0);
  const [pauseOverride, setPauseOverride] = useState<boolean | null>(null);
  const reducedMotion = useSyncExternalStore(
    subscribeMotionPreference,
    readMotionPreference,
    () => true,
  );
  const paused = pauseOverride ?? reducedMotion;
  const copy = useSiteContent().home[locale].engine;
  const modes = copy.modes;

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const context = canvas.getContext("2d", { alpha: true });
    if (!context) return;
    const ctx = context;
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const visual = wrap.closest<HTMLElement>(".hero-visual");
    let width = 600;
    let height = 530;
    let frame = 0;
    let visible = true;
    let tick = 0;
    let last = 0;
    let blend = 0;
    let pointerX = 0;
    let pointerY = 0;
    let tiltX = 0;
    let tiltY = 0;
    let scrollPosition = 0;
    let scrollTarget = 0;
    let measuredScroll = Number.NaN;
    let displayedTravel = "";
    let cameraCos = 1;
    let cameraSin = 0;
    let cameraScale = 1;
    let cameraPitch = 1;
    let cameraY = 0;
    let alive = true;
    const tau = Math.PI * 2;

    // The sculpture describes connected architectural layers, never business telemetry.
    const project = (point: Point3) => {
      const x = point.x * cameraCos - point.y * cameraSin;
      const y = point.x * cameraSin + point.y * cameraCos;
      const depth = 1 + (x + y) * 0.028;
      return {
        x: width * 0.51 + (x * 0.87 - y * 0.76) * cameraScale * depth,
        y:
          cameraY +
          ((x * 0.39 + y * 0.43) * cameraPitch - point.z) * cameraScale * depth,
      };
    };
    const line = (points: Point3[]) => {
      ctx.beginPath();
      points.forEach((point, index) => {
        const p = project(point);
        if (index === 0) ctx.moveTo(p.x, p.y);
        else ctx.lineTo(p.x, p.y);
      });
    };
    const polygon = (points: Point3[]) => {
      line(points);
      ctx.closePath();
    };
    const glowNode = (point: Point3, radius: number, color: string) => {
      const p = project(point);
      const glow = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, radius);
      glow.addColorStop(0, "rgba(223,255,255,0.95)");
      glow.addColorStop(0.16, color);
      glow.addColorStop(1, "rgba(0,160,255,0)");
      ctx.fillStyle = glow;
      ctx.fillRect(p.x - radius, p.y - radius, radius * 2, radius * 2);
    };
    const along = (points: Point3[], progress: number): Point3 => {
      const segment = Math.min(points.length - 2, Math.floor(progress));
      const fraction = progress - segment;
      const a = points[segment];
      const b = points[segment + 1];
      return {
        x: a.x + (b.x - a.x) * fraction,
        y: a.y + (b.y - a.y) * fraction,
        z: a.z + (b.z - a.z) * fraction,
      };
    };

    const render = () => {
      if (!alive) return;
      ctx.clearRect(0, 0, width, height);
      const automation = Math.max(0, 1 - Math.abs(blend - 1));
      const growth = Math.max(0, blend - 1);
      const travel = 1 - (1 - scrollPosition) ** 1.45;
      const sweep = Math.sin(Math.PI * travel);
      const angle =
        -0.13 + travel * 0.49 + tiltX * 0.13 + Math.sin(tick * 0.62) * 0.04;
      cameraCos = Math.cos(angle);
      cameraSin = Math.sin(angle);
      cameraScale = Math.min(width / 4.85, height / 4.2) * (1 - travel * 0.09);
      cameraPitch = 1 + tiltY * 0.12 - travel * 0.2;
      cameraY = height * (0.51 + travel * 0.06);
      const travelStyle = travel.toFixed(3);
      if (travelStyle !== displayedTravel) {
        visual?.style.setProperty("--engine-travel", travelStyle);
        displayedTravel = travelStyle;
      }
      const centerX = width * 0.51;
      const centerY = cameraY - height * 0.02;
      const haloSize = Math.min(width, height) * 0.65;
      const halo = ctx.createRadialGradient(
        centerX,
        centerY,
        0,
        centerX,
        centerY,
        haloSize,
      );
      halo.addColorStop(0, `rgba(0,112,255,${0.2 + sweep * 0.14})`);
      halo.addColorStop(0.48, "rgba(6,75,255,0.08)");
      halo.addColorStop(1, "rgba(0,70,255,0)");
      ctx.fillStyle = halo;
      ctx.fillRect(0, 0, width, height);

      // A quiet isometric ground plane gives the floating glass a physical scale.
      ctx.lineWidth = 0.6;
      ctx.strokeStyle = "rgba(45,117,176,0.13)";
      for (let step = -4; step <= 4; step += 1) {
        const position = step * 0.42;
        line([
          { x: -1.95, y: position, z: -1.42 },
          { x: 1.95, y: position, z: -1.42 },
        ]);
        ctx.stroke();
        line([
          { x: position, y: -1.95, z: -1.42 },
          { x: position, y: 1.95, z: -1.42 },
        ]);
        ctx.stroke();
      }
      for (const baseRadius of [1.42, 1.92]) {
        const radius = baseRadius + travel * 0.16;
        const orbit: Point3[] = [];
        for (let step = 0; step <= 90; step += 1) {
          const angle = (step / 90) * tau;
          orbit.push({
            x: Math.cos(angle) * radius,
            y: Math.sin(angle) * radius,
            z: -1.42,
          });
        }
        line(orbit);
        ctx.strokeStyle = `rgba(34,148,215,${0.23 + sweep * 0.14})`;
        ctx.stroke();
      }

      const layers = Array.from({ length: 5 }, (_, index) => {
        const offset = index - 2;
        const float = Math.sin(tick * 1.03 + index * 0.73) * 0.055;
        return {
          index,
          x: Math.sin(index * 1.8) * automation * 0.32 + offset * travel * 0.11,
          y:
            Math.cos(index * 1.4) * automation * 0.19 - offset * travel * 0.085,
          z: offset * (0.48 + growth * 0.065 + travel * 0.19) + float,
          size: 1.04 - growth * index * 0.055,
        };
      });
      const layerPoint = (
        layer: (typeof layers)[number],
        x: number,
        y: number,
        elevation = 0,
      ): Point3 => ({
        x: layer.x + x,
        y: layer.y + y,
        z: layer.z + elevation,
      });

      // Connection routes remain legible when motion is disabled; travelling light
      // simply makes the relationships more tangible when animation is enabled.
      const routes: Point3[][] = [
        [
          { x: -1.9, y: -0.2, z: -0.77 },
          { x: -1.9, y: -0.2, z: 0.05 },
          { x: -0.75, y: -0.2, z: 0.05 },
          { x: -0.1, y: -0.2, z: 0.05 },
        ],
        [
          { x: 1.85, y: 0.25, z: -0.68 },
          { x: 1.85, y: 0.25, z: 0.55 },
          { x: 0.8, y: 0.25, z: 0.55 },
          { x: 0.25, y: 0.25, z: 0.55 },
        ],
        [
          { x: -0.05, y: 1.7, z: -1.05 },
          { x: -0.05, y: 1.7, z: -0.4 },
          { x: -0.05, y: 0.9, z: -0.4 },
          { x: -0.05, y: 0.25, z: -0.4 },
        ],
      ];
      ctx.lineWidth = 1;
      for (const [index, route] of routes.entries()) {
        line(route);
        ctx.strokeStyle = `rgba(0,203,213,${0.28 + automation * 0.24 + sweep * 0.2})`;
        ctx.stroke();
        const end = project(route[0]);
        ctx.fillStyle = "#061d35";
        ctx.strokeStyle = "rgba(37,156,215,0.65)";
        ctx.beginPath();
        ctx.arc(end.x, end.y, 4.5, 0, tau);
        ctx.fill();
        ctx.stroke();
        const moving =
          (tick * (0.6 + automation * 0.2) + index * 0.9 + travel * 2.4) % 3;
        glowNode(along(route, moving), 9, "rgba(0,224,225,0.75)");
      }

      // The back edge of a continuous luminous spine connects every layer.
      line(layers.map((layer) => layerPoint(layer, -0.68, -0.68)));
      ctx.strokeStyle = "rgba(54,190,242,0.45)";
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 6]);
      ctx.stroke();
      ctx.setLineDash([]);

      for (const layer of layers) {
        const { size, index } = layer;
        const corners = [
          layerPoint(layer, -size, -size),
          layerPoint(layer, size, -size),
          layerPoint(layer, size, size),
          layerPoint(layer, -size, size),
        ];
        const projected = corners.map(project);

        // Thin blue side faces and a transparent top replace a solid default cube.
        for (const side of [1, 2]) {
          const a = corners[side];
          const b = corners[(side + 1) % 4];
          polygon([a, b, { ...b, z: b.z - 0.07 }, { ...a, z: a.z - 0.07 }]);
          ctx.fillStyle =
            side === 1 ? "rgba(0,85,215,0.42)" : "rgba(0,163,210,0.3)";
          ctx.fill();
        }
        const face = ctx.createLinearGradient(
          projected[0].x,
          projected[0].y,
          projected[2].x,
          projected[2].y,
        );
        face.addColorStop(0, "rgba(14,59,140,0.54)");
        face.addColorStop(0.5, "rgba(10,54,114,0.45)");
        face.addColorStop(1, "rgba(29,127,198,0.22)");
        polygon(corners);
        ctx.fillStyle = face;
        ctx.fill();
        ctx.strokeStyle = `rgba(67,164,235,${0.46 + index * 0.045})`;
        ctx.lineWidth = 1;
        ctx.stroke();

        // Subtle etched paths communicate structure without decorative text or data.
        ctx.lineWidth = 0.65;
        ctx.strokeStyle = "rgba(85,172,223,0.22)";
        for (const position of [-0.6, 0, 0.6]) {
          line([
            layerPoint(layer, -size + 0.12, position * size, 0.005),
            layerPoint(layer, size - 0.12, position * size, 0.005),
          ]);
          ctx.stroke();
          line([
            layerPoint(layer, position * size, -size + 0.12, 0.005),
            layerPoint(layer, position * size, size - 0.12, 0.005),
          ]);
          ctx.stroke();
        }
        const inset = size - 0.13;
        line([
          layerPoint(layer, -inset, inset, 0.01),
          layerPoint(layer, inset, inset, 0.01),
          layerPoint(layer, inset, -inset, 0.01),
        ]);
        const edge = ctx.createLinearGradient(
          projected[3].x,
          projected[3].y,
          projected[1].x,
          projected[1].y,
        );
        edge.addColorStop(0, "rgba(6,75,255,0.25)");
        edge.addColorStop(0.5, "rgba(25,154,255,0.88)");
        edge.addColorStop(1, "rgba(0,224,224,0.92)");
        ctx.strokeStyle = edge;
        ctx.lineWidth = index === 4 ? 2 : 1.35;
        ctx.shadowColor = "#008fff";
        ctx.shadowBlur = index === 4 ? 14 : 5;
        ctx.stroke();
        ctx.shadowBlur = 0;

        // A light wave follows the scroll across the unfolding layer surfaces.
        const wave = sweep * clamp(1 - Math.abs(travel * 6 - index - 0.5));
        if (wave > 0.01) {
          const scan = (clamp(travel * 1.6 - index * 0.12) * 2 - 1) * inset;
          const start = layerPoint(layer, -inset, scan, 0.02);
          const end = layerPoint(layer, inset, scan, 0.02);
          const a = project(start);
          const b = project(end);
          const beam = ctx.createLinearGradient(a.x, a.y, b.x, b.y);
          beam.addColorStop(0, "rgba(6,75,255,0)");
          beam.addColorStop(0.55, `rgba(0,212,214,${wave * 0.9})`);
          beam.addColorStop(1, "rgba(0,212,214,0)");
          line([start, end]);
          ctx.strokeStyle = beam;
          ctx.lineWidth = 2;
          ctx.shadowColor = "#00cbd5";
          ctx.shadowBlur = 10;
          ctx.stroke();
          ctx.shadowBlur = 0;
        }

        // Abstract components sit on the glass surface, with a highlighted core.
        const chipSize = index === 2 ? 0.24 : 0.14;
        const chipX = index % 2 ? 0.3 : -0.2;
        const chipY = index % 2 ? -0.15 : 0.15;
        polygon([
          layerPoint(layer, chipX - chipSize, chipY - chipSize, 0.015),
          layerPoint(layer, chipX + chipSize, chipY - chipSize, 0.015),
          layerPoint(layer, chipX + chipSize, chipY + chipSize, 0.015),
          layerPoint(layer, chipX - chipSize, chipY + chipSize, 0.015),
        ]);
        ctx.fillStyle =
          index === 2 ? "rgba(6,96,255,0.65)" : "rgba(15,115,181,0.32)";
        ctx.fill();
        ctx.strokeStyle =
          index === 2 ? "rgba(109,247,255,0.88)" : "rgba(66,182,223,0.6)";
        ctx.lineWidth = 1;
        ctx.stroke();
        glowNode(
          layerPoint(layer, size, -size, 0.015),
          index === 4 ? 11 : 6,
          "rgba(0,214,225,0.7)",
        );
      }

      // One animated seam across the architecture gives a restrained sense of flow.
      const seam = layers.map((layer) =>
        layerPoint(
          layer,
          0.72 - layer.index * 0.035,
          0.72 - layer.index * 0.035,
          0.03,
        ),
      );
      line(seam);
      ctx.strokeStyle = "rgba(0,211,220,0.6)";
      ctx.lineWidth = 1.3;
      ctx.stroke();
      const travelling = (tick * 0.53 + blend * 0.65) % (seam.length - 1);
      glowNode(along(seam, travelling), 11, "rgba(0,230,229,0.8)");
      if (sweep > 0.02) {
        ctx.globalAlpha = sweep;
        glowNode(
          along(seam, travel * (seam.length - 1)),
          18,
          "rgba(0,212,214,0.8)",
        );
        ctx.globalAlpha = 1;
      }
    };

    const shouldAnimate = () =>
      alive && visible && !document.hidden && !pausedRef.current;
    const updateScrollTarget = () => {
      const scroll = window.scrollY;
      if (scroll === measuredScroll) return;
      measuredScroll = scroll;
      const bounds = wrap.getBoundingClientRect();
      const top = scroll + bounds.top;
      // Start as the sculpture enters view on mobile, and unfold before it leaves.
      const start = Math.max(0, top - window.innerHeight * 0.68);
      const end = top + bounds.height * 0.65;
      scrollTarget = clamp((scroll - start) / Math.max(1, end - start));
    };
    const loop = (time: number) => {
      frame = 0;
      if (!shouldAnimate()) return;
      const elapsed = last ? Math.min((time - last) / 1000, 0.04) : 0.016;
      last = time;
      tick += elapsed;
      blend += (modeRef.current - blend) * 0.035;
      tiltX += (pointerX - tiltX) * 0.035;
      tiltY += (pointerY - tiltY) * 0.035;
      updateScrollTarget();
      const distance = scrollTarget - scrollPosition;
      scrollPosition +=
        Math.abs(distance) < 0.001
          ? distance
          : distance * (1 - Math.exp(-elapsed * 11));
      render();
      frame = requestAnimationFrame(loop);
    };
    const refresh = () => {
      if (!alive) return;
      if (pausedRef.current) {
        blend = modeRef.current;
        render();
      }
      if (shouldAnimate() && !frame) {
        last = 0;
        measuredScroll = Number.NaN;
        frame = requestAnimationFrame(loop);
      } else if (!shouldAnimate() && frame) {
        cancelAnimationFrame(frame);
        frame = 0;
      }
    };
    forceRender.current = refresh;
    const resize = () => {
      const bounds = wrap.getBoundingClientRect();
      measuredScroll = Number.NaN;
      width = Math.max(280, bounds.width);
      height = bounds.height || 440;
      const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      render();
      refresh();
    };
    const move = (event: PointerEvent) => {
      if (event.pointerType === "touch" || pausedRef.current) return;
      const bounds = wrap.getBoundingClientRect();
      pointerX = ((event.clientX - bounds.left) / bounds.width - 0.5) * 2;
      pointerY = ((event.clientY - bounds.top) / bounds.height - 0.5) * 2;
    };
    const leave = () => {
      pointerX = 0;
      pointerY = 0;
    };
    const changePreference = () => {
      if (pauseOverrideRef.current === null) pausedRef.current = media.matches;
      if (media.matches && pauseOverrideRef.current === null)
        scrollPosition = 0;
      refresh();
    };
    const intersection = new IntersectionObserver(
      ([entry]) => {
        visible = entry.isIntersecting;
        refresh();
      },
      { threshold: 0.05 },
    );
    const observer = new ResizeObserver(resize);
    observer.observe(wrap);
    intersection.observe(wrap);
    wrap.addEventListener("pointermove", move);
    wrap.addEventListener("pointerleave", leave);
    window.addEventListener("resize", resize);
    document.addEventListener("visibilitychange", refresh);
    media.addEventListener("change", changePreference);
    pausedRef.current = pauseOverrideRef.current ?? media.matches;
    resize();
    refresh();
    return () => {
      alive = false;
      cancelAnimationFrame(frame);
      observer.disconnect();
      intersection.disconnect();
      wrap.removeEventListener("pointermove", move);
      wrap.removeEventListener("pointerleave", leave);
      window.removeEventListener("resize", resize);
      document.removeEventListener("visibilitychange", refresh);
      media.removeEventListener("change", changePreference);
      visual?.style.removeProperty("--engine-travel");
      forceRender.current = undefined;
    };
  }, []);

  function selectMode(value: number) {
    modeRef.current = value;
    setMode(value);
    forceRender.current?.();
  }
  function toggleAnimation() {
    pausedRef.current = !pausedRef.current;
    pauseOverrideRef.current = pausedRef.current;
    setPauseOverride(pausedRef.current);
    forceRender.current?.();
  }
  return (
    <div className="digital-engine">
      <div className="engine-canvas-wrap" ref={wrapRef}>
        <canvas
          ref={canvasRef}
          className="engine-canvas"
          role="img"
          aria-label={copy.title}
        />
      </div>
      <div className="engine-control-label">
        <span>{copy.hint}</span>
        <button
          type="button"
          className="engine-pause"
          onClick={toggleAnimation}
          aria-label={paused ? copy.play : copy.pause}
          aria-pressed={paused}
        >
          {paused ? <Play size={13} /> : <Pause size={13} />}
        </button>
      </div>
      <div className="engine-controls" role="group" aria-label={copy.mode}>
        {modes.map((label, index) => (
          <button
            type="button"
            className={`engine-mode${mode === index ? " is-active" : ""}`}
            key={index}
            aria-pressed={mode === index}
            onClick={() => selectMode(index)}
          >
            {label}
            <i aria-hidden="true" />
          </button>
        ))}
      </div>
      <p className="engine-mode-description" aria-live="polite">
        {copy.active[mode]}
      </p>
    </div>
  );
}
