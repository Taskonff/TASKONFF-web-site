"use client";
import { useSiteContent } from "@/cms/site-context";
import { useState } from "react";
import { Pause, Play, Asterisk } from "lucide-react";
import { motion, useScroll, useSpring, useReducedMotion } from "motion/react";
export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const smooth = useSpring(scrollYProgress, { stiffness: 180, damping: 35 });
  const reduced = useReducedMotion();
  return (
    <motion.div
      className="scroll-progress"
      aria-hidden="true"
      style={{ scaleX: reduced ? scrollYProgress : smooth }}
    />
  );
}
export function CapabilityStrip({ locale }: { locale: "ru" | "en" }) {
  const [paused, setPaused] = useState(false);
  const copy = useSiteContent().home[locale].capability;
  return (
    <div className="capability-strip" data-paused={paused}>
      <div
        className="capability-window"
        role="region"
        aria-label={copy.label}
        tabIndex={0}
      >
        <div className="capability-track">
          {[0, 1].map((repeat) => (
            <div
              key={repeat}
              className="capability-set"
              aria-hidden={repeat === 1 ? true : undefined}
            >
              {copy.terms
                .filter((term) => term.trim())
                .map((term, index) => (
                  <span key={index}>
                    <Asterisk size={22} strokeWidth={1.4} aria-hidden="true" />
                    {term}
                  </span>
                ))}
            </div>
          ))}
        </div>
      </div>
      <div className="capability-controls">
        <button
          className="ribbon-toggle"
          type="button"
          onClick={() => setPaused(!paused)}
          aria-pressed={paused}
          aria-label={paused ? copy.play : copy.pause}
        >
          {paused ? (
            <Play size={15} aria-hidden="true" />
          ) : (
            <Pause size={15} aria-hidden="true" />
          )}
        </button>
      </div>
    </div>
  );
}
