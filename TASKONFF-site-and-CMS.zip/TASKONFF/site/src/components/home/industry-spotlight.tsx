"use client";

import Link from "next/link";
import { useId, useRef, useState, type KeyboardEvent } from "react";
import { motion, useReducedMotion } from "motion/react";
import {
  ArrowRight,
  ArrowUpRight,
  Building2,
  Factory,
  HeartPulse,
  Landmark,
  ShieldCheck,
  ShoppingBag,
  Truck,
  type LucideIcon,
} from "lucide-react";
import { useSiteContent } from "@/cms/site-context";
import type { Locale } from "@/content/site";
import "./industry-spotlight.css";

const icons: Record<string, LucideIcon> = {
  Building2,
  Factory,
  HeartPulse,
  Landmark,
  ShoppingBag,
  Truck,
};

export function IndustrySpotlight({ locale }: { locale: Locale }) {
  const data = useSiteContent();
  const copy = data.expertise[locale].industries;
  const [selected, setSelected] = useState(0);
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  const id = useId();
  const reduced = useReducedMotion();
  const item = copy.items[selected];
  const Icon = icons[item.iconId] ?? Building2;

  function navigate(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next = index;
    if (event.key === "ArrowDown" || event.key === "ArrowRight")
      next = (index + 1) % copy.items.length;
    else if (event.key === "ArrowUp" || event.key === "ArrowLeft")
      next = (index + copy.items.length - 1) % copy.items.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = copy.items.length - 1;
    else return;
    event.preventDefault();
    setSelected(next);
    refs.current[next]?.focus();
  }

  return (
    <section
      className="industry-spotlight"
      id="industries"
      aria-labelledby={`${id}-heading`}
    >
      <div className="industry-spotlight-container">
        <div className="industry-spotlight-heading">
          <div>
            <p className="industry-spotlight-eyebrow">
              <span aria-hidden="true" />
              {copy.label}
            </p>
            <h2 id={`${id}-heading`}>{copy.title}</h2>
          </div>
          <div className="industry-spotlight-intro">
            <p>{copy.description}</p>
            <Link href={`/${locale}/industries`}>
              {data.shared[locale].navigation.industries}
              <ArrowUpRight size={18} aria-hidden="true" />
            </Link>
          </div>
        </div>
        <div className="industry-spotlight-layout">
          <div
            className="industry-spotlight-tabs"
            role="tablist"
            aria-label={copy.tabsLabel}
            aria-orientation="vertical"
          >
            {copy.items.map((industry, index) => {
              const TabIcon = icons[industry.iconId] ?? Building2;
              return (
                <button
                  type="button"
                  role="tab"
                  key={industry.iconId}
                  id={`${id}-tab-${index}`}
                  aria-controls={`${id}-panel`}
                  aria-selected={selected === index}
                  tabIndex={selected === index ? 0 : -1}
                  ref={(element) => {
                    refs.current[index] = element;
                  }}
                  onClick={() => setSelected(index)}
                  onKeyDown={(event) => navigate(event, index)}
                >
                  <span className="industry-spotlight-tab-icon">
                    <TabIcon size={21} strokeWidth={1.5} aria-hidden="true" />
                  </span>
                  <span>{industry.name}</span>
                  <ArrowUpRight size={18} aria-hidden="true" />
                </button>
              );
            })}
          </div>
          <motion.div
            key={selected}
            className="industry-spotlight-panel"
            id={`${id}-panel`}
            role="tabpanel"
            aria-labelledby={`${id}-tab-${selected}`}
            tabIndex={0}
            initial={false}
            animate={reduced ? undefined : { opacity: [0.6, 1], y: [6, 0] }}
            transition={{ duration: 0.25 }}
          >
            <div className="industry-spotlight-panel-top">
              <span>{copy.scenarioLabel}</span>
              <span>{String(selected + 1).padStart(2, "0")}</span>
            </div>
            <div className="industry-spotlight-story">
              <div>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </div>
              <div className="industry-spotlight-art" aria-hidden="true">
                <span className="industry-spotlight-art-orbit" />
                <span className="industry-spotlight-art-pane" />
                <span className="industry-spotlight-art-pane" />
                <span className="industry-spotlight-art-icon">
                  <Icon size={42} strokeWidth={1.2} />
                </span>
                <i />
              </div>
            </div>
            <ol
              className="industry-spotlight-steps"
              aria-label={copy.stepsLabel}
            >
              {item.steps.map(([title, description], index) => (
                <li key={title}>
                  <span className="industry-spotlight-step-number">
                    0{index + 1}
                    {index < item.steps.length - 1 && (
                      <ArrowRight size={14} aria-hidden="true" />
                    )}
                  </span>
                  <strong>{title}</strong>
                  <p>{description}</p>
                </li>
              ))}
            </ol>
            <div className="industry-spotlight-note">
              <ShieldCheck size={17} strokeWidth={1.5} aria-hidden="true" />
              <p>{item.guard}</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
