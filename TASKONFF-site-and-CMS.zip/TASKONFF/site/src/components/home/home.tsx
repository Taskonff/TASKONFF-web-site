import Link from "next/link";
import Image from "next/image";
import { ArrowDown, ArrowRight, Braces, FileText, Orbit } from "lucide-react";
import { Reveal } from "./reveal";
import { DigitalEngine } from "./digital-engine";
import { CapabilityStrip } from "./experience";
import { ServiceGrid } from "./service-grid";
import { ProjectBrief } from "./project-brief";
import { Button } from "@/components/ui/button";
import { getSiteData } from "@/cms/site-data";
import { PageMedia } from "@/cms/page-media";
import { ProductsPreview } from "@/components/pages/products-pages";
import { ContactDetails } from "@/components/site/contact-details";
import "./corporate-home.css";
import type { Locale, SiteContent } from "@/content/site";

export async function Home({ locale }: { locale: Locale; copy?: SiteContent }) {
  const data = await getSiteData();
  const copy = data.site[locale];
  const h = data.home[locale];
  const navigation = data.shared[locale].navigation;
  const directory = [
    {
      path: "industries",
      title: navigation.industries,
      description: h.directory.industries,
    },
    {
      path: "technologies",
      title: navigation.technologies,
      description: h.directory.technologies,
    },
    {
      path: "process",
      title: navigation.process,
      description: h.directory.process,
    },
  ];

  return (
    <main id="main" className="corporate-home">
      <div className="home-first-screen">
        <section className="hero" id="top">
          <div className="hero-grid-bg" aria-hidden="true" />
          <div className="container hero-grid">
            <div className="hero-content">
              <Reveal>
                <p className="hero-kicker">{h.hero.eyebrow}</p>
                <h1>
                  {h.hero.titleFirst}
                  <br />
                  <span className="hero-title-middle">
                    {h.hero.titleOutline}
                  </span>
                  <br />
                  <span className="gradient-text">{h.hero.titleAccent}</span>
                </h1>
                <p className="hero-intro">{h.hero.intro}</p>
                <div className="hero-buttons">
                  <Button asChild>
                    <a href="#contact">
                      {copy.primary}
                      <span aria-hidden="true">
                        <ArrowRight size={19} />
                      </span>
                    </a>
                  </Button>
                  <a
                    className="hero-explore"
                    href={
                      data.products.length > 0
                        ? "#products-preview"
                        : "#expertise"
                    }
                  >
                    {data.products.length > 0
                      ? h.hero.explore
                      : h.sections.allServices}
                    <ArrowDown size={16} aria-hidden="true" />
                  </a>
                </div>
              </Reveal>
            </div>
            <div className="hero-visual">
              <DigitalEngine locale={locale} />
              <div className="visual-tag tag-product">
                <span className="tag-icon">
                  <Braces size={16} aria-hidden="true" />
                </span>
                <span>{h.visual.product}</span>
              </div>
              <div className="visual-tag tag-ai">
                <span className="tag-icon">
                  <Orbit size={16} aria-hidden="true" />
                </span>
                <span>{h.visual.intelligence}</span>
              </div>
            </div>
          </div>
        </section>
        <CapabilityStrip locale={locale} />
      </div>
      {data.products.length > 0 && <ProductsPreview locale={locale} />}
      <PageMedia pageKey="home" />
      <section className="expertise light-section section" id="expertise">
        <div className="container">
          <Reveal>
            <p className="eyebrow">
              <span className="eyebrow-cross" aria-hidden="true">
                +
              </span>
              {copy.expertise}
            </p>
            <div className="section-heading">
              <h2>
                {h.sections.expertiseTitle}
                <br />
                <span>{h.sections.expertiseAccent}</span>
              </h2>
              <p>{copy.servicesIntro}</p>
            </div>
          </Reveal>
          <ServiceGrid copy={copy} locale={locale} />
          <div className="home-page-link">
            <Link href={`/${locale}/services`}>
              {h.sections.allServices}
              <ArrowRight size={18} aria-hidden="true" />
            </Link>
          </div>
        </div>
      </section>
      {data.cases.length > 0 && (
        <section className="section home-cases light-section">
          <div className="container">
            <Reveal>
              <div className="section-heading">
                <h2>{data.trust[locale].portfolio.title}</h2>
                <Link
                  className="corporate-text-link"
                  href={`/${locale}/portfolio`}
                >
                  {navigation.portfolio}
                  <ArrowRight size={19} aria-hidden="true" />
                </Link>
              </div>
            </Reveal>
            <div className="home-case-grid">
              {data.cases.slice(0, 3).map((entry) => (
                <Link key={entry.id} href={`/${locale}/portfolio`}>
                  {entry.image && (
                    <Image
                      src={entry.image.url}
                      alt={entry.image.alt}
                      width={960}
                      height={540}
                      unoptimized
                    />
                  )}
                  <h3>{entry[locale].title}</h3>
                  <p>{entry[locale].summary}</p>
                  <ArrowRight size={22} aria-hidden="true" />
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
      <section className="approach light-section section" id="approach">
        <div className="container">
          <Reveal>
            <div className="manifesto">
              <h2>{h.directory.title}</h2>
              <div className="manifesto-note">
                <p>{copy.aboutText}</p>
                <Link className="corporate-text-link" href={`/${locale}/about`}>
                  {navigation.about}
                  <ArrowRight size={20} aria-hidden="true" />
                </Link>
              </div>
            </div>
          </Reveal>
          <ul className="home-directory">
            {directory.map(({ path, title, description }) => (
              <li key={path}>
                <Link href={`/${locale}/${path}`}>
                  <div>
                    <h3>{title}</h3>
                    <p>{description}</p>
                  </div>
                  <ArrowRight size={20} aria-hidden="true" />
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>
      <section className="contact section" id="contact">
        <div className="container contact-layout">
          <div className="contact-copy">
            <Reveal>
              <p className="eyebrow">{copy.contactLabel}</p>
              <h2>
                {h.contact.title}
                <br />
                <span>{h.contact.accent}</span>
              </h2>
              <div className="contact-aside">
                <p>{copy.contactText}</p>
                <ContactDetails settings={data.settings} locale={locale} />
              </div>
            </Reveal>
          </div>
          <Reveal className="contact-form-panel">
            <div className="contact-form-heading">
              <span>{h.contact.briefHint}</span>
              <FileText size={24} strokeWidth={1.4} aria-hidden="true" />
            </div>
            <ProjectBrief copy={copy} locale={locale} />
          </Reveal>
        </div>
      </section>
    </main>
  );
}
