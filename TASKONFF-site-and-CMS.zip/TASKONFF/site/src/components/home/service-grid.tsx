"use client";
import Link from "next/link";
import { useRef, type PointerEvent } from "react";
import {
  ArrowRight,
  Code2,
  Cpu,
  Layers3,
  PenTool,
  Sparkles,
  Workflow,
  Box,
  Check,
} from "lucide-react";
import type { SiteContent } from "@/content/site";
import { Reveal } from "./reveal";
import { useSiteContent } from "@/cms/site-context";
import type { Service } from "@/content/services";
const icons = [Code2, Cpu, Layers3, PenTool];
function Card({
  service,
  index,
  detail,
  locale,
  items,
}: {
  service: SiteContent["services"][number];
  index: number;
  detail: string;
  locale: "ru" | "en";
  items: Service[];
}) {
  const ref = useRef<HTMLElement>(null);
  const Icon = icons[index];
  function move(event: PointerEvent<HTMLElement>) {
    if (event.pointerType !== "mouse" || !ref.current) return;
    const box = ref.current.getBoundingClientRect();
    ref.current.style.setProperty(
      "--pointer-x",
      `${event.clientX - box.left}px`,
    );
    ref.current.style.setProperty(
      "--pointer-y",
      `${event.clientY - box.top}px`,
    );
  }
  return (
    <article
      ref={ref}
      className={`service-card service-${index}`}
      onPointerMove={move}
    >
      <div className="service-top">
        <Icon size={22} strokeWidth={1.5} />
      </div>
      <div className="service-art" aria-hidden="true">
        {index === 0 ? (
          <div className="art-window">
            <div className="window-bar">
              <i />
              <i />
              <i />
            </div>
            <div className="code-lines">
              <span />
              <span />
              <span />
              <span />
              <span />
            </div>
            <div className="code-floating">
              <Code2 size={22} />
            </div>
          </div>
        ) : index === 1 ? (
          <div className="art-ai">
            <span className="ai-ring ring-a" />
            <span className="ai-ring ring-b" />
            <span className="ai-ring ring-c" />
            <span className="ai-center">
              <Sparkles size={30} />
            </span>
            <i className="ai-spark spark-a" />
            <i className="ai-spark spark-b" />
          </div>
        ) : index === 2 ? (
          <div className="art-system">
            <span>
              <Box size={21} />
            </span>
            <i />
            <span>
              <Workflow size={28} />
            </span>
            <i />
            <span>
              <Layers3 size={21} />
            </span>
          </div>
        ) : (
          <div className="art-design">
            <div className="design-palette">
              <i />
              <i />
              <i />
              <i />
            </div>
            <div className="design-screen">
              <span />
              <div />
              <div />
            </div>
            <span className="design-check">
              <Check size={21} />
            </span>
          </div>
        )}
      </div>
      <h3>{service.title}</h3>
      <p>{service.text}</p>
      <div className="service-catalog-links">
        {items.map((item) => (
          <Link key={item.slug} href={`/${locale}/services/${item.slug}`}>
            {item[locale].title}
            <ArrowRight size={14} aria-hidden="true" />
          </Link>
        ))}
      </div>
      <a
        className="service-link"
        href="#contact"
        onClick={() =>
          window.dispatchEvent(
            new CustomEvent("taskonff:service", { detail: service.title }),
          )
        }
      >
        <span>{detail}</span>
        <span className="round-arrow">
          <ArrowRight size={20} />
        </span>
      </a>
    </article>
  );
}
export function ServiceGrid({
  copy,
  locale,
}: {
  copy: SiteContent;
  locale: "ru" | "en";
}) {
  const data = useSiteContent();
  const groups = ["build", "automate", "operate", "design"];
  return (
    <div className="services-grid">
      {copy.services.map((service, index) => (
        <Reveal key={service.title} delay={index * 0.06}>
          <Card
            service={service}
            index={index}
            detail={copy.detail}
            locale={locale}
            items={data.services.filter((item) => item.group === groups[index])}
          />
        </Reveal>
      ))}
    </div>
  );
}
