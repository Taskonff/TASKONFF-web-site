@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto usepython
py -3 preview.py
goto done
:usepython
python preview.py
:done
pause
