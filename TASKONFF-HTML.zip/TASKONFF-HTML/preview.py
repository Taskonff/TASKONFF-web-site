from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys
root = Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(root), **kwargs)
    def guess_type(self, path):
        if path.endswith("/opengraph-image"):
            return "image/png"
        return super().guess_type(path)
port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
print(f"TASKONFF: http://127.0.0.1:{port}/ (Ctrl+C to stop)", flush=True)
with ThreadingHTTPServer(("127.0.0.1", port), Handler) as server:
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
