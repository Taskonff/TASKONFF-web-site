# Homepage validation

Validated in the managed environment on 2026-11-04 using Node 24.22.1, npm 11.9.0 and Next.js 16.4.5.

- ESLint: passes with no warnings.
- TypeScript: passes.
- Unit tests: 2 passed (Unicode brief generation; invalid name/email/message and honeypot rejection).
- Prettier: passes.
- Production build: passes. Next.js reports an expected missing `metadataBase` warning until an official `SITE_URL` is configured. No production domain has been assumed.
- Chromium against the production server: RU and EN at 360, 390, 768 and 1440 pixels, all passed. Checked HTTP 200, document language, a single H1, no horizontal overflow, real anchor targets, hero stage selection, mobile menu, brief download and success feedback, language switching and absence of uncaught page errors.
- Root redirects to `/ru`; unsupported locale returns 404; Open Graph image returns PNG; robots prevents indexing without a public origin.
- Desktop and mobile full-page screenshots inspected visually. Browser evidence is stored outside the checkout at `/workspace/taskonff-validation` in the current environment.

These checks do not establish real contact delivery, CMS/database integration, production SEO origin, analytics, accessibility certification, Safari/Firefox compatibility or brand compliance against an unavailable brandbook. They are outside the implemented first-phase homepage.

## Reproduce

Run the lint, typecheck, test, format:check and build scripts in `package.json`. `npm start` serves the production build on port 3000. Check both `/ru` and `/en`, keyboard navigation, reduced-motion mode, mobile menu and the downloaded text brief. The browser checks used the environment-provided Playwright and `/usr/bin/chromium`; these are not application runtime dependencies.

## Brand-reference revision

After the supplied inline logo reference, updated the palette, white logo surfaces, chamfer accents and layered interactive hero. Repeated lint, typecheck, both unit tests, production build and all 8 Chromium locale/viewport combinations successfully. Refreshed screenshots were visually reviewed. Original logo insertion remains pending because the inline reference has no downloadable file/path in this execution environment. Add the original as `public/brand/taskonff-logo.svg`, `.png` or `.webp`, then rebuild so statically rendered pages include it.

## Full technology-led redesign

Replaced the original composition and styles with the design documented in DESIGN.md. Added local Manrope, animated 3D canvas flow, topology controls, pause/resume, offscreen suspension, accessible interactive solution explorer, illustrated service bento, service-to-brief selection, scroll progress and a pausable capability ribbon.

Final validation: ESLint, TypeScript, formatting, production build and 2 unit tests passed. The repository Playwright suite `tests/e2e/home.spec.ts` passed all 10 tests (8 localized viewport workflows, real animation/pause/offscreen behavior, routing and preview SEO). An additional focused Chromium check passed 6 solution-explorer locale/viewport combinations, including 18 scenario selections, 72 node updates, keyboard focus/selection and valid ARIA relationships. Updated screenshots are `redesign-ru-1440.png`, `redesign-ru-390.png`, `redesign-en-1440.png` and `hero-new.png` under `/workspace/taskonff-validation`. The logo source asset remains unavailable; no exact logo replacement is claimed.
