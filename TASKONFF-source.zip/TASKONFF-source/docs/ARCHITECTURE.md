# TASKONFF: architecture and review scope

## Current delivery

Only the homepage, localized at `/ru` and `/en`. Root redirects to Russian. Navigation targets real homepage sections. Other pages require homepage approval before implementation. No clients, testimonials, certifications, company metrics, cases or contact details have been invented.

Next.js App Router + TypeScript + Tailwind CSS 4. shadcn/ui-compatible Button uses Radix Slot, CVA and local source ownership (`components.json`). Motion handles scroll animation; CSS respects reduced motion. Lucide icons represent functions, not the TASKONFF logo. The company name is plain text pending original assets.

## Modules

- `src/content/site.ts`: typed RU/EN content. Replace with a server-side content provider when connecting CMS; keep presentation props stable.
- `src/components/home`: homepage sections, responsive navigation, interactive hero and local project brief.
- `src/components/ui`: shared design primitives.
- `src/lib/brief.ts`: input schema and local brief generation. No server delivery or persistence is claimed.
- `src/app/[locale]`: static localized pages and language-specific metadata.
- `src/app/robots.ts`, `sitemap.ts`: discovery only after a confirmed `SITE_URL` is configured. No guessed production URLs.

## Page map after approval

`/[locale]/{about,services,industries,portfolio,technologies,process,contact,privacy,terms}`. Services can later add `[slug]`, cases `[slug]`. Portfolio is published only with approved source material. Legal pages require actual controller, jurisdiction and processing details.

## Later integrations

Payload collections: pages, services, industries, case studies, technologies, site settings. Use localized fields, draft/preview access, PostgreSQL adapter, role-based admin access and migrations. Keep CMS access server-side behind a content-provider module. CMS and PostgreSQL are not installed or claimed functional in this phase.

Contact delivery needs an official destination/provider and approved privacy text. Add a POST route with the shared Zod schema, body-size limit, origin checks, honeypot, shared persistent rate limiting and optionally a verified challenge. Never log message bodies. Do not report success until delivery is accepted. Current form downloads a local brief and makes no network request; consequently no server validation, spam endpoint or privacy consent is needed or claimed for it.

Analytics is not active. Add a provider through a consent-aware integration after destination and policy approval. No hardcoded tracker or invented IDs.

## Brand and design system

The user supplied an inline logo reference: navy wordmark with blue ON lettering and a blue-to-cyan geometric symbol. The attachment is visible in chat but its binary is not available in the execution filesystem. No reconstructed logo is included. A server-only asset resolver automatically uses `public/brand/taskonff-logo.svg`, `.png`, or `.webp` when the original is supplied. The shared logo component preserves the full image using `object-fit: contain`. Header and footer use white surfaces for the original dark wordmark. Until the actual file exists, they show the company name as plain text.

Colors: navy `#020e1b`, electric blue `#064bff`, turquoise `#00cbd5`, off-white `#f3f5f7`. These tokens are visually matched to the logo reference supplied in chat, not measured from an available source asset. Local Manrope Variable from @fontsource-variable/manrope includes Cyrillic and avoids font CDN requests. Type scale: desktop hero up to 92px, section headings up to 52px, body 14–15px. Spacing: 4/8px rhythm; 1280px content width. Grid: two-column hero, four/two/one-column services, two-column mobile process. Thin borders, restrained radii, no fabricated company data. The animated canvas engine and service illustrations are decorative UI, not a company mark. See DESIGN.md for the replacement design.

Accessibility: semantic landmarks, skip link, focus rings, native form labels, live status, keyboard-operable hero controls, mobile menu state, reduced motion. Static content remains readable before animation. No external stock image is needed for the technical visual.

## Review dependencies

Original logos/brandbook; approved cases and industry descriptions; official contact delivery; confirmed public origin; legal entity and policies. These block their corresponding production integrations, not local homepage review.
