# TASKONFF website

Russian and English corporate website with internal sections and ten detailed service pages. See [multipage implementation and validation](docs/MULTIPAGE.md). See [architecture](docs/ARCHITECTURE.md) and the [interactive design system](docs/DESIGN.md).

## Development

Use Node.js 24 and npm. From this checkout:

```sh
npm ci
npm run dev
```

Open the `/ru` or `/en` path on the development server, port 3000.

```sh
npm run lint
npm run typecheck
npm test
npm run build
npm start
```

After the first Next.js build, generated route types are included automatically. `npm run build` uses the standard Next.js production compiler.

Only set `SITE_URL` to the confirmed public origin before production deployment (see `.env.example`). Without it, robots disallows indexing and sitemap has no URLs. No production domain, contact address, credentials or analytics IDs are invented.

The form sends data to `/api/brief` for server validation and downloadable document generation; it does not deliver an inquiry to the team or persist message content. Direct delivery awaits an official destination and approved privacy information. Original logo assets are pending; `public/brand` is reserved for supplied originals. Portfolio contains no fabricated cases; legal pages are marked drafts.

## Browser checks

After `npm run build`, run `npm run test:e2e`. Install the Playwright Chromium browser with `npx playwright install chromium` if your machine has no supported browser. In this cloud environment the existing system browser was used:

```sh
PLAYWRIGHT_CHROMIUM_EXECUTABLE=/usr/bin/chromium npm run test:e2e
```

The suite checks both languages at four widths, animated/static canvas modes, pause/resume and offscreen suspension, scenario tabs and nodes, keyboard controls, service-to-brief selection, download and routing.
