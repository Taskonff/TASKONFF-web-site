import { notFound } from "next/navigation";
import { isLocale } from "@/content/site";
import { pageMetadata } from "@/lib/metadata";
import { IndustriesPage } from "@/components/pages/expertise-pages";
export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return pageMetadata(
    locale,
    "industries",
    locale === "ru" ? "Отраслевые сценарии" : "Industry scenarios",
    locale === "ru"
      ? "Возможные применения цифровых продуктов, автоматизации и интеграций в разных бизнес-процессах."
      : "Possible applications of digital products, automation and integration across business workflows.",
  );
}
export default async function Page({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return <IndustriesPage locale={locale} />;
}
