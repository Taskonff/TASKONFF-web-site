import { notFound } from "next/navigation";
import { isLocale } from "@/content/site";
import { trustContent } from "@/content/trust";
import { pageMetadata } from "@/lib/metadata";
import { LegalPage } from "@/components/pages/trust-pages";
type Props = { params: Promise<{ locale: string }> };
export async function generateMetadata({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const copy = trustContent[locale].legal.privacy;
  return pageMetadata(locale, "privacy", copy.label, copy.description);
}
export default async function Page({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return <LegalPage locale={locale} kind="privacy" />;
}
