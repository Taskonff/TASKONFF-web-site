import { notFound } from "next/navigation";
import { isLocale } from "@/content/site";
import { trustContent } from "@/content/trust";
import { pageMetadata } from "@/lib/metadata";
import { ContactPage } from "@/components/pages/trust-pages";
type Props = { params: Promise<{ locale: string }> };
export async function generateMetadata({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const copy = trustContent[locale].contact;
  return pageMetadata(locale, "contact", copy.label, copy.description);
}
export default async function Page({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return <ContactPage locale={locale} />;
}
