import { notFound } from "next/navigation";
import { isLocale } from "@/content/site";
import { getService, serviceSlugs } from "@/content/services";
import { pageMetadata } from "@/lib/metadata";
import { ServiceDetailPage } from "@/components/pages/expertise-pages";
export function generateStaticParams() {
  return serviceSlugs.map((service) => ({ service }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string; service: string }>;
}) {
  const { locale, service: slug } = await params;
  const service = getService(slug);
  if (!isLocale(locale) || !service) notFound();
  return pageMetadata(
    locale,
    `services/${slug}`,
    service[locale].title,
    service[locale].intro,
  );
}
export default async function Page({
  params,
}: {
  params: Promise<{ locale: string; service: string }>;
}) {
  const { locale, service: slug } = await params;
  const service = getService(slug);
  if (!isLocale(locale) || !service) notFound();
  return <ServiceDetailPage locale={locale} service={service} />;
}
