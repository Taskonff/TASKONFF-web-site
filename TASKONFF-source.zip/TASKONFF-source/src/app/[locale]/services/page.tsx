import { notFound } from "next/navigation";
import { isLocale } from "@/content/site";
import { pageMetadata } from "@/lib/metadata";
import { ServicesPage } from "@/components/pages/expertise-pages";
export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return pageMetadata(
    locale,
    "services",
    locale === "ru" ? "Услуги" : "Services",
    locale === "ru"
      ? "Заказное ПО, веб и мобильные приложения, AI, автоматизация, CRM и ERP, интеграции, Cloud, дизайн и QA."
      : "Custom software, web and mobile apps, AI, automation, CRM and ERP, integration, cloud, design and QA.",
  );
}
export default async function Page({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return <ServicesPage locale={locale} />;
}
