import { ImageResponse } from "next/og";
export const alt = "TASKONFF — BUILD • AUTOMATE • GROW";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";
export default function Image() {
  return new ImageResponse(
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        padding: "70px",
        background: "linear-gradient(135deg,#020e1b,#034888)",
        color: "#fff",
        fontFamily: "sans-serif",
      }}
    >
      <div style={{ display: "flex", fontSize: 32, letterSpacing: 3 }}>
        TASKONFF
      </div>
      <div style={{ display: "flex", fontSize: 88, lineHeight: 1.1 }}>
        Build what’s next.
      </div>
      <div
        style={{
          display: "flex",
          fontSize: 24,
          letterSpacing: 7,
          color: "#00cbd5",
        }}
      >
        BUILD • AUTOMATE • GROW
      </div>
    </div>,
    size,
  );
}
