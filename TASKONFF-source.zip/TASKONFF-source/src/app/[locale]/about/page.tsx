import { notFound } from "next/navigation";
import { isLocale } from "@/content/site";
import { companyContent } from "@/content/company";
import { pageMetadata } from "@/lib/metadata";
import { AboutPage } from "@/components/pages/company-pages";
type Props = { params: Promise<{ locale: string }> };
export async function generateMetadata({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const c = companyContent[locale].about;
  return pageMetadata(locale, "about", c.label, c.intro);
}
export default async function Page({ params }: Props) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  return <AboutPage locale={locale} />;
}
