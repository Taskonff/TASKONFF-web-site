export const trustContent = {
  ru: {
    portfolio: {
      label: "Портфолио",
      title: "За каждой системой —\nреальная задача.",
      description:
        "Хороший кейс показывает путь от задачи бизнеса до инженерного решения. Мы публикуем проекты только с проверенными материалами и разрешением на раскрытие.",
      emptyTitle: "Кейсы появятся здесь, когда будут готовы к публикации.",
      emptyText:
        "Публичные материалы о проектах будут добавлены после проверки содержания и согласования условий раскрытия.",
      evidenceLabel: "ЧТО ВАЖНО В КАЖДОМ КЕЙСЕ",
      evidenceTitle: "Не только экран.\nВся логика решения.",
      evidence: [
        [
          "Контекст",
          "Какая задача стояла перед бизнесом, для кого создавался продукт и какие ограничения влияли на решение.",
        ],
        [
          "Решение",
          "Архитектура, пользовательские сценарии, интеграции и причины выбора технологий.",
        ],
        [
          "Работа",
          "Границы ответственности, этапы разработки и проверка качества.",
        ],
        [
          "Результат",
          "Подтверждённые изменения и выводы, которые можно раскрывать публично.",
        ],
      ],
      scenarioLabel: "ВОЗМОЖНЫЕ НАПРАВЛЕНИЯ",
      scenarioTitle: "Исследуйте то,\nчто можно создать.",
      scenarioNote:
        "Это примеры задач для обсуждения, а не кейсы выполненных проектов.",
      scenarios: [
        [
          "Цифровой продукт",
          "От первого пользовательского сценария до веб-приложения или SaaS-платформы.",
          "web-mobile",
        ],
        [
          "Связанные процессы",
          "Интеграция данных, CRM и внутренних инструментов вокруг реального процесса.",
          "business-automation",
        ],
        [
          "AI в работе команды",
          "Агент, который помогает находить знания и выполнять согласованные действия.",
          "ai-agents",
        ],
      ],
      scenarioLink: "Узнать о направлении",
    },
    contact: {
      label: "Контакты",
      title: "Начнём\nс вашей задачи.",
      description:
        "Опишите идею, процесс или систему, которую хотите улучшить. Бриф поможет сформулировать исходные данные и подготовиться к предметному обсуждению.",
      mode: "ПОДГОТОВКА БРИФА",
      modeTitle: "Сначала — ясность.",
      modeText:
        "Форма проверяет данные на сервере сайта и создаёт текстовый файл для скачивания. Сообщение не отправляется команде TASKONFF автоматически.",
      modeHelp:
        "После скачивания передайте файл через ваш уже действующий канал связи с компанией. Официальные адреса и каналы будут добавлены после подтверждения.",
      prepareLabel: "ЧТО ПОЛЕЗНО ПОДГОТОВИТЬ",
      prepareTitle: "Несколько деталей,\nкоторые задают направление.",
      prepare: [
        ["Цель", "Что должно измениться для бизнеса или пользователей?"],
        ["Контекст", "Какие системы, данные и процессы уже существуют?"],
        [
          "Приоритеты",
          "Что необходимо для первого этапа, а что можно развивать позже?",
        ],
        [
          "Ограничения",
          "Есть ли согласованный срок, бюджетный ориентир или требования к безопасности?",
        ],
      ],
      faqTitle: "Перед первым шагом",
      faq: [
        [
          "Нужна ли готовая спецификация?",
          "Нет. Для начала достаточно описать задачу, пользователей и ожидаемый результат. Требования можно уточнять по мере исследования.",
        ],
        [
          "Что происходит с данными формы?",
          "Данные передаются серверу сайта для проверки и формирования файла. Приложение не сохраняет текст брифа в базе данных и не отправляет его команде через эту форму.",
        ],
        [
          "Можно ли прикрепить конфиденциальные материалы?",
          "Эта форма не поддерживает вложения. Не добавляйте пароли, токены, персональные данные третьих лиц и закрытые коммерческие материалы в описание. Условия обмена такими материалами нужно согласовать отдельно.",
        ],
        [
          "Куда придёт ответ?",
          "Скачивание брифа не отправляет заявку, поэтому автоматического ответа не будет. Передайте готовый файл через установленный канал общения с TASKONFF.",
        ],
      ],
      techLink: "Посмотреть технологический подход",
      privacyLink: "Как обрабатываются данные",
    },
    legal: {
      draftLabel: "ПРОЕКТ ДОКУМЕНТА",
      draftText:
        "Эта редакция описывает текущую функциональность сайта. Сведения о юридическом владельце, хостинге, применимых правилах и сроках обработки должны быть согласованы до публичного запуска. Документ не представлен как окончательно утверждённая правовая политика.",
      contents: "Содержание",
      backContact: "Перейти к подготовке брифа",
      privacy: {
        label: "Конфиденциальность",
        title: "Прозрачно\nо данных.",
        description:
          "Что происходит с данными при просмотре сайта и создании проектного брифа.",
        sections: [
          [
            "Область документа",
            "Здесь описана текущая версия сайта TASKONFF и доступная форма создания брифа. Этот текст не заменяет согласованную политику конкретного юридического лица. Данные владельца и канал для обращений по вопросам обработки пока не предоставлены.",
          ],
          [
            "Данные проектного брифа",
            "Форма запрашивает имя, рабочий email, направление интереса и описание проекта. Эти сведения передаются серверу сайта для проверки корректности и формирования текстового файла. Скачивание не означает доставку заявки команде TASKONFF.",
          ],
          [
            "Хранение и передача",
            "В текущей реализации приложение не записывает содержание брифа в базу данных, не ведёт журнал текста сообщений и не пересылает бриф внешнему получателю. Сформированный файл скачивается в браузер. Хранение и последующая передача скачанного файла зависят от ваших действий и настроек устройства.",
          ],
          [
            "Технические данные",
            "Для работы сайта и ограничения частоты запросов сервер обрабатывает технические сведения о запросах. Поставщик хостинга может обрабатывать собственные технические журналы. Его состав данных, сроки хранения и условия обработки необходимо уточнить в утверждённой политике перед запуском.",
          ],
          [
            "Cookies и аналитика",
            "В текущем приложении не подключены аналитические трекеры и не создаются cookies для рекламного отслеживания. Если аналитика или другие сервисы будут добавлены, сведения об их работе и необходимые настройки согласия должны быть обновлены.",
          ],
          [
            "Ваши действия и обращения",
            "Не указывайте в форме секреты, учётные данные или чужие персональные данные. До публикации окончательной политики необходимо определить юридического владельца и официальный канал для запросов об обработке данных. Подтверждённые сведения будут включены в окончательную редакцию.",
          ],
          [
            "Изменения функциональности",
            "Подключение прямой отправки заявок, CRM, внешней аналитики или иных обработчиков потребует уточнения этой редакции до включения соответствующих функций.",
          ],
        ],
      },
      terms: {
        label: "Условия использования",
        title: "Понятные правила\nвзаимодействия.",
        description:
          "Информационный характер сайта, правила работы с брифом и границы текущей функциональности.",
        sections: [
          [
            "Статус условий",
            "Это проект условий для текущей версии сайта. Юридическое лицо, применимое право и порядок разрешения споров должны быть определены в утверждённом документе. Эта редакция не заявлена как готовый договор об оказании услуг.",
          ],
          [
            "Информация о решениях",
            "Страницы описывают направления разработки и возможные сценарии применения технологий. Они не являются индивидуальным техническим заданием, обязательством о сроках или публичной офертой на конкретный объём работ. Условия проекта согласуются отдельно.",
          ],
          [
            "Бриф и обращение",
            "Форма создаёт скачиваемый файл после серверной проверки. Она не заключает договор и в текущем интерфейсе не отправляет сообщение команде. Наличие email в брифе само по себе не означает, что компания получила обращение или обязалась ответить.",
          ],
          [
            "Допустимое использование",
            "Используйте сайт для знакомства с услугами и подготовки описания задачи. Не отправляйте вредоносный контент, секретные ключи, пароли или материалы, которыми вы не вправе делиться. Не пытайтесь обходить ограничения запросов и нарушать работу сайта.",
          ],
          [
            "Интеллектуальные права",
            "Название, оригинальный логотип и материалы TASKONFF следует использовать с учётом прав их владельцев. Представление технологий и сторонних наименований не означает передачи прав на них или заявления о партнёрстве.",
          ],
          [
            "Сценарии и портфолио",
            "Иллюстрации возможных решений не представлены как выполненные проекты. Публичные кейсы должны опираться на проверенные материалы и разрешение на раскрытие. Условия реализации каждого решения определяются отдельно.",
          ],
          [
            "Изменения и доступность",
            "Содержание и функции могут развиваться. Окончательные положения об ответственности, доступности сервиса и порядке уведомления об изменениях должны быть согласованы юридическим владельцем перед публичным запуском.",
          ],
        ],
      },
    },
  },
  en: {
    portfolio: {
      label: "Portfolio",
      title: "Behind every system,\na real challenge.",
      description:
        "A useful case study connects a business challenge to the engineering decisions behind a solution. We publish projects only with verified material and permission to disclose.",
      emptyTitle:
        "Case studies will appear here when they are approved for publication.",
      emptyText:
        "Public project materials will be added after the content is verified and disclosure terms are approved.",
      evidenceLabel: "WHAT A CASE SHOULD EXPLAIN",
      evidenceTitle: "Beyond the screen.\nThe thinking behind it.",
      evidence: [
        [
          "Context",
          "The business challenge, intended users and constraints that shaped the solution.",
        ],
        [
          "Solution",
          "Architecture, user journeys, integrations and the reasons behind technology choices.",
        ],
        [
          "Delivery",
          "Scope of responsibility, development stages and quality checks.",
        ],
        [
          "Outcome",
          "Verified changes and findings that can be shared publicly.",
        ],
      ],
      scenarioLabel: "POSSIBLE DIRECTIONS",
      scenarioTitle: "Explore what\nwe could build.",
      scenarioNote:
        "These are examples of challenges to discuss, not completed project case studies.",
      scenarios: [
        [
          "A digital product",
          "From a first user journey to a web application or SaaS platform.",
          "web-mobile",
        ],
        [
          "Connected operations",
          "Data, CRM and internal tools connected around an actual business process.",
          "business-automation",
        ],
        [
          "AI for your team",
          "An agent that helps find knowledge and carry out agreed actions.",
          "ai-agents",
        ],
      ],
      scenarioLink: "Explore this direction",
    },
    contact: {
      label: "Contact",
      title: "Start with\nyour challenge.",
      description:
        "Describe the idea, process or system you want to improve. A brief helps organize the starting information for a focused conversation.",
      mode: "PREPARE A PROJECT BRIEF",
      modeTitle: "Clarity comes first.",
      modeText:
        "The form validates data on this site’s server and creates a downloadable text file. It does not automatically send a message to the TASKONFF team.",
      modeHelp:
        "After downloading, share the file through your established contact channel with the company. Official addresses and channels will be added after confirmation.",
      prepareLabel: "USEFUL STARTING POINTS",
      prepareTitle: "A few details\nthat set the direction.",
      prepare: [
        ["Goal", "What should change for the business or its users?"],
        ["Context", "Which systems, data sources and processes already exist?"],
        [
          "Priorities",
          "What belongs in the first stage, and what can evolve later?",
        ],
        [
          "Constraints",
          "Is there an agreed timeframe, budget range or security requirement?",
        ],
      ],
      faqTitle: "Before the first step",
      faq: [
        [
          "Do I need a finished specification?",
          "No. You can start with the challenge, intended users and desired outcome. Requirements can be refined during discovery.",
        ],
        [
          "What happens to form data?",
          "Data is sent to this site’s server for validation and text-file generation. The application does not save brief content in a database or use this form to deliver it to the team.",
        ],
        [
          "Can I attach confidential materials?",
          "This form does not support attachments. Do not include passwords, tokens, third-party personal data or confidential commercial materials. Agree on a separate process for sharing them.",
        ],
        [
          "Where will I receive a reply?",
          "Downloading a brief does not submit an inquiry, so there is no automatic reply. Share the file through your established communication channel with TASKONFF.",
        ],
      ],
      techLink: "Explore the technology approach",
      privacyLink: "How data is processed",
    },
    legal: {
      draftLabel: "DRAFT DOCUMENT",
      draftText:
        "This edition describes the site’s current functionality. The legal owner, hosting details, applicable rules and processing periods must be confirmed before public launch. This document is not presented as a final approved legal policy.",
      contents: "Contents",
      backContact: "Prepare a project brief",
      privacy: {
        label: "Privacy",
        title: "A clear view\nof your data.",
        description:
          "What happens to data when you browse the site or create a project brief.",
        sections: [
          [
            "Scope",
            "This document describes the current TASKONFF website and its brief-generation form. It does not replace an approved policy for a specific legal entity. The owner’s details and an official data-processing contact have not yet been supplied.",
          ],
          [
            "Project brief data",
            "The form asks for your name, work email, area of interest and project description. This data is sent to the site’s server for validation and text-file generation. Downloading does not mean an inquiry has been delivered to the TASKONFF team.",
          ],
          [
            "Storage and transmission",
            "In the current implementation, the application does not save brief content in a database, log message bodies or forward the brief to an external recipient. The generated file is downloaded through your browser. Storage and subsequent sharing of the downloaded file depend on your actions and device settings.",
          ],
          [
            "Technical data",
            "The server processes technical request information to operate the website and limit request frequency. The hosting provider may process its own technical logs. Their contents, retention periods and processing terms must be clarified in the approved policy before launch.",
          ],
          [
            "Cookies and analytics",
            "The current application does not include analytics trackers or create cookies for advertising tracking. If analytics or other services are added, the disclosures and any required consent settings must be updated.",
          ],
          [
            "Your actions and inquiries",
            "Do not enter secrets, account credentials or other people’s personal data in the form. Before a final policy is published, the legal owner and official channel for data-processing requests must be identified. Confirmed details will be included in the final edition.",
          ],
          [
            "Changes in functionality",
            "Direct inquiry delivery, CRM connections, external analytics or other processors will require this edition to be updated before those functions are enabled.",
          ],
        ],
      },
      terms: {
        label: "Terms of use",
        title: "Clear expectations.\nA better starting point.",
        description:
          "The informational nature of the site, use of the project brief and the limits of current functionality.",
        sections: [
          [
            "Status of these terms",
            "These are draft terms for the current website. The legal entity, applicable law and dispute-resolution process must be set out in an approved document. This edition is not presented as a completed service agreement.",
          ],
          [
            "Information about solutions",
            "Pages describe development capabilities and possible uses of technology. They are not an individual specification, a delivery-date commitment or an offer for a defined scope of work. Project terms are agreed separately.",
          ],
          [
            "Briefs and inquiries",
            "The form creates a downloadable file after server validation. It does not form a contract, and the current interface does not send a message to the team. An email address in a brief does not by itself mean the company received an inquiry or agreed to respond.",
          ],
          [
            "Acceptable use",
            "Use the site to explore services and prepare a challenge description. Do not submit harmful content, secret keys, passwords or materials you are not entitled to share. Do not attempt to bypass request limits or disrupt the website.",
          ],
          [
            "Intellectual rights",
            "The TASKONFF name, original logo and materials should be used with respect for their owners’ rights. Mentioning technologies or third-party names does not transfer rights or imply a partnership.",
          ],
          [
            "Scenarios and portfolio",
            "Illustrations of possible solutions are not presented as delivered projects. Public case studies must be based on verified materials and permission to disclose. The terms for delivering each solution are agreed separately.",
          ],
          [
            "Changes and availability",
            "Content and functionality may evolve. Final provisions on liability, service availability and notice of changes must be approved by the legal owner before public launch.",
          ],
        ],
      },
    },
  },
};
