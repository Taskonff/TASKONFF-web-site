import { services } from "@/content/services";
import type { Locale, SiteContent } from "@/content/site";
import { ProjectBriefForm } from "./project-brief-form";
export function ProjectBrief({
  copy,
  locale = "ru",
}: {
  copy: SiteContent;
  locale?: Locale;
}) {
  return (
    <ProjectBriefForm
      copy={copy}
      locale={locale}
      options={services.map((service) => ({
        slug: service.slug,
        title: service[locale].title,
      }))}
    />
  );
}
