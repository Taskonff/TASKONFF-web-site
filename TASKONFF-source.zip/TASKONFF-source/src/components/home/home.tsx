import Link from "next/link";
import {
  ArrowDown,
  ArrowUpRight,
  ArrowRight,
  Plus,
  Braces,
  Layers3,
  Orbit,
  Workflow,
} from "lucide-react";
import { Reveal } from "./reveal";
import { DigitalEngine } from "./digital-engine";
import { ServiceGrid } from "./service-grid";
import { SolutionExplorer } from "./solution-explorer";
import { CapabilityStrip } from "./experience";
import { ProjectBrief } from "./project-brief";
import { Button } from "@/components/ui/button";
import type { Locale, SiteContent } from "@/content/site";
export function Home({ locale, copy }: { locale: Locale; copy: SiteContent }) {
  const ru = locale === "ru";
  return (
    <>
      <main id="main">
        <section className="hero" id="top">
          <div className="hero-grid-bg" aria-hidden="true" />
          <div className="container hero-topline">
            <span>
              <i />
              {ru
                ? "ИНЖЕНЕРИЯ ЦИФРОВОГО БУДУЩЕГО"
                : "ENGINEERING THE DIGITAL FUTURE"}
            </span>
            <span>SOFTWARE × INTELLIGENCE</span>
          </div>
          <div className="container hero-grid">
            <div className="hero-content">
              <Reveal>
                <p className="hero-kicker">BUILD. AUTOMATE. GROW.</p>
                <h1>
                  {ru ? (
                    <>
                      Сложные идеи.
                      <br />
                      <span className="hero-type-outline">Сильные</span>
                      <br />
                      <span className="gradient-text">решения.</span>
                    </>
                  ) : (
                    <>
                      Big ideas.
                      <br />
                      <span className="hero-type-outline">Brilliant</span>
                      <br />
                      <span className="gradient-text">execution.</span>
                    </>
                  )}
                </h1>
                <p className="hero-intro">
                  {ru
                    ? "Создаём цифровые продукты, внедряем AI и соединяем бизнес-процессы в работающие системы."
                    : "We build digital products, put AI to work and connect business processes into powerful systems."}
                </p>
                <div className="hero-buttons">
                  <Button asChild>
                    <a href="#contact">
                      {copy.primary}
                      <span>
                        <ArrowUpRight size={19} />
                      </span>
                    </a>
                  </Button>
                  <a className="hero-explore" href="#solutions">
                    {ru ? "Как это работает" : "See how it works"}
                    <ArrowDown size={16} />
                  </a>
                </div>
              </Reveal>
            </div>
            <div className="hero-visual">
              <DigitalEngine locale={locale} />
              <div className="visual-tag tag-product">
                <span className="tag-icon">
                  <Braces size={16} />
                </span>
                <div>
                  {ru ? "Цифровые продукты" : "Digital products"}
                  <small>WEB / MOBILE / SAAS</small>
                </div>
              </div>
              <div className="visual-tag tag-ai">
                <span className="tag-icon">
                  <Orbit size={16} />
                </span>
                <div>
                  {ru ? "Интеллект внутри" : "Intelligence inside"}
                  <small>AI / AGENTS / AUTOMATION</small>
                </div>
              </div>
            </div>
          </div>
          <div className="container hero-bottom">
            <a href="#expertise">
              <span className="scroll-mouse">
                <i />
              </span>
              {copy.scroll}
            </a>
            <span className="hero-bottom-note">
              {ru
                ? "ОТ ПЕРВОЙ ИДЕИ ДО СЛЕДУЮЩЕГО ЭТАПА"
                : "FROM YOUR FIRST IDEA TO WHAT COMES NEXT"}
              <ArrowUpRight size={14} />
            </span>
          </div>
        </section>
        <CapabilityStrip locale={locale} />
        <section className="expertise light-section section" id="expertise">
          <div className="container">
            <Reveal>
              <div className="section-topline">
                <p className="eyebrow">
                  <span className="eyebrow-cross">+</span>
                  {copy.expertise}
                </p>
                <span className="section-number">01 — EXPERTISE</span>
              </div>
              <div className="section-heading">
                <h2>
                  {ru ? (
                    <>
                      Не просто код.
                      <br />
                      <span>Ваше преимущество.</span>
                    </>
                  ) : (
                    <>
                      More than code.
                      <br />
                      <span>Your next advantage.</span>
                    </>
                  )}
                </h2>
                <p>{copy.servicesIntro}</p>
              </div>
            </Reveal>
            <ServiceGrid copy={copy} locale={locale} />
            <div className="home-page-link">
              <Link href={`/${locale}/services`}>
                {ru ? "Все услуги и направления" : "Explore all services"}
                <ArrowUpRight size={18} />
              </Link>
            </div>
          </div>
        </section>
        <SolutionExplorer locale={locale} />
        <section className="approach light-section section" id="approach">
          <div className="container">
            <Reveal>
              <div className="section-topline">
                <p className="eyebrow">
                  <span className="eyebrow-cross">+</span>
                  {copy.aboutLabel}
                </p>
                <span className="section-number">03 — APPROACH</span>
              </div>
              <div className="manifesto">
                <h2>
                  {ru ? (
                    <>
                      Сначала <span className="manifesto-blue">ваша цель.</span>
                      <br />
                      Затем — технология,
                      <br />
                      которая к ней ведёт
                      <span className="manifesto-dot">.</span>
                    </>
                  ) : (
                    <>
                      Your ambition{" "}
                      <span className="manifesto-blue">comes first.</span>
                      <br />
                      Then the technology
                      <br />
                      to take you there<span className="manifesto-dot">.</span>
                    </>
                  )}
                </h2>
                <div className="manifesto-note">
                  <span className="manifesto-icon">
                    <ArrowUpRight size={30} />
                  </span>
                  <p>{copy.aboutText}</p>
                </div>
              </div>
            </Reveal>
            <div className="process-heading">
              <h3>{copy.processTitle}</h3>
              <span>{copy.processLabel}</span>
            </div>
            <div className="process-grid">
              {copy.process.map(([title, description], i) => (
                <Reveal key={title} delay={i * 0.08}>
                  <article className="process-step">
                    <div className="step-track">
                      <span>0{i + 1}</span>
                      <ArrowRight size={18} />
                    </div>
                    <h4>{title}</h4>
                    <p>{description}</p>
                  </article>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
        <section className="technologies section" id="technologies">
          <div className="container tech-grid">
            <Reveal>
              <p className="eyebrow">
                <span className="eyebrow-cross">+</span>
                {copy.techLabel}
              </p>
              <h2>
                {ru ? (
                  <>
                    Сильный стек.
                    <br />
                    <span className="gradient-text">Свобода роста.</span>
                  </>
                ) : (
                  <>
                    A solid foundation.
                    <br />
                    <span className="gradient-text">Room to grow.</span>
                  </>
                )}
              </h2>
              <p className="tech-description">{copy.techText}</p>
              <a href="#contact" className="text-link">
                {ru ? "Обсудить вашу задачу" : "Explore your project"}
                <ArrowUpRight size={18} />
              </a>
            </Reveal>
            <Reveal className="tech-panel">
              <div className="tech-panel-heading">
                <span>{copy.techCaption}</span>
                <span aria-hidden="true">
                  <Plus size={16} />
                </span>
              </div>
              <div className="tech-core">
                <div className="tech-core-icon">
                  <Layers3 size={32} strokeWidth={1.2} />
                </div>
                <span>CONNECTED BY DESIGN</span>
              </div>
              <div className="tech-list">
                {[
                  "Next.js",
                  "TypeScript",
                  "React",
                  "Tailwind CSS",
                  "shadcn/ui",
                  "Motion",
                ].map((name, i) => (
                  <div key={name}>
                    <span className="tech-symbol">
                      {["N", "TS", "Re", "Tw", "/", "M"][i]}
                    </span>
                    <span>{name}</span>
                    <i />
                  </div>
                ))}
              </div>
              <div className="tech-panel-footer">
                <Workflow size={14} />
                <span>
                  {ru
                    ? "Модульность. Интеграции. Развитие."
                    : "Modular. Connected. Evolvable."}
                </span>
              </div>
            </Reveal>
          </div>
        </section>
        <section className="contact section" id="contact">
          <div className="container">
            <div className="contact-intro">
              <Reveal>
                <p className="eyebrow">
                  <span className="eyebrow-cross">+</span>
                  {copy.contactLabel}
                </p>
                <h2>
                  {ru ? (
                    <>
                      Ваша следующая
                      <br />
                      <span>большая идея.</span>
                    </>
                  ) : (
                    <>
                      Your next
                      <br />
                      <span>big thing.</span>
                    </>
                  )}
                </h2>
              </Reveal>
              <ArrowUpRight
                className="contact-arrow"
                strokeWidth={0.8}
                aria-hidden="true"
              />
            </div>
            <div className="contact-grid">
              <div className="contact-aside">
                <p>{copy.contactText}</p>
                <span className="contact-local-label">
                  <span />
                  {ru
                    ? "Начните с короткого брифа"
                    : "Start with a short project brief"}
                </span>
                <div className="contact-lines" aria-hidden="true">
                  <i />
                  <i />
                  <i />
                </div>
              </div>
              <Reveal>
                <ProjectBrief copy={copy} locale={locale} />
              </Reveal>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
