"use client";
import { useState } from "react";
import { Pause, Play, Asterisk } from "lucide-react";
import { motion, useScroll, useSpring, useReducedMotion } from "motion/react";
export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const smooth = useSpring(scrollYProgress, { stiffness: 180, damping: 35 });
  const reduced = useReducedMotion();
  return (
    <motion.div
      className="scroll-progress"
      aria-hidden="true"
      style={{ scaleX: reduced ? scrollYProgress : smooth }}
    />
  );
}
export function CapabilityStrip({ locale }: { locale: "ru" | "en" }) {
  const [paused, setPaused] = useState(false);
  const terms =
    locale === "ru"
      ? [
          "Цифровые продукты",
          "Искусственный интеллект",
          "Автоматизация",
          "Системная интеграция",
        ]
      : [
          "Digital products",
          "Artificial intelligence",
          "Automation",
          "System integration",
        ];
  return (
    <div className="capability-strip">
      <div
        className="capability-track"
        style={{ animationPlayState: paused ? "paused" : undefined }}
      >
        {[0, 1].map((repeat) => (
          <div
            key={repeat}
            className="capability-set"
            aria-hidden={repeat === 1 ? true : undefined}
          >
            {terms.map((term) => (
              <span key={term}>
                <Asterisk size={25} strokeWidth={1.4} aria-hidden="true" />
                {term}
              </span>
            ))}
          </div>
        ))}
      </div>
      <button
        className="ribbon-toggle"
        type="button"
        onClick={() => setPaused(!paused)}
        aria-pressed={paused}
        aria-label={
          locale === "ru"
            ? paused
              ? "Продолжить движение ленты"
              : "Остановить движение ленты"
            : paused
              ? "Play capability ribbon"
              : "Pause capability ribbon"
        }
      >
        {paused ? <Play size={13} /> : <Pause size={13} />}
      </button>
    </div>
  );
}
