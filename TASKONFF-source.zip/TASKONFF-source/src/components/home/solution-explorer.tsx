"use client";

import { useId, useRef, useState, type KeyboardEvent } from "react";
import { motion, useReducedMotion } from "motion/react";
import {
  ArrowRight,
  ArrowUpRight,
  Bot,
  Boxes,
  Braces,
  CircleCheck,
  Database,
  FileInput,
  GitBranch,
  Layers3,
  Lightbulb,
  Network,
  Rocket,
  ShieldCheck,
  Sparkles,
  Workflow,
  type LucideIcon,
} from "lucide-react";
import "./solution-explorer.css";

type Scenario = {
  tab: string;
  title: string;
  description: string;
  icon: LucideIcon;
  nodes: { title: string; label: string; detail: string; icon: LucideIcon }[];
};

const scenarios: Record<"ru" | "en", Scenario[]> = {
  ru: [
    {
      tab: "Запуск продукта",
      title: "От идеи — к работающему продукту.",
      description:
        "Объединяем пользовательский опыт, разработку и инфраструктуру в одну систему. Исследуйте возможную архитектуру вашего продукта.",
      icon: Rocket,
      nodes: [
        {
          title: "Идея и задачи",
          label: "Стратегия",
          detail:
            "Начинаем с бизнес-задачи: кому нужен продукт, какую проблему он решает и что важно проверить до разработки.",
          icon: Lightbulb,
        },
        {
          title: "Опыт пользователя",
          label: "Дизайн",
          detail:
            "Собираем сценарии в понятный интерфейс. Прототип помогает проверить логику и согласовать решения до написания кода.",
          icon: Layers3,
        },
        {
          title: "Модульная система",
          label: "Разработка",
          detail:
            "Разделяем продукт на понятные модули и интеграции. Это упрощает тестирование, сопровождение и добавление новых возможностей.",
          icon: Braces,
        },
        {
          title: "Запуск и развитие",
          label: "Инфраструктура",
          detail:
            "Планируем окружения, проверку качества и выпуск продукта. Архитектура учитывает будущие изменения и интеграции.",
          icon: Rocket,
        },
      ],
    },
    {
      tab: "Автоматизация бизнеса",
      title: "Меньше ручных действий. Больше связей.",
      description:
        "Соединяем данные, инструменты и процессы. Посмотрите, как может выглядеть путь задачи от входящего события до результата.",
      icon: Workflow,
      nodes: [
        {
          title: "Входящие данные",
          label: "Источники",
          detail:
            "Определяем, откуда приходят заявки и документы, какие данные нужны команде и где сейчас появляются повторные действия.",
          icon: FileInput,
        },
        {
          title: "Единая логика",
          label: "Процессы",
          detail:
            "Описываем правила маршрутизации, согласования и обработки исключений. Сохраняем контроль сотрудников там, где он необходим.",
          icon: GitBranch,
        },
        {
          title: "Связанные системы",
          label: "Интеграции",
          detail:
            "Связываем CRM, ERP и другие инструменты через согласованные интерфейсы. Учитываем права доступа и проверку данных.",
          icon: Network,
        },
        {
          title: "Понятный результат",
          label: "Контроль",
          detail:
            "Проектируем статусы, уведомления и возможность проследить путь задачи. Ошибки должны быть заметны и доступны для разбора.",
          icon: CircleCheck,
        },
      ],
    },
    {
      tab: "AI-агенты",
      title: "Интеллект, встроенный в ваш процесс.",
      description:
        "AI приносит пользу в контексте конкретной задачи. Исследуйте сценарий помощника, который использует знания компании и работает в заданных границах.",
      icon: Bot,
      nodes: [
        {
          title: "База знаний",
          label: "Контекст",
          detail:
            "Выбираем разрешённые источники и правила доступа. Подготовка данных определяет, какую информацию помощник сможет использовать.",
          icon: Database,
        },
        {
          title: "AI-помощник",
          label: "Модель",
          detail:
            "Подбираем модель под задачу, ограничения и требования к данным. Проектируем инструкции и способы проверки качества ответов.",
          icon: Sparkles,
        },
        {
          title: "Инструменты",
          label: "Действия",
          detail:
            "Даём агенту только необходимые инструменты: поиск, подготовку документов или работу с разрешёнными API. Определяем границы каждого действия.",
          icon: Boxes,
        },
        {
          title: "Контроль человека",
          label: "Проверка",
          detail:
            "Предусматриваем подтверждение значимых действий, передачу сложных запросов сотруднику и проверку результата перед использованием.",
          icon: ShieldCheck,
        },
      ],
    },
  ],
  en: [
    {
      tab: "Product launch",
      title: "From an idea to a working product.",
      description:
        "Connect user experience, engineering and infrastructure into one system. Explore a possible architecture for your next product.",
      icon: Rocket,
      nodes: [
        {
          title: "Idea & purpose",
          label: "Strategy",
          detail:
            "Start with the business problem: who needs the product, what it should solve and what needs to be tested before development.",
          icon: Lightbulb,
        },
        {
          title: "User experience",
          label: "Design",
          detail:
            "Turn user journeys into a clear interface. A prototype helps validate the logic and align decisions before writing code.",
          icon: Layers3,
        },
        {
          title: "Modular system",
          label: "Engineering",
          detail:
            "Organize the product into clear modules and integrations, making it easier to test, maintain and introduce new capabilities.",
          icon: Braces,
        },
        {
          title: "Launch & evolve",
          label: "Infrastructure",
          detail:
            "Plan environments, quality checks and product releases. Leave room in the architecture for future changes and integrations.",
          icon: Rocket,
        },
      ],
    },
    {
      tab: "Business automation",
      title: "Fewer manual steps. More connections.",
      description:
        "Connect data, tools and workflows. Explore how a task could move from an incoming event to a clear, traceable result.",
      icon: Workflow,
      nodes: [
        {
          title: "Incoming data",
          label: "Sources",
          detail:
            "Identify where requests and documents originate, what information the team needs and where repetitive work happens today.",
          icon: FileInput,
        },
        {
          title: "Shared logic",
          label: "Workflows",
          detail:
            "Define routing, approval and exception handling. Keep people in control wherever their judgment is required.",
          icon: GitBranch,
        },
        {
          title: "Connected tools",
          label: "Integrations",
          detail:
            "Connect CRM, ERP and other tools through agreed interfaces, with appropriate access permissions and data validation.",
          icon: Network,
        },
        {
          title: "A clear result",
          label: "Visibility",
          detail:
            "Design statuses, notifications and a traceable task journey. Errors should be visible and available for investigation.",
          icon: CircleCheck,
        },
      ],
    },
    {
      tab: "AI agents",
      title: "Intelligence, built into your workflow.",
      description:
        "AI is useful in the context of a real task. Explore an assistant that uses company knowledge and works within defined boundaries.",
      icon: Bot,
      nodes: [
        {
          title: "Knowledge base",
          label: "Context",
          detail:
            "Choose approved sources and access rules. Data preparation determines what information the assistant will be able to use.",
          icon: Database,
        },
        {
          title: "AI assistant",
          label: "Model",
          detail:
            "Select a model around the task, constraints and data requirements. Design instructions and ways to assess response quality.",
          icon: Sparkles,
        },
        {
          title: "Connected tools",
          label: "Actions",
          detail:
            "Give the agent only the tools it needs: search, document preparation or approved APIs. Define the boundaries of every action.",
          icon: Boxes,
        },
        {
          title: "Human oversight",
          label: "Review",
          detail:
            "Include approval for consequential actions, handover of complex requests and a review of results before they are used.",
          icon: ShieldCheck,
        },
      ],
    },
  ],
};

export function SolutionExplorer({ locale }: { locale: "ru" | "en" }) {
  const [selected, setSelected] = useState(0);
  const [node, setNode] = useState(0);
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);
  const uid = useId();
  const reduced = useReducedMotion();
  const items = scenarios[locale];
  const scenario = items[selected];
  const detail = scenario.nodes[node];
  const DetailIcon = detail.icon;
  const ru = locale === "ru";

  function select(index: number) {
    setSelected(index);
    setNode(0);
  }

  function navigate(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next = index;
    if (event.key === "ArrowRight") next = (index + 1) % items.length;
    else if (event.key === "ArrowLeft")
      next = (index + items.length - 1) % items.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = items.length - 1;
    else return;
    event.preventDefault();
    select(next);
    tabs.current[next]?.focus();
  }

  return (
    <section
      className="solutions-section"
      id="solutions"
      aria-labelledby={`${uid}-heading`}
    >
      <div className="solutions-container">
        <div className="solutions-heading-row">
          <div>
            <p className="solutions-eyebrow">
              <span />
              {ru ? "ТЕХНОЛОГИИ В ДЕЙСТВИИ" : "TECHNOLOGY IN ACTION"}
            </p>
            <h2 id={`${uid}-heading`}>
              {ru
                ? "Посмотрите, как всё\nсоединяется."
                : "See how it all\nconnects."}
            </h2>
          </div>
          <p className="solutions-intro">
            {ru
              ? "Выберите задачу. Исследуйте логику решения. Каждый элемент схемы раскрывает свой этап."
              : "Choose a challenge. Explore the solution. Each element reveals a part of the process."}
          </p>
        </div>

        <div
          className="solutions-tabs"
          role="tablist"
          aria-label={ru ? "Сценарии решений" : "Solution scenarios"}
        >
          {items.map((item, index) => {
            const Icon = item.icon;
            return (
              <button
                key={item.tab}
                id={`${uid}-tab-${index}`}
                ref={(element) => {
                  tabs.current[index] = element;
                }}
                type="button"
                role="tab"
                aria-selected={selected === index}
                tabIndex={selected === index ? 0 : -1}
                aria-controls={`${uid}-panel`}
                className="solutions-tab"
                onClick={() => select(index)}
                onKeyDown={(event) => navigate(event, index)}
              >
                <Icon size={18} strokeWidth={1.5} />
                <span>{item.tab}</span>
                <ArrowUpRight size={16} />
              </button>
            );
          })}
        </div>

        <motion.div
          key={selected}
          role="tabpanel"
          id={`${uid}-panel`}
          aria-labelledby={`${uid}-tab-${selected}`}
          tabIndex={0}
          className="solutions-panel"
          initial={reduced ? false : { opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.22 }}
        >
          <div className="solutions-panel-heading">
            <div>
              <span className="solutions-scenario-label">
                {ru ? "ВОЗМОЖНЫЙ СЦЕНАРИЙ" : "A POSSIBLE SCENARIO"}
              </span>
              <h3>{scenario.title}</h3>
            </div>
            <p>{scenario.description}</p>
          </div>
          <div className="solutions-workflow">
            {scenario.nodes.map((item, index) => {
              const Icon = item.icon;
              return (
                <div className="solutions-node-wrap" key={item.title}>
                  <button
                    type="button"
                    className="solutions-node"
                    aria-pressed={node === index}
                    aria-controls={`${uid}-detail`}
                    onClick={() => setNode(index)}
                  >
                    <span className="solutions-node-top">
                      <span className="solutions-node-icon">
                        <Icon size={25} strokeWidth={1.5} />
                      </span>
                      <span className="solutions-node-index">0{index + 1}</span>
                    </span>
                    <span className="solutions-node-label">{item.label}</span>
                    <strong>{item.title}</strong>
                    <span className="solutions-node-action">
                      <span>{ru ? "Исследовать" : "Explore"}</span>
                      <ArrowUpRight size={15} />
                    </span>
                  </button>
                  {index < scenario.nodes.length - 1 && (
                    <span className="solutions-connector" aria-hidden="true">
                      <i />
                      <ArrowRight size={13} />
                    </span>
                  )}
                </div>
              );
            })}
          </div>
          <div
            className="solutions-detail"
            id={`${uid}-detail`}
            aria-live="polite"
            aria-atomic="true"
          >
            <div className="solutions-detail-icon">
              <DetailIcon size={22} strokeWidth={1.5} />
            </div>
            <div>
              <span>{detail.label}</span>
              <p>{detail.detail}</p>
            </div>
            <a href="#contact">
              {ru ? "Обсудить свою задачу" : "Discuss your challenge"}
              <ArrowUpRight size={17} />
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
