"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useRef } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { BrandLogo } from "@/components/brand-logo";
import { Button } from "@/components/ui/button";
import type { Locale, SiteContent } from "@/content/site";
import { pageNames, type PageSlug } from "@/lib/routes";
const desktopPages: PageSlug[] = [
  "about",
  "services",
  "industries",
  "portfolio",
  "technologies",
  "process",
];
export function Header({
  locale,
  copy,
  logo,
}: {
  locale: Locale;
  copy: SiteContent;
  logo?: string;
}) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const menu = useRef<HTMLButtonElement>(null);
  const other = locale === "ru" ? "en" : "ru";
  const languagePath = pathname.replace(/^\/(ru|en)(?=\/|$)/, `/${other}`);
  const active = (slug: string) =>
    pathname === `/${locale}/${slug}` ||
    pathname.startsWith(`/${locale}/${slug}/`);
  return (
    <>
      <a className="skip-link" href="#main">
        {copy.skip}
      </a>
      <header
        className="header site-header"
        onKeyDown={(event) => {
          if (event.key === "Escape" && open) {
            setOpen(false);
            menu.current?.focus();
          }
        }}
      >
        <div className="container header-inner">
          <Link
            className="company-name"
            href={`/${locale}`}
            aria-label="TASKONFF"
            onClick={() => setOpen(false)}
          >
            <BrandLogo src={logo} />
          </Link>
          <nav
            className="desktop-nav"
            aria-label={
              locale === "ru" ? "Основная навигация" : "Main navigation"
            }
          >
            {desktopPages.map((slug) => (
              <Link
                key={slug}
                href={`/${locale}/${slug}`}
                aria-current={active(slug) ? "page" : undefined}
              >
                {pageNames[locale][slug]}
              </Link>
            ))}
          </nav>
          <div className="header-actions">
            <Link
              className="language"
              href={languagePath}
              aria-label={copy.language}
              onClick={() => setOpen(false)}
            >
              {other.toUpperCase()}
              <ArrowUpRight size={11} />
            </Link>
            <Button asChild variant="outline" size="sm" className="header-cta">
              <Link href={`/${locale}/contact`}>
                {copy.talk}
                <ArrowUpRight size={15} />
              </Link>
            </Button>
            <button
              ref={menu}
              type="button"
              className="menu-toggle"
              aria-label={open ? copy.close : copy.menu}
              aria-expanded={open}
              aria-controls="mobile-nav"
              onClick={() => setOpen(!open)}
            >
              {open ? <X /> : <Menu />}
            </button>
          </div>
        </div>
        <nav
          id="mobile-nav"
          hidden={!open}
          className="mobile-nav"
          aria-label={copy.menu}
        >
          <Link href={`/${locale}`} onClick={() => setOpen(false)}>
            {locale === "ru" ? "Главная" : "Home"}
            <ArrowUpRight size={16} />
          </Link>
          {[...desktopPages, "contact" as const].map((slug) => (
            <Link
              key={slug}
              href={`/${locale}/${slug}`}
              onClick={() => setOpen(false)}
              aria-current={active(slug) ? "page" : undefined}
            >
              {pageNames[locale][slug]}
              <ArrowUpRight size={16} />
            </Link>
          ))}
        </nav>
      </header>
    </>
  );
}
