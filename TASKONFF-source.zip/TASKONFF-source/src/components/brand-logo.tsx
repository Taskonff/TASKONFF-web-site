import Image from "next/image";
export function BrandLogo({ src }: { src?: string }) {
  return src ? (
    <span className="brand-logo">
      <Image
        src={src}
        alt="TASKONFF"
        fill
        sizes="(max-width: 640px) 152px, 200px"
        style={{ objectFit: "contain" }}
        priority
      />
    </span>
  ) : (
    <span className="brand-name-text">TASKONFF</span>
  );
}
