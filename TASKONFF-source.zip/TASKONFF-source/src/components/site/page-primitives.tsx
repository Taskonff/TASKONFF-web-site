import Link from "next/link";
import { ArrowUpRight, ArrowLeft } from "lucide-react";
import type { Locale } from "@/content/site";
import { Reveal } from "@/components/home/reveal";
export function InternalHero({
  locale,
  eyebrow,
  title,
  description,
  index = "TASKONFF",
  children,
}: {
  locale: Locale;
  eyebrow: string;
  title: string;
  description: string;
  index?: string;
  children?: React.ReactNode;
}) {
  return (
    <section className="internal-hero" id="top">
      <div className="internal-hero-grid" aria-hidden="true" />
      <div className="container">
        <nav
          className="breadcrumbs"
          aria-label={locale === "ru" ? "Хлебные крошки" : "Breadcrumbs"}
        >
          <Link href={`/${locale}`}>
            <ArrowLeft size={13} />
            {locale === "ru" ? "Главная" : "Home"}
          </Link>
          <span>/</span>
          <span aria-current="page">{eyebrow}</span>
        </nav>
        <div className="internal-hero-content">
          <Reveal>
            <p className="eyebrow">
              <span className="eyebrow-cross">+</span>
              {eyebrow}
            </p>
            <h1>{title}</h1>
            <p className="internal-intro">{description}</p>
          </Reveal>
          <div className="internal-hero-art">
            {children ?? (
              <div className="page-sculpture" aria-hidden="true">
                <div />
                <div />
                <div />
                <span>
                  BUILD
                  <br />
                  AUTOMATE
                  <br />
                  GROW
                </span>
              </div>
            )}
          </div>
        </div>
        <div className="internal-hero-bottom">
          <span>{index}</span>
          <span>BUILD • AUTOMATE • GROW</span>
        </div>
      </div>
    </section>
  );
}
export function PageCTA({
  locale,
  title,
  description,
}: {
  locale: Locale;
  title?: string;
  description?: string;
}) {
  const ru = locale === "ru";
  return (
    <section className="internal-cta">
      <div className="container">
        <Reveal>
          <p className="eyebrow">{ru ? "СЛЕДУЮЩИЙ ШАГ" : "WHAT’S NEXT"}</p>
          <h2>
            {title ??
              (ru ? "От задачи — к решению." : "From challenge to solution.")}
          </h2>
          <p>
            {description ??
              (ru
                ? "Расскажите, что вы хотите создать или улучшить. Начнём с ясного описания задачи."
                : "Tell us what you want to build or improve. Let’s start with a clear project brief.")}
          </p>
        </Reveal>
        <Link className="internal-cta-link" href={`/${locale}/contact`}>
          <span>{ru ? "Обсудить проект" : "Discuss a project"}</span>
          <ArrowUpRight size={32} />
        </Link>
      </div>
    </section>
  );
}
