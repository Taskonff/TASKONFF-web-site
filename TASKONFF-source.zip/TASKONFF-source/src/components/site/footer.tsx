import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { BrandLogo } from "@/components/brand-logo";
import { content, type Locale } from "@/content/site";
import { pageNames, pageSlugs } from "@/lib/routes";
export function Footer({ locale, logo }: { locale: Locale; logo?: string }) {
  const copy = content[locale];
  return (
    <footer className="footer site-footer">
      <div className="container">
        <div className="footer-directory">
          <div className="footer-brand">
            <Link
              href={`/${locale}`}
              className="company-name"
              aria-label="TASKONFF"
            >
              <BrandLogo src={logo} />
            </Link>
            <p>{copy.footer}</p>
            <span>BUILD • AUTOMATE • GROW</span>
          </div>
          <nav
            aria-label={locale === "ru" ? "Разделы сайта" : "Site directory"}
            className="footer-page-links"
          >
            {pageSlugs
              .filter((s) => s !== "privacy" && s !== "terms")
              .map((slug) => (
                <Link key={slug} href={`/${locale}/${slug}`}>
                  {pageNames[locale][slug]}
                  <ArrowUpRight size={12} />
                </Link>
              ))}
          </nav>
        </div>
        <div className="footer-bottom">
          <span>
            © {new Date().getFullYear()} TASKONFF. {copy.rights}
          </span>
          <nav
            aria-label={
              locale === "ru" ? "Правовая информация" : "Legal information"
            }
          >
            <Link href={`/${locale}/privacy`}>{pageNames[locale].privacy}</Link>
            <Link href={`/${locale}/terms`}>{pageNames[locale].terms}</Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}
