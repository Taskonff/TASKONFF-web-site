import Link from "next/link";
import {
  ArrowUpRight,
  ArrowRight,
  Compass,
  Layers3,
  ShieldCheck,
  Plus,
} from "lucide-react";
import type { Locale } from "@/content/site";
import { companyContent } from "@/content/company";
import { InternalHero, PageCTA } from "@/components/site/page-primitives";
import { Reveal } from "@/components/home/reveal";
import { CompanyExplorer } from "./company-interactions";
import "./company-pages.css";
export function AboutPage({ locale }: { locale: Locale }) {
  const c = companyContent[locale].about;
  const icons = [Compass, Layers3, ShieldCheck];
  return (
    <main id="main" className="internal-page">
      <InternalHero
        locale={locale}
        eyebrow={c.label}
        title={c.title}
        description={c.intro}
        index="01 / ABOUT"
      />
      <section className="section light-section company-about">
        <div className="container">
          <Reveal>
            <div className="company-editorial">
              <h2>{c.heading}</h2>
              <p>{c.body}</p>
            </div>
          </Reveal>
          <div className="company-principles">
            {c.principles.map(([title, text], index) => {
              const Icon = icons[index];
              return (
                <Reveal key={title} delay={index * 0.06}>
                  <article>
                    <div className="company-card-top">
                      <Icon size={24} strokeWidth={1.4} />
                      <span>0{index + 1}</span>
                    </div>
                    <h3>{title}</h3>
                    <p>{text}</p>
                  </article>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>
      <section className="section company-capabilities">
        <div className="container">
          <Reveal>
            <p className="eyebrow">
              <span className="eyebrow-cross">+</span>
              {locale === "ru" ? "ЧТО МЫ ОБЪЕДИНЯЕМ" : "WHAT WE CONNECT"}
            </p>
            <div className="company-section-heading">
              <h2>{c.capTitle}</h2>
              <p>{c.capText}</p>
            </div>
          </Reveal>
          <div className="company-capability-grid">
            {c.capabilities.map(([title, text, slug], index) => (
              <Reveal key={slug} delay={index * 0.04}>
                <Link href={`/${locale}/services/${slug}`}>
                  <span className="company-cap-number">0{index + 1}</span>
                  <h3>{title}</h3>
                  <p>{text}</p>
                  <ArrowUpRight size={21} />
                </Link>
              </Reveal>
            ))}
          </div>
          <Link className="company-more-link" href={`/${locale}/process`}>
            {locale === "ru"
              ? "Как устроена работа над проектом"
              : "How a project takes shape"}
            <ArrowRight size={17} />
          </Link>
        </div>
      </section>
      <PageCTA locale={locale} title={c.cta} />
    </main>
  );
}
export function TechnologiesPage({ locale }: { locale: Locale }) {
  const c = companyContent[locale].tech;
  return (
    <main id="main" className="internal-page">
      <InternalHero
        locale={locale}
        eyebrow={c.label}
        title={c.title}
        description={c.intro}
        index="05 / TECHNOLOGIES"
      />
      <section className="section company-architecture">
        <div className="container">
          <Reveal>
            <h2>{c.heading}</h2>
            <p className="company-section-note">{c.note}</p>
          </Reveal>
          <CompanyExplorer locale={locale} kind="architecture" />
        </div>
      </section>
      <section className="section light-section">
        <div className="container">
          <Reveal>
            <div className="company-editorial">
              <h2>{c.toolTitle}</h2>
              <p>{c.toolText}</p>
            </div>
          </Reveal>
          <div className="company-tools">
            {c.tools.map(([title, text], index) => (
              <Reveal key={title} delay={index * 0.05}>
                <article>
                  <span>0{index + 1}</span>
                  <h3>{title}</h3>
                  <p>{text}</p>
                </article>
              </Reveal>
            ))}
          </div>
          <div className="company-future">
            <span>
              <Plus size={21} />
              {c.future}
            </span>
            <p>{c.futureText}</p>
          </div>
        </div>
      </section>
      <PageCTA locale={locale} title={c.cta} />
    </main>
  );
}
export function ProcessPage({ locale }: { locale: Locale }) {
  const c = companyContent[locale].process;
  return (
    <main id="main" className="internal-page">
      <InternalHero
        locale={locale}
        eyebrow={c.label}
        title={c.title}
        description={c.intro}
        index="06 / PROCESS"
      />
      <section className="section company-process">
        <div className="container">
          <Reveal>
            <h2>{c.heading}</h2>
            <p className="company-section-note">{c.note}</p>
          </Reveal>
          <CompanyExplorer locale={locale} kind="phases" />
        </div>
      </section>
      <section className="section light-section">
        <div className="container">
          <Reveal>
            <div className="company-editorial">
              <h2>{c.feedbackTitle}</h2>
              <p>{c.feedbackText}</p>
            </div>
          </Reveal>
          <div className="company-feedback">
            {c.feedback.map(([title, text], index) => (
              <Reveal key={title} delay={index * 0.06}>
                <article>
                  <span>0{index + 1}</span>
                  <h3>{title}</h3>
                  <p>{text}</p>
                </article>
              </Reveal>
            ))}
          </div>
          <div className="company-faq">
            <h2>{c.faqTitle}</h2>
            <div>
              {c.faq.map(([question, answer]) => (
                <details key={question}>
                  <summary>
                    {question}
                    <Plus size={18} />
                  </summary>
                  <p>{answer}</p>
                </details>
              ))}
            </div>
          </div>
        </div>
      </section>
      <PageCTA locale={locale} title={c.cta} />
    </main>
  );
}
