"use client";
import { useId, useRef, useState, type KeyboardEvent } from "react";
import { motion, useReducedMotion } from "motion/react";
import {
  ArrowRight,
  ArrowUpRight,
  Braces,
  Database,
  Layers3,
  Workflow,
  Check,
} from "lucide-react";
import type { Locale } from "@/content/site";
import { companyContent } from "@/content/company";
export function CompanyExplorer({
  locale,
  kind,
}: {
  locale: Locale;
  kind: "architecture" | "phases";
}) {
  const data = companyContent[locale][kind];
  const [selected, setSelected] = useState(0);
  const uid = useId();
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  const reduced = useReducedMotion();
  const active = data.items[selected];
  function navigate(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next = index;
    if (event.key === "ArrowRight") next = (index + 1) % data.items.length;
    else if (event.key === "ArrowLeft")
      next = (index + data.items.length - 1) % data.items.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = data.items.length - 1;
    else return;
    event.preventDefault();
    setSelected(next);
    refs.current[next]?.focus();
  }
  const icons = [Braces, Workflow, Database, Layers3];
  return (
    <div className={`company-explorer company-explorer-${kind}`}>
      <div className="company-explorer-label">
        <span>{data.label}</span>
        <p>{data.hint}</p>
      </div>
      <div className="company-tabs" role="tablist" aria-label={data.label}>
        {data.items.map((item, index) => {
          const Icon = icons[index];
          return (
            <button
              key={item.title}
              ref={(el) => {
                refs.current[index] = el;
              }}
              type="button"
              role="tab"
              id={`${uid}-tab-${index}`}
              aria-selected={selected === index}
              tabIndex={selected === index ? 0 : -1}
              aria-controls={`${uid}-panel`}
              onKeyDown={(event) => navigate(event, index)}
              onClick={() => setSelected(index)}
            >
              <span>0{index + 1}</span>
              <Icon size={18} />
              <strong>{item.title}</strong>
              <ArrowUpRight size={15} />
            </button>
          );
        })}
      </div>
      <div
        id={`${uid}-panel`}
        className="company-panel"
        role="tabpanel"
        tabIndex={0}
        aria-labelledby={`${uid}-tab-${selected}`}
      >
        <motion.div
          key={selected}
          initial={reduced ? false : { opacity: 0.5, y: 9 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="company-panel-grid"
        >
          <div>
            <p className="company-panel-eyebrow">{active.eyebrow}</p>
            <h3>{active.title}</h3>
            <p className="company-panel-description">{active.text}</p>
            <div className="company-chips">
              {active.chips.map((chip) => (
                <span key={chip}>{chip}</span>
              ))}
            </div>
          </div>
          <div className="company-diagram" aria-hidden="true">
            {active.nodes.map((node, index) => (
              <div className="company-node-wrap" key={node}>
                <div
                  className={`company-node ${index === 1 ? "company-node-focus" : ""}`}
                >
                  <span>0{index + 1}</span>
                  {index === 0 ? (
                    <Braces size={22} />
                  ) : index === 1 ? (
                    <Layers3 size={25} />
                  ) : (
                    <Workflow size={22} />
                  )}
                  <strong>{node}</strong>
                </div>
                {index < 2 && (
                  <span className="company-node-connector">
                    <i />
                    <ArrowRight size={13} />
                  </span>
                )}
              </div>
            ))}
          </div>
        </motion.div>
        <div className="company-deliverables">
          <p>{locale === "ru" ? "ЧТО ОПРЕДЕЛЯЕМ" : "WHAT TAKES SHAPE"}</p>
          <ul>
            {active.outputs.map((output) => (
              <li key={output}>
                <Check size={14} />
                {output}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
