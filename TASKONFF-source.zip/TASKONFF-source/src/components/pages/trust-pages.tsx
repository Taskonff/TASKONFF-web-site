import Link from "next/link";
import {
  ArrowUpRight,
  ArrowDownToLine,
  FileCheck2,
  FolderOpen,
  ScanLine,
  ShieldCheck,
  MessageSquare,
  Plus,
  Check,
} from "lucide-react";
import { InternalHero, PageCTA } from "@/components/site/page-primitives";
import { Reveal } from "@/components/home/reveal";
import { ProjectBrief } from "@/components/home/project-brief";
import { content, type Locale } from "@/content/site";
import { trustContent } from "@/content/trust";
import "./trust-pages.css";

export function PortfolioPage({ locale }: { locale: Locale }) {
  const copy = trustContent[locale].portfolio;
  return (
    <main id="main" className="internal-page trust-page">
      <InternalHero
        locale={locale}
        eyebrow={copy.label}
        title={copy.title}
        description={copy.description}
        index="04 — PORTFOLIO"
      >
        <div className="trust-portfolio-art" aria-hidden="true">
          <span />
          <span />
          <span />
          <FolderOpen size={50} strokeWidth={1} />
        </div>
      </InternalHero>
      <section className="trust-publication section light-section">
        <div className="container">
          <Reveal className="trust-empty">
            <span className="trust-empty-icon">
              <FolderOpen size={30} strokeWidth={1.3} />
            </span>
            <div>
              <p className="eyebrow">
                {locale === "ru"
                  ? "ПУБЛИКАЦИЯ КЕЙСОВ"
                  : "CASE STUDY PUBLICATION"}
              </p>
              <h2>{copy.emptyTitle}</h2>
              <p>{copy.emptyText}</p>
            </div>
          </Reveal>
          <div className="trust-evidence-heading">
            <p className="eyebrow">
              <span className="eyebrow-cross">+</span>
              {copy.evidenceLabel}
            </p>
            <h2>{copy.evidenceTitle}</h2>
          </div>
          <div className="trust-evidence-grid">
            {copy.evidence.map(([title, text], i) => (
              <Reveal key={title} delay={i * 0.05}>
                <article>
                  <span>0{i + 1}</span>
                  <h3>{title}</h3>
                  <p>{text}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="trust-scenarios section">
        <div className="container">
          <Reveal>
            <p className="eyebrow">
              <span className="eyebrow-cross">+</span>
              {copy.scenarioLabel}
            </p>
            <div className="trust-scenario-heading">
              <h2>{copy.scenarioTitle}</h2>
              <p>{copy.scenarioNote}</p>
            </div>
          </Reveal>
          <div className="trust-scenario-grid">
            {copy.scenarios.map(([title, text, slug], i) => (
              <Reveal key={slug} delay={i * 0.06}>
                <article>
                  <span className="trust-scenario-index">
                    0{i + 1} / {locale === "ru" ? "СЦЕНАРИЙ" : "SCENARIO"}
                  </span>
                  <h3>{title}</h3>
                  <p>{text}</p>
                  <Link href={`/${locale}/services/${slug}`}>
                    {copy.scenarioLink}
                    <ArrowUpRight size={18} />
                  </Link>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <PageCTA locale={locale} />
    </main>
  );
}
export function ContactPage({ locale }: { locale: Locale }) {
  const copy = trustContent[locale].contact;
  return (
    <main id="main" className="internal-page trust-page">
      <InternalHero
        locale={locale}
        eyebrow={copy.label}
        title={copy.title}
        description={copy.description}
        index="07 — CONTACT"
      >
        <div className="trust-contact-art" aria-hidden="true">
          <div>
            <MessageSquare size={35} strokeWidth={1} />
          </div>
          <i />
          <div>
            <FileCheck2 size={35} strokeWidth={1} />
          </div>
          <i />
          <div>
            <ArrowDownToLine size={35} strokeWidth={1} />
          </div>
        </div>
      </InternalHero>
      <section className="trust-contact-section section" id="brief">
        <div className="container trust-contact-grid">
          <Reveal>
            <p className="eyebrow">
              <span className="eyebrow-cross">+</span>
              {copy.mode}
            </p>
            <h2>{copy.modeTitle}</h2>
            <p>{copy.modeText}</p>
            <p className="trust-contact-help">{copy.modeHelp}</p>
            <Link className="trust-subtle-link" href={`/${locale}/privacy`}>
              <ShieldCheck size={16} />
              {copy.privacyLink}
              <ArrowUpRight size={14} />
            </Link>
          </Reveal>
          <div className="trust-form-panel">
            <ProjectBrief copy={content[locale]} locale={locale} />
          </div>
        </div>
      </section>
      <section className="trust-preparation section light-section">
        <div className="container">
          <Reveal>
            <p className="eyebrow">
              <span className="eyebrow-cross">+</span>
              {copy.prepareLabel}
            </p>
            <h2>{copy.prepareTitle}</h2>
          </Reveal>
          <div className="trust-prepare-grid">
            {copy.prepare.map(([title, text], i) => (
              <Reveal key={title} delay={i * 0.06}>
                <article>
                  <span className="trust-prepare-number">0{i + 1}</span>
                  <h3>{title}</h3>
                  <p>{text}</p>
                </article>
              </Reveal>
            ))}
          </div>
          <Link className="trust-tech-link" href={`/${locale}/technologies`}>
            {copy.techLink}
            <ArrowUpRight size={18} />
          </Link>
        </div>
      </section>
      <section className="trust-faq-section section">
        <div className="container trust-faq-grid">
          <Reveal>
            <p className="eyebrow">
              <span className="eyebrow-cross">+</span>FAQ
            </p>
            <h2>{copy.faqTitle}</h2>
            <div className="trust-faq-illustration" aria-hidden="true">
              <ScanLine size={68} strokeWidth={0.7} />
            </div>
          </Reveal>
          <div className="trust-faq">
            {copy.faq.map(([question, answer]) => (
              <details key={question}>
                <summary>
                  {question}
                  <Plus size={17} />
                </summary>
                <p>{answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
export function LegalPage({
  locale,
  kind,
}: {
  locale: Locale;
  kind: "privacy" | "terms";
}) {
  const copy = trustContent[locale].legal;
  const page = copy[kind];
  return (
    <main id="main" className="internal-page trust-page">
      <InternalHero
        locale={locale}
        eyebrow={page.label}
        title={page.title}
        description={page.description}
        index={kind === "privacy" ? "08 — PRIVACY" : "09 — TERMS"}
      >
        <div className="trust-legal-art" aria-hidden="true">
          <ShieldCheck size={70} strokeWidth={0.8} />
          <span />
          <span />
        </div>
      </InternalHero>
      <section className="trust-legal-section light-section">
        <div className="container">
          <aside className="trust-draft-note" role="note">
            <FileCheck2 size={25} strokeWidth={1.4} />
            <div>
              <strong>{copy.draftLabel}</strong>
              <p>{copy.draftText}</p>
            </div>
          </aside>
          <div className="trust-legal-grid">
            <nav className="trust-legal-contents" aria-label={copy.contents}>
              <p>{copy.contents}</p>
              {page.sections.map(([title], i) => (
                <a key={title} href={`#legal-section-${i + 1}`}>
                  <span>0{i + 1}</span>
                  {title}
                </a>
              ))}
            </nav>
            <div className="trust-legal-body">
              {page.sections.map(([title, text], i) => (
                <Reveal key={title}>
                  <section id={`legal-section-${i + 1}`}>
                    <span>0{i + 1}</span>
                    <h2>{title}</h2>
                    <p>{text}</p>
                  </section>
                </Reveal>
              ))}
              <Link className="trust-legal-back" href={`/${locale}/contact`}>
                {copy.backContact}
                <ArrowUpRight size={18} />
              </Link>
              <p className="trust-document-state">
                <Check size={14} />
                {locale === "ru"
                  ? "Фактическая редакция текущей функциональности. Проект, не окончательный документ."
                  : "A factual description of current functionality. Draft, not a final policy."}
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
