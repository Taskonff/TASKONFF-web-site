import Link from "next/link";
import {
  ArrowUpRight,
  Check,
  ArrowRight,
  Braces,
  Workflow,
} from "lucide-react";
import { InternalHero, PageCTA } from "@/components/site/page-primitives";
import { Reveal } from "@/components/home/reveal";
import { ServiceCatalog, IndustryExplorer } from "./expertise-interactions";
import { services, serviceGroups, type Service } from "@/content/services";
import type { Locale } from "@/content/site";
import "./expertise-pages.css";
export function ServicesPage({ locale }: { locale: Locale }) {
  const ru = locale === "ru";
  return (
    <main id="main" className="internal-page">
      <InternalHero
        locale={locale}
        eyebrow={ru ? "Услуги" : "Services"}
        title={
          ru
            ? "Технологии под задачу.\nНе наоборот."
            : "Technology around\nyour challenge."
        }
        description={
          ru
            ? "От отдельного интерфейса до связанной цифровой системы. Выберите направление и узнайте, какие задачи оно решает, что входит в работу и с чего начать."
            : "From one interface to a connected digital system. Explore each service, the problems it addresses, what the work includes and where to begin."
        }
        index="02 / EXPERTISE"
      >
        <div className="expertise-hero-diagram" aria-hidden="true">
          <Braces size={38} />
          <i />
          <Workflow size={38} />
          <span>PRODUCT × SYSTEM</span>
        </div>
      </InternalHero>
      <section className="section light-section">
        <div className="container">
          <Reveal>
            <div className="expertise-section-heading">
              <p className="eyebrow">
                {ru ? "НАПРАВЛЕНИЯ РАЗРАБОТКИ" : "AREAS OF EXPERTISE"}
              </p>
              <h2>
                {ru
                  ? "От цели —\nк нужным инструментам."
                  : "From your goal\nto the right tools."}
              </h2>
            </div>
          </Reveal>
          <ServiceCatalog locale={locale} />
        </div>
      </section>
      <section className="section expertise-engagement">
        <div className="container">
          <div>
            <p className="eyebrow">
              {ru ? "КАК ВЫБРАТЬ НАПРАВЛЕНИЕ" : "WHERE TO START"}
            </p>
            <h2>
              {ru
                ? "Можно начать\nс самой задачи."
                : "Start with\nthe problem itself."}
            </h2>
          </div>
          <div>
            <p>
              {ru
                ? "Не обязательно заранее выбирать услугу или стек. Достаточно описать текущий процесс, пользователей и то, что должно измениться. Несколько направлений могут стать частями одного решения."
                : "You do not need to choose a service or stack upfront. Describe the current process, its users and what needs to change. Several areas can become parts of one solution."}
            </p>
            <Link href={`/${locale}/process`}>
              {ru ? "Посмотреть процесс работы" : "Explore our process"}
              <ArrowUpRight size={18} />
            </Link>
          </div>
        </div>
      </section>
      <PageCTA locale={locale} />
    </main>
  );
}
export function ServiceDetailPage({
  locale,
  service,
}: {
  locale: Locale;
  service: Service;
}) {
  const ru = locale === "ru";
  const copy = service[locale];
  return (
    <main id="main" className="internal-page">
      <InternalHero
        locale={locale}
        eyebrow={copy.title}
        title={copy.title}
        description={copy.intro}
        index={serviceGroups[locale][service.group]}
      >
        <div className="expertise-detail-mark" aria-hidden="true">
          <span>{String(services.indexOf(service) + 1).padStart(2, "0")}</span>
          <Braces size={36} />
        </div>
      </InternalHero>
      <section className="section light-section">
        <div className="container">
          <Link href={`/${locale}/services`} className="expertise-back-link">
            ← {ru ? "Все услуги" : "All services"}
          </Link>
          <div className="expertise-detail-columns">
            <Reveal>
              <p className="eyebrow">
                {ru ? "КОГДА ЭТО НУЖНО" : "WHEN IT HELPS"}
              </p>
              <h2>
                {ru
                  ? "Задачи,\nс которых начинаем."
                  : "Challenges\nwe start with."}
              </h2>
              <ul className="expertise-needs">
                {copy.needs.map((need) => (
                  <li key={need}>
                    <ArrowRight size={17} />
                    {need}
                  </li>
                ))}
              </ul>
            </Reveal>
            <Reveal className="expertise-deliverables">
              <p className="eyebrow">
                {ru ? "РЕЗУЛЬТАТ РАБОТЫ" : "WORK OUTPUTS"}
              </p>
              <h3>
                {ru
                  ? "Что определяем\nи создаём."
                  : "What we define\nand build."}
              </h3>
              <ul>
                {copy.deliverables.map((item) => (
                  <li key={item}>
                    <Check size={18} />
                    {item}
                  </li>
                ))}
              </ul>
              <p>
                {ru
                  ? "Точный состав и критерии готовности согласовываются после изучения задачи."
                  : "Exact scope and acceptance criteria are agreed after exploring your requirements."}
              </p>
            </Reveal>
          </div>
        </div>
      </section>
      <section className="section expertise-workflow">
        <div className="container">
          <div className="expertise-section-heading">
            <p className="eyebrow">
              {ru ? "ПОДХОД К ЗАДАЧЕ" : "DELIVERY APPROACH"}
            </p>
            <h2>
              {ru
                ? "Последовательность,\nа не набор обещаний."
                : "A clear sequence,\nnot a list of promises."}
            </h2>
          </div>
          <div className="expertise-workflow-grid">
            {copy.workflow.map((step, index) => (
              <Reveal key={step} delay={index * 0.06}>
                <article>
                  <span>0{index + 1}</span>
                  <h3>{step}</h3>
                </article>
              </Reveal>
            ))}
          </div>
          <div className="expertise-decision">
            <span>+</span>
            <p>{copy.decision}</p>
          </div>
        </div>
      </section>
      <section className="section light-section">
        <div className="container expertise-faq-grid">
          <div>
            <p className="eyebrow">FAQ</p>
            <h2>{ru ? "Перед стартом." : "Before we start."}</h2>
          </div>
          <div className="expertise-faq">
            {copy.faq.map(([question, answer]) => (
              <details key={question}>
                <summary>
                  {question}
                  <span>+</span>
                </summary>
                <p>{answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
      <section className="expertise-related">
        <div className="container">
          <h2>{ru ? "Рядом с этой задачей." : "Related capabilities."}</h2>
          <div>
            {services
              .filter(
                (item) =>
                  item.slug !== service.slug && item.group === service.group,
              )
              .concat(services.filter((item) => item.group !== service.group))
              .slice(0, 3)
              .map((item) => (
                <Link key={item.slug} href={`/${locale}/services/${item.slug}`}>
                  {item[locale].title}
                  <ArrowUpRight size={18} />
                </Link>
              ))}
          </div>
        </div>
      </section>
      <PageCTA
        locale={locale}
        title={ru ? "Обсудим вашу задачу?" : "Let’s explore your challenge."}
      />
    </main>
  );
}
export function IndustriesPage({ locale }: { locale: Locale }) {
  const ru = locale === "ru";
  return (
    <main id="main" className="internal-page">
      <InternalHero
        locale={locale}
        eyebrow={ru ? "Отрасли" : "Industries"}
        title={
          ru
            ? "Разные процессы.\nСистемный подход."
            : "Different industries.\nA systematic approach."
        }
        description={
          ru
            ? "Контекст бизнеса меняет требования к продукту. Ниже — примеры возможного применения цифровых решений, а не перечень выполненных проектов или клиентов."
            : "Business context shapes product requirements. Explore possible uses for digital solutions—not a list of delivered projects or clients."
        }
        index="03 / INDUSTRIES"
      />
      <section className="section expertise-industries-section">
        <div className="container">
          <div className="expertise-section-heading">
            <p className="eyebrow">
              {ru ? "ИССЛЕДУЙТЕ СЦЕНАРИЙ" : "EXPLORE A SCENARIO"}
            </p>
            <h2>
              {ru
                ? "Что может\nизмениться в работе."
                : "What could change\nin your workflow."}
            </h2>
          </div>
          <IndustryExplorer locale={locale} />
        </div>
      </section>
      <section className="section light-section">
        <div className="container expertise-industry-principles">
          <div>
            <p className="eyebrow">
              {ru ? "ПЕРЕД РАЗРАБОТКОЙ" : "BEFORE DEVELOPMENT"}
            </p>
            <h2>
              {ru
                ? "Сначала контекст.\nПотом архитектура."
                : "Context first.\nArchitecture next."}
            </h2>
          </div>
          <div>
            {(ru
              ? [
                  [
                    "Процессы",
                    "Изучаем реальную последовательность действий, участников и исключения.",
                  ],
                  [
                    "Данные",
                    "Определяем источники истины, качество информации и необходимые права доступа.",
                  ],
                  [
                    "Ограничения",
                    "Уточняем инфраструктуру, требования к безопасности и применимые правила.",
                  ],
                ]
              : [
                  [
                    "Processes",
                    "Understand the actual sequence of actions, participants and exceptions.",
                  ],
                  [
                    "Data",
                    "Identify sources of truth, data quality and necessary access permissions.",
                  ],
                  [
                    "Constraints",
                    "Clarify infrastructure, security requirements and applicable rules.",
                  ],
                ]
            ).map(([title, text]) => (
              <article key={title}>
                <h3>{title}</h3>
                <p>{text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
      <PageCTA locale={locale} />
    </main>
  );
}
