"use client";
import Link from "next/link";
import { useId, useRef, useState, type KeyboardEvent } from "react";
import { motion, useReducedMotion } from "motion/react";
import {
  Search,
  ArrowUpRight,
  ArrowRight,
  Building2,
  ShoppingBag,
  Truck,
  HeartPulse,
  Landmark,
  Factory,
  ShieldCheck,
} from "lucide-react";
import { services, serviceGroups, type ServiceGroup } from "@/content/services";
import type { Locale } from "@/content/site";
const groupIds: ServiceGroup[] = ["build", "automate", "operate", "design"];
export function ServiceCatalog({ locale }: { locale: Locale }) {
  const [query, setQuery] = useState("");
  const [group, setGroup] = useState<ServiceGroup | "all">("all");
  const reduced = useReducedMotion();
  const input = useId();
  const ru = locale === "ru";
  const normalized = query.toLocaleLowerCase(locale).trim();
  const visible = services.filter(
    (service) =>
      (group === "all" || service.group === group) &&
      `${service[locale].title} ${service[locale].intro} ${serviceGroups[locale][service.group]}`
        .toLocaleLowerCase(locale)
        .includes(normalized),
  );
  return (
    <div className="expertise-catalog">
      <div className="expertise-catalog-tools">
        <label className="expertise-search" htmlFor={input}>
          <Search size={18} />
          <input
            id={input}
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={ru ? "Найти услугу" : "Find a service"}
            aria-label={ru ? "Поиск услуг" : "Search services"}
          />
        </label>
        <div
          className="expertise-filters"
          role="group"
          aria-label={ru ? "Направления услуг" : "Service categories"}
        >
          {(["all", ...groupIds] as const).map((id) => (
            <button
              key={id}
              type="button"
              aria-pressed={group === id}
              onClick={() => setGroup(id)}
            >
              {id === "all"
                ? ru
                  ? "Все направления"
                  : "All services"
                : serviceGroups[locale][id]}
            </button>
          ))}
        </div>
      </div>
      <p className="expertise-result-count" aria-live="polite">
        {ru ? "Найдено направлений" : "Services found"}: {visible.length}
      </p>
      <div className="expertise-catalog-grid">
        {visible.map((service) => (
          <motion.article
            key={service.slug}
            className="expertise-service-card"
            initial={false}
            animate={reduced ? undefined : { opacity: [0.55, 1], y: [8, 0] }}
            transition={{ duration: 0.3 }}
          >
            <div className="expertise-card-top">
              <span>{serviceGroups[locale][service.group]}</span>
              <span>
                {String(services.indexOf(service) + 1).padStart(2, "0")}
              </span>
            </div>
            <h3>
              <Link href={`/${locale}/services/${service.slug}`}>
                {service[locale].title}
              </Link>
            </h3>
            <p>{service[locale].intro}</p>
            <ul>
              {service[locale].deliverables.slice(0, 2).map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
            <Link
              className="expertise-card-link"
              href={`/${locale}/services/${service.slug}`}
            >
              <span>{ru ? "Задачи и подход" : "Scope & approach"}</span>
              <ArrowUpRight size={19} />
            </Link>
          </motion.article>
        ))}
      </div>
      {!visible.length && (
        <div className="expertise-no-results">
          <h3>{ru ? "Такого направления не найдено" : "No services found"}</h3>
          <p>
            {ru
              ? "Попробуйте другой запрос или сбросьте фильтры."
              : "Try another search or clear the filters."}
          </p>
          <button
            type="button"
            onClick={() => {
              setGroup("all");
              setQuery("");
            }}
          >
            {ru ? "Сбросить фильтры" : "Clear filters"}
            <ArrowRight size={15} />
          </button>
        </div>
      )}
    </div>
  );
}
const industries = {
  ru: [
    {
      name: "Ритейл и e-commerce",
      icon: ShoppingBag,
      title: "Единый путь от каталога до исполнения.",
      text: "Возможный сценарий: связать витрину, остатки, заказы и работу с покупателями. Детали зависят от модели продаж и существующих систем.",
      steps: [
        ["Каталог", "Согласованные карточки, цены и правила публикации."],
        ["Заказ", "Понятный путь покупки и состояния заказа."],
        ["Исполнение", "Передача в учёт, уведомления и обработка исключений."],
      ],
      guard:
        "Предусмотреть ошибки оплаты, рассинхронизацию остатков и защиту персональных данных.",
    },
    {
      name: "Логистика",
      icon: Truck,
      title: "События поставки становятся понятным процессом.",
      text: "Возможный сценарий: объединить заявки, статусы перемещения и документы в одном операционном интерфейсе.",
      steps: [
        ["Заявка", "Структурированные вводные и правила обработки."],
        ["Маршрут", "События, ответственные и актуальные статусы."],
        ["Документы", "Связь подтверждений с операциями и исключениями."],
      ],
      guard:
        "Учитывать задержки данных, повторные события и работу с неполной информацией.",
    },
    {
      name: "Профессиональные услуги",
      icon: Building2,
      title: "Меньше ручной координации между командами.",
      text: "Возможный сценарий: кабинет клиента, управление задачами и автоматизация согласований вокруг оказания услуги.",
      steps: [
        ["Запрос", "Единая точка входа и уточнение задачи."],
        ["Работа", "Ответственные, доступы и согласования."],
        ["Результат", "Передача материалов и история изменений."],
      ],
      guard:
        "Разграничить доступ между клиентами и определить правила хранения документов.",
    },
    {
      name: "Финансовые сервисы",
      icon: Landmark,
      title: "Контролируемая обработка данных и операций.",
      text: "Возможный сценарий: внутренний операционный кабинет или автоматизация сверок. Требования к регулированию определяются отдельно.",
      steps: [
        ["Данные", "Проверка источников, форматов и полноты."],
        ["Правила", "Согласованная логика обработки и эскалации."],
        ["Контроль", "Проверяемые действия и доступ по ролям."],
      ],
      guard:
        "Нужны отдельная оценка рисков, модель доступа и проверка применимых требований; соответствие стандартам не подразумевается.",
    },
    {
      name: "Медицина и сервисы здоровья",
      icon: HeartPulse,
      title: "Цифровые сценарии с вниманием к чувствительным данным.",
      text: "Возможный сценарий: запись, административные процессы и взаимодействие с пользователями. Клинические решения требуют отдельной экспертизы.",
      steps: [
        [
          "Обращение",
          "Понятный пользовательский путь и сбор минимальных данных.",
        ],
        ["Координация", "Расписание, роли и события обслуживания."],
        ["Доступ", "Разделение прав и правил обработки информации."],
      ],
      guard:
        "До разработки определить правовое основание обработки данных и ограничения системы. Диагностика не входит в этот пример.",
    },
    {
      name: "Производство",
      icon: Factory,
      title: "Операционная информация без разрозненных таблиц.",
      text: "Возможный сценарий: рабочие кабинеты для планирования, учёта задач и регистрации событий производства.",
      steps: [
        ["План", "Связь задач, ресурсов и ограничений."],
        ["Операции", "Фиксация выполнения и причин отклонений."],
        ["Обзор", "Актуальные данные для ответственных ролей."],
      ],
      guard:
        "Сначала изучить источники данных, доступность оборудования и допустимый уровень вмешательства в процессы.",
    },
  ],
  en: [
    {
      name: "Retail & e-commerce",
      icon: ShoppingBag,
      title: "A connected journey from catalog to fulfillment.",
      text: "Possible scenario: connect the storefront, inventory, orders and customer operations. Details depend on the sales model and existing systems.",
      steps: [
        ["Catalog", "Consistent product data, prices and publishing rules."],
        ["Order", "A clear purchasing journey and order states."],
        [
          "Fulfillment",
          "Handoff to operations, notifications and exception handling.",
        ],
      ],
      guard:
        "Plan for payment errors, inventory drift and personal-data protection.",
    },
    {
      name: "Logistics",
      icon: Truck,
      title: "Delivery events become a clear operating process.",
      text: "Possible scenario: bring requests, movement status and documents into a single operational interface.",
      steps: [
        ["Request", "Structured inputs and processing rules."],
        ["Journey", "Events, owners and current statuses."],
        ["Documents", "Connect evidence to operations and exceptions."],
      ],
      guard:
        "Account for delayed data, duplicate events and incomplete information.",
    },
    {
      name: "Professional services",
      icon: Building2,
      title: "Less manual coordination between teams.",
      text: "Possible scenario: customer workspaces, task management and automated approvals organized around service delivery.",
      steps: [
        ["Request", "A consistent entry point and scope clarification."],
        ["Delivery", "Ownership, access and approvals."],
        ["Result", "Material handoff and change history."],
      ],
      guard: "Separate client access and define document-retention rules.",
    },
    {
      name: "Financial services",
      icon: Landmark,
      title: "Controlled handling of data and operations.",
      text: "Possible scenario: internal operating workspaces or automated reconciliation. Regulatory requirements need a separate assessment.",
      steps: [
        ["Data", "Check sources, formats and completeness."],
        ["Rules", "Agreed processing and escalation logic."],
        ["Control", "Traceable actions and role-based access."],
      ],
      guard:
        "Assess risks, access models and applicable requirements separately. Standards compliance is not implied.",
    },
    {
      name: "Health services",
      icon: HeartPulse,
      title: "Digital journeys that respect sensitive information.",
      text: "Possible scenario: scheduling, administrative workflows and user interactions. Clinical decisions need separate expertise.",
      steps: [
        ["Intake", "Clear journeys and minimum necessary data."],
        ["Coordination", "Schedules, roles and service events."],
        ["Access", "Separate permissions and processing rules."],
      ],
      guard:
        "Define lawful processing grounds and system limits before development. Diagnosis is outside this example.",
    },
    {
      name: "Manufacturing",
      icon: Factory,
      title: "Operational information beyond disconnected spreadsheets.",
      text: "Possible scenario: workspaces for planning, task tracking and recording production events.",
      steps: [
        ["Plan", "Connect tasks, resources and constraints."],
        ["Operations", "Record execution and reasons for deviations."],
        ["Overview", "Current information for responsible roles."],
      ],
      guard:
        "Assess data sources, equipment availability and permitted interventions before designing integrations.",
    },
  ],
};
export function IndustryExplorer({ locale }: { locale: Locale }) {
  const [active, setActive] = useState(0);
  const [step, setStep] = useState(0);
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  const uid = useId();
  const reduced = useReducedMotion();
  const ru = locale === "ru";
  const items = industries[locale];
  const item = items[active];
  const Icon = item.icon;
  function select(index: number) {
    setActive(index);
    setStep(0);
  }
  function navigate(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next = index;
    if (event.key === "ArrowDown" || event.key === "ArrowRight")
      next = (index + 1) % items.length;
    else if (event.key === "ArrowUp" || event.key === "ArrowLeft")
      next = (index + items.length - 1) % items.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = items.length - 1;
    else return;
    event.preventDefault();
    select(next);
    refs.current[next]?.focus();
  }
  return (
    <div className="expertise-industry-explorer">
      <div
        className="expertise-industry-tabs"
        role="tablist"
        aria-label={
          ru
            ? "Возможные отраслевые применения"
            : "Possible industry applications"
        }
      >
        {items.map((industry, index) => {
          const TabIcon = industry.icon;
          return (
            <button
              key={industry.name}
              ref={(el) => {
                refs.current[index] = el;
              }}
              type="button"
              role="tab"
              id={`${uid}-tab-${index}`}
              aria-selected={active === index}
              aria-controls={`${uid}-panel`}
              tabIndex={active === index ? 0 : -1}
              onClick={() => select(index)}
              onKeyDown={(event) => navigate(event, index)}
            >
              <TabIcon size={18} />
              {industry.name}
              <ArrowUpRight size={15} />
            </button>
          );
        })}
      </div>
      <motion.div
        className="expertise-industry-panel"
        id={`${uid}-panel`}
        role="tabpanel"
        aria-labelledby={`${uid}-tab-${active}`}
        tabIndex={0}
        key={active}
        initial={false}
        animate={reduced ? undefined : { opacity: [0.5, 1], y: [10, 0] }}
        transition={{ duration: 0.3 }}
      >
        <div className="expertise-industry-panel-top">
          <span>
            <Icon size={25} />
          </span>
          <small>{ru ? "ВОЗМОЖНЫЙ СЦЕНАРИЙ" : "POSSIBLE SCENARIO"}</small>
        </div>
        <h3>{item.title}</h3>
        <p>{item.text}</p>
        <div
          className="expertise-industry-flow"
          role="group"
          aria-label={ru ? "Этапы сценария" : "Scenario stages"}
        >
          {item.steps.map(([title], index) => (
            <button
              key={title}
              type="button"
              aria-pressed={step === index}
              aria-controls={`${uid}-detail`}
              onClick={() => setStep(index)}
            >
              <span>0{index + 1}</span>
              {title}
              {index < 2 && <ArrowRight size={14} />}
            </button>
          ))}
        </div>
        <p
          className="expertise-industry-step"
          id={`${uid}-detail`}
          aria-live="polite"
        >
          {item.steps[step][1]}
        </p>
        <div className="expertise-industry-guard">
          <ShieldCheck size={19} />
          <p>{item.guard}</p>
        </div>
      </motion.div>
    </div>
  );
}
