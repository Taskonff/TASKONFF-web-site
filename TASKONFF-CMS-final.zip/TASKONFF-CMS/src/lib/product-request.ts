import { z } from "zod";

export const productRequestKinds = ["trial", "connection"] as const;
export type ProductRequestKind = (typeof productRequestKinds)[number];

export const productRequestSchema = z.object({
  productSlug: z
    .string()
    .max(100)
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  kind: z.enum(productRequestKinds),
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().pipe(z.email().max(254)),
  message: z.string().trim().max(2000).default(""),
  consent: z.literal(true),
  website: z.literal(""),
  locale: z.enum(["ru", "en"]),
});

export function createProductRequest(input: unknown, productTitle: string) {
  const { kind, name, email, message, locale } =
    productRequestSchema.parse(input);
  if (locale === "ru") {
    const action = kind === "trial" ? "Тестовый период" : "Подключение";
    return `TASKONFF — ЗАПРОС ПО ПРОДУКТУ\n\nПродукт: ${productTitle}\nЗапрос: ${action}\nИмя: ${name}\nEmail: ${email}\n\n${message}\n`;
  }
  const action = kind === "trial" ? "Trial" : "Connection";
  return `TASKONFF — PRODUCT REQUEST\n\nProduct: ${productTitle}\nRequest: ${action}\nName: ${name}\nEmail: ${email}\n\n${message}\n`;
}
