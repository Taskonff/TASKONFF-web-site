import type { SiteSettings } from "@/cms/defaults";

export function contactEmailHref(email?: string) {
  // Exclude mailto URI delimiters, line breaks and parameters.
  return email && /^[^\s@<>?&%:/#]+@[^\s@<>?&%:/#]+\.[a-z\d-]+$/i.test(email)
    ? `mailto:${email}`
    : undefined;
}

export function hasContactDetails(settings: SiteSettings, locale: "ru" | "en") {
  return Boolean(
    settings.contactEmail ||
    settings.contactPhone ||
    settings.telegram ||
    settings.city?.[locale] ||
    settings.address ||
    settings.responseHours?.[locale],
  );
}
