"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  ChevronDown,
  Code2,
  Cpu,
  Layers3,
  Menu,
  PenTool,
  X,
} from "lucide-react";
import { useSiteContent } from "@/cms/site-context";
import { BrandLogo } from "@/components/brand-logo";
import { Button } from "@/components/ui/button";
import { productText } from "@/content/products";
import type { Locale, SiteContent } from "@/content/site";
import type { ServiceGroup } from "@/content/services";
import { productNavLabel, type PageSlug } from "@/lib/routes";
import "./corporate-header.css";

const desktopPages: PageSlug[] = [
  "about",
  "services",
  "products",
  "industries",
  "portfolio",
  "technologies",
  "process",
];
const serviceGroups: ServiceGroup[] = [
  "build",
  "automate",
  "operate",
  "design",
];
const groupIcons = {
  build: Code2,
  automate: Cpu,
  operate: Layers3,
  design: PenTool,
};
type Directory = "services" | "products";
const directoryIds: Record<Directory, string> = {
  services: "corporate-service-directory",
  products: "corporate-product-directory",
};
const mobileDirectoryIds: Record<Directory, string> = {
  services: "corporate-mobile-service-list",
  products: "corporate-mobile-product-list",
};
function isDirectory(slug: PageSlug, hasProducts: boolean): slug is Directory {
  return slug === "services" || (slug === "products" && hasProducts);
}
const productMenuCopy = {
  ru: {
    toggle: "Показать продукты TASKONFF",
    title: "Собственная разработка",
    catalog: "Все продукты",
  },
  en: {
    toggle: "Show TASKONFF products",
    title: "Built by TASKONFF",
    catalog: "All products",
  },
};

export function Header({
  locale,
  copy,
  logo,
}: {
  locale: Locale;
  copy: SiteContent;
  logo?: string;
}) {
  const data = useSiteContent();
  const pageNames = {
    ...data.shared[locale].navigation,
    products: productNavLabel[locale],
  };
  const shared = data.shared[locale];
  const brandName = data.settings.brandName || "TASKONFF";
  const pathname = usePathname();
  const [expanded, setExpanded] = useState<"mobile" | Directory | null>(null);
  const [mobileDirectory, setMobileDirectory] = useState<Directory | null>(
    null,
  );
  const header = useRef<HTMLElement>(null);
  const menu = useRef<HTMLButtonElement>(null);
  const servicesToggle = useRef<HTMLButtonElement>(null);
  const productsToggle = useRef<HTMLButtonElement>(null);
  const mobileServicesToggle = useRef<HTMLButtonElement>(null);
  const mobileProductsToggle = useRef<HTMLButtonElement>(null);
  const serviceDirectory = useRef<HTMLDivElement>(null);
  const productDirectory = useRef<HTMLDivElement>(null);
  const other = locale === "ru" ? "en" : "ru";
  const languagePath = pathname.replace(/^\/(ru|en)(?=\/|$)/, `/${other}`);
  const mobileOpen = expanded === "mobile";
  const servicesOpen = expanded === "services";
  const productsOpen = expanded === "products";
  const hasProducts = data.products.length > 0;
  const pages = desktopPages.filter(
    (slug) => slug !== "portfolio" || data.cases.length > 0,
  );
  const groups = serviceGroups.map((group) => ({
    group,
    title: data.groups[locale][group],
    services: data.services.filter((service) => service.group === group),
  }));
  const productsCopy = productMenuCopy[locale];
  const directoryLabels = {
    services:
      locale === "ru"
        ? "Показать направления услуг"
        : "Show service categories",
    products: productsCopy.toggle,
  };
  const catalogPath = `/${locale}/products`;
  const close = useCallback(() => {
    setExpanded(null);
    setMobileDirectory(null);
  }, []);
  const active = (slug: string) =>
    pathname === `/${locale}/${slug}` ||
    pathname.startsWith(`/${locale}/${slug}/`);

  useEffect(() => {
    if (!expanded) return;
    function outside(event: PointerEvent) {
      if (
        event.target instanceof Node &&
        !header.current?.contains(event.target)
      )
        close();
    }
    const breakpoint = window.matchMedia("(max-width: 1100px)");
    document.addEventListener("pointerdown", outside);
    window.addEventListener("popstate", close);
    breakpoint.addEventListener("change", close);
    return () => {
      document.removeEventListener("pointerdown", outside);
      window.removeEventListener("popstate", close);
      breakpoint.removeEventListener("change", close);
    };
  }, [expanded, close]);

  function openDirectory(directory: Directory, focus?: "first" | "last") {
    setExpanded(directory);
    if (!focus) return;
    requestAnimationFrame(() => {
      const panel =
        directory === "services"
          ? serviceDirectory.current
          : productDirectory.current;
      const links = panel?.querySelectorAll<HTMLAnchorElement>(
        directory === "services" ? "a" : ".corporate-product-directory-link",
      );
      if (links?.length) links[focus === "last" ? links.length - 1 : 0].focus();
    });
  }

  return (
    <>
      <a className="skip-link" href="#main">
        {copy.skip}
      </a>
      <header
        ref={header}
        className="header site-header corporate-header"
        onBlur={(event) => {
          if (
            event.relatedTarget instanceof Node &&
            !event.currentTarget.contains(event.relatedTarget)
          )
            close();
        }}
        onKeyDown={(event) => {
          if (event.key === "Escape" && expanded) {
            event.preventDefault();
            if (mobileOpen && mobileDirectory) {
              setMobileDirectory(null);
              const toggle =
                mobileDirectory === "services"
                  ? mobileServicesToggle
                  : mobileProductsToggle;
              toggle.current?.focus();
              return;
            }
            close();
            const trigger = mobileOpen
              ? menu
              : productsOpen
                ? productsToggle
                : servicesToggle;
            trigger.current?.focus();
          }
        }}
      >
        <div className="container header-inner">
          <Link
            className="company-name corporate-brand"
            href={`/${locale}`}
            aria-label={brandName}
            onClick={close}
          >
            <BrandLogo src={logo} name={brandName} />
            <span className="corporate-brand-tagline">
              {shared.brandTagline}
            </span>
          </Link>
          <nav
            className="desktop-nav"
            aria-label={
              locale === "ru" ? "Основная навигация" : "Main navigation"
            }
          >
            {pages.map((slug) => (
              <div className="corporate-nav-item" key={slug}>
                <Link
                  href={`/${locale}/${slug}`}
                  aria-current={active(slug) ? "page" : undefined}
                  onClick={close}
                >
                  {pageNames[slug]}
                </Link>
                {isDirectory(slug, hasProducts) && (
                  <button
                    ref={slug === "services" ? servicesToggle : productsToggle}
                    type="button"
                    className={`corporate-${slug}-toggle`}
                    aria-label={directoryLabels[slug]}
                    aria-expanded={expanded === slug}
                    aria-controls={directoryIds[slug]}
                    onClick={(event) =>
                      expanded === slug
                        ? close()
                        : openDirectory(
                            slug,
                            event.detail === 0 ? "first" : undefined,
                          )
                    }
                    onKeyDown={(event) => {
                      if (event.key !== "ArrowDown" && event.key !== "ArrowUp")
                        return;
                      event.preventDefault();
                      openDirectory(
                        slug,
                        event.key === "ArrowUp" ? "last" : "first",
                      );
                    }}
                  >
                    <ChevronDown size={14} aria-hidden="true" />
                  </button>
                )}
              </div>
            ))}
          </nav>
          <div className="header-actions">
            <Link
              className="language"
              href={languagePath}
              aria-label={copy.language}
              onClick={close}
            >
              {other.toUpperCase()}
            </Link>
            <Button asChild variant="outline" size="sm" className="header-cta">
              <Link href={`/${locale}/contact`} onClick={close}>
                {copy.talk}
                <ArrowRight size={15} aria-hidden="true" />
              </Link>
            </Button>
            <button
              ref={menu}
              type="button"
              className="menu-toggle"
              aria-label={mobileOpen ? copy.close : copy.menu}
              aria-expanded={mobileOpen}
              aria-controls="mobile-nav"
              onClick={() => (mobileOpen ? close() : setExpanded("mobile"))}
            >
              {mobileOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        <button
          type="button"
          className="corporate-nav-backdrop"
          aria-label={copy.close}
          tabIndex={-1}
          hidden={!expanded}
          onClick={close}
        />

        <div
          ref={serviceDirectory}
          id={directoryIds.services}
          className="corporate-service-directory"
          hidden={!servicesOpen}
        >
          <div className="container corporate-directory-grid">
            <div className="corporate-directory-intro">
              <span>{copy.expertise}</span>
              <h2>{shared.cta.title}</h2>
              <p>{copy.servicesIntro}</p>
              <Link href={`/${locale}/services`} onClick={close}>
                {data.home[locale].sections.allServices}
                <ArrowRight size={16} aria-hidden="true" />
              </Link>
            </div>
            {groups.map(({ group, title, services }) => {
              const Icon = groupIcons[group];
              return (
                <section className="corporate-directory-group" key={group}>
                  <div className="corporate-directory-icon" aria-hidden="true">
                    <Icon size={23} strokeWidth={1.5} />
                  </div>
                  <h3>{title}</h3>
                  <ul>
                    {services.map((service) => (
                      <li key={service.slug}>
                        <Link
                          href={`/${locale}/services/${service.slug}`}
                          onClick={close}
                        >
                          <span>{service[locale].title}</span>
                          <ArrowRight size={13} aria-hidden="true" />
                        </Link>
                      </li>
                    ))}
                  </ul>
                </section>
              );
            })}
          </div>
          <div className="corporate-directory-bottom">
            <div className="container">
              <Link href={`/${locale}/contact`} onClick={close}>
                {shared.cta.button}
                <ArrowRight size={15} aria-hidden="true" />
              </Link>
            </div>
          </div>
        </div>

        {hasProducts && (
          <div
            ref={productDirectory}
            id={directoryIds.products}
            className="corporate-product-directory"
            hidden={!productsOpen}
          >
            <div className="container corporate-product-directory-grid">
              <div className="corporate-directory-intro">
                <h2>{productsCopy.title}</h2>
                <Link href={catalogPath} onClick={close}>
                  {productsCopy.catalog}
                  <ArrowRight size={16} aria-hidden="true" />
                </Link>
              </div>
              <ul className="corporate-product-directory-list">
                {data.products.map((product) => {
                  const href = `${catalogPath}/${product.slug}`;
                  const { title, summary } = productText(product, locale);
                  return (
                    <li key={product.id}>
                      <Link
                        className="corporate-product-directory-link"
                        href={href}
                        aria-current={pathname === href ? "page" : undefined}
                        onClick={close}
                      >
                        <span>
                          <strong>{title}</strong>
                          {summary.trim() && <small>{summary}</small>}
                        </span>
                        <ArrowRight size={18} aria-hidden="true" />
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        )}

        <nav
          id="mobile-nav"
          hidden={!mobileOpen}
          className="mobile-nav"
          aria-label={copy.menu}
        >
          <Link href={`/${locale}`} onClick={close}>
            {shared.homeLabel}
          </Link>
          {[...pages, "contact" as const].map((slug) => {
            const href = `/${locale}/${slug}`;
            if (!isDirectory(slug, hasProducts)) {
              return (
                <Link
                  key={slug}
                  href={href}
                  onClick={close}
                  aria-current={active(slug) ? "page" : undefined}
                >
                  {pageNames[slug]}
                </Link>
              );
            }
            return (
              <div key={slug}>
                <div className="corporate-mobile-directory-row">
                  <Link
                    href={href}
                    onClick={close}
                    aria-current={active(slug) ? "page" : undefined}
                  >
                    {pageNames[slug]}
                  </Link>
                  <button
                    ref={
                      slug === "services"
                        ? mobileServicesToggle
                        : mobileProductsToggle
                    }
                    className={`corporate-mobile-directory-toggle corporate-mobile-${slug === "services" ? "service" : "product"}-toggle`}
                    type="button"
                    aria-label={directoryLabels[slug]}
                    aria-expanded={mobileDirectory === slug}
                    aria-controls={mobileDirectoryIds[slug]}
                    onClick={() =>
                      setMobileDirectory((open) =>
                        open === slug ? null : slug,
                      )
                    }
                  >
                    <ChevronDown size={18} aria-hidden="true" />
                  </button>
                </div>
                <div
                  id={mobileDirectoryIds[slug]}
                  className="corporate-mobile-directory-content"
                  hidden={mobileDirectory !== slug}
                >
                  {slug === "products" ? (
                    <ul aria-label={productNavLabel[locale]}>
                      {data.products.map((product) => {
                        const productHref = `${catalogPath}/${product.slug}`;
                        return (
                          <li key={product.id}>
                            <Link
                              href={productHref}
                              onClick={close}
                              aria-current={
                                pathname === productHref ? "page" : undefined
                              }
                            >
                              {product[locale].title}
                              <ArrowRight size={14} aria-hidden="true" />
                            </Link>
                          </li>
                        );
                      })}
                    </ul>
                  ) : (
                    groups.map(({ group, title, services }) => (
                      <div
                        key={group}
                        className="corporate-mobile-service-group"
                      >
                        <p>{title}</p>
                        <ul>
                          {services.map((service) => {
                            const serviceHref = `/${locale}/services/${service.slug}`;
                            return (
                              <li key={service.slug}>
                                <Link
                                  href={serviceHref}
                                  onClick={close}
                                  aria-current={
                                    pathname === serviceHref
                                      ? "page"
                                      : undefined
                                  }
                                >
                                  {service[locale].title}
                                  <ArrowRight size={14} aria-hidden="true" />
                                </Link>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </nav>
      </header>
    </>
  );
}
