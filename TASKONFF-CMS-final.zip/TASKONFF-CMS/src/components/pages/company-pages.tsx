import Link from "next/link";
import { ArrowRight, Compass, Layers3, ShieldCheck, Plus } from "lucide-react";
import type { Locale } from "@/content/site";
import { getSiteData } from "@/cms/site-data";
import { PageMedia } from "@/cms/page-media";
import { InternalHero, PageCTA } from "@/components/site/page-primitives";
import { Reveal } from "@/components/home/reveal";
import { CompanyExplorer } from "./company-interactions";
import "./company-pages.css";
export async function AboutPage({ locale }: { locale: Locale }) {
  const snapshot = await getSiteData();
  const c = snapshot.company[locale].about;
  const icons = [Compass, Layers3, ShieldCheck];
  const people = c.team.filter(({ name, role }) => name.trim() && role.trim());
  const facts = c.facts.filter(([, value]) => value.trim());
  const caseCount = snapshot.cases.length;
  const work = [
    ...snapshot.products.map((product) => ({
      href: `/${locale}/products/${product.slug}`,
      title: product[locale].title,
    })),
    ...(caseCount > 0
      ? [
          {
            href: `/${locale}/portfolio`,
            title: snapshot.shared[locale].navigation.portfolio,
          },
        ]
      : []),
  ];

  return (
    <main id="main" className="internal-page">
      <InternalHero
        locale={locale}
        eyebrow={c.label}
        title={c.title}
        description={c.intro}
      />
      <PageMedia pageKey="about" />
      <section className="section light-section company-about">
        <div className="container">
          <Reveal>
            <div className="company-editorial">
              <h2>{c.heading}</h2>
              <p>{c.body}</p>
            </div>
          </Reveal>
          {facts.length > 0 && (
            <dl className="company-facts">
              {facts.map(([label, value]) => (
                <div key={label}>
                  <dt>{label}</dt>
                  <dd>{value}</dd>
                </div>
              ))}
            </dl>
          )}
          {work.length > 0 && (
            <div className="company-work">
              <h3>{c.workTitle}</h3>
              <ul>
                {work.map(({ href, title }) => (
                  <li key={href}>
                    <Link href={href}>
                      {title}
                      <ArrowRight size={17} aria-hidden="true" />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
          {people.length > 0 && (
            <div className="company-team">
              <h3>{c.teamTitle}</h3>
              <ul>
                {people.map(({ name, role }, index) => (
                  <li key={index}>
                    <strong>{name}</strong>
                    <span>{role}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div className="company-principles">
            {c.principles.map(([title, text], index) => {
              const Icon = icons[index];
              return (
                <Reveal key={title} delay={index * 0.06}>
                  <article>
                    <div className="company-card-top">
                      <Icon size={24} strokeWidth={1.4} aria-hidden="true" />
                    </div>
                    <h3>{title}</h3>
                    <p>{text}</p>
                  </article>
                </Reveal>
              );
            })}
          </div>
          <Link
            className="company-more-link company-about-more"
            href={`/${locale}/process`}
          >
            {c.processLink}
            <ArrowRight size={17} aria-hidden="true" />
          </Link>
        </div>
      </section>
      <PageCTA locale={locale} title={c.cta} />
    </main>
  );
}
export async function TechnologiesPage({ locale }: { locale: Locale }) {
  const snapshot = await getSiteData();
  const c = snapshot.company[locale].tech;
  return (
    <main id="main" className="internal-page">
      <InternalHero
        locale={locale}
        eyebrow={c.label}
        title={c.title}
        description={c.intro}
      />
      <PageMedia pageKey="technologies" />
      <section className="section company-architecture">
        <div className="container">
          <Reveal>
            <h2>{c.heading}</h2>
            <p className="company-section-note">{c.note}</p>
          </Reveal>
          <CompanyExplorer locale={locale} kind="architecture" />
        </div>
      </section>
      <section className="section light-section">
        <div className="container">
          <Reveal className="company-architecture-future">
            <h2>{c.future}</h2>
            <p>{c.futureText}</p>
          </Reveal>
        </div>
      </section>
      <PageCTA locale={locale} title={c.cta} />
    </main>
  );
}
export async function ProcessPage({ locale }: { locale: Locale }) {
  const snapshot = await getSiteData();
  const c = snapshot.company[locale].process;
  return (
    <main id="main" className="internal-page">
      <InternalHero
        locale={locale}
        eyebrow={c.label}
        title={c.title}
        description={c.intro}
      />
      <PageMedia pageKey="process" />
      <section className="section company-process">
        <div className="container">
          <Reveal>
            <h2>{c.heading}</h2>
            <p className="company-section-note">{c.note}</p>
          </Reveal>
          <CompanyExplorer locale={locale} kind="phases" />
        </div>
      </section>
      <section className="section light-section">
        <div className="container">
          <Reveal>
            <div className="company-editorial">
              <h2>{c.feedbackTitle}</h2>
              <p>{c.feedbackText}</p>
            </div>
          </Reveal>
          <div className="company-feedback">
            {c.feedback.map(([title, text], index) => (
              <Reveal key={title} delay={index * 0.06}>
                <article>
                  <span>0{index + 1}</span>
                  <h3>{title}</h3>
                  <p>{text}</p>
                </article>
              </Reveal>
            ))}
          </div>
          <div className="company-faq">
            <h2>{c.faqTitle}</h2>
            <div>
              {c.faq.map(([question, answer]) => (
                <details key={question}>
                  <summary>
                    {question}
                    <Plus size={18} />
                  </summary>
                  <p>{answer}</p>
                </details>
              ))}
            </div>
          </div>
        </div>
      </section>
      <PageCTA locale={locale} title={c.cta} />
    </main>
  );
}
