import Image from "next/image";
import Link from "next/link";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  AudioLines,
  ChartNoAxesColumnIncreasing,
  ClipboardCheck,
  Database,
  FileText,
  LockKeyhole,
} from "lucide-react";
import { Reveal } from "@/components/home/reveal";
import { ProductRequestForm } from "@/components/products/product-request-form";
import { InternalHero, PageCTA } from "@/components/site/page-primitives";
import { Button } from "@/components/ui/button";
import { getSiteData } from "@/cms/site-data";
import type { PublishedProduct } from "@/cms/defaults";
import { productDetail } from "@/content/product-details";
import { productText } from "@/content/products";
import type { Locale } from "@/content/site";
import "./products-pages.css";

export const productsCopy = {
  ru: {
    label: "Продукты",
    title: "Продукты TASKONFF",
    description:
      "Изучите продукты собственной разработки и выберите сценарий для пилота.",
    previewTitle: "Собственная разработка",
    catalog: "Открыть каталог",
    details: "Подробнее о продукте",
    website: "Сайт продукта",
    trial: "Запросить тестовый период",
    connection: "Запросить подключение",
    overview: "О продукте",
    capabilities: "Что можно проверить на пилоте",
    workflow: "Как устроен сценарий",
    fit: "Кому подходит",
    prerequisites: "Что учесть перед тестом",
    dataHandling: "Данные в пилоте MedVoice",
    pilotTerms: "Формат пилота",
    pricing: "Стоимость",
    byRequest: "По запросу",
    duration: "Длительность",
    toBeAgreed: "Согласуем по объёму теста",
    detailFallback:
      "Обсудите с командой ваш рабочий сценарий и условия тестирования.",
    emptyTitle: "Карточки продуктов появятся здесь",
    emptyAction: "Связаться с командой",
    question: "Какой продукт подойдёт вашей команде?",
    questionDescription:
      "Расскажите, какой продукт вас заинтересовал и что вы хотите узнать.",
    pilot: {
      title: "Как оценить эффект",
      intro:
        "Возьмите один рабочий сценарий и сравните сопоставимые задачи до и во время пилота. Так можно понять, какие шаги стоит менять.",
      metric: "Что сравнить",
      before: "До теста",
      during: "В пилоте",
      comparison: [
        [
          "Время на задачу",
          "Замерьте время от начала задачи до готового результата.",
          "Повторите замер на сопоставимых задачах с продуктом.",
        ],
        [
          "Ручная работа",
          "Посчитайте ручные действия, повторный ввод и возвраты на доработку.",
          "Сравните количество действий и проверьте, какие из них по-прежнему нужны.",
        ],
        [
          "Передача между участниками",
          "Отметьте, где работа ждёт ответа и кому виден её статус.",
          "Проверьте, легче ли передать задачу и понять, на каком она этапе.",
        ],
      ],
      stepsTitle: "От рабочего сценария к подключению",
      steps: [
        [
          "Определите цель",
          "Выберите повторяющуюся задачу и зафиксируйте исходные показатели.",
        ],
        [
          "Проведите пилот",
          "Согласуйте критерии успеха и повторите замеры на тех же этапах работы.",
        ],
        [
          "Примите решение",
          "Сравните результаты и обсудите подключение, если продукт подходит вашей команде.",
        ],
      ],
    },
    why: {
      title: "Почему TASKONFF",
      developmentTitle: "Собственная разработка",
      developmentText:
        "Вы обсуждаете продукт с командой, которая его разрабатывает. Можно уточнить, что поддерживается сейчас и что потребуется для вашего сценария.",
      integrationTitle: "Интеграция с вашим процессом",
      integrationText:
        "TASKONFF занимается интеграцией систем. Если для подключения нужны данные из других инструментов, обсудим точки обмена и объём работ до запуска.",
      integrationLink: "Системная интеграция",
    },
  },
  en: {
    label: "Products",
    title: "Products by TASKONFF",
    description:
      "Explore the products we build and find a workflow you’d like to pilot.",
    previewTitle: "Built by TASKONFF",
    catalog: "View the product catalog",
    details: "Product details",
    website: "Product website",
    trial: "Request a trial",
    connection: "Request setup",
    overview: "About the product",
    capabilities: "What to evaluate in a pilot",
    workflow: "Workflow at a glance",
    fit: "Who it’s for",
    prerequisites: "Before you start",
    dataHandling: "Data in a MedVoice pilot",
    pilotTerms: "Pilot scope",
    pricing: "Pricing",
    byRequest: "On request",
    duration: "Duration",
    toBeAgreed: "Agreed based on the scope of the trial",
    detailFallback: "Discuss your workflow and trial options with the team.",
    emptyTitle: "Product listings will appear here",
    emptyAction: "Contact the team",
    question: "Which product suits your team?",
    questionDescription:
      "Let us know which product interests you and what you’d like to ask.",
    pilot: {
      title: "How to measure the impact",
      intro:
        "Choose one workflow and compare similar tasks before and during the pilot. This helps you decide which steps are worth changing.",
      metric: "What to compare",
      before: "Before the trial",
      during: "During the pilot",
      comparison: [
        [
          "Time per task",
          "Measure the time between starting a task and completing it.",
          "Repeat the measurement on comparable tasks using the product.",
        ],
        [
          "Manual work",
          "Count manual steps, duplicate data entry and work sent back for revisions.",
          "Compare the number of steps and identify what still needs to be done manually.",
        ],
        [
          "Handoffs",
          "Note where work waits for a response and who can see its status.",
          "Check whether handing work off and checking its status are easier.",
        ],
      ],
      stepsTitle: "From workflow review to setup",
      steps: [
        [
          "Set a goal",
          "Choose a recurring task and record how it works today.",
        ],
        [
          "Run a pilot",
          "Agree on success criteria and measure the same stages again.",
        ],
        [
          "Make a decision",
          "Compare the results and discuss setup if the product suits your team.",
        ],
      ],
    },
    why: {
      title: "Why TASKONFF",
      developmentTitle: "Built in-house",
      developmentText:
        "Discuss the product with the team that develops it. Ask what is supported today and what your workflow would require.",
      integrationTitle: "Integration with your workflow",
      integrationText:
        "TASKONFF provides systems integration. If you need data from other tools, we can discuss where it needs to flow and what setup would involve.",
      integrationLink: "Systems integration",
    },
  },
} as const;

function ProductLayers() {
  return (
    <div className="products-layers" aria-hidden="true">
      <div className="products-layers-grid" />
      <div className="products-layers-track" />
      <span className="products-layer products-layer-base" />
      <span className="products-layer products-layer-middle" />
      <span className="products-layer products-layer-top">
        <i />
      </span>
    </div>
  );
}

const waveform = [
  24, 38, 67, 43, 83, 100, 53, 27, 64, 75, 48, 28, 50, 71, 39, 26,
];

function ProductIllustration({ slug }: { slug: string }) {
  if (slug === "medvoice") {
    return (
      <div
        className="product-illustration product-illustration-voice"
        aria-hidden="true"
      >
        <div className="product-voice-wave">
          <AudioLines size={22} />
          <div>
            {waveform.map((level, index) => (
              <span key={index} style={{ height: `${level}%` }} />
            ))}
          </div>
        </div>
        <div className="product-voice-note">
          <FileText size={24} />
          <div>
            <i />
            <i />
            <i />
          </div>
          <ClipboardCheck size={23} />
        </div>
      </div>
    );
  }
  if (slug === "arckpi") {
    return (
      <div
        className="product-illustration product-illustration-analytics"
        aria-hidden="true"
      >
        <div className="product-analytics-inputs">
          <span>
            <ChartNoAxesColumnIncreasing size={20} />
          </span>
          <span>
            <FileText size={20} />
          </span>
          <span>
            <Database size={20} />
          </span>
        </div>
        <div className="product-analytics-wires">
          <i />
          <i />
          <i />
        </div>
        <div className="product-analytics-chart">
          <i />
          <i />
          <i />
          <i />
          <i />
        </div>
      </div>
    );
  }
  return <ProductLayers />;
}

export async function ProductsPreview({ locale }: { locale: Locale }) {
  const snapshot = await getSiteData();
  const copy = productsCopy[locale];
  const products = snapshot.products.slice(0, 3);
  const href = `/${locale}/products`;

  if (products.length === 0) return null;

  return (
    <section
      className="section products-preview"
      id="products-preview"
      aria-labelledby="products-preview-title"
    >
      <div className="container">
        <Reveal className="products-preview-heading">
          <h2 id="products-preview-title">{copy.title}</h2>
          <Link className="product-text-link" href={href}>
            {copy.catalog}
            <ArrowRight size={17} aria-hidden="true" />
          </Link>
        </Reveal>
        <ul className="products-preview-links">
          {products.map((product, index) => {
            const content = productText(product, locale);
            return (
              <li key={product.id}>
                <Reveal
                  className="products-preview-reveal"
                  delay={index * 0.08}
                >
                  <Link
                    className="products-preview-card"
                    href={`${href}/${product.slug}`}
                  >
                    <div className="products-preview-copy">
                      <h3>{content.title}</h3>
                      {content.summary && <p>{content.summary}</p>}
                      <span
                        className="products-preview-arrow"
                        aria-hidden="true"
                      >
                        <ArrowRight size={18} />
                      </span>
                    </div>
                    <div
                      className="products-preview-visual"
                      data-product={product.slug}
                      aria-hidden="true"
                    >
                      <ProductIllustration slug={product.slug} />
                    </div>
                  </Link>
                </Reveal>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}

export async function ProductsPage({ locale }: { locale: Locale }) {
  const snapshot = await getSiteData();
  const copy = productsCopy[locale];
  const products = snapshot.products;
  const href = `/${locale}/products`;

  return (
    <main id="main" className="internal-page products-page">
      <InternalHero
        locale={locale}
        eyebrow={copy.label}
        title={copy.title}
        description={copy.description}
      >
        <Reveal className="products-art-entrance">
          <ProductLayers />
        </Reveal>
      </InternalHero>
      <section
        className="section light-section products-catalog"
        aria-label={copy.label}
      >
        <div className="container">
          {products.length === 0 ? (
            <Reveal>
              <div className="products-empty">
                <h2>{copy.emptyTitle}</h2>
                <Button asChild>
                  <Link href={`/${locale}/contact#brief`}>
                    {copy.emptyAction}
                    <ArrowRight size={17} aria-hidden="true" />
                  </Link>
                </Button>
              </div>
            </Reveal>
          ) : (
            <div className="products-grid">
              {products.map((product, index) => {
                const content = productText(product, locale);
                return (
                  <Reveal
                    className="product-card-reveal"
                    delay={Math.min(index, 3) * 0.08}
                    key={product.id}
                  >
                    <article
                      className="product-card"
                      id={`product-${product.slug}`}
                    >
                      <Link
                        className="product-card-link"
                        href={`${href}/${product.slug}`}
                      >
                        {product.image ? (
                          <div className="product-card-media">
                            <Image
                              src={product.image.url}
                              alt={product.image.alt}
                              width={1280}
                              height={720}
                              unoptimized
                              sizes="(max-width: 760px) 100vw, 50vw"
                            />
                          </div>
                        ) : (
                          <div className="product-card-art" aria-hidden="true">
                            <ProductIllustration slug={product.slug} />
                          </div>
                        )}
                        <div className="product-card-copy">
                          <h2>{content.title}</h2>
                          {content.summary && <p>{content.summary}</p>}
                          <span className="product-card-action">
                            {copy.details}
                            <ArrowRight size={18} aria-hidden="true" />
                          </span>
                        </div>
                      </Link>
                    </article>
                  </Reveal>
                );
              })}
            </div>
          )}
        </div>
      </section>
      {products.length > 0 && (
        <PageCTA
          locale={locale}
          title={copy.question}
          description={copy.questionDescription}
        />
      )}
    </main>
  );
}

export function ProductDetailPage({
  locale,
  product,
  offline = false,
}: {
  locale: Locale;
  product: PublishedProduct;
  offline?: boolean;
}) {
  const copy = productsCopy[locale];
  const content = productText(product, locale);
  const detail = productDetail(product.slug, locale);

  return (
    <main id="main" className="internal-page product-detail-page">
      <InternalHero
        locale={locale}
        eyebrow={copy.previewTitle}
        title={content.title}
        description={content.summary || copy.detailFallback}
        parent={{ href: `/${locale}/products`, label: copy.label }}
        actions={
          <div className="product-detail-actions">
            <Button asChild>
              <a href="#trial">
                {copy.trial}
                <ArrowDown size={16} aria-hidden="true" />
              </a>
            </Button>
            <Button asChild variant="outline">
              <a href="#connection">
                {copy.connection}
                <ArrowDown size={16} aria-hidden="true" />
              </a>
            </Button>
          </div>
        }
      >
        <Reveal className="products-art-entrance">
          {product.image ? (
            <Image
              className="product-detail-image"
              src={product.image.url}
              alt={product.image.alt}
              width={1280}
              height={720}
              unoptimized
              sizes="(max-width: 760px) 100vw, 44vw"
            />
          ) : (
            <ProductIllustration slug={product.slug} />
          )}
        </Reveal>
      </InternalHero>

      {(content.body.trim() || product.website) && (
        <section
          className="section light-section product-overview"
          aria-labelledby="product-overview-title"
        >
          <div className="container">
            <Reveal className="product-overview-content">
              <h2 id="product-overview-title">{copy.overview}</h2>
              {content.body.trim() && <p>{content.body}</p>}
              {product.website && (
                <a className="product-text-link" href={product.website}>
                  {copy.website}
                  <ArrowUpRight size={17} aria-hidden="true" />
                </a>
              )}
            </Reveal>
          </div>
        </section>
      )}

      {detail && (
        <section
          className="section light-section product-capabilities"
          aria-labelledby="product-capabilities-title"
        >
          <div className="container">
            <Reveal>
              <h2 id="product-capabilities-title">{copy.capabilities}</h2>
              <ul className="product-capability-list">
                {detail.capabilities.map(([title, description]) => (
                  <li key={title}>
                    <h3>{title}</h3>
                    <p>{description}</p>
                  </li>
                ))}
              </ul>
            </Reveal>
            <Reveal className="product-workflow">
              <h3>{copy.workflow}</h3>
              <ol className="product-workflow-list">
                {detail.workflow.map(([title, description]) => (
                  <li key={title}>
                    <strong>{title}</strong>
                    <p>{description}</p>
                  </li>
                ))}
              </ol>
            </Reveal>
            <Reveal className="product-fit">
              <div>
                <h3>{copy.fit}</h3>
                <p>{detail.audience}</p>
              </div>
              <div>
                <h3>{copy.prerequisites}</h3>
                <p>{detail.prerequisites}</p>
              </div>
            </Reveal>
            {detail.dataHandling && (
              <Reveal className="product-data-note">
                <LockKeyhole size={23} aria-hidden="true" />
                <div>
                  <h3>{copy.dataHandling}</h3>
                  <p>{detail.dataHandling}</p>
                </div>
              </Reveal>
            )}
          </div>
        </section>
      )}

      <section
        className="section light-section product-pilot"
        aria-labelledby="product-pilot-title"
      >
        <div className="container">
          <Reveal className="product-section-intro">
            <h2 id="product-pilot-title">{copy.pilot.title}</h2>
            <p>{copy.pilot.intro}</p>
          </Reveal>
          <Reveal>
            <table className="product-pilot-table">
              <caption className="sr-only">{copy.pilot.title}</caption>
              <thead>
                <tr>
                  <th scope="col">{copy.pilot.metric}</th>
                  <th scope="col">{copy.pilot.before}</th>
                  <th scope="col">{copy.pilot.during}</th>
                </tr>
              </thead>
              <tbody>
                {(detail?.comparison ?? copy.pilot.comparison).map(
                  ([metric, before, during]) => (
                    <tr key={metric}>
                      <th scope="row">{metric}</th>
                      <td>
                        <span aria-hidden="true">{copy.pilot.before}</span>
                        {before}
                      </td>
                      <td>
                        <span aria-hidden="true">{copy.pilot.during}</span>
                        {during}
                      </td>
                    </tr>
                  ),
                )}
              </tbody>
            </table>
          </Reveal>

          <Reveal className="product-pilot-workflow">
            <h3>{copy.pilot.stepsTitle}</h3>
            <ol className="product-pilot-steps">
              {copy.pilot.steps.map(([title, text]) => (
                <li key={title}>
                  <strong>{title}</strong>
                  <p>{text}</p>
                </li>
              ))}
            </ol>
          </Reveal>
        </div>
      </section>

      <section
        className="section product-why"
        aria-labelledby="product-why-title"
      >
        <div className="container">
          <Reveal className="product-why-content">
            <h2 id="product-why-title">{copy.why.title}</h2>
            <div className="product-why-reasons">
              <div>
                <h3>{copy.why.developmentTitle}</h3>
                <p>{copy.why.developmentText}</p>
              </div>
              <div>
                <h3>{copy.why.integrationTitle}</h3>
                <p>{copy.why.integrationText}</p>
                <Link
                  className="product-text-link"
                  href={`/${locale}/services/system-integration`}
                >
                  {copy.why.integrationLink}
                  <ArrowRight size={17} aria-hidden="true" />
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <div className="section light-section product-request-area">
        <div className="container">
          {detail && (
            <Reveal className="product-pilot-terms">
              <h2>{copy.pilotTerms}</h2>
              <p>{detail.pilotScope}</p>
              <dl>
                <div>
                  <dt>{copy.duration}</dt>
                  <dd>{copy.toBeAgreed}</dd>
                </div>
                <div>
                  <dt>{copy.pricing}</dt>
                  <dd>{copy.byRequest}</dd>
                </div>
              </dl>
            </Reveal>
          )}
          <ProductRequestForm
            key={product.slug}
            locale={locale}
            productSlug={product.slug}
            productTitle={content.title}
            offline={offline}
          />
        </div>
      </div>
    </main>
  );
}
