import type { SiteSettings } from "@/cms/defaults";
import type { Locale } from "@/content/site";
import { contactEmailHref } from "@/lib/contact-details";
import "./contact-details.css";

const labels = {
  ru: {
    email: "Электронная почта",
    phone: "Телефон",
    city: "Город",
    address: "Адрес",
    hours: "Часы ответа",
    registration: "Регистрационный номер",
  },
  en: {
    email: "Email",
    phone: "Phone",
    city: "City",
    address: "Address",
    hours: "Response hours",
    registration: "Registration number",
  },
};

export function ContactDetails({
  settings,
  locale,
  className = "",
}: {
  settings: SiteSettings;
  locale: Locale;
  className?: string;
}) {
  const copy = labels[locale];
  const phone = settings.contactPhone?.replace(/[^+\d]/g, "");
  const telegram = settings.telegram;
  const items = [
    {
      label: copy.email,
      text: settings.contactEmail,
      href: contactEmailHref(settings.contactEmail),
    },
    {
      label: copy.phone,
      text: settings.contactPhone,
      href: phone && /^\+?\d{5,20}$/.test(phone) ? `tel:${phone}` : undefined,
    },
    {
      label: "Telegram",
      text: telegram ? `@${telegram}` : undefined,
      href:
        telegram && /^[a-zA-Z][a-zA-Z0-9_]{4,31}$/.test(telegram)
          ? `https://t.me/${telegram}`
          : undefined,
    },
    { label: copy.city, text: settings.city?.[locale] },
    { label: copy.address, text: settings.address },
    { label: copy.hours, text: settings.responseHours?.[locale] },
  ].filter((item) => item.text);
  if (items.length === 0) return null;
  return (
    <dl className={`public-contact-list ${className}`.trim()}>
      {items.map(({ label, text, href }) => (
        <div key={label}>
          <dt>{label}</dt>
          <dd>{href ? <a href={href}>{text}</a> : text}</dd>
        </div>
      ))}
    </dl>
  );
}

export function OrganizationDetails({
  settings,
  locale,
}: {
  settings: SiteSettings;
  locale: Locale;
}) {
  const name = settings.legalName?.[locale];
  const registration = settings.legalRegistration;
  if (!name && !registration) return null;
  return (
    <p className="public-organization">
      {name}
      {name && registration && " · "}
      {registration && `${labels[locale].registration}: ${registration}`}
    </p>
  );
}
