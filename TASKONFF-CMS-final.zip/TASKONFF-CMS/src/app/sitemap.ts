import type { MetadataRoute } from "next";
import { getSiteData } from "@/cms/site-data";
import { localizedPath, pageSlugs } from "@/lib/routes";
import { serviceSlugs } from "@/content/services";
import { getSiteOrigin } from "@/lib/metadata";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = getSiteOrigin();
  if (!base) return [];
  const { cases, products } = await getSiteData();
  const paths = [
    "",
    ...pageSlugs.filter((slug) => slug !== "portfolio" || cases.length > 0),
    ...serviceSlugs.map((slug) => `services/${slug}`),
    ...products.map(({ slug }) => `products/${slug}`),
  ];
  return paths.flatMap((path) =>
    (["ru", "en"] as const).map((locale) => ({
      url: `${base}${localizedPath(locale, path)}`,
      alternates: {
        languages: {
          ru: `${base}${localizedPath("ru", path)}`,
          en: `${base}${localizedPath("en", path)}`,
          "x-default": `${base}${localizedPath("ru", path)}`,
        },
      },
    })),
  );
}
