import { createHmac } from "node:crypto";
import { getCms } from "@/cms/server/payload";
import { inquirySchema } from "@/lib/brief";
import {
  checkFormRate,
  formError,
  FormRequestError,
  readFormRequest,
} from "@/lib/form-security";

export const runtime = "nodejs";

async function notifyConfiguredWebhook(data: object) {
  const url = process.env.CONTACT_WEBHOOK_URL;
  if (process.env.CONTACT_FORM_ENABLED !== "true" || !url) return;
  try {
    const target = new URL(url);
    if (target.protocol !== "https:" || target.username || target.password) {
      throw new Error("Invalid webhook URL");
    }
    const body = JSON.stringify({ type: "project_inquiry", ...data });
    const secret = process.env.CONTACT_WEBHOOK_SECRET;
    const response = await fetch(target, {
      method: "POST",
      redirect: "error",
      cache: "no-store",
      headers: {
        "Content-Type": "application/json",
        ...(secret
          ? {
              "X-Taskonff-Signature": createHmac("sha256", secret)
                .update(body)
                .digest("hex"),
            }
          : {}),
      },
      body,
      signal: AbortSignal.timeout(8000),
    });
    if (!response.ok) throw new Error("Webhook delivery failed");
  } catch {
    // The request stays available in the private CMS inbox if external delivery fails.
    console.warn("Project inquiry webhook delivery failed.");
  }
}

export async function POST(request: Request) {
  try {
    const raw = await readFormRequest(request);
    checkFormRate(request, "contact");
    const result = inquirySchema.safeParse(raw);
    if (!result.success) throw new FormRequestError(400, "invalid");

    const { name, email, service, message, consent, locale, source } =
      result.data;
    const data = { name, email, service, message, consent, locale, source };
    const payload = await getCms();
    await payload.create({
      collection: "project-inquiries",
      overrideAccess: true,
      data: { ...data, status: "new" },
    });
    await notifyConfiguredWebhook(data);

    return Response.json(
      { accepted: true },
      { status: 201, headers: { "Cache-Control": "no-store" } },
    );
  } catch (error) {
    return formError(
      error instanceof FormRequestError
        ? error
        : new FormRequestError(503, "unavailable"),
    );
  }
}
