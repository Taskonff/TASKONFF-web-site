import type { Locale } from "./site";

type ProductDetail = {
  capabilities: ReadonlyArray<readonly [title: string, description: string]>;
  workflow: ReadonlyArray<readonly [title: string, description: string]>;
  audience: string;
  prerequisites: string;
  pilotScope: string;
  comparison: ReadonlyArray<
    readonly [metric: string, before: string, during: string]
  >;
  dataHandling?: string;
};

const arckpi = {
  ru: {
    capabilities: [
      [
        "Данные из разных источников",
        "Сведите данные о расходах, заявках и сделках в одном разрезе, чтобы сократить ручную сверку отчётов.",
      ],
      [
        "Путь от заявки до сделки",
        "Сопоставьте этапы продаж с источником заявки. Это помогает понять, на каком этапе теряются обращения из каждого канала.",
      ],
      [
        "Стоимость привлечения",
        "Сравнивайте расходы с закрытыми сделками, чтобы обсуждать рекламный бюджет с учётом выручки.",
      ],
    ],
    workflow: [
      ["Соберите источники", "Расходы на рекламу, заявки и данные о сделках."],
      ["Сопоставьте данные", "Свяжите записи с каналом и этапом продаж."],
      ["Сравните каналы", "Посмотрите, какие обращения доходят до продаж."],
    ],
    audience:
      "Команды маркетинга и продаж, которые получают заявки из нескольких каналов и ведут учёт сделок.",
    prerequisites:
      "Если заявки или сделки ещё не фиксируются, начните с настройки учёта. Для сравнения каналов нужны данные по каждому из них.",
    pilotScope:
      "Возьмите один канал, отчёт о расходах и выгрузку по сделкам за тот же период. Перед стартом согласуем источники и критерии оценки.",
    comparison: [
      [
        "Подготовка отчёта",
        "Замерьте, сколько времени уходит на сбор и проверку данных в текущем отчёте.",
        "Подготовьте отчёт за сопоставимый период и повторите замер.",
      ],
      [
        "Связь заявки со сделкой",
        "Посчитайте, у скольких закрытых сделок можно определить источник заявки.",
        "Сравните долю сделок с известным источником на той же выборке.",
      ],
      [
        "Расхождения в данных",
        "Отметьте дубли, пропуски и различия между рекламным отчётом и CRM.",
        "Проверьте, какие расхождения команда может объяснить и устранить.",
      ],
    ],
  },
  en: {
    capabilities: [
      [
        "Data from multiple sources",
        "Bring spending, lead and deal data together so there is less manual work reconciling separate reports.",
      ],
      [
        "From lead to sale",
        "Map sales stages to lead sources to see where inquiries from each channel drop out of the funnel.",
      ],
      [
        "Acquisition costs",
        "Compare spend with closed deals so revenue can inform advertising budget decisions.",
      ],
    ],
    workflow: [
      ["Gather source data", "Advertising spend, leads and recorded deals."],
      ["Match the records", "Link each record to its channel and sales stage."],
      ["Compare channels", "See which inquiries turn into sales."],
    ],
    audience:
      "Marketing and sales teams that record deals and receive leads from multiple channels.",
    prerequisites:
      "If you don’t already track leads or deals, start by setting up tracking. You need source data for each channel to compare them.",
    pilotScope:
      "Start with one channel, an advertising spend report and a deal export for the same period. We’ll agree on sources and success criteria before the pilot.",
    comparison: [
      [
        "Report preparation",
        "Time how long it takes to collect and review the data for your current report.",
        "Prepare a report for a comparable period and time it again.",
      ],
      [
        "Linking leads to sales",
        "Count the closed deals where you can identify the source of the lead.",
        "Compare the share of deals with a known source in the same sample.",
      ],
      [
        "Data discrepancies",
        "Identify duplicates, gaps and discrepancies between ad reports and the CRM.",
        "Check which discrepancies the team can explain and resolve.",
      ],
    ],
  },
} satisfies Record<Locale, ProductDetail>;

const medvoice = {
  ru: {
    capabilities: [
      [
        "Заметки голосом",
        "Продиктуйте заметку по завершении приёма и проверьте, сокращает ли диктовка время на набор текста.",
      ],
      [
        "Черновик записи",
        "Проверьте, насколько получившийся текст подходит для ваших шаблонов и сколько правок нужно перед использованием.",
      ],
      [
        "Проверка врачом",
        "Врач сверяет формулировки, исправляет неточности и сам решает, что включить в запись.",
      ],
    ],
    workflow: [
      ["Продиктуйте заметку", "Для первого теста используйте учебный пример."],
      ["Проверьте черновик", "Сверьте текст с исходной диктовкой."],
      ["Подготовьте запись", "Внесите правки и утвердите нужный текст."],
    ],
    audience:
      "Клиники и врачи, которым нужно проверить, помогает ли голосовой ввод быстрее оформлять записи о приёме.",
    prerequisites:
      "Для сценария требуется проверка врачом. Если нужен автоматический медицинский вывод или запись без проверки, этот сценарий не подойдёт.",
    pilotScope:
      "Начните с учебных примеров одного типа приёма. Согласуем формат черновика, критерии проверки и условия подключения.",
    dataHandling:
      "Первую проверку проводите на учебных или обезличенных примерах. До работы с данными пациентов согласуйте с клиникой и TASKONFF, где будут храниться аудио и текст, кто получит доступ и когда материалы будут удалены.",
    comparison: [
      [
        "Время на оформление",
        "Замерьте время от начала ввода до готовой учебной записи.",
        "На сопоставимом примере учтите время диктовки, проверки и правок.",
      ],
      [
        "Точность формулировок",
        "Отметьте, какие поля и термины требуют отдельной проверки при ручном вводе.",
        "Посчитайте исправления в черновике и разберите критичные неточности с врачом.",
      ],
      [
        "Перенос в документацию",
        "Посчитайте, сколько действий занимает сохранение записи в вашем процессе.",
        "Проверьте, какие ручные шаги сохраняются после проверки черновика.",
      ],
    ],
  },
  en: {
    capabilities: [
      [
        "Voice notes",
        "Dictate a note after a visit and check if dictation reduces the time you spend typing.",
      ],
      [
        "Draft documentation",
        "Check how well the text fits your templates and how much editing it needs before use.",
      ],
      [
        "Clinician review",
        "The clinician checks the wording, corrects errors and decides what to include in the record.",
      ],
    ],
    workflow: [
      ["Dictate a note", "Start with a training example for the first test."],
      ["Review the draft", "Compare the draft with the original dictation."],
      ["Prepare the record", "Make your edits and approve the selected text."],
    ],
    audience:
      "Clinics and clinicians who want to see whether voice input can make visit documentation quicker.",
    prerequisites:
      "The workflow requires clinician review. It’s unsuitable for workflows that require autonomous clinical conclusions or records without review.",
    pilotScope:
      "Start with training examples for one type of visit. We’ll agree on the draft format, review criteria and setup requirements.",
    dataHandling:
      "Use training or de-identified examples for the first evaluation. Before handling patient data, agree with the clinic and TASKONFF on where audio and text will be stored, who can access them and when they will be deleted.",
    comparison: [
      [
        "Time to complete the record",
        "Time how long it takes to enter and complete a training record manually.",
        "Include dictation, review and editing when timing a comparable example.",
      ],
      [
        "Accuracy of wording",
        "Identify fields and terminology that need extra review during manual entry.",
        "Count edits made to the draft and review major errors with a clinician.",
      ],
      [
        "Adding the record to your documentation",
        "Count the steps it takes to save a record in your current process.",
        "Check which manual steps remain after reviewing and approving the draft.",
      ],
    ],
  },
} satisfies Record<Locale, ProductDetail>;

export function productDetail(
  slug: string,
  locale: Locale,
): ProductDetail | undefined {
  if (slug === "arckpi") return arckpi[locale];
  if (slug === "medvoice") return medvoice[locale];
}
