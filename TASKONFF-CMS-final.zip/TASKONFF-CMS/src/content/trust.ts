export const trustContent = {
  ru: {
    portfolio: {
      label: "Портфолио",
      title: "За каждой системой —\nреальная задача.",
      description:
        "Хороший кейс показывает путь от задачи бизнеса до инженерного решения. Мы публикуем проекты только с проверенными материалами и разрешением на раскрытие.",
      emptyTitle: "Кейсы появятся здесь, когда будут готовы к публикации.",
      emptyText:
        "Публичные материалы о проектах будут добавлены после проверки содержания и согласования условий раскрытия.",
      evidenceLabel: "ЧТО ВАЖНО В КАЖДОМ КЕЙСЕ",
      evidenceTitle: "Не только экран.\nВся логика решения.",
      evidence: [
        [
          "Контекст",
          "Какая задача стояла перед бизнесом, для кого создавался продукт и какие ограничения влияли на решение.",
        ],
        [
          "Решение",
          "Архитектура, пользовательские сценарии, интеграции и причины выбора технологий.",
        ],
        [
          "Работа",
          "Границы ответственности, этапы разработки и проверка качества.",
        ],
        [
          "Результат",
          "Подтверждённые изменения и выводы, которые можно раскрывать публично.",
        ],
      ],
      scenarioLabel: "ВОЗМОЖНЫЕ НАПРАВЛЕНИЯ",
      scenarioTitle: "Исследуйте то,\nчто можно создать.",
      scenarioNote:
        "Это примеры задач для обсуждения, а не кейсы выполненных проектов.",
      scenarios: [
        [
          "Цифровой продукт",
          "От первого пользовательского сценария до веб-приложения или SaaS-платформы.",
          "web-mobile",
        ],
        [
          "Связанные процессы",
          "Интеграция данных, CRM и внутренних инструментов вокруг реального процесса.",
          "business-automation",
        ],
        [
          "AI в работе команды",
          "Агент, который помогает находить знания и выполнять согласованные действия.",
          "ai-agents",
        ],
      ],
      scenarioLink: "Узнать о направлении",
      publicationLabel: "ПУБЛИКАЦИЯ КЕЙСОВ",
      scenarioKind: "СЦЕНАРИЙ",
      caseDetails: "Подробнее о проекте",
    },
    contact: {
      label: "Контакты",
      title: "Обсудим ваш проект.",
      description:
        "Расскажите, что хотите разработать, автоматизировать или улучшить. Команда изучит задачу и уточнит следующий шаг.",
      mode: "СВЯЗАТЬСЯ",
      modeTitle: "Связаться с TASKONFF",
      modeText:
        "Опишите задачу и оставьте электронную почту, чтобы мы могли уточнить детали.",
      modeHelp:
        "Подготовьте цель проекта, информацию о текущих системах и ограничения, которые важно учесть.",
      prepareLabel: "ЧТО ПОЛЕЗНО ПОДГОТОВИТЬ",
      prepareTitle: "Несколько деталей,\nкоторые задают направление.",
      prepare: [
        ["Цель", "Что должно измениться для бизнеса или пользователей?"],
        ["Контекст", "Какие системы, данные и процессы уже существуют?"],
        [
          "Приоритеты",
          "Что необходимо для первого этапа, а что можно развивать позже?",
        ],
        [
          "Ограничения",
          "Есть ли согласованный срок, бюджетный ориентир или требования к безопасности?",
        ],
      ],
      faqTitle: "Перед первым шагом",
      faq: [
        [
          "Нужна ли готовая спецификация?",
          "Нет. Для начала достаточно описать задачу, пользователей и ожидаемый результат. Требования можно уточнять по мере исследования.",
        ],
        [
          "Что происходит с данными формы?",
          "Отправленная заявка поступает в закрытый раздел для команды TASKONFF. Мы используем её, чтобы разобраться в задаче и ответить вам.",
        ],
        [
          "Можно ли прикрепить конфиденциальные материалы?",
          "Эта форма не поддерживает вложения. Не добавляйте пароли, токены, персональные данные третьих лиц и закрытые коммерческие материалы в описание. Условия обмена такими материалами нужно согласовать отдельно.",
        ],
        [
          "Куда придёт ответ?",
          "Мы напишем на электронную почту, которую вы укажете при отправке заявки.",
        ],
      ],
      techLink: "Посмотреть технологический подход",
      privacyLink: "Как обрабатываются данные",
      deliveryHelp:
        "Вы также можете связаться с командой по указанным каналам.",
    },
    legal: {
      draftLabel: "ПРОЕКТ ДОКУМЕНТА",
      draftText:
        "Эта редакция описывает текущую функциональность сайта. Сведения о юридическом владельце, хостинге, применимых правилах и сроках обработки должны быть согласованы до публичного запуска. Документ не представлен как окончательно утверждённая правовая политика.",
      contents: "Содержание",
      backContact: "Перейти к контактам",
      privacy: {
        label: "Конфиденциальность",
        title: "Прозрачно\nо данных.",
        description:
          "Как TASKONFF обрабатывает данные при просмотре сайта, отправке проектной заявки и запросе доступа к продуктам.",
        sections: [
          [
            "Область документа",
            "Документ описывает обработку данных посетителей сайта TASKONFF и пользователей форм обратной связи.",
          ],
          [
            "Данные проектного брифа",
            "При отправке формы сервер проверяет имя, электронную почту, направление, описание проекта и согласие на обработку данных. Команда использует сведения для обработки заявки и ответа.",
          ],
          [
            "Хранение и передача",
            "Отправленные заявки хранятся в закрытом разделе административной панели. Доступ имеют администраторы сайта. При настроенной интеграции с системой обработки заявок данные могут передаваться в неё. Копия, скачанная через форму, сохраняется на вашем устройстве.",
          ],
          [
            "Технические данные",
            "Для работы сайта и ограничения частоты запросов сервер обрабатывает технические сведения о запросах. Поставщик хостинга может обрабатывать собственные технические журналы. Его состав данных, сроки хранения и условия обработки необходимо уточнить в утверждённой политике перед запуском.",
          ],
          [
            "Cookies и аналитика",
            "Административная панель использует файлы cookie для защищённого входа. В текущей публичной версии сайта рекламное отслеживание и аналитические трекеры отсутствуют.",
          ],
          [
            "Ваши действия и обращения",
            "В форме укажите только то, что нужно для обсуждения задачи. Обращения по обработке данных можно направить на указанный на этой странице контакт.",
          ],
          [
            "Изменения функциональности",
            "Описание обработки данных обновляется при изменении сервисов, способов хранения или передачи заявок.",
          ],
        ],
      },
      terms: {
        label: "Условия использования",
        title: "Понятные правила\nвзаимодействия.",
        description:
          "Информационный характер сайта, правила работы с брифом и границы текущей функциональности.",
        sections: [
          [
            "Статус условий",
            "Это проект условий для текущей версии сайта. Юридическое лицо, применимое право и порядок разрешения споров должны быть определены в утверждённом документе. Эта редакция не заявлена как готовый договор об оказании услуг.",
          ],
          [
            "Информация о решениях",
            "Страницы описывают направления разработки и возможные сценарии применения технологий. Они не являются индивидуальным техническим заданием, обязательством о сроках или публичной офертой на конкретный объём работ. Условия проекта согласуются отдельно.",
          ],
          [
            "Бриф и обращение",
            "Через форму можно передать описание проекта для предварительного обсуждения. После отправки появляется подтверждение приёма. Объём работ и договорные условия согласовываются отдельно.",
          ],
          [
            "Допустимое использование",
            "Используйте сайт для знакомства с услугами и подготовки описания задачи. Не отправляйте вредоносный контент, секретные ключи, пароли или материалы, которыми вы не вправе делиться. Не пытайтесь обходить ограничения запросов и нарушать работу сайта.",
          ],
          [
            "Интеллектуальные права",
            "Название, оригинальный логотип и материалы TASKONFF следует использовать с учётом прав их владельцев. Представление технологий и сторонних наименований не означает передачи прав на них или заявления о партнёрстве.",
          ],
          [
            "Сценарии и портфолио",
            "Иллюстрации возможных решений не представлены как выполненные проекты. Публичные кейсы должны опираться на проверенные материалы и разрешение на раскрытие. Условия реализации каждого решения определяются отдельно.",
          ],
          [
            "Изменения и доступность",
            "Содержание и функции могут развиваться. Окончательные положения об ответственности, доступности сервиса и порядке уведомления об изменениях должны быть согласованы юридическим владельцем перед публичным запуском.",
          ],
        ],
      },
      documentState:
        "Фактическая редакция текущей функциональности. Проект, не окончательный документ.",
    },
  },
  en: {
    portfolio: {
      label: "Portfolio",
      title: "Behind every system,\na real challenge.",
      description:
        "A useful case study connects a business challenge to the engineering decisions behind a solution. We publish projects only with verified material and permission to disclose.",
      emptyTitle:
        "Case studies will appear here when they are approved for publication.",
      emptyText:
        "Public project materials will be added after the content is verified and disclosure terms are approved.",
      evidenceLabel: "WHAT A CASE SHOULD EXPLAIN",
      evidenceTitle: "Beyond the screen.\nThe thinking behind it.",
      evidence: [
        [
          "Context",
          "The business challenge, intended users and constraints that shaped the solution.",
        ],
        [
          "Solution",
          "Architecture, user journeys, integrations and the reasons behind technology choices.",
        ],
        [
          "Delivery",
          "Scope of responsibility, development stages and quality checks.",
        ],
        [
          "Outcome",
          "Verified changes and findings that can be shared publicly.",
        ],
      ],
      scenarioLabel: "POSSIBLE DIRECTIONS",
      scenarioTitle: "Explore what\nwe could build.",
      scenarioNote:
        "These are examples of challenges to discuss, not completed project case studies.",
      scenarios: [
        [
          "A digital product",
          "From a first user journey to a web application or SaaS platform.",
          "web-mobile",
        ],
        [
          "Connected operations",
          "Data, CRM and internal tools connected around an actual business process.",
          "business-automation",
        ],
        [
          "AI for your team",
          "An agent that helps find knowledge and carry out agreed actions.",
          "ai-agents",
        ],
      ],
      scenarioLink: "Explore this direction",
      publicationLabel: "CASE STUDY PUBLICATION",
      scenarioKind: "SCENARIO",
      caseDetails: "Project details",
    },
    contact: {
      label: "Contact",
      title: "Let’s discuss your project.",
      description:
        "Tell us what you want to build, automate or improve. The team will review your project and follow up by email.",
      mode: "GET IN TOUCH",
      modeTitle: "Contact TASKONFF",
      modeText:
        "Describe your project and leave an email address so we can follow up.",
      modeHelp:
        "Include your goal, the systems you use today and any constraints that matter to the project.",
      prepareLabel: "USEFUL STARTING POINTS",
      prepareTitle: "A few details\nthat set the direction.",
      prepare: [
        ["Goal", "What should change for the business or its users?"],
        ["Context", "Which systems, data sources and processes already exist?"],
        [
          "Priorities",
          "What belongs in the first stage, and what can evolve later?",
        ],
        [
          "Constraints",
          "Is there an agreed timeframe, budget range or security requirement?",
        ],
      ],
      faqTitle: "Before the first step",
      faq: [
        [
          "Do I need a finished specification?",
          "No. You can start with the challenge, intended users and desired outcome. Requirements can be refined during discovery.",
        ],
        [
          "What happens to form data?",
          "Submitted requests are saved to a private inbox for the TASKONFF team. We use your information to understand your project and respond.",
        ],
        [
          "Can I attach confidential materials?",
          "This form does not support attachments. Do not include passwords, tokens, third-party personal data or confidential commercial materials. Agree on a separate process for sharing them.",
        ],
        [
          "Where will I receive a reply?",
          "We’ll write to the email address you enter when submitting your request.",
        ],
      ],
      techLink: "Explore the technology approach",
      privacyLink: "How data is processed",
      deliveryHelp:
        "You can also get in touch through the contact channels shown here.",
    },
    legal: {
      draftLabel: "DRAFT DOCUMENT",
      draftText:
        "This edition describes the site’s current functionality. The legal owner, hosting details, applicable rules and processing periods must be confirmed before public launch. This document is not presented as a final approved legal policy.",
      contents: "Contents",
      backContact: "View contact details",
      privacy: {
        label: "Privacy",
        title: "A clear view\nof your data.",
        description:
          "How TASKONFF handles data when you visit the website, send a project inquiry or request access to a product.",
        sections: [
          [
            "Scope",
            "This document describes data processing for visitors to the TASKONFF website and people who submit its forms.",
          ],
          [
            "Project brief data",
            "When you submit the form, the server validates your name, email, area of interest, project description and consent. The team uses these details to process and respond to your request.",
          ],
          [
            "Storage and transmission",
            "Submitted requests are stored in the private CMS inbox and are accessible to site administrators. An enabled request-management integration can also receive the submission. A downloaded copy stays on your device.",
          ],
          [
            "Technical data",
            "The server processes technical request information to operate the website and limit request frequency. The hosting provider may process its own technical logs. Their contents, retention periods and processing terms must be clarified in the approved policy before launch.",
          ],
          [
            "Cookies and analytics",
            "The administration panel uses session cookies for secure sign-in. The current public website has no analytics trackers or advertising cookies.",
          ],
          [
            "Your actions and inquiries",
            "Only include information needed to discuss your project. Send questions about data processing to the contact listed on this page.",
          ],
          [
            "Changes in functionality",
            "This notice is updated when services, storage or request delivery changes.",
          ],
        ],
      },
      terms: {
        label: "Terms of use",
        title: "Clear expectations.\nA better starting point.",
        description:
          "The informational nature of the site, use of the project brief and the limits of current functionality.",
        sections: [
          [
            "Status of these terms",
            "These are draft terms for the current website. The legal entity, applicable law and dispute-resolution process must be set out in an approved document. This edition is not presented as a completed service agreement.",
          ],
          [
            "Information about solutions",
            "Pages describe development capabilities and possible uses of technology. They are not an individual specification, a delivery-date commitment or an offer for a defined scope of work. Project terms are agreed separately.",
          ],
          [
            "Briefs and inquiries",
            "Use the form to submit a project description for initial discussion. A confirmation appears after the request is received. The scope of work and any contractual terms are agreed separately.",
          ],
          [
            "Acceptable use",
            "Use the site to explore services and prepare a challenge description. Do not submit harmful content, secret keys, passwords or materials you are not entitled to share. Do not attempt to bypass request limits or disrupt the website.",
          ],
          [
            "Intellectual rights",
            "The TASKONFF name, original logo and materials should be used with respect for their owners’ rights. Mentioning technologies or third-party names does not transfer rights or imply a partnership.",
          ],
          [
            "Scenarios and portfolio",
            "Illustrations of possible solutions are not presented as delivered projects. Public case studies must be based on verified materials and permission to disclose. The terms for delivering each solution are agreed separately.",
          ],
          [
            "Changes and availability",
            "Content and functionality may evolve. Final provisions on liability, service availability and notice of changes must be approved by the legal owner before public launch.",
          ],
        ],
      },
      documentState:
        "A factual description of current functionality. Draft, not a final policy.",
    },
  },
};
