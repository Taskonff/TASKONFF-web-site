import type { PublishedProduct } from "@/cms/defaults";
import type { Locale } from "./site";

const summaries: Record<string, Record<Locale, string>> = {
  arckpi: {
    ru: "Сквозная аналитика для команд маркетинга и продаж. Сопоставьте расходы, заявки и сделки, чтобы понять, какие каналы приводят к выручке.",
    en: "Cross-channel analytics for marketing and sales teams. Compare ad spend, leads and deals to understand which channels contribute to revenue.",
  },
  medvoice: {
    ru: "Голосовой сценарий для приёма в клинике: врач диктует заметки, проверяет черновик записи и решает, какие данные перенести в документацию.",
    en: "A voice workflow for clinical documentation: clinicians dictate notes, review a draft and decide what to include in the visit record.",
  },
};

export function productText(product: PublishedProduct, locale: Locale) {
  const content = product[locale];
  return {
    ...content,
    summary: content.summary.trim() || summaries[product.slug]?.[locale] || "",
  };
}
