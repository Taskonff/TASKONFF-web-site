import fs from "node:fs";
import {
  defaultSiteData,
  mergeContent,
  type CmsSiteData,
  type MediaAsset,
  type PublishedCase,
  type PublishedProduct,
} from "./defaults";
import { productWebsiteUrl } from "@/lib/product-url";
type RecordValue = Record<string, unknown>;
function record(value: unknown): RecordValue {
  return value && typeof value === "object" ? (value as RecordValue) : {};
}
function translated(value: unknown, locale: "ru" | "en"): string {
  if (typeof value === "string") return value;
  const data = record(value);
  return typeof data[locale] === "string"
    ? (data[locale] as string)
    : typeof data.ru === "string"
      ? (data.ru as string)
      : "";
}
export function mediaAsset(
  value: unknown,
  locale: "ru" | "en" = "ru",
): MediaAsset | undefined {
  const media = record(value);
  const url = media.url;
  if (
    typeof url !== "string" ||
    (!url.startsWith("/") && !url.startsWith("https://"))
  )
    return;
  return { url, alt: translated(media.alt, locale) };
}
export async function readSiteData(): Promise<CmsSiteData> {
  if (process.env.CMS_STATIC_EXPORT === "1") {
    const file = process.env.CMS_SNAPSHOT_FILE;
    if (file && fs.existsSync(/* turbopackIgnore: true */ file))
      return JSON.parse(
        fs.readFileSync(/* turbopackIgnore: true */ file, "utf8"),
      ) as CmsSiteData;
    return defaultSiteData();
  }
  const data = defaultSiteData();
  const { getCms } = await import("@/cms/server/payload");
  const payload = await getCms();
  const [pages, settings, cases, products] = await Promise.all([
    payload.find({
      collection: "pages",
      limit: 100,
      depth: 1,
      overrideAccess: false,
      draft: false,
      where: { _status: { equals: "published" } },
    }),
    payload.findGlobal({
      slug: "site-settings",
      depth: 1,
      overrideAccess: false,
      locale: "all",
    }),
    payload.find({
      collection: "case-studies",
      limit: 100,
      depth: 1,
      overrideAccess: false,
      draft: false,
      locale: "all",
      where: { _status: { equals: "published" } },
      sort: "-createdAt",
    }),
    payload.find({
      collection: "products",
      limit: 100,
      depth: 1,
      overrideAccess: false,
      draft: false,
      locale: "all",
      where: { _status: { equals: "published" } },
      sort: "title",
    }),
  ]);
  for (const raw of pages.docs) {
    const doc = record(raw);
    const key = String(doc.key ?? "");
    const edited = record(doc.content);
    for (const locale of ["ru", "en"] as const) {
      const value = edited[locale];
      const v = record(value);
      if (key === "home") {
        data.site[locale] = mergeContent(data.site[locale], v.site);
        data.home[locale] = mergeContent(data.home[locale], v.home);
        data.solutions[locale] = mergeContent(
          data.solutions[locale],
          v.solutions,
        );
      } else if (key === "shared") {
        data.shared[locale] = mergeContent(data.shared[locale], v.shared);
        data.groups[locale] = mergeContent(data.groups[locale], v.groups);
        Object.assign(
          data.trust[locale].legal,
          mergeContent(
            {
              draftLabel: data.trust[locale].legal.draftLabel,
              draftText: data.trust[locale].legal.draftText,
              contents: data.trust[locale].legal.contents,
              backContact: data.trust[locale].legal.backContact,
              documentState: data.trust[locale].legal.documentState,
            },
            v.legal,
          ),
        );
      } else if (key === "about")
        data.company[locale].about = mergeContent(
          data.company[locale].about,
          value,
        );
      else if (key === "technologies") {
        data.company[locale].tech = mergeContent(
          data.company[locale].tech,
          v.page,
        );
        data.company[locale].architecture = mergeContent(
          data.company[locale].architecture,
          v.explorer,
        );
      } else if (key === "process") {
        data.company[locale].process = mergeContent(
          data.company[locale].process,
          v.page,
        );
        data.company[locale].phases = mergeContent(
          data.company[locale].phases,
          v.explorer,
        );
      } else if (key === "portfolio")
        data.trust[locale].portfolio = mergeContent(
          data.trust[locale].portfolio,
          value,
        );
      else if (key === "contact")
        data.trust[locale].contact = mergeContent(
          data.trust[locale].contact,
          value,
        );
      else if (key === "privacy" || key === "terms")
        data.trust[locale].legal[key] = mergeContent(
          data.trust[locale].legal[key],
          value,
        );
      else if (key === "services") {
        data.expertise[locale].services = mergeContent(
          data.expertise[locale].services,
          v.page,
        );
        data.expertise[locale].detail = mergeContent(
          data.expertise[locale].detail,
          v.detail,
        );
      } else if (key === "industries")
        data.expertise[locale].industries = mergeContent(
          data.expertise[locale].industries,
          value,
        );
      else if (key.startsWith("service-")) {
        const service = data.services.find(
          (item) => `service-${item.slug}` === key,
        );
        if (service) service[locale] = mergeContent(service[locale], value);
      }
    }
    const image = mediaAsset(doc.heroImage);
    if (image) {
      image.alt = translated(doc.imageAlt, "ru") || image.alt;
      data.pageMedia[key] = image;
    }
  }
  const s = record(settings);
  for (const key of [
    "brandName",
    "contactEmail",
    "contactPhone",
    "address",
    "telegram",
    "legalRegistration",
    "privacyEmail",
  ] as const)
    if (typeof s[key] === "string") data.settings[key] = s[key].trim();
  for (const key of [
    "city",
    "responseHours",
    "responseTime",
    "legalName",
  ] as const) {
    const value = record(s[key]);
    data.settings[key] = {
      ru: typeof value.ru === "string" ? value.ru.trim() : undefined,
      en: typeof value.en === "string" ? value.en.trim() : undefined,
    };
  }
  data.settings.logoUrl = mediaAsset(s.logo)?.url;
  data.settings.heroImageUrl = mediaAsset(s.heroImage)?.url;
  data.settings.ogImageUrl = mediaAsset(s.ogImage)?.url;
  if (Array.isArray(s.pageImages))
    for (const slot of s.pageImages) {
      const entry = record(slot);
      const image = mediaAsset(entry.image);
      if (typeof entry.key === "string" && image && !data.pageMedia[entry.key])
        data.pageMedia[entry.key] = {
          ...image,
          alt: translated(entry.alt, "ru") || image.alt,
        };
    }
  if (!data.pageMedia.home && data.settings.heroImageUrl)
    data.pageMedia.home = {
      url: data.settings.heroImageUrl,
      alt: data.home.ru.hero.titleFirst,
    };
  data.cases = cases.docs.map((raw) => {
    const c = record(raw);
    const text = (locale: "ru" | "en") => ({
      title: translated(c.title, locale),
      summary: translated(c.summary, locale),
      body: translated(c.body, locale),
    });
    return {
      id: String(c.id),
      slug: String(c.slug ?? c.id),
      ru: text("ru"),
      en: text("en"),
      image: mediaAsset(c.heroImage),
    } satisfies PublishedCase;
  });
  data.products = products.docs.map((entry): PublishedProduct => {
    const text = (locale: "ru" | "en") => ({
      title:
        translated(entry.title, locale) ||
        translated(entry.title, locale === "ru" ? "en" : "ru"),
      summary: translated(entry.summary, locale),
      body: translated(entry.body, locale),
    });
    return {
      id: String(entry.id),
      slug: entry.slug,
      ru: text("ru"),
      en: text("en"),
      image: mediaAsset(entry.image),
      website: productWebsiteUrl(entry.website),
    };
  });
  return data;
}
