import type { CollectionConfig } from "payload";
import { productWebsiteUrl } from "@/lib/product-url";
import { authenticated, publishedOrAuthenticated } from "./access";

const maxSlugLength = 100;
const maxWebsiteLength = 2048;

function validateWebsite(value: unknown) {
  if (value === undefined || value === null || value === "") return true;
  return (
    (typeof value === "string" &&
      value.length <= maxWebsiteLength &&
      Boolean(productWebsiteUrl(value))) ||
    "Enter a complete HTTPS address without credentials (up to 2048 characters)."
  );
}

export const products: CollectionConfig = {
  slug: "products",
  labels: {
    singular: { ru: "Продукт", en: "Product" },
    plural: { ru: "Продукты", en: "Products" },
  },
  admin: {
    useAsTitle: "title",
    defaultColumns: ["title", "slug", "_status", "updatedAt"],
    group: { ru: "Контент", en: "Content" },
    description: {
      ru: "Каталог продуктов собственной разработки TASKONFF. Заполните тексты на русском и английском перед публикацией.",
      en: "The TASKONFF catalog of products built in-house. Add Russian and English copy before publishing.",
    },
  },
  access: {
    create: authenticated,
    read: publishedOrAuthenticated,
    update: authenticated,
    delete: authenticated,
    readVersions: authenticated,
  },
  versions: { drafts: true, maxPerDoc: 30 },
  fields: [
    {
      name: "title",
      label: { ru: "Название", en: "Name" },
      type: "text",
      localized: true,
      required: true,
      maxLength: 180,
    },
    {
      name: "slug",
      label: { ru: "Идентификатор", en: "Slug" },
      type: "text",
      required: true,
      unique: true,
      maxLength: maxSlugLength,
      validate: (value: unknown) =>
        (typeof value === "string" &&
          value.length <= maxSlugLength &&
          /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value)) ||
        "Use lowercase Latin letters, numbers and hyphens (up to 100 characters).",
    },
    {
      name: "summary",
      label: { ru: "Краткое описание", en: "Summary" },
      type: "textarea",
      localized: true,
      maxLength: 1000,
    },
    {
      name: "body",
      label: { ru: "Описание продукта", en: "Product description" },
      type: "textarea",
      localized: true,
      maxLength: 20000,
    },
    {
      name: "image",
      label: { ru: "Изображение", en: "Image" },
      type: "upload",
      relationTo: "media",
    },
    {
      name: "website",
      label: { ru: "Сайт или демо", en: "Website or demo" },
      type: "text",
      maxLength: maxWebsiteLength,
      validate: validateWebsite,
      admin: {
        description: {
          ru: "Публичная HTTPS-ссылка на сайт продукта или демо.",
          en: "A public HTTPS link to the product website or demo.",
        },
      },
    },
  ],
};
