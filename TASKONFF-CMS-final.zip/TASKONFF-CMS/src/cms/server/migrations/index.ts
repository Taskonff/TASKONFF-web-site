import * as migration_20261105_094319_initial from "./20261105_094319_initial";
import * as migration_20261120_052315_products from "./20261120_052315_products";
import * as migration_20261120_053422_product_requests from "./20261120_053422_product_requests";
import * as migration_20261120_145809_project_inquiries from "./20261120_145809_project_inquiries";

export const migrations = [
  {
    up: migration_20261105_094319_initial.up,
    down: migration_20261105_094319_initial.down,
    name: "20261105_094319_initial",
  },
  {
    up: migration_20261120_052315_products.up,
    down: migration_20261120_052315_products.down,
    name: "20261120_052315_products",
  },
  {
    up: migration_20261120_053422_product_requests.up,
    down: migration_20261120_053422_product_requests.down,
    name: "20261120_053422_product_requests",
  },
  {
    up: migration_20261120_145809_project_inquiries.up,
    down: migration_20261120_145809_project_inquiries.down,
    name: "20261120_145809_project_inquiries",
  },
];
