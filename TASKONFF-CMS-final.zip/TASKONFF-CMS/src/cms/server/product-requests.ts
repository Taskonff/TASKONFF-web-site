import type { CollectionConfig } from "payload";
import { authenticated } from "./access";

const readOnly = { readOnly: true } as const;
const preventFieldUpdate = { update: () => false };

export const productRequests: CollectionConfig = {
  slug: "product-requests",
  labels: {
    singular: { ru: "Заявка на продукт", en: "Product request" },
    plural: { ru: "Заявки на продукты", en: "Product requests" },
  },
  admin: {
    useAsTitle: "productTitle",
    group: { ru: "Управление", en: "Administration" },
    defaultColumns: ["productTitle", "kind", "status", "email", "createdAt"],
    description: {
      ru: "Заявки на тестовый период и подключение. Отметьте обработанную заявку в поле «Статус».",
      en: "Trial and connection requests. Update the status after reviewing a request.",
    },
  },
  access: {
    create: () => false,
    read: authenticated,
    update: authenticated,
    delete: authenticated,
    readVersions: () => false,
  },
  fields: [
    {
      name: "status",
      label: { ru: "Статус", en: "Status" },
      type: "select",
      required: true,
      defaultValue: "new",
      options: [
        { label: { ru: "Новая", en: "New" }, value: "new" },
        { label: { ru: "Обработана", en: "Reviewed" }, value: "reviewed" },
      ],
    },
    {
      name: "productTitle",
      label: { ru: "Продукт", en: "Product" },
      type: "text",
      required: true,
      maxLength: 180,
      admin: readOnly,
      access: preventFieldUpdate,
    },
    {
      name: "productSlug",
      label: { ru: "Идентификатор продукта", en: "Product slug" },
      type: "text",
      required: true,
      maxLength: 100,
      admin: readOnly,
      access: preventFieldUpdate,
    },
    {
      name: "kind",
      label: { ru: "Тип заявки", en: "Request type" },
      type: "select",
      required: true,
      options: [
        { label: { ru: "Тестовый период", en: "Trial" }, value: "trial" },
        { label: { ru: "Подключение", en: "Connection" }, value: "connection" },
      ],
      admin: readOnly,
      access: preventFieldUpdate,
    },
    {
      name: "name",
      label: { ru: "Имя", en: "Name" },
      type: "text",
      required: true,
      minLength: 2,
      maxLength: 100,
      admin: readOnly,
      access: preventFieldUpdate,
    },
    {
      name: "email",
      label: "Email",
      type: "email",
      required: true,
      admin: readOnly,
      access: preventFieldUpdate,
    },
    {
      name: "message",
      label: { ru: "Комментарий", en: "Comment" },
      type: "textarea",
      maxLength: 2000,
      admin: readOnly,
      access: preventFieldUpdate,
    },
    {
      name: "locale",
      label: { ru: "Язык формы", en: "Form language" },
      type: "select",
      required: true,
      options: [
        { label: "Русский", value: "ru" },
        { label: "English", value: "en" },
      ],
      admin: readOnly,
      access: preventFieldUpdate,
    },
    {
      name: "consent",
      label: {
        ru: "Согласие на обработку данных",
        en: "Data processing consent",
      },
      type: "checkbox",
      required: true,
      admin: readOnly,
      access: preventFieldUpdate,
    },
  ],
};
