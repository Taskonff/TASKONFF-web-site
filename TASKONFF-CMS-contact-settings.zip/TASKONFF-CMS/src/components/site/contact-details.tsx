import {
  ArrowUpRight,
  Building2,
  Clock,
  Instagram,
  Linkedin,
  Mail,
  MapPin,
  Phone,
  Send,
} from "lucide-react";
import type { SiteSettings } from "@/cms/defaults";
import type { Locale } from "@/content/site";
import { contactEmailHref, contactSocialHref } from "@/lib/contact-details";
import "./contact-details.css";

const labels = {
  ru: {
    email: "Электронная почта",
    phone: "Телефон",
    city: "Город",
    address: "Адрес офиса",
    linkedInProfile: "Страница компании",
    linkedInLink: "Страница компании в LinkedIn",
    hours: "Часы ответа",
    registration: "Регистрационный номер",
  },
  en: {
    email: "Email",
    phone: "Phone",
    city: "City",
    address: "Office address",
    linkedInProfile: "Company profile",
    linkedInLink: "Company profile on LinkedIn",
    hours: "Response hours",
    registration: "Registration number",
  },
};

export function ContactDetails({
  settings,
  locale,
  className = "",
}: {
  settings: SiteSettings;
  locale: Locale;
  className?: string;
}) {
  const copy = labels[locale];
  const phone = settings.contactPhone?.replace(/[^+\d]/g, "");
  const telegram = settings.telegram;
  const instagram = contactSocialHref("instagram", settings.instagram);
  const linkedin = contactSocialHref("linkedin", settings.linkedin);
  const items = [
    {
      key: "phone",
      icon: Phone,
      label: copy.phone,
      text: settings.contactPhone,
      href: phone && /^\+?\d{5,20}$/.test(phone) ? `tel:${phone}` : undefined,
    },
    {
      key: "email",
      icon: Mail,
      label: copy.email,
      text: settings.contactEmail,
      href: contactEmailHref(settings.contactEmail),
    },
    {
      key: "telegram",
      icon: Send,
      label: "Telegram",
      text: telegram ? `@${telegram}` : undefined,
      href:
        telegram && /^[a-zA-Z][a-zA-Z0-9_]{4,31}$/.test(telegram)
          ? `https://t.me/${telegram}`
          : undefined,
    },
    {
      key: "instagram",
      icon: Instagram,
      label: "Instagram",
      text: instagram
        ? `@${new URL(instagram).pathname.split("/")[1]}`
        : undefined,
      href: instagram,
    },
    {
      key: "linkedin",
      icon: Linkedin,
      label: "LinkedIn",
      text: linkedin ? copy.linkedInProfile : undefined,
      linkName: copy.linkedInLink,
      href: linkedin,
    },
    {
      key: "city",
      icon: Building2,
      label: copy.city,
      text: settings.city?.[locale],
    },
    {
      key: "address",
      icon: MapPin,
      label: copy.address,
      text: settings.address,
    },
    {
      key: "hours",
      icon: Clock,
      label: copy.hours,
      text: settings.responseHours?.[locale],
    },
  ].filter((item) => item.text);
  if (items.length === 0) return null;
  return (
    <dl className={`public-contact-list ${className}`.trim()}>
      {items.map(({ key, icon: Icon, label, text, href, linkName }) => {
        const external = href?.startsWith("https://");
        return (
          <div className="public-contact-item" data-contact={key} key={key}>
            <dt>
              <Icon size={16} aria-hidden="true" />
              {label}
            </dt>
            <dd>
              {href ? (
                <a
                  href={href}
                  aria-label={linkName}
                  target={external ? "_blank" : undefined}
                  rel={external ? "noopener noreferrer" : undefined}
                >
                  <span>{text}</span>
                  {external && <ArrowUpRight size={14} aria-hidden="true" />}
                </a>
              ) : (
                text
              )}
            </dd>
          </div>
        );
      })}
    </dl>
  );
}

export function OrganizationDetails({
  settings,
  locale,
}: {
  settings: SiteSettings;
  locale: Locale;
}) {
  const name = settings.legalName?.[locale];
  const registration = settings.legalRegistration;
  if (!name && !registration) return null;
  return (
    <p className="public-organization">
      {name}
      {name && registration && " · "}
      {registration && `${labels[locale].registration}: ${registration}`}
    </p>
  );
}
