import Link from "next/link";
import Image from "next/image";
import {
  ArrowRight,
  FileCheck2,
  FolderOpen,
  ScanLine,
  ShieldCheck,
  Plus,
  Check,
} from "lucide-react";
import { InternalHero, PageCTA } from "@/components/site/page-primitives";
import { Reveal } from "@/components/home/reveal";
import { ProjectBrief } from "@/components/home/project-brief";
import {
  ContactDetails,
  OrganizationDetails,
} from "@/components/site/contact-details";
import { contactEmailHref, hasContactDetails } from "@/lib/contact-details";
import type { Locale } from "@/content/site";
import { getSiteData } from "@/cms/site-data";
import { PageMedia } from "@/cms/page-media";
import "./trust-pages.css";

export async function PortfolioPage({ locale }: { locale: Locale }) {
  const snapshot = await getSiteData();
  const copy = snapshot.trust[locale].portfolio;
  return (
    <main id="main" className="internal-page trust-page">
      <InternalHero
        locale={locale}
        eyebrow={copy.label}
        title={copy.title}
        description={copy.description}
      >
        <div className="trust-portfolio-art" aria-hidden="true">
          <span />
          <span />
          <span />
          <FolderOpen size={50} strokeWidth={1} />
        </div>
      </InternalHero>
      <PageMedia pageKey={"portfolio"} />
      <section className="section light-section cms-case-library">
        <div className="container">
          <div className="cms-case-grid">
            {snapshot.cases.map((entry) => (
              <article className="cms-case" key={entry.id}>
                {entry.image && (
                  <Image
                    src={entry.image.url}
                    alt={entry.image.alt}
                    width={1280}
                    height={720}
                    unoptimized
                    sizes="(max-width:640px) 100vw, 650px"
                  />
                )}
                <div>
                  <h2>{entry[locale].title}</h2>
                  <p>{entry[locale].summary}</p>
                  {entry[locale].body && (
                    <details>
                      <summary>
                        {copy.caseDetails}
                        <Plus size={17} />
                      </summary>
                      <p className="cms-case-body">{entry[locale].body}</p>
                    </details>
                  )}
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
      <PageCTA locale={locale} />
    </main>
  );
}
const offlineContactCopy = {
  ru: {
    title: "Сохранить заявку",
    details:
      "Подготовьте описание задачи и сохраните копию на своём устройстве. Передайте файл команде через согласованный канал связи.",
    data: "Форма готовит копию на вашем устройстве.",
    reply:
      "Ответ можно получить после передачи файла команде через согласованный канал связи.",
  },
  en: {
    title: "Save your request",
    details:
      "Describe your project and save a copy to your device. Share the file with the team through your agreed contact channel.",
    data: "The form prepares a copy on your device.",
    reply:
      "To receive a reply, share the file with the team through your agreed contact channel.",
  },
};

export async function ContactPage({
  locale,
  offline = process.env.CMS_STATIC_EXPORT === "1",
}: {
  locale: Locale;
  offline?: boolean;
}) {
  const snapshot = await getSiteData();
  const copy = snapshot.trust[locale].contact;
  const local = offlineContactCopy[locale];
  const hasContacts = hasContactDetails(snapshot.settings, locale);
  const faq = offline
    ? copy.faq.map(([question, answer], index) => [
        question,
        index === 1 ? local.data : index === 3 ? local.reply : answer,
      ])
    : copy.faq;
  return (
    <main id="main" className="internal-page trust-page trust-contact-page">
      <InternalHero
        locale={locale}
        eyebrow={copy.label}
        title={copy.title}
        description={copy.description}
      >
        <div className="trust-contact-art" aria-hidden="true">
          <ShieldCheck size={54} strokeWidth={1.05} />
          <span />
          <span />
        </div>
      </InternalHero>
      <section className="trust-contact-section section" id="brief">
        <div className="container trust-contact-grid">
          <div className="trust-contact-intro">
            <h2>
              {hasContacts
                ? copy.modeTitle
                : offline
                  ? local.title
                  : copy.modeTitle}
            </h2>
            <ContactDetails
              settings={snapshot.settings}
              locale={locale}
              className="contact-page-details"
            />
            <p>{offline ? local.details : copy.modeText}</p>
            <OrganizationDetails settings={snapshot.settings} locale={locale} />
          </div>
          <div className="trust-form-panel contact-form-panel">
            <ProjectBrief
              copy={snapshot.site[locale]}
              locale={locale}
              source="contact"
              offline={offline}
            />
          </div>
        </div>
      </section>
      <PageMedia pageKey="contact" />
      <section className="trust-preparation section light-section">
        <div className="container">
          <Reveal>
            <p className="eyebrow">
              <span className="eyebrow-cross">+</span>
              {copy.prepareLabel}
            </p>
            <h2>{copy.prepareTitle}</h2>
          </Reveal>
          <div className="trust-prepare-grid">
            {copy.prepare.map(([title, text], i) => (
              <Reveal key={title} delay={i * 0.06}>
                <article>
                  <span className="trust-prepare-number">0{i + 1}</span>
                  <h3>{title}</h3>
                  <p>{text}</p>
                </article>
              </Reveal>
            ))}
          </div>
          <Link className="trust-tech-link" href={`/${locale}/technologies`}>
            {copy.techLink}
            <ArrowRight size={18} />
          </Link>
        </div>
      </section>
      <section className="trust-faq-section section">
        <div className="container trust-faq-grid">
          <Reveal>
            <h2>{copy.faqTitle}</h2>
            <div className="trust-faq-illustration" aria-hidden="true">
              <ScanLine size={68} strokeWidth={0.7} />
            </div>
          </Reveal>
          <div className="trust-faq">
            {faq.map(([question, answer]) => (
              <details key={question}>
                <summary>
                  {question}
                  <Plus size={17} />
                </summary>
                <p>{answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}

const legalEdition = {
  ru: {
    updated: "Последняя редакция",
    date: "20 ноября 2026",
    contact: "Вопросы о данных",
    offlinePrivacy:
      "В этой версии формы создают текстовые файлы прямо на вашем устройстве. Сведения из форм остаются на устройстве до тех пор, пока вы сами не передадите их получателю.",
    offlineTerms:
      "Форма позволяет сохранить копию заявки на устройстве и передать её через согласованный канал. Условия проекта согласуются отдельно.",
  },
  en: {
    updated: "Last updated",
    date: "20 November 2026",
    contact: "Data privacy inquiries",
    offlinePrivacy:
      "Forms in this edition create text files on your device. The information stays on your device until you choose to share the file.",
    offlineTerms:
      "The form lets you save a copy of your request and share it through your agreed contact channel. Project terms are agreed separately.",
  },
};

const productRequestPrivacy = {
  ru: [
    "Заявки на продукты",
    "При отправке запроса по продукту мы сохраняем имя, email, название продукта, тип заявки и ваш комментарий. Форма демонстрации MedVoice AI дополнительно запрашивает организацию, должность, рабочий телефон и число филиалов при его указании. Администраторы TASKONFF используют эти данные для обработки заявки и ответа.",
  ],
  en: [
    "Product requests",
    "When you send a product request, we save your name, email address, the product, the request type and any message you provide. The MedVoice AI demo form also asks for your organisation, role, work phone and an optional branch count. TASKONFF administrators use this information to process and respond to your request.",
  ],
} as const;

export async function LegalPage({
  locale,
  kind,
  offline = process.env.CMS_STATIC_EXPORT === "1",
}: {
  locale: Locale;
  kind: "privacy" | "terms";
  offline?: boolean;
}) {
  const snapshot = await getSiteData();
  const copy = snapshot.trust[locale].legal;
  const page = copy[kind];
  const edition = legalEdition[locale];
  const privacyEmail = snapshot.settings.privacyEmail;
  const privacyContact = contactEmailHref(privacyEmail);
  const sections = offline
    ? page.sections.map(([title, text], index) => [
        title,
        kind === "privacy" && (index === 1 || index === 2)
          ? edition.offlinePrivacy
          : kind === "terms" && index === 2
            ? edition.offlineTerms
            : text,
      ])
    : kind === "privacy"
      ? [...page.sections, productRequestPrivacy[locale]]
      : page.sections;
  return (
    <main id="main" className="internal-page trust-page">
      <InternalHero
        locale={locale}
        eyebrow={page.label}
        title={page.title}
        description={page.description}
      >
        <div className="trust-legal-art" aria-hidden="true">
          <ShieldCheck size={70} strokeWidth={0.8} />
          <span />
          <span />
        </div>
      </InternalHero>
      <PageMedia pageKey={kind} />
      <section className="trust-legal-section light-section">
        <div className="container">
          <aside className="trust-draft-note" role="note">
            <FileCheck2 size={25} strokeWidth={1.4} />
            <div>
              <strong>{copy.draftLabel}</strong>
              <p>{copy.draftText}</p>
            </div>
          </aside>
          <div className="trust-legal-edition">
            <p>
              {edition.updated}{" "}
              <time dateTime="2026-11-20">{edition.date}</time>
            </p>
            <OrganizationDetails settings={snapshot.settings} locale={locale} />
            {privacyContact && (
              <p>
                {edition.contact} <a href={privacyContact}>{privacyEmail}</a>
              </p>
            )}
          </div>
          <div className="trust-legal-grid">
            <nav className="trust-legal-contents" aria-label={copy.contents}>
              <p>{copy.contents}</p>
              {sections.map(([title], i) => (
                <a key={title} href={`#legal-section-${i + 1}`}>
                  <span>0{i + 1}</span>
                  {title}
                </a>
              ))}
            </nav>
            <div className="trust-legal-body">
              {sections.map(([title, text], i) => (
                <Reveal key={title}>
                  <section id={`legal-section-${i + 1}`}>
                    <span>0{i + 1}</span>
                    <h2>{title}</h2>
                    <p>{text}</p>
                  </section>
                </Reveal>
              ))}
              <Link className="trust-legal-back" href={`/${locale}/contact`}>
                {copy.backContact}
                <ArrowRight size={18} />
              </Link>
              <p className="trust-document-state">
                <Check size={14} />
                {copy.documentState}
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
