#!/bin/sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  exec python3 preview.py "$@"
fi
printf '%s\n' 'Install Python 3 from https://www.python.org/ and run python3 preview.py.'
exit 1
