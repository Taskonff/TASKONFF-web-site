#!/usr/bin/env python3
"""Local HTTP preview for the TASKONFF HTML snapshot. Requires Python 3."""
import argparse
import functools
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import threading
import webbrowser

class Handler(SimpleHTTPRequestHandler):
    def guess_type(self, filename):
        name = Path(filename).name
        if name == "index.txt" or (name.startswith("__next.") and name.endswith(".txt")):
            return "text/x-component"
        return super().guess_type(filename)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--port", type=int, default=4173)
parser.add_argument("--no-browser", action="store_true")
args = parser.parse_args()
root = Path(__file__).resolve().parent
handler = functools.partial(Handler, directory=str(root))
try:
    server = ThreadingHTTPServer(("127.0.0.1", args.port), handler)
except OSError as error:
    raise SystemExit(f"Cannot start preview: {error}. Try --port 4174.")
url = f"http://127.0.0.1:{server.server_port}/ru/"
print(f"TASKONFF preview: {url} (Ctrl+C to stop)", flush=True)
if not args.no_browser:
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
