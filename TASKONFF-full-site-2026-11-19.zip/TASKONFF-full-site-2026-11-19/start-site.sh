#!/bin/sh
cd "$(dirname "$0")/source" || exit 1
exec sh start-cms.sh
