import { test, expect } from "@playwright/test";

for (const locale of ["ru", "en"] as const) {
  for (const width of [390, 1440]) {
    test(`${locale} corporate navigation and industry scenarios at ${width}px`, async ({
      page,
    }) => {
      await page.setViewportSize({ width, height: 1000 });
      await page.emulateMedia({ reducedMotion: "reduce" });
      const errors: string[] = [];
      page.on("pageerror", (error) => errors.push(error.message));
      await page.goto(`/${locale}`);

      if (width === 1440) {
        const toggle = page.locator(".corporate-services-toggle");
        const directory = page.locator("#corporate-service-directory");
        await toggle.focus();
        await toggle.press("ArrowDown");
        await expect(toggle).toHaveAttribute("aria-expanded", "true");
        await expect(directory).toBeVisible();
        await expect(directory.getByRole("link").first()).toBeFocused();
        await expect(
          directory.locator(".corporate-directory-group a"),
        ).toHaveCount(10);
        await page.keyboard.press("Escape");
        await expect(directory).toBeHidden();
        await expect(toggle).toBeFocused();

        await toggle.click();
        const service = directory
          .locator(".corporate-directory-group a")
          .first();
        const href = await service.getAttribute("href");
        expect(href).toMatch(new RegExp(`^/${locale}/services/`));
        await service.click();
        await expect(page).toHaveURL(new RegExp(`${href}$`));
        await expect(toggle).toHaveAttribute("aria-expanded", "false");
        await expect(directory).toBeHidden();
      } else {
        const toggle = page.locator(".menu-toggle");
        const directory = page.locator("#mobile-nav");
        await toggle.click();
        await expect(toggle).toHaveAttribute("aria-expanded", "true");
        await directory.locator(".corporate-mobile-services summary").click();
        const services = directory.locator(".corporate-mobile-services a");
        await expect(services).toHaveCount(10);
        const href = await services.first().getAttribute("href");
        expect(href).toMatch(new RegExp(`^/${locale}/services/`));
        await services.first().click();
        await expect(page).toHaveURL(new RegExp(`${href}$`));
        await expect(toggle).toHaveAttribute("aria-expanded", "false");
        await expect(directory).toBeHidden();
      }

      await page.goto(`/${locale}`);
      const industries = page.locator(".industry-spotlight");
      const tabs = industries.getByRole("tab");
      const panel = industries.getByRole("tabpanel");
      await expect(tabs).toHaveCount(6);
      const headings = new Set<string>();
      for (let index = 0; index < 6; index++) {
        const tab = tabs.nth(index);
        await tab.click();
        await expect(tab).toHaveAttribute("aria-selected", "true");
        await expect(panel).toHaveAttribute(
          "aria-labelledby",
          (await tab.getAttribute("id"))!,
        );
        await expect(panel).toHaveAttribute(
          "id",
          (await tab.getAttribute("aria-controls"))!,
        );
        await expect(panel.getByRole("heading", { level: 3 })).toBeVisible();
        headings.add(
          await panel.getByRole("heading", { level: 3 }).innerText(),
        );
        await expect(panel.getByRole("listitem")).toHaveCount(3);
        expect(
          await page.evaluate(
            () => document.documentElement.scrollWidth <= innerWidth,
          ),
        ).toBe(true);
      }
      expect(headings.size).toBe(6);
      await tabs.last().press("Home");
      await expect(tabs.first()).toBeFocused();
      await expect(tabs.first()).toHaveAttribute("aria-selected", "true");
      await tabs.first().press("End");
      await expect(tabs.last()).toBeFocused();
      await tabs.last().press("ArrowDown");
      await expect(tabs.first()).toBeFocused();
      await expect(tabs.first()).toHaveAttribute("aria-selected", "true");
      await industries.locator(".industry-spotlight-intro a").click();
      await expect(page).toHaveURL(new RegExp(`/${locale}/industries$`));
      expect(errors).toEqual([]);
    });
  }
}
