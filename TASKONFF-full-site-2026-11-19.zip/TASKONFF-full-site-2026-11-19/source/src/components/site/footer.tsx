import { getSiteData } from "@/cms/site-data";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { BrandLogo } from "@/components/brand-logo";
import { type Locale } from "@/content/site";
import { pageSlugs } from "@/lib/routes";
import "./corporate-footer.css";
export async function Footer({
  locale,
  logo,
}: {
  locale: Locale;
  logo?: string;
}) {
  const data = await getSiteData();
  const copy = data.site[locale];
  const pageNames = {
    ru: data.shared.ru.navigation,
    en: data.shared.en.navigation,
  };
  const brandName = data.settings.brandName || "TASKONFF";
  return (
    <footer className="footer site-footer corporate-footer">
      <div className="container">
        <div className="footer-directory">
          <div className="footer-brand">
            <Link
              href={`/${locale}`}
              className="company-name"
              aria-label={brandName}
            >
              <BrandLogo src={logo} name={brandName} />
            </Link>
            <p>{copy.footer}</p>
            <span>{data.shared[locale].brandTagline}</span>
            {(data.settings.contactEmail || data.settings.contactPhone) && (
              <div className="footer-contacts">
                {data.settings.contactEmail && (
                  <a href={`mailto:${data.settings.contactEmail}`}>
                    {data.settings.contactEmail}
                  </a>
                )}
                {data.settings.contactPhone && (
                  <a
                    href={`tel:${data.settings.contactPhone.replace(/[^\d+]/g, "")}`}
                  >
                    {data.settings.contactPhone}
                  </a>
                )}
              </div>
            )}
          </div>
          <nav
            aria-label={locale === "ru" ? "Разделы сайта" : "Site directory"}
            className="footer-page-links"
          >
            <p className="footer-directory-heading">{copy.menu}</p>
            {pageSlugs
              .filter((s) => s !== "privacy" && s !== "terms")
              .map((slug) => (
                <Link key={slug} href={`/${locale}/${slug}`}>
                  {pageNames[locale][slug]}
                  <ArrowUpRight size={12} />
                </Link>
              ))}
          </nav>
          <nav
            aria-label={pageNames[locale].services}
            className="footer-services"
          >
            <p className="footer-directory-heading">
              {pageNames[locale].services}
            </p>
            <div>
              {data.services.map((service) => (
                <Link
                  key={service.slug}
                  href={`/${locale}/services/${service.slug}`}
                >
                  {service[locale].title}
                </Link>
              ))}
            </div>
          </nav>
        </div>
        <div className="footer-bottom">
          <span>
            © {new Date().getFullYear()} {brandName}. {copy.rights}
          </span>
          <nav
            aria-label={
              locale === "ru" ? "Правовая информация" : "Legal information"
            }
          >
            <Link href={`/${locale}/privacy`}>{pageNames[locale].privacy}</Link>
            <Link href={`/${locale}/terms`}>{pageNames[locale].terms}</Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}
