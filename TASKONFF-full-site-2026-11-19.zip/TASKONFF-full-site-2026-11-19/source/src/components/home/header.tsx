"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  ChevronDown,
  Code2,
  Cpu,
  Layers3,
  Menu,
  PenTool,
  X,
} from "lucide-react";
import { useSiteContent } from "@/cms/site-context";
import { BrandLogo } from "@/components/brand-logo";
import { Button } from "@/components/ui/button";
import type { Locale, SiteContent } from "@/content/site";
import type { ServiceGroup } from "@/content/services";
import type { PageSlug } from "@/lib/routes";
import "./corporate-header.css";

const desktopPages: PageSlug[] = [
  "about",
  "services",
  "industries",
  "portfolio",
  "technologies",
  "process",
];
const serviceGroups: ServiceGroup[] = [
  "build",
  "automate",
  "operate",
  "design",
];
const groupIcons = {
  build: Code2,
  automate: Cpu,
  operate: Layers3,
  design: PenTool,
};

export function Header({
  locale,
  copy,
  logo,
}: {
  locale: Locale;
  copy: SiteContent;
  logo?: string;
}) {
  const data = useSiteContent();
  const pageNames = data.shared[locale].navigation;
  const shared = data.shared[locale];
  const brandName = data.settings.brandName || "TASKONFF";
  const pathname = usePathname();
  const [expanded, setExpanded] = useState<"mobile" | "services" | null>(null);
  const header = useRef<HTMLElement>(null);
  const menu = useRef<HTMLButtonElement>(null);
  const servicesToggle = useRef<HTMLButtonElement>(null);
  const serviceDirectory = useRef<HTMLDivElement>(null);
  const other = locale === "ru" ? "en" : "ru";
  const languagePath = pathname.replace(/^\/(ru|en)(?=\/|$)/, `/${other}`);
  const mobileOpen = expanded === "mobile";
  const servicesOpen = expanded === "services";
  const close = () => setExpanded(null);
  const active = (slug: string) =>
    pathname === `/${locale}/${slug}` ||
    pathname.startsWith(`/${locale}/${slug}/`);

  useEffect(() => {
    if (!expanded) return;
    function outside(event: PointerEvent) {
      if (
        event.target instanceof Node &&
        !header.current?.contains(event.target)
      )
        setExpanded(null);
    }
    const breakpoint = window.matchMedia("(max-width: 1100px)");
    const resized = () => setExpanded(null);
    document.addEventListener("pointerdown", outside);
    window.addEventListener("popstate", resized);
    breakpoint.addEventListener("change", resized);
    return () => {
      document.removeEventListener("pointerdown", outside);
      window.removeEventListener("popstate", resized);
      breakpoint.removeEventListener("change", resized);
    };
  }, [expanded]);

  return (
    <>
      <a className="skip-link" href="#main">
        {copy.skip}
      </a>
      <header
        ref={header}
        className="header site-header corporate-header"
        onBlur={(event) => {
          if (
            event.relatedTarget instanceof Node &&
            !event.currentTarget.contains(event.relatedTarget)
          )
            close();
        }}
        onKeyDown={(event) => {
          if (event.key === "Escape" && expanded) {
            event.preventDefault();
            close();
            (mobileOpen ? menu : servicesToggle).current?.focus();
          }
        }}
      >
        <div className="container header-inner">
          <Link
            className="company-name corporate-brand"
            href={`/${locale}`}
            aria-label={brandName}
            onClick={close}
          >
            <BrandLogo src={logo} name={brandName} />
            <span className="corporate-brand-tagline">
              {shared.brandTagline}
            </span>
          </Link>
          <nav
            className="desktop-nav"
            aria-label={
              locale === "ru" ? "Основная навигация" : "Main navigation"
            }
          >
            {desktopPages.map((slug) => (
              <div className="corporate-nav-item" key={slug}>
                <Link
                  href={`/${locale}/${slug}`}
                  aria-current={active(slug) ? "page" : undefined}
                  onClick={close}
                >
                  {pageNames[slug]}
                </Link>
                {slug === "services" && (
                  <button
                    ref={servicesToggle}
                    type="button"
                    className="corporate-services-toggle"
                    aria-label={
                      locale === "ru"
                        ? "Показать направления услуг"
                        : "Show service categories"
                    }
                    aria-expanded={servicesOpen}
                    aria-controls="corporate-service-directory"
                    onClick={() =>
                      setExpanded(servicesOpen ? null : "services")
                    }
                    onKeyDown={(event) => {
                      if (event.key !== "ArrowDown" && event.key !== "ArrowUp")
                        return;
                      event.preventDefault();
                      const last = event.key === "ArrowUp";
                      setExpanded("services");
                      requestAnimationFrame(() => {
                        const links =
                          serviceDirectory.current?.querySelectorAll<HTMLAnchorElement>(
                            "a",
                          );
                        if (links?.length)
                          links[last ? links.length - 1 : 0].focus();
                      });
                    }}
                  >
                    <ChevronDown size={14} aria-hidden="true" />
                  </button>
                )}
              </div>
            ))}
          </nav>
          <div className="header-actions">
            <Link
              className="language"
              href={languagePath}
              aria-label={copy.language}
              onClick={close}
            >
              {other.toUpperCase()}
              <ArrowUpRight size={11} aria-hidden="true" />
            </Link>
            <Button asChild variant="outline" size="sm" className="header-cta">
              <Link href={`/${locale}/contact`} onClick={close}>
                {copy.talk}
                <ArrowUpRight size={15} aria-hidden="true" />
              </Link>
            </Button>
            <button
              ref={menu}
              type="button"
              className="menu-toggle"
              aria-label={mobileOpen ? copy.close : copy.menu}
              aria-expanded={mobileOpen}
              aria-controls="mobile-nav"
              onClick={() => setExpanded(mobileOpen ? null : "mobile")}
            >
              {mobileOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        <button
          type="button"
          className="corporate-nav-backdrop"
          aria-label={copy.close}
          tabIndex={-1}
          hidden={!expanded}
          onClick={close}
        />

        <div
          ref={serviceDirectory}
          id="corporate-service-directory"
          className="corporate-service-directory"
          hidden={!servicesOpen}
        >
          <div className="container corporate-directory-grid">
            <div className="corporate-directory-intro">
              <span>{copy.expertise}</span>
              <h2>{shared.cta.title}</h2>
              <p>{copy.servicesIntro}</p>
              <Link href={`/${locale}/services`} onClick={close}>
                {data.home[locale].sections.allServices}
                <ArrowRight size={16} aria-hidden="true" />
              </Link>
            </div>
            {serviceGroups.map((group, index) => {
              const Icon = groupIcons[group];
              return (
                <section className="corporate-directory-group" key={group}>
                  <div className="corporate-directory-icon" aria-hidden="true">
                    <Icon size={23} strokeWidth={1.5} />
                    <span>0{index + 1}</span>
                  </div>
                  <h3>{data.groups[locale][group]}</h3>
                  <ul>
                    {data.services
                      .filter((service) => service.group === group)
                      .map((service) => (
                        <li key={service.slug}>
                          <Link
                            href={`/${locale}/services/${service.slug}`}
                            onClick={close}
                          >
                            <span>{service[locale].title}</span>
                            <ArrowUpRight size={13} aria-hidden="true" />
                          </Link>
                        </li>
                      ))}
                  </ul>
                </section>
              );
            })}
          </div>
          <div className="corporate-directory-bottom">
            <div className="container">
              <span>{shared.brandTagline}</span>
              <Link href={`/${locale}/contact`} onClick={close}>
                {shared.cta.button}
                <ArrowUpRight size={15} aria-hidden="true" />
              </Link>
            </div>
          </div>
        </div>

        <nav
          id="mobile-nav"
          hidden={!mobileOpen}
          className="mobile-nav"
          aria-label={copy.menu}
        >
          <Link href={`/${locale}`} onClick={close}>
            {shared.homeLabel}
            <ArrowUpRight size={16} aria-hidden="true" />
          </Link>
          {[...desktopPages, "contact" as const].map((slug) => (
            <Link
              key={slug}
              href={`/${locale}/${slug}`}
              onClick={close}
              aria-current={active(slug) ? "page" : undefined}
            >
              {pageNames[slug]}
              <ArrowUpRight size={16} aria-hidden="true" />
            </Link>
          ))}
          <details className="corporate-mobile-services">
            <summary>
              {data.home[locale].sections.allServices}
              <ChevronDown size={16} aria-hidden="true" />
            </summary>
            <div>
              {serviceGroups.map((group) => (
                <section key={group}>
                  <h3>{data.groups[locale][group]}</h3>
                  {data.services
                    .filter((service) => service.group === group)
                    .map((service) => (
                      <Link
                        href={`/${locale}/services/${service.slug}`}
                        key={service.slug}
                        onClick={close}
                      >
                        {service[locale].title}
                        <ArrowUpRight size={13} aria-hidden="true" />
                      </Link>
                    ))}
                </section>
              ))}
            </div>
          </details>
        </nav>
      </header>
    </>
  );
}
