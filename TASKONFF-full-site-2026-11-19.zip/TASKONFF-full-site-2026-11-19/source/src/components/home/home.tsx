import Link from "next/link";
import Image from "next/image";
import {
  ArrowDown,
  ArrowUpRight,
  ArrowRight,
  Plus,
  Braces,
  Layers3,
  Orbit,
  Workflow,
  Check,
} from "lucide-react";
import { Reveal } from "./reveal";
import { DigitalEngine } from "./digital-engine";
import { ServiceGrid } from "./service-grid";
import { SolutionExplorer } from "./solution-explorer";
import { CapabilityStrip } from "./experience";
import { ProjectBrief } from "./project-brief";
import { Button } from "@/components/ui/button";
import { getSiteData } from "@/cms/site-data";
import { PageMedia } from "@/cms/page-media";
import { IndustrySpotlight } from "./industry-spotlight";
import "./corporate-home.css";
import type { Locale, SiteContent } from "@/content/site";

export async function Home({ locale }: { locale: Locale; copy?: SiteContent }) {
  const data = await getSiteData();
  const copy = data.site[locale];
  const h = data.home[locale];
  const company = data.company[locale].about;
  const quickGroups = ["build", "automate", "operate"] as const;
  const quickRoutes = ["custom-software", "business-automation", "crm-erp"];
  return (
    <main id="main" className="corporate-home">
      <section className="hero" id="top">
        <div className="hero-grid-bg" aria-hidden="true" />
        <div className="container hero-topline">
          <span>
            <i />
            {h.hero.eyebrow}
          </span>
          <span>{h.hero.signature}</span>
        </div>
        <div className="container hero-grid">
          <div className="hero-content">
            <Reveal>
              <p className="hero-kicker">{h.hero.kicker}</p>
              <h1>
                {h.hero.titleFirst}
                <br />
                <span className="hero-title-middle">{h.hero.titleOutline}</span>
                <br />
                <span className="gradient-text">{h.hero.titleAccent}</span>
              </h1>
              <p className="hero-intro">{h.hero.intro}</p>
              <div className="hero-buttons">
                <Button asChild>
                  <a href="#contact">
                    {copy.primary}
                    <span>
                      <ArrowUpRight size={19} />
                    </span>
                  </a>
                </Button>
                <a className="hero-explore" href="#solutions">
                  {h.hero.explore}
                  <ArrowDown size={16} />
                </a>
              </div>
            </Reveal>
          </div>
          <div className="hero-visual">
            <DigitalEngine locale={locale} />
            <div className="visual-tag tag-product">
              <span className="tag-icon">
                <Braces size={16} />
              </span>
              <div>
                {h.visual.product}
                <small>{h.visual.productTypes}</small>
              </div>
            </div>
            <div className="visual-tag tag-ai">
              <span className="tag-icon">
                <Orbit size={16} />
              </span>
              <div>
                {h.visual.intelligence}
                <small>{h.visual.intelligenceTypes}</small>
              </div>
            </div>
          </div>
        </div>
        <div className="container hero-bottom">
          <a href="#expertise">
            <span className="scroll-mouse">
              <i />
            </span>
            {copy.scroll}
          </a>
          <span className="hero-bottom-note">
            {h.hero.bottomNote}
            <ArrowUpRight size={14} />
          </span>
        </div>
        <div className="container hero-shortcuts">
          {quickGroups.map((group, index) => (
            <Link
              key={group}
              href={`/${locale}/services/${quickRoutes[index]}`}
            >
              <span className="hero-shortcut-index">0{index + 1}</span>
              <span>{data.groups[locale][group]}</span>
              <ArrowUpRight size={22} strokeWidth={1.5} />
            </Link>
          ))}
        </div>
      </section>
      <PageMedia pageKey="home" />
      <CapabilityStrip locale={locale} />
      <section className="expertise light-section section" id="expertise">
        <div className="container">
          <Reveal>
            <div className="section-topline">
              <p className="eyebrow">
                <span className="eyebrow-cross">+</span>
                {copy.expertise}
              </p>
              <span className="section-number">
                {h.sections.expertiseIndex}
              </span>
            </div>
            <div className="section-heading">
              <h2>
                {h.sections.expertiseTitle}
                <br />
                <span>{h.sections.expertiseAccent}</span>
              </h2>
              <p>{copy.servicesIntro}</p>
            </div>
          </Reveal>
          <ServiceGrid copy={copy} locale={locale} />
          <div className="home-page-link">
            <Link href={`/${locale}/services`}>
              {h.sections.allServices}
              <ArrowUpRight size={18} />
            </Link>
          </div>
        </div>
      </section>
      <SolutionExplorer locale={locale} />
      <IndustrySpotlight locale={locale} />
      {data.cases.length > 0 && (
        <section className="section home-cases light-section">
          <div className="container">
            <Reveal>
              <p className="eyebrow">{data.trust[locale].portfolio.label}</p>
              <div className="section-heading">
                <h2>{data.trust[locale].portfolio.title}</h2>
                <Link
                  className="corporate-text-link"
                  href={`/${locale}/portfolio`}
                >
                  {data.shared[locale].navigation.portfolio}
                  <ArrowUpRight size={19} />
                </Link>
              </div>
            </Reveal>
            <div className="home-case-grid">
              {data.cases.slice(0, 3).map((entry) => (
                <Link key={entry.id} href={`/${locale}/portfolio`}>
                  {entry.image && (
                    <Image
                      src={entry.image.url}
                      alt={entry.image.alt}
                      width={960}
                      height={540}
                      unoptimized
                    />
                  )}
                  <h3>{entry[locale].title}</h3>
                  <p>{entry[locale].summary}</p>
                  <ArrowUpRight size={22} />
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
      <section className="approach light-section section" id="approach">
        <div className="container">
          <Reveal>
            <div className="section-topline">
              <p className="eyebrow">
                <span className="eyebrow-cross">+</span>
                {copy.aboutLabel}
              </p>
              <span className="section-number">{h.sections.approachIndex}</span>
            </div>
            <div className="manifesto">
              <h2>
                {h.manifesto.lead}{" "}
                <span className="manifesto-blue">{h.manifesto.accent}</span>
                <br />
                {h.manifesto.secondLine}
                <br />
                {h.manifesto.thirdLine}
                <span className="manifesto-dot">{h.manifesto.punctuation}</span>
              </h2>
              <div className="manifesto-note">
                <p>{copy.aboutText}</p>
                <Link className="corporate-text-link" href={`/${locale}/about`}>
                  {data.shared[locale].navigation.about}
                  <ArrowUpRight size={20} />
                </Link>
              </div>
            </div>
          </Reveal>
          <div className="home-principles">
            {company.principles.map(([title, text], index) => (
              <Reveal key={index} delay={index * 0.05}>
                <article>
                  <Check size={20} strokeWidth={1.5} />
                  <h3>{title}</h3>
                  <p>{text}</p>
                </article>
              </Reveal>
            ))}
          </div>
          <div className="process-heading">
            <h3>{copy.processTitle}</h3>
            <span>{copy.processLabel}</span>
          </div>
          <div className="process-more">
            <Link className="corporate-text-link" href={`/${locale}/process`}>
              {company.processLink}
              <ArrowUpRight size={20} />
            </Link>
          </div>
          <div className="process-grid">
            {copy.process.map(([title, description], i) => (
              <Reveal key={i} delay={i * 0.08}>
                <article className="process-step">
                  <div className="step-track">
                    <span>0{i + 1}</span>
                    <ArrowRight size={18} />
                  </div>
                  <h4>{title}</h4>
                  <p>{description}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="technologies section" id="technologies">
        <div className="container tech-grid">
          <Reveal>
            <p className="eyebrow">
              <span className="eyebrow-cross">+</span>
              {copy.techLabel}
            </p>
            <h2>
              {h.technology.title}
              <br />
              <span className="gradient-text">{h.technology.accent}</span>
            </h2>
            <p className="tech-description">{copy.techText}</p>
            <a href="#contact" className="text-link">
              {h.technology.action}
              <ArrowUpRight size={18} />
            </a>
            <Link
              className="tech-directory-link"
              href={`/${locale}/technologies`}
            >
              {data.shared[locale].navigation.technologies}
              <ArrowRight size={18} />
            </Link>
          </Reveal>
          <Reveal className="tech-panel">
            <div className="tech-panel-heading">
              <span>{copy.techCaption}</span>
              <span aria-hidden="true">
                <Plus size={16} />
              </span>
            </div>
            <div className="tech-core">
              <div className="tech-core-icon">
                <Layers3 size={32} strokeWidth={1.2} />
              </div>
              <span>{h.technology.connected}</span>
            </div>
            <div className="tech-list">
              {h.technology.items.map((item, i) => (
                <div key={i}>
                  <span className="tech-symbol">{item.symbol}</span>
                  <span>{item.name}</span>
                  <i />
                </div>
              ))}
            </div>
            <div className="tech-panel-footer">
              <Workflow size={14} />
              <span>{h.technology.footer}</span>
            </div>
          </Reveal>
        </div>
      </section>
      <section className="contact section" id="contact">
        <div className="container contact-layout">
          <div className="contact-copy">
            <Reveal>
              <p className="eyebrow">
                <span className="eyebrow-cross">+</span>
                {copy.contactLabel}
              </p>
              <h2>
                {h.contact.title}
                <br />
                <span>{h.contact.accent}</span>
              </h2>
            </Reveal>
            <div className="contact-aside">
              <p>{copy.contactText}</p>
              <span className="contact-local-label">
                <span />
                {h.contact.briefHint}
              </span>
              <div className="contact-lines" aria-hidden="true">
                <i />
                <i />
                <i />
              </div>
            </div>
          </div>
          <Reveal className="contact-form-panel">
            <div className="contact-form-heading">
              <span>{h.contact.briefHint}</span>
              <ArrowUpRight size={24} strokeWidth={1.4} />
            </div>
            <ProjectBrief copy={copy} locale={locale} />
          </Reveal>
        </div>
      </section>
    </main>
  );
}
