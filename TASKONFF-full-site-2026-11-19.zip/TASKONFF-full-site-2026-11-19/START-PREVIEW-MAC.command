#!/bin/sh
cd "$(dirname "$0")/html-preview" || exit 1
exec sh preview.sh
