@echo off
call "%~dp0source\START-CMS-WINDOWS.bat"
